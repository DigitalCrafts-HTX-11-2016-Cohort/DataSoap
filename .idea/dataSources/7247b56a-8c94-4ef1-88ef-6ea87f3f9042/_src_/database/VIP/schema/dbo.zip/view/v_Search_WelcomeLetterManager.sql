CREATE VIEW v_Search_WelcomeLetterManager AS
	SELECT  
		a.VIP_WelcomeLetterManagerID ,
		a.VIP_ProductBundleID ,
		a.VIP_UtilityID ,
		a.VIP_AccountClassID ,
		a.VIP_MarketerCodeID ,
		a.Spanish ,
		a.WelcomeLetterFileName ,
		ISNULL(b.code, '*') Utility ,
		ISNULL(c.code, '*') AccountClass ,
		ISNULL(d.Code, '*') Marketer ,
		ISNULL(e.Code, '*') ProductBundleName ,
		'True' SetOtherControls ,
		'True' SetProductBundleOn ,
		a.TemplateType ,
		a.EmailAttachmentFile_1 ,
		a.EmailAttachmentFile_2 ,
		a.EmailAttachmentFile_3 ,
		a.EmailAttachmentFile_4 ,
		a.EmailAttachmentFile_5,
		UtilityCode = b.Code
	FROM    
		VIP_WelcomeLetterManager a
		LEFT OUTER JOIN VIP_Utilities b ON a.VIP_UtilityID = b.VIP_UtilityID
		LEFT OUTER JOIN VIP_AccountClasses c ON a.VIP_AccountClassID = c.VIP_AccountClassID
		LEFT OUTER JOIN VIP_Marketers d ON a.VIP_MarketerCodeID = d.VIP_MarketerID
		LEFT OUTER JOIN VIP_ProductBundles e ON a.VIP_ProductBundleID = e.VIP_ProductBundleID


GO
