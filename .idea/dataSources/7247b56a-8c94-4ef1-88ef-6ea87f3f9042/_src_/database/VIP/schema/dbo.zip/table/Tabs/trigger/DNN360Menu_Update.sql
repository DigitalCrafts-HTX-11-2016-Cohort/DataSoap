 
 CREATE TRIGGER DNN360Menu_Update ON  dbo.Tabs 
FOR UPDATE 
AS

   DECLARE @PortalID int
   

   SET @PortalID = (SELECT PortalID FROM Deleted)
   
 
   
Delete from dbo.MCISS_MenuUpdate where PortalID= @PortalID
Insert into dbo.MCISS_MenuUpdate (lastupdate,portalID) values (getdate(),@PortalID)


SET QUOTED_IDENTIFIER OFF
 GO
