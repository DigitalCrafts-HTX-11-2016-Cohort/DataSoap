
CREATE PROCEDURE dbo.[GetPortal]

	@PortalID  int

AS
SELECT *
FROM dbo.vw_Portals
WHERE PortalId = @PortalID

GO
