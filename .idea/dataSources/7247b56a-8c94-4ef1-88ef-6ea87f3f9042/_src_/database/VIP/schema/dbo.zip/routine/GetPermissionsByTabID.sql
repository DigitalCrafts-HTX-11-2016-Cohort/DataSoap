
CREATE PROCEDURE dbo.GetPermissionsByTabID
	@TabID int
AS

SELECT  PermissionID,
	PermissionCode,
	PermissionKey,
	ModuleDefID,
	PermissionName
FROM    dbo.Permission
WHERE   PermissionCode = 'SYSTEM_TAB'
ORDER BY PermissionID

GO
