CREATE Procedure [dbo].[usp_VIP_SearchAccounts]

	@SearchCriteria varchar(100), @Utility varchar(10),@AccountClassName varchar(20), @AccountStatus varchar(20), @sort int, @CoreCustomer varchar(2)
As

IF @CoreCustomer = '-1'
BEGIN
   Select @CoreCustomer = ''
END

Select
	VIP_AccountID,
	CompanyName,
	ServiceFirstName,
	ServiceLastName,
	ServiceFirstName + ' ' + ServiceLastName ServiceContact,
	ServiceAddress1,
	ServiceAddress2,
	ServiceCity,
	ServiceState,
	VIP_Utilities.Code UtilityName,
	UtilityAccountNumber,
	UtilityServiceAccountID,
	RetailerAccountNumber,
	ServiceZipCode,
	ServicePhone,	
	ServiceAddress1 + ' ' + ServiceAddress2 as Address,
	ServiceCity + ', ' +	ServiceState + ' ' + ServiceZipCode as CityStateZip,
	VIP_AccountClasses.Name as AccountClassName,
	AccountStatus,	DateSold,
	case UtilityServiceAccountID 
		when '' then UtilityAccountNumber
		else UtilityServiceAccountID
	end as ServiceAccountID,
	case
		when vip_accounts.CoreCustomer = 0 then 'Non Core Account'
		when vip_accounts.CoreCustomer = 1 then 'Core Account'
	end as CoreCustomer,
	CASE
		WHEN @sort = 1 THEN (RANK() OVER (ORDER BY UtilityServiceAccountID))
		WHEN @sort = 2 THEN (RANK() OVER (ORDER BY UtilityAccountNumber))
		WHEN @sort = 3 THEN (RANK() OVER (ORDER BY CompanyName))
		WHEN @sort = 4 THEN (RANK() OVER (ORDER BY ServiceLastName))
		WHEN @sort = 5 THEN (RANK() OVER (ORDER BY VIP_AccountClasses.Name))			
		WHEN @sort = 6 THEN (RANK() OVER (ORDER BY AccountStatus))
		WHEN @sort = 7 THEN (RANK() OVER (ORDER BY VIP_Utilities.Code))
		WHEN @sort = 8 THEN (RANK() OVER (ORDER BY vip_accounts.CoreCustomer DESC))
		WHEN @sort = 9 THEN (RANK() OVER (ORDER BY vip_accounts.DateSold))		
	END AS RankNumber	
From
	VIP_Accounts 
	Inner Join VIP_Utilities On VIP_Accounts.VIP_UtilityID = VIP_Utilities.VIP_UtilityID
	Inner Join VIP_AccountClasses on VIP_AccountClasses.VIP_AccountClassID = VIP_Accounts.VIP_AccountClassID
Where

	(ServiceFirstName like @SearchCriteria + '%'
	Or ServiceLastName like @SearchCriteria + '%'	
	Or ServiceAddress1 like @SearchCriteria + '%'
	Or ServiceAddress2 like @SearchCriteria + '%'
	Or ServiceCity like @SearchCriteria + '%'
	Or ServiceState like @SearchCriteria + '%'
	Or VIP_Utilities.Name like @SearchCriteria + '%'
	Or UtilityAccountNumber like '%' + @SearchCriteria + '%'
	Or RetailerAccountNumber like '%' + @SearchCriteria + '%'
	Or UtilityServiceAccountID like @SearchCriteria + '%'
	Or CompanyName like @SearchCriteria + '%'
	Or ServiceZipCode like @SearchCriteria + '%'
	Or ServicePhone like @SearchCriteria + '%')	
	and VIP_Utilities.Code like @Utility + '%'
	and VIP_AccountClasses.Name like @AccountClassName	+ '%'
	and AccountStatus like @AccountStatus + '%'
	and convert(varchar(1), vip_accounts.corecustomer) like @CoreCustomer + '%'				
order by RankNumber


GO
