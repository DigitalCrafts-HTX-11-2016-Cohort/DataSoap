-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	retrievs all dual account contracts that expiring within 60 days
-- =============================================
CREATE PROCEDURE [dbo].[usp_VIP_GetAccountExpiration]	
AS
Select *,
case when a.DifferenceDays between 0 and 10 then '1'
	 when a.DifferenceDays between 11 and 20 then '2'
	 when a.DifferenceDays between 21 and 31 then '3'	 
	 else 'Yellow' end Colors
 from
(
	Select UtilityAccountNumber, UtilityServiceAccountID, 
	AccountStatus, util.code,
	CONVERT(varchar(10), getdate(), 101) CurrentDate,
	CONVERT(varchar(10), cont.EndDate, 101) EndDate,
	datediff(d,CONVERT(varchar(10), getdate(), 101), cont.EndDate)  DifferenceDays,
	acct.VIP_AccountID,
	case when acct.CompanyName is null then acct.ServiceFirstName + ' ' + acct.ServiceLastName else acct.CompanyName end CompanyName
	from VIP_Accounts acct
	inner join VIP_Contracts cont on cont.VIP_ContractID = acct.VIP_ContractID
	inner join VIP_Utilities util on util.VIP_UtilityID = acct.VIP_UtilityID
	where acct.VIP_AccountID in
	(
		Select distinct vip_Accountid from VIP_AccountProducts where VIP_ProductID in
		(
			Select VIP_ProductID from VIP_Products where VIP_ProductBillingTypeID IN
			(
				Select VIP_ProductBillingTypeID from VIP_ProductBillingTypes 
				where Code = 'DUAL'
			)
		)
	) and AccountStatus = 'Enrolled'
) a
where a.DifferenceDays between 0 and 60
order by a.DifferenceDays, a.UtilityAccountNumber
GO
