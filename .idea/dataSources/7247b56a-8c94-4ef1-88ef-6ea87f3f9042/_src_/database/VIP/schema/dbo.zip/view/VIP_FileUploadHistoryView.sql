CREATE VIEW dbo.VIP_FileUploadHistoryView
AS
Select *,'' Archived from VIP_FileUpLoadHistory
union
Select *,'Archived' Archived from VIP_Archive..VIP_FileUpLoadHistory
GO
