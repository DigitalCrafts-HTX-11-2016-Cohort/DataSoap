

CREATE procedure dbo.GetPortalByAlias

@HTTPAlias nvarchar(200)

as

select 'PortalId' = min(PortalId)
from dbo.PortalAlias
where  HTTPAlias = @HTTPAlias


GO
