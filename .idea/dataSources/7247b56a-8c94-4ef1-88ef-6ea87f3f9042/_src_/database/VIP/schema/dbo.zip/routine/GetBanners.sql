
create procedure dbo.GetBanners

@VendorId int

as

select BannerId,
       BannerName,
       URL,
       Impressions,
       CPM,
       Views,
       ClickThroughs,
       StartDate,
       EndDate,
       BannerTypeId,
       Description,
       GroupName,
       Criteria,
       Width,
       Height
from   dbo.Banners
where  VendorId = @VendorId
order  by CreatedDate desc


GO
