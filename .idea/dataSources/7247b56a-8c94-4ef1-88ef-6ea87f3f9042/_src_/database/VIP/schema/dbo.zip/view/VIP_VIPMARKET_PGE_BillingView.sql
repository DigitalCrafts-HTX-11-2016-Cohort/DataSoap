CREATE VIEW dbo.VIP_VIPMARKET_PGE_BillingView
AS
SELECT     *, '' Archived
FROM         VIPMARKET_PGE_Billing
UNION
SELECT     *, 'Archived' Archived
FROM         VIP_Archive..VIPMARKET_PGE_Billing
GO
