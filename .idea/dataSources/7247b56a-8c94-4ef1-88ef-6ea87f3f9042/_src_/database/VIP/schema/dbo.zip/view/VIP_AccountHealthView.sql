CREATE VIEW dbo.VIP_AccountHealth
AS
SELECT     TOP (100) PERCENT VIP_Accounts_1.VIP_AccountID, VIP_Accounts_1.UtilityServiceAccountID, VIP_Accounts_1.UtilityAccountNumber, VIP_Accounts_1.CompanyName, 
                      VIP_Accounts_1.ServiceFirstName + ' ' + VIP_Accounts_1.ServiceLastName AS ContactName, VIP_Accounts_1.AccountStatus, VIP_Accounts_1.EnrollmentAcceptDate, 
                      VIP_Accounts_1.VIP_UtilityID, VIP_Accounts_1.EST_DropDate,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.VIP_AccountInteractions
                            WHERE      (Status = 'Pending') AND (VIP_AccountID = VIP_Accounts_1.VIP_AccountID) AND (DATEADD(day, 5, StartDateTime) < GETDATE())) 
                      AS InteractionsStuckInPending,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.VIP_AccountInteractions AS VIP_AccountInteractions_3
                            WHERE      (Status = 'Processing') AND (VIP_AccountID = VIP_Accounts_1.VIP_AccountID) AND (DATEADD(day, 5, StartDateTime) < GETDATE())) 
                      AS InteractionsStuckInProcessing,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.VIP_AccountInteractions AS VIP_AccountInteractions_2
                            WHERE      (Status = 'Error') AND (VIP_AccountID = VIP_Accounts_1.VIP_AccountID)) AS InteractionsInError,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.VIP_AccountInteractionAudit INNER JOIN
                                                   dbo.VIP_AccountInteractions AS VIP_AccountInteractions_1 ON 
                                                   VIP_AccountInteractions_1.VIP_AccountInteractionID = dbo.VIP_AccountInteractionAudit.VIP_AccountInteractionID
                            WHERE      (dbo.VIP_AccountInteractionAudit.AuditType = 'Exception') AND (VIP_AccountInteractions_1.VIP_AccountID = VIP_Accounts_1.VIP_AccountID)) 
                      AS InteractionAuditsWithExceptions,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.VIP_Usage
                            WHERE      (StartDate > VIP_Accounts_1.EnrollmentAcceptDate) AND (VIP_AccountID = VIP_Accounts_1.VIP_AccountID)) AS ActualUsageReads,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.VIPMARKET_PGE_DASR
                            WHERE      (ReceiverCustomerID = VIP_Accounts_1.UtilityServiceAccountID) AND (Reason = 'CONNECT') AND (OperationType = 'SP-REQ')) 
                      AS DASR_EnrollmentRequests,
                          (SELECT     TOP (1) OperationType
                            FROM          dbo.VIPMARKET_PGE_DASR AS VIPMARKET_PGE_DASR_5
                            WHERE      (SenderCustomerID = VIP_Accounts_1.UtilityServiceAccountID) AND (Reason = 'CONNECT')
                            ORDER BY VIPMARKET_PGE_DASRID DESC) AS DASR_EnrollmentResponse,
                          (SELECT     TOP (1) TypeOfServiceRelationship
                            FROM          dbo.VIPMARKET_PGE_DASR AS VIPMARKET_PGE_DASR_4
                            WHERE      (SenderCustomerID = VIP_Accounts_1.UtilityServiceAccountID) AND (Reason = 'CONNECT')
                            ORDER BY VIPMARKET_PGE_DASRID DESC) AS DASR_EnrollmentResponseMessage,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.VIPMARKET_PGE_DASR AS VIPMARKET_PGE_DASR_3
                            WHERE      (ReceiverCustomerID = VIP_Accounts_1.UtilityServiceAccountID) AND (Reason = 'MAINTENANCE') AND (OperationType = 'SP-REQ')) 
                      AS DASR_ProductChangeRequests,
                          (SELECT     TOP (1) OperationType
                            FROM          dbo.VIPMARKET_PGE_DASR AS VIPMARKET_PGE_DASR_2
                            WHERE      (SenderCustomerID = VIP_Accounts_1.UtilityServiceAccountID) AND (Reason = 'MAINTENANCE') AND (OperationType IN ('SP-ACK-MAINTENANCE', 
                                                   'SP-NAK-MAINTENANCE'))
                            ORDER BY VIPMARKET_PGE_DASRID DESC) AS DASR_ProductChangeResponse,
                          (SELECT     TOP (1) TypeOfServiceRelationship
                            FROM          dbo.VIPMARKET_PGE_DASR AS VIPMARKET_PGE_DASR_1
                            WHERE      (SenderCustomerID = VIP_Accounts_1.UtilityServiceAccountID) AND (Reason = 'MAINTENANCE') AND (OperationType IN ('SP-ACK-MAINTENANCE', 
                                                   'SP-NAK-MAINTENANCE'))
                            ORDER BY VIPMARKET_PGE_DASRID DESC) AS DASR_ProductChangeResponseMessage,
                          (SELECT     TOP (1) EndDate
                            FROM          dbo.VIP_Usage AS VIP_Usage_1
                            WHERE      (VIP_AccountID = VIP_Accounts_1.VIP_AccountID) AND (VIP_UsageTypeID IN (2, 3))
                            ORDER BY EndDate DESC) AS LastUsageReadDate,
                          (SELECT     TOP (1) DATEDIFF(d, EndDate, GETDATE()) AS Expr1
                            FROM          dbo.VIP_Usage AS VIP_Usage_2
                            WHERE      (VIP_UsageTypeID IN
                                                       (SELECT     VIP_UsageTypeID
                                                         FROM          dbo.VIP_UsageTypes
                                                         WHERE      (Code = 'ACTUAL'))) AND (VIP_AccountID = VIP_Accounts_1.VIP_AccountID)
                            ORDER BY EndDate DESC) AS NoUsageReported,
                          (SELECT     TOP (1) DATEDIFF(d, EndDateTime, GETDATE()) AS Expr1
                            FROM          dbo.VIP_AccountInteractions AS VIP_AccountInteractions_4
                            WHERE      (VIP_AccountInteractionTypeID = 1) AND (VIP_AccountID = VIP_Accounts_1.VIP_AccountID) AND (VIP_Accounts_1.AccountStatus = 'Enrollment Rejected')
                            ORDER BY EndDateTime DESC) AS EnrollmentRejected,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.VIP_AccountInteractions AS VIP_AccountInteractions_5 INNER JOIN
                                                   dbo.VIP_Accounts ON VIP_AccountInteractions_5.VIP_AccountID = dbo.VIP_Accounts.VIP_AccountID AND 
                                                   VIP_AccountInteractions_5.VIP_AccountID = dbo.VIP_Accounts.VIP_AccountID
                            WHERE      (VIP_AccountInteractions_5.VIP_AccountInteractionTypeID = 17) AND (dbo.VIP_Accounts.AccountStatus = 'Enrolled') AND 
                                                   (VIP_AccountInteractions_5.VIP_AccountID = VIP_Accounts_1.VIP_AccountID)) AS NoProductChangeSent,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.VIP_Accounts AS VIP_Accounts_2
                            WHERE      (VIP_AccountID = VIP_Accounts_1.VIP_AccountID) AND (AccountStatus = 'Terminated') AND
                                                       ((SELECT     MAX(StartDate) AS Expr1
                                                           FROM         dbo.VIP_Usage AS VIP_Usage_3
                                                           WHERE     (VIP_AccountID = VIP_Accounts_2.VIP_AccountID) AND (VIP_UsageTypeID = 2)) > EST_DropDate) AND (YEAR(EST_DropDate) <> 1900)) 
                      AS UsagePastTerminationDate
FROM         dbo.VIP_Accounts AS VIP_Accounts_1 INNER JOIN
                      dbo.VIP_AccountClasses ON VIP_Accounts_1.VIP_AccountClassID = dbo.VIP_AccountClasses.VIP_AccountClassID
ORDER BY VIP_Accounts_1.VIP_AccountID
GO
