
create procedure dbo.DeleteModuleSetting
@ModuleId      int,
@SettingName   nvarchar(50)
as

DELETE FROM dbo.ModuleSettings 
WHERE ModuleId = @ModuleId
AND SettingName = @SettingName


GO
