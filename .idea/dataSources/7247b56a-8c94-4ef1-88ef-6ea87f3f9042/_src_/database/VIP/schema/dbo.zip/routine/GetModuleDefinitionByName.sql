
create procedure dbo.GetModuleDefinitionByName

@DesktopModuleId int,    
@FriendlyName    nvarchar(128)

as

select *
from   dbo.ModuleDefinitions
where  DesktopModuleId = @DesktopModuleId
and    FriendlyName = @FriendlyName


GO
