
CREATE PROCEDURE dbo.DeleteFolderPermissionsByFolderPath
	@PortalID int,
	@FolderPath varchar(300)
AS
DECLARE @FolderID int
SELECT @FolderID = FolderID FROM dbo.Folders
WHERE FolderPath = @FolderPath
AND ((PortalID = @PortalID) or (PortalID is null and @PortalID is null))

DELETE FROM dbo.FolderPermission
WHERE
	[FolderID] = @FolderID


GO
