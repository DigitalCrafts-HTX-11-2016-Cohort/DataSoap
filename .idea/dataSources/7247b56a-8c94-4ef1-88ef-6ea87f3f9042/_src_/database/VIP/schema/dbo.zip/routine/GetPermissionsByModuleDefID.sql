
CREATE PROCEDURE dbo.GetPermissionsByModuleDefID
	@ModuleDefID int
AS

SELECT  PermissionID,
	PermissionCode,
	ModuleDefID,
	PermissionKey,
	PermissionName
FROM    dbo.Permission
WHERE   ModuleDefID = @ModuleDefID
ORDER BY PermissionID

GO
