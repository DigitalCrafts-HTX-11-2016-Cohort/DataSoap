
CREATE PROCEDURE dbo.ListSearchItemWordPosition
AS

SELECT
	[SearchItemWordPositionID],
	[SearchItemWordID],
	[ContentPosition]
FROM
	dbo.SearchItemWordPosition


GO
