-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE SCG_EbillCheckDuplicate
	@param varchar(1000)
AS
Select 
* 
 from dbo.VIPMARKET_SCG_EBill
 where 
 Account + 
Name + 
Address + 
MKTR + 
MeterNo + 
StartDate + 
StartRead + 
EndDate + 
EndRead + 
SERV_Type + 
Billed_Usage + 
Actual_Usage + 
Read_Exc + 
Charge_Date + 
Billed_Usage_Adj + 
Actual_Usage_Adj + 
Press_Factor + 
BVI_Ind + 
BVI_Factor + 
Division + 
Action_Code + 
Bill_From_Date + 
Bill_To_Date + 
Previous_Bal + 
Payments + 
Adjustments + 
Bal_Forward + 
Cust_Chg + 
Delivery_Chg + 
Peak_Chg + 
WNA_Chg + 
CAM_Chg + 
GRT_Chg + 
Late_Chg + 
Meter_Chg + 
RC_Chg + 
TSCV_Chg + 
TCSD_Chg + 
Serv_Chg + 
Sales_Tax + 
Total_Charges + 
Acct_Balance = @param
GO
