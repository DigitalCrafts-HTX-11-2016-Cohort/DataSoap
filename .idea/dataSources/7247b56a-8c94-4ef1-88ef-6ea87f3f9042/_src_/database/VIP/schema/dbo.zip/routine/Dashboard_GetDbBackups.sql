
CREATE procedure dbo.[Dashboard_GetDbBackups]
AS
	
	SELECT TOP 20     
		name, 
		backup_start_date as StartDate, 
		backup_finish_date as FinishDate, 
		backup_size as size, 
		database_name, 
		CASE type
			WHEN 'D' THEN 'Database'
			WHEN 'I' THEN 'Differential database'
			WHEN 'L' THEN 'Log'
			WHEN 'F' THEN 'File or filegroup'
			WHEN 'G' THEN 'Differential file'
			WHEN 'P' THEN 'Partial'
			WHEN 'Q' THEN 'Differential partial'
		END as BackupType
	FROM         
		msdb..backupset
	WHERE
		database_name = DB_NAME() 
	ORDER BY backup_start_date DESC

GO
