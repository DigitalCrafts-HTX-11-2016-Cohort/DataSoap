
create procedure dbo.GetSystemMessages

as

select MessageName
from   dbo.SystemMessages
where  PortalID is null


GO
