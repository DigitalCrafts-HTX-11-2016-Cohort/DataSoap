
CREATE PROCEDURE dbo.GetPermissionsByFolderPath
	@PortalID int,
	@FolderPath varchar(300)
AS

SELECT  PermissionID,
	PermissionCode,
	PermissionKey,
	PermissionName
FROM    dbo.Permission P
WHERE   PermissionCode = 'SYSTEM_FOLDER'
ORDER BY PermissionID

GO
