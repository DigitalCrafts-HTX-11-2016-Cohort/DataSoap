
--EXECUTE dbo.p_VIPMarket_SG_Pricing_LoadFromStaging

--SELECT * FROM dbo.VIPMARKET_SG_Pricing_STAGING
CREATE PROCEDURE dbo.p_VIPMarket_SG_Pricing_LoadFromStaging AS
BEGIN

	DECLARE @test int

BEGIN TRAN

INSERT INTO dbo.VIPMARKET_SG_Pricing
        ( Account_Number ,
          Marketer ,
          FixedPriceRate ,
          FixedpriceCode ,
          FixedPriceRate2 ,
          FixedPriceCode2 ,
          IndexRate ,
          IndexCode ,
          IndexRate2 ,
          IndexCode2 ,
          BlendCode ,
          BlendCode2 ,
          Weighted_Fixed_Average ,
          Weighted_Fixed_Code ,
          NymexRate1 ,
          NymexCode1 ,
          NymexRate2 ,
          NymexCode2 ,
          FixedBillUnlimitedCode1 ,
          FixedBillUnlimitedRate1 ,
          FixedBillUnlimitedCode2 ,
          FixedBillUnlimitedRate2 ,
          BrokerDiscount ,
          VistaMatchDiscount ,
          ImportDate ,
          ImportFileName ,
          FixedPriceRate3 ,
          FixedPriceCode3 ,
          FixedBillUnlimitedCode3 ,
          FixedBillUnlimitedRate3 ,
          IndexRate3 ,
          IndexCode3 ,
          GLTPORRate1 ,
          GLTPORCode1 ,
          GLTPORRate2 ,
          GLTPORCode2 ,
          GLTPORRate3 ,
          GLTPORCode3,
		  ServicePointID
        )
SELECT Account_Number 
          ,Marketer 
          ,FixedPriceRate 
          ,FixedpriceCode 
          ,FixedPriceRate2 
          ,FixedPriceCode2 
          ,IndexRate 
          ,IndexCode 
          ,IndexRate2 
          ,IndexCode2 
          ,BlendCode 
          ,BlendCode2 
          ,Weighted_Fixed_Average 
          ,Weighted_Fixed_Code 
          ,NymexRate1 
          ,NymexCode1 
          ,NymexRate2 
          ,NymexCode2 
          ,FixedBillUnlimitedCode1 
          ,FixedBillUnlimitedRate1 
          ,FixedBillUnlimitedCode2 
          ,FixedBillUnlimitedRate2 
          ,BrokerDiscount 
          ,VistaMatchDiscount 
          ,ImportDate 
          ,ImportFileName 
          ,FixedPriceRate3 
          ,FixedPriceCode3 
          ,FixedBillUnlimitedCode3 
          ,FixedBillUnlimitedRate3 
		  , IndexRate3 
		  ,IndexCOde3 
          ,GLTPORRate1 ,
          GLTPORCode1 ,
          GLTPORRate2 ,
          GLTPORCode2 ,
          GLTPORRate3 ,
          GLTPORCode3 ,
		  ServicePointID
FROM VIPMARKET_SG_Pricing_STAGING

DELETE FROM VIPMARKET_SG_Pricing_STAGING

COMMIT

END

GO
