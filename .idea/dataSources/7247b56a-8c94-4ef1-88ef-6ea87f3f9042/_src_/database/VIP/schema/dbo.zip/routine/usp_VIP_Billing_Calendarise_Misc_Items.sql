-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE usp_VIP_Billing_Calendarise_Misc_Items
	@VIP_Invoiceid int
AS

Update VIP_InvoiceBreakdowns
set Misc_Items = 
	(
		Select SUM(total) InvoiceAmount
		from VIP_InvoiceItems 
		where VIP_InvoiceID = @VIP_Invoiceid and AddedItem = 1 and Tax = 0		
	)
	/ 
	(
		Select COUNT(*) from VIP_InvoiceBreakdowns 
		where VIP_InvoiceID = @VIP_Invoiceid
	)
where VIP_InvoiceID = @VIP_Invoiceid
GO
