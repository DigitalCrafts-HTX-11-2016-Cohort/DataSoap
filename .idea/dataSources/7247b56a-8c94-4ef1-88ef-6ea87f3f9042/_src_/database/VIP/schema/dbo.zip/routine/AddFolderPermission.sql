
CREATE PROCEDURE dbo.AddFolderPermission
	@FolderID int,
	@PermissionID int,
	@RoleID int,
	@AllowAccess bit,
        @UserID int
AS

INSERT INTO dbo.FolderPermission (
	[FolderID],
	[PermissionID],
	[RoleID],
	[AllowAccess],
        [UserID]
) VALUES (
	@FolderID,
	@PermissionID,
	@RoleID,
	@AllowAccess,
        @UserID
)

select SCOPE_IDENTITY()

GO
