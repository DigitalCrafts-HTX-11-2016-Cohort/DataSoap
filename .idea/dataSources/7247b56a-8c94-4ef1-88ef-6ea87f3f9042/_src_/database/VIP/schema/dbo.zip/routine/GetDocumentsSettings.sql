
CREATE PROCEDURE dbo.GetDocumentsSettings
@ModuleId INT
AS
SELECT *
FROM DocumentsSettings
WHERE  DocumentsSettings.ModuleId = @ModuleId
GO
