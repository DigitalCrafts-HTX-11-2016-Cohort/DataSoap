CREATE VIEW dbo.v_Users AS
	SELECT 
		u.UserID ,
        u.Username ,
        u.FirstName ,
        u.LastName ,
        u.IsSuperUser ,
        u.AffiliateId ,
        u.Email ,
        u.DisplayName ,
        u.UpdatePassword
	FROM 
		dbo.Users u
GO
