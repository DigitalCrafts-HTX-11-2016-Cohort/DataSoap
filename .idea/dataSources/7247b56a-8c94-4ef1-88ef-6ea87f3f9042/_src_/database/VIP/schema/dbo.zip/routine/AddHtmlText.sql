

/** Create Stored Procedures **/

create procedure dbo.AddHtmlText

	@ModuleId       int,
	@DesktopHtml    ntext,
	@DesktopSummary ntext,
	@UserID         int

as

insert into HtmlText (
	ModuleId,
	DesktopHtml,
	DesktopSummary,
	CreatedByUser,
	CreatedDate
) 
values (
	@ModuleId,
	@DesktopHtml,
	@DesktopSummary,
	@UserID,
	getdate()
)

GO
