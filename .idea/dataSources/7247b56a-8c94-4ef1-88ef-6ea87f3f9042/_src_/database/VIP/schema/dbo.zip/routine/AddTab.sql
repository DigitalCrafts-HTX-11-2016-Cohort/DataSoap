
CREATE PROCEDURE dbo.AddTab 
	@PortalId           int,
	@TabName            nvarchar(50),
	@IsVisible          bit,
	@DisableLink        bit,
	@ParentId           int,
	@IconFile           nvarchar(100),
	@Title              nvarchar(200),
	@Description        nvarchar(500),
	@KeyWords           nvarchar(500),
	@Url                nvarchar(255),
	@SkinSrc            nvarchar(200),
	@ContainerSrc       nvarchar(200),
	@TabPath            nvarchar(255),
	@StartDate          datetime,
	@EndDate            datetime,
	@RefreshInterval    int,
	@PageHeadText	    nvarchar(500),
	@IsSecure           bit,
	@PermanentRedirect	bit
AS
	INSERT INTO dbo.Tabs (
		PortalId,
		TabName,
		IsVisible,
		DisableLink,
		ParentId,
		IconFile,
		Title,
		Description,
		KeyWords,
		IsDeleted,
		Url,
		SkinSrc,
		ContainerSrc,
		TabPath,
		StartDate,
		EndDate,
		RefreshInterval,
		PageHeadText,
		IsSecure,
		PermanentRedirect
	)
	VALUES (
		@PortalId,
		@TabName,
		@IsVisible,
		@DisableLink,
		@ParentId,
		@IconFile,
		@Title,
		@Description,
		@KeyWords,
		0,
		@Url,
		@SkinSrc,
		@ContainerSrc,
		@TabPath,
		@StartDate,
		@EndDate,
		@RefreshInterval,
		@PageHeadText,
		@IsSecure,
		@PermanentRedirect
	)

	SELECT SCOPE_IDENTITY()
GO
