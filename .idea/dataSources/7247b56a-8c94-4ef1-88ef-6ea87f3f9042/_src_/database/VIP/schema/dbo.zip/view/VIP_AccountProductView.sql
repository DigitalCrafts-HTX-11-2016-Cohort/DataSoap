
CREATE VIEW [dbo].[VIP_AccountProductView]
AS
SELECT     ap.VIP_AccountProductID, ap.VIP_AccountID, ap.VIP_ProductID, p.ProductName, ap.FixedPrice, ap.VariableAdder, ap.ServiceFeeAmount, ap.BandwidthAdder, 
                      ap.UsageAllocationAmount, ap.UsageAllocationPriority, ap.StartDate, ap.EndDate, pbt.Name AS BillingType, ppt.Name AS PricingType, ap.Archived, 
                      ap.BrokerCommisionRate, ap.BrokerCommisionRate_Intolerance, ap.UtilityCode, ap.RetailerCode, ap.BandwidthMaxPercentage, ap.BandwidthUsageAmount, 
                      ap.BandwidthMinPercentage, ap.BandwidthLowAdder, ap.BandwidthHighAdder, ap.Fuel, p.UsageAllocationAvailable, p.BandwidthAvailable, 
                      UOM.Name AS UnitOfMeasure
					  ,BTUPrecision = ISNULL(ap.BTUPrecision,'N/A'), FixedBill_Amount, UtilityApprovalStatus
					  ,ap.Eligibility_Requirement
					  ,ap.Eligibility_Status_DefaultIsEligible
					  ,ap.EndDate_Explicit
FROM         dbo.VIP_AccountProductsView AS ap INNER JOIN
                      dbo.VIP_Products AS p ON ap.VIP_ProductID = p.VIP_ProductID INNER JOIN
                      dbo.VIP_ProductBillingTypes AS pbt ON p.VIP_ProductBillingTypeID = pbt.VIP_ProductBillingTypeID INNER JOIN
                      dbo.VIP_ProductPricingTypes AS ppt ON p.VIP_ProductPricingTypeID = ppt.VIP_ProductPricingTypeID INNER JOIN
                      dbo.VIP_UnitsOfMeasure AS UOM ON UOM.VIP_UnitOfMeasureID = p.VIP_UnitOfMeasureID

GO
