
CREATE PROCEDURE dbo.ListSearchItemWord
AS

SELECT
	[SearchItemWordID],
	[SearchItemID],
	[SearchWordsID],
	[Occurrences]
FROM
	dbo.SearchItemWord


GO
