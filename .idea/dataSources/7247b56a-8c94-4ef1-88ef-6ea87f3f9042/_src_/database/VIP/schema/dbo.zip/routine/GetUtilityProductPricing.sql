
CREATE FUNCTION [dbo].[GetUtilityProductPricing]
(	
	@VIP_AccountID int,
	@UtilityProductCode varchar(50),
	@BillingDate varchar(10)	
)
RETURNS TABLE
AS
RETURN 
(
	SELECT 
		CASE WHEN ppt.Name = 'Variable' THEN
			ISNULL((SELECT VariableProductIndexPrice FROM VIP_VariableProductIndexPrices WHERE VIP_VariableProductIndexID = p.CommoidtyVariableProductIndexID AND @BillingDate BETWEEN EffectiveStartDate and EffectiveEndDate) + ap.VariableAdder, 0)
		ELSE
			ISNULL(ap.FixedPrice, 0)
		END AS Price,
		CASE WHEN ppt.Name = 'Variable' THEN
			ISNULL((SELECT VariableProductServiceFee FROM VIP_VariableProductIndexPrices WHERE VIP_VariableProductIndexID = p.CommoidtyVariableProductIndexID AND @BillingDate BETWEEN EffectiveStartDate and EffectiveEndDate), 0)
		ELSE
			ISNULL(ap.ServiceFeeAmount, 0)
		END AS ServiceFee
	FROM VIP_AccountProducts ap
		INNER JOIN VIP_Products p ON ap.VIP_ProductID = p.VIP_ProductID
		INNER JOIN VIP_ProductPricingTypes ppt ON p.VIP_ProductPricingTypeID = ppt.VIP_ProductPricingTypeID
	WHERE ap.VIP_AccountID = @VIP_AccountID
		AND p.UtilityProductCode = @UtilityProductCode
)
GO
