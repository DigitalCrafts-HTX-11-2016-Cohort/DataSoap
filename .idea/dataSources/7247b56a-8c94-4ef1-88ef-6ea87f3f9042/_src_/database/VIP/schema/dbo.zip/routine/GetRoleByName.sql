
CREATE PROCEDURE dbo.[GetRoleByName]

	@PortalID int,
	@RoleName nvarchar(50)

AS

SELECT RoleId,
       PortalId,
       RoleGroupId,
       RoleName,
       Description,
       ServiceFee,
       BillingPeriod,
       BillingFrequency,
       TrialFee,
       TrialPeriod,
       TrialFrequency,
       IsPublic,
       AutoAssignment,
       RSVPCode,
       IconFile
FROM   dbo.Roles
WHERE  PortalId = @PortalID 
	AND RoleName = @RoleName


GO
