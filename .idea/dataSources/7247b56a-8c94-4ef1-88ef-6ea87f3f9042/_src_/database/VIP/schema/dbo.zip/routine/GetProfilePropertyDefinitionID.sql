
CREATE FUNCTION dbo.[GetProfilePropertyDefinitionID]
(
	@PortalID				int,
	@PropertyName			nvarchar(50)
)
RETURNS int

AS
BEGIN
	DECLARE @DefinitionID int
	SELECT @DefinitionID = -1

	IF  @PropertyName IS NULL
		OR LEN(@PropertyName) = 0
		RETURN -1

	IF @PortalID IS NULL
		SET @PortalID = -1

	SET @DefinitionID = (SELECT PropertyDefinitionID 
							FROM dbo.ProfilePropertyDefinition
							WHERE PortalID = @PortalID
								AND PropertyName = @PropertyName
						)
	
	RETURN @DefinitionID
END


GO
