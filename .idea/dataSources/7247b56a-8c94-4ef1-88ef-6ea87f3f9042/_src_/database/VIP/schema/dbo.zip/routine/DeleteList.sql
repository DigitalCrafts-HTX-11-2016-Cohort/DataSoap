
CREATE procedure dbo.[DeleteList]
	@ListName nvarchar(50),
	@ParentKey nvarchar(150)

AS
DELETE 
	FROM dbo.vw_Lists
	WHERE ListName = @ListName
		AND ParentKey =@ParentKey
GO
