
CREATE PROCEDURE dbo.[GetExpiredPortals]

AS
SELECT * FROM dbo.vw_Portals
WHERE ExpiryDate < getDate()

GO
