
CREATE PROCEDURE dbo.AddDocumentsSettings

@ModuleId          INT,
@ShowTitleLink     BIT,
@SortOrder         nvarchar(2000),
@DisplayColumns    nvarchar(2000),
@UseCategoriesList BIT,
@DefaultFolder     nvarchar(2000),
@CategoriesListName nvarchar(50),
@AllowUserSort     BIT

AS
INSERT INTO dbo.DocumentsSettings (
  ModuleId,
  ShowTitleLink,
  SortOrder,    
  DisplayColumns,
  UseCategoriesList,
  DefaultFolder,
  CategoriesListName,
  AllowUserSort
)
VALUES (
  @ModuleId,
  @ShowTitleLink,
  @SortOrder,    
  @DisplayColumns,
  @UseCategoriesList,
  @DefaultFolder,
  @CategoriesListName,
  @AllowUserSort
)
SELECT @ModuleId
GO
