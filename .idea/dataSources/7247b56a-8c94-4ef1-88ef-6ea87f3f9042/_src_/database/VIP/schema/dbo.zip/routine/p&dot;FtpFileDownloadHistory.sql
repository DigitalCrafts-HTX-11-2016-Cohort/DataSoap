CREATE	 
PROCEDURE dbo.[p.FtpFileDownloadHistory]
    (
      @FileName VARCHAR(100) ,
      @Market VARCHAR(100) ,
      @DateDownloaded VARCHAR(100) ,
      @DestinationOfDownload VARCHAR(100) ,
      @CheckForDownload VARCHAR(100)
    )
AS
    BEGIN

----First lets see if the file already exists

        IF @CheckForDownload = 'YES'
            BEGIN
                IF EXISTS ( SELECT  *
                            FROM    dbo.VIP_FTP_FileDownloadHistory
                            WHERE   FileName = @FileName
                                    AND Market = @Market )
                    BEGIN
                        SELECT  'no' AS ShouldIDownloadFile
                    END
                ELSE
                    SELECT  'yes' AS ShouldIDownloadFile
            END


        IF @CheckForDownload = 'NO'
            BEGIN
                INSERT  INTO dbo.VIP_FTP_FileDownloadHistory
                VALUES  ( @FileName, -- FileName - varchar(200)
                          @Market, -- Market - varchar(150)
                          @DateDownloaded, -- DateDownloaded - varchar(150)
                          @DestinationOfDownload  -- DestinationOfDownload - varchar(200)
                          )
                SELECT  'yes' AS ShouldIDownloadFile
                
            END


    END	


    --    IF EXISTS ( SELECT  *
    --                FROM    dbo.VIP_FTP_FileDownloadHistory
    --                WHERE   FileName = @FileName
    --                        AND Market = @Market )
    --        BEGIN
    --            SELECT  'no' AS ShouldIDownloadFile
    --        END
    --    ELSE
    --        BEGIN
    --            INSERT  INTO dbo.VIP_FTP_FileDownloadHistory
    --            VALUES  ( @FileName, -- FileName - varchar(200)
    --                      @Market, -- Market - varchar(150)
    --                      @DateDownloaded, -- DateDownloaded - varchar(150)
    --                      @DestinationOfDownload  -- DestinationOfDownload - varchar(200)
    --                      )

				--		  SELECT 'yes' AS ShouldIDownloadFile
    --        END	
    --END

GO
