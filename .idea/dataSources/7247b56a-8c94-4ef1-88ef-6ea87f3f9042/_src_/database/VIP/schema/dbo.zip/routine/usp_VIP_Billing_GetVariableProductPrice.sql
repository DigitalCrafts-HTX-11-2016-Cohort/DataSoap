

CREATE PROCEDURE [dbo].[usp_VIP_Billing_GetVariableProductPrice]
	@VIP_VariableProductIndexID int,
	@Date varchar(10)
	
AS

	SELECT VariableProductServiceFee, VariableProductIndexPrice
	FROM VIP_VariableProductIndexPrices
	WHERE VIP_VariableProductIndexID = @VIP_VariableProductIndexID
		AND @Date BETWEEN EffectiveStartDate AND EffectiveEndDate
GO
