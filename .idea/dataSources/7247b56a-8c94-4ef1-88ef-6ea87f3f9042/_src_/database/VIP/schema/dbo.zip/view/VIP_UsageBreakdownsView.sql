CREATE VIEW dbo.VIP_UsageBreakdownsView
AS
SELECT     *, '' Archived
FROM         dbo.VIP_UsageBreakdowns
UNION
SELECT     *, 'Archived' Archived
FROM         VIP_Archive..VIP_UsageBreakdowns
GO
