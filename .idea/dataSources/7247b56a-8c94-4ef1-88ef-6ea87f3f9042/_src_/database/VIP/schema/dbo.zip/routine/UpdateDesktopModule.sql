
CREATE  PROCEDURE dbo.UpdateDesktopModule

	@DesktopModuleId	int,    
	@ModuleName		nvarchar(128),
	@FolderName		nvarchar(128),
	@FriendlyName		nvarchar(128),
	@Description		nvarchar(2000),
	@Version		nvarchar(8),
	@IsPremium		bit,
	@IsAdmin		bit,
	@BusinessController 	nvarchar(200),
	@SupportedFeatures	int,
	@CompatibleVersions 	nvarchar(500),
    @Dependencies           nvarchar(400),
    @Permissions      nvarchar(400)

AS

UPDATE 	dbo.DesktopModules
SET    	ModuleName = @ModuleName,
	FolderName = @FolderName,
	FriendlyName = @FriendlyName,
	Description = @Description,
	Version = @Version,
	IsPremium = @IsPremium,
	IsAdmin = @IsAdmin,
	BusinessControllerClass = @BusinessController,
	SupportedFeatures = @SupportedFeatures,
	CompatibleVersions = @CompatibleVersions,
	Dependencies = @Dependencies,
	Permissions = @Permissions
WHERE  DesktopModuleId = @DesktopModuleId

GO
