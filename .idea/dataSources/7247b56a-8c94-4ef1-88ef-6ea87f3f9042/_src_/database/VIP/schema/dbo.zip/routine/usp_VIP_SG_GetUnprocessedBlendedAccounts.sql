-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE usp_VIP_SG_GetUnprocessedBlendedAccounts	
AS
BEGIN	
	Select pricing.account_number, priceoption, pricing.Blendcode from dbo.VIPMARKET_SG_ELG_PREMISE 
	inner join VIPMARKET_SG_Pricing pricing on pricing.VIPMARKET_SG_Pricing_ID = VIPMARKET_SG_ELG_PREMISE.selectedrow
	where status = 'Sale Accepted' and priceoption in('Blended')
	and pricing.Blendcode = '00000'
	union
	Select pricing.account_number, priceoption, pricing.Blendcode from dbo.VIPMARKET_SG_ELG_PREMISE 
	inner join VIPMARKET_SG_Pricing pricing on pricing.VIPMARKET_SG_Pricing_ID = VIPMARKET_SG_ELG_PREMISE.selectedrow
	where status = 'Sale Accepted' and priceoption in('Blended2')
	and pricing.Blendcode2 = '00000'	
END
GO
