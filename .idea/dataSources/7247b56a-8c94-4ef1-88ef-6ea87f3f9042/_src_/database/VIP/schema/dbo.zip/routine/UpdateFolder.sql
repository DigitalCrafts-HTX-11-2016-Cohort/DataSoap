
CREATE PROCEDURE dbo.UpdateFolder

	@PortalID int,
	@FolderID int,
	@FolderPath varchar(300),
	@StorageLocation int,
	@IsProtected bit,
        @IsCached bit,
        @LastUpdated datetime

AS

UPDATE dbo.Folders
SET    FolderPath = @FolderPath,
       StorageLocation = @StorageLocation,
       IsProtected = @IsProtected,
       IsCached = @IsCached,
       LastUpdated = @LastUpdated
WHERE  ((PortalID = @PortalID) OR (PortalID IS Null AND @PortalID IS Null))
AND    FolderID = @FolderID


GO
