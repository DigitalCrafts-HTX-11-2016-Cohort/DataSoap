

-- =============================================
-- Author:		Bryan Panjavan
-- Create date: 2/13/2013
-- Description:	Back-end Script - run a process now (only works for Eshelman's process-runner)
-- =============================================
CREATE PROCEDURE [dbo].[BackEnd_RunProcessNow]
(
	@processName VARCHAR(100)
)
AS
BEGIN

	BEGIN TRY
		PRINT('Executing.  Begin Transaction')
		BEGIN TRAN

		UPDATE pr
			SET 
				NextRun = GETDATE()
		FROM
			VIP_Process pr
		WHERE (1 = 1)
			AND ProcessName = @processName

		SELECT * FROM dbo.VIP_Process WHERE ProcessName = @processName

		PRINT('Execution Complete.  Committing Transaction')
		COMMIT
	END TRY
	BEGIN CATCH
		PRINT('Execution Error.  Rolling back transaction')
		ROLLBACK
	
		PRINT('ERROR_NUMBER: ' + CONVERT(varchar(100), ERROR_NUMBER()) )
		PRINT('ERROR_SEVERITY: ' + CONVERT(varchar(100), ERROR_SEVERITY()) )
		PRINT('ERROR_STATE: ' + CONVERT(varchar(100), ERROR_STATE()) )
		PRINT('ERROR_PROCEDURE: ' + CONVERT(varchar(100), ERROR_PROCEDURE()) )
		PRINT('ERROR_LINE: ' + CONVERT(varchar(100), ERROR_LINE()) )
		PRINT('ERROR_MESSAGE: ' + CONVERT(varchar(100), ERROR_MESSAGE()) )
	END CATCH

	-- Open Transaction Count
	IF (@@TRANCOUNT = 0)
	BEGIN
		PRINT('Transaction Status: GOOD')
	END
	ELSE
	BEGIN
		PRINT('Transaction Status: WARNING -> OPEN TRANSACTION COUNT: ' + CONVERT(varchar(100), @@TRANCOUNT)	)
	END

END

GO
