
CREATE PROCEDURE [dbo].[usp_VIP_UpdateProductIndexPrices]
@IndexName varchar(70), @EffectiveStartDate datetime, @days int, 
@Price numeric(15,5), @UserID int, @FileName varchar(50)
AS


declare @EffectiveEndDate datetime
Select @EffectiveEndDate = dateadd(day, @days, @EffectiveStartDate)
--DETERMINE IF THE INDEX EXIST
IF EXISTS
	(
	Select * from VIP_VariableProductIndexes 
	where ImportColumnName = @IndexName --and ImportFileName like @FileName + '%'
	)
BEGIN
	declare @VariableProdIndexID int
	Select @VariableProdIndexID = (Select VIP_VariableProductIndexID from VIP_VariableProductIndexes 
	where ImportColumnName = @IndexName)

	--DETERMINE IF THE INDEX PRICE CURRENTLY EXIST FOR EFFECTIVE DATE
	if EXISTS
		(
			Select * from VIP_VariableProductIndexes a
			INNER JOIN VIP_VariableProductIndexPrices b ON
			b.VIP_VariableProductIndexID = a.VIP_VariableProductIndexID
			where ImportColumnName = @IndexName
			and EffectiveStartDate = @EffectiveStartDate
		)
		--UPDATE THE PRICE IF IT EXIST
		BEGIN
			update VIP_VariableProductIndexPrices
			set
			VariableProductServiceFee = 0, 
			VariableProductIndexPrice = @Price,
			DateCreated = getdate(),
			CreatedByUserID = @UserID
			where  
			VIP_VariableProductIndexID = @VariableProdIndexID
			and EffectiveStartDate = @EffectiveStartDate			
		END
	ELSE
		--INSERT A NEW RECORD IF IT IS A NEW ENTRY
		BEGIN
			Insert VIP_VariableProductIndexPrices
			(VIP_VariableProductIndexID,VariableProductServiceFee, VariableProductIndexPrice,EffectiveStartDate, EffectiveEndDate,DateCreated, CreatedByUserID)
			values
			(@VariableProdIndexID, 0, @Price, @EffectiveStartDate, @EffectiveEndDate, getdate(), @UserID)
		END 
END
GO
