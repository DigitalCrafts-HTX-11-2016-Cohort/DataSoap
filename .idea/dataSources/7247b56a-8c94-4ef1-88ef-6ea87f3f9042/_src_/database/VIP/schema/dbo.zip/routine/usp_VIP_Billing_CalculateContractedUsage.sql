-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE usp_VIP_Billing_CalculateContractedUsage 
	@VIP_Accountid int, @VIP_Usageid int
AS

Select sum(ContUsageAmount1) + sum(ContUsageAmount2) from
(
	Select *,
	case when usagestartdate >= UsageMonthStart and usagestartdate <= usagemonthend then 
		--datediff(d, usagestartdate,usagemonthend) * (ContractedUsage / NoOfDays)
		datediff(d, usagestartdate, dateadd(d,1,usagemonthend)) * (ContractedUsage / NoOfDays)
	else 0
	end ContUsageAmount1,
	case
		when month(usagestartdate) = month(usageenddate) then 0 
		when usageenddate >= UsageMonthStart and usageenddate <= usagemonthend then 
		--datediff(d, UsageMonthStart , usageenddate) * (ContractedUsage / NoOfDays)
		datediff(d, UsageMonthStart , dateadd(d,1,usageenddate)) * (ContractedUsage / NoOfDays)
	else 0
	end ContUsageAmount2,
	ContractedUsage / NoOfDays DailyContractedAmount from 
	(
		Select 
			*,
			(
				Select UsageAmount from VIP_UsageView 
				where VIP_AccountID = @VIP_Accountid and VIP_UsageTypeID = 1 and MONTH(StartDate) = MONTH(a.UsageMonthEnd)
			) ContractedUsage,
			(Select startdate from vip_usage where vip_usageid = a.vip_usageid) UsageStartDate,
			(Select enddate from vip_usage where vip_usageid = a.vip_usageid) UsageEndDate
		 from 
		(
			Select distinct MONTH(UsageDate) MonthPeriod, YEAR(usagedate) YearPeriod, VIP_UsageID,
			dbo.ufn_GetDaysInMonth(convert(varchar(10),MONTH(UsageDate)) + '/1/' + CONVERT(varchar(10), YEAR(usagedate))) NoOfDays,		
			convert(varchar(10),MONTH(UsageDate)) + '/1/' + CONVERT(varchar(10), YEAR(usagedate)) UsageMonthStart,
			convert(varchar(10),MONTH(UsageDate)) + '/' + convert(varchar(2),dbo.ufn_GetDaysInMonth(convert(varchar(10),MONTH(UsageDate)) + '/1/' + CONVERT(varchar(10), YEAR(usagedate)))) + '/' + CONVERT(varchar(10), YEAR(usagedate)) UsageMonthEnd
			 from VIP_UsageBreakdowns where VIP_UsageID in
			(
				Select vip_usageid from VIP_UsageView where VIP_UsageID = @VIP_Usageid
			) 
		) a
	) b	
) c
GO
