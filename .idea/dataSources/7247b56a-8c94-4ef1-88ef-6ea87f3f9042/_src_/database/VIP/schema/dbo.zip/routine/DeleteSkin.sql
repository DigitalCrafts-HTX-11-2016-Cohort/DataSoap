
create procedure dbo.DeleteSkin

@SkinRoot               nvarchar(50),
@PortalID		int,
@SkinType               int

as

delete
from   dbo.Skins
where   SkinRoot = @SkinRoot
and     SkinType = @SkinType
and    ((PortalID is null and @PortalID is null) or (PortalID = @PortalID))


GO
