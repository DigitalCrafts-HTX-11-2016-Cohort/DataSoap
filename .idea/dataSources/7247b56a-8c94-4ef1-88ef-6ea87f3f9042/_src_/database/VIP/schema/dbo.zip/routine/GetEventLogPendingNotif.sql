
CREATE PROCEDURE dbo.GetEventLogPendingNotif
	@LogConfigID int
AS
SELECT *
FROM dbo.EventLog
WHERE LogNotificationPending = 1
AND LogConfigID = @LogConfigID


GO
