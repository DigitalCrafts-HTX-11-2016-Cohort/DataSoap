

CREATE PROCEDURE dbo.MCISS_CacheUpdate
	@name nvarchar(250),
	@cachecontent ntext,
	@lastupdate datetime,
	@type char,
	@expire datetime
AS

Update dbo.MCISS_Cache set 
	[name]=@name,[cachecontent]=@cachecontent,[lastupdate]=@lastupdate,[type]=@type,[expire]=@expire


select SCOPE_IDENTITY()
GO
