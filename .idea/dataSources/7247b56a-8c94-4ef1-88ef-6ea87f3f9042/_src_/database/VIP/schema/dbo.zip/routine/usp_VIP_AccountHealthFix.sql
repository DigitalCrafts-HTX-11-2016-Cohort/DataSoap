CREATE Procedure [dbo].[usp_VIP_AccountHealthFix]

	@FixName varchar(100),
	@VIP_AccountID int,
	@RunByUserName varchar(100)
	
As

Declare @VIP_AccountInteractionID int

Print @VIP_AccountID

If @FixName = 'PGE_BillingPointPendingButNotNeeded'
Begin

	Set @VIP_AccountInteractionID = (select top 1 VIP_AccountInteractionID from VIP_AccountInteractions inner join VIP_Accounts on VIP_AccountInteractions.VIP_AccountID = VIP_Accounts.vip_accountid where vip_accounts.VIP_AccountID = @VIP_AccountID And Status = 'Pending' and VIP_AccountInteractionTypeID = 20 and AccountStatus in ('Enrolling'))
	Insert Into VIP_AccountInteractionAudit (VIP_AccountInteractionID, AuditType, AuditLevel, AuditMessage, AuditDateTime) Values (@VIP_AccountInteractionID, 'Manual Intervention', 'High', 'Billing point request was made before the account was successfully enrolled.  Billing point was not needed.  Marked as Complete by ' + @RunByUserName, GETDATE())
	Update VIP_AccountInteractions Set Status = 'Complete', EndDateTime=GETDATE() Where VIP_AccountInteractionID = @VIP_AccountInteractionID

End

If @FixName = 'PGE_PriceChangeUpdateRequestSent'
Begin
	
	-- Handle the incomplete UPDATE interaction
	Set @VIP_AccountInteractionID = (Select Top 1 VIP_AccountInteractions.VIP_AccountInteractionID From VIP_AccountInteractions Inner Join VIP_AccountInteractionAudit On VIP_AccountInteractions.VIP_AccountInteractionID = VIP_AccountINteractionAudit.VIP_AccountInteractionID Where VIP_AccountID = @VIP_AccountID And VIP_AccountInteractionTypeID = 17 And AuditMessage Like '%Update%' And Status = 'Processing')
	Insert Into VIP_AccountInteractionAudit (VIP_AccountInteractionID, AuditType, AuditLevel, AuditMessage, AuditDateTime) Values (@VIP_AccountInteractionID, 'Manual Intervention', 'High', 'Product change sent as UPDATE instead of MAINTENANCE.  Marked as Complete by ' + @RunByUserName, GETDATE())
	Update VIP_AccountInteractions Set Status = 'Complete', EndDateTime=GETDATE() Where VIP_AccountInteractionID = @VIP_AccountInteractionID

	-- Handle the incomplete MAINTENANCE interaction
	--Set @VIP_AccountInteractionID = (Select Distinct VIP_AccountInteractions.VIP_AccountInteractionID From VIP_AccountInteractions Inner Join VIP_AccountInteractionAudit On VIP_AccountInteractions.VIP_AccountInteractionID = VIP_AccountINteractionAudit.VIP_AccountInteractionID Where VIP_AccountID = @VIP_AccountID And VIP_AccountInteractionTypeID = 17 And AuditMessage Like '%Maintenance%' And Status = 'Processing')
	--Insert Into VIP_AccountInteractionAudit (VIP_AccountInteractionID, AuditType, AuditLevel, AuditMessage, AuditDateTime) Values (@VIP_AccountInteractionID, 'Manual Intervention', 'High', 'MAINTENANCE request received successfully, however the interaction was not completed.  Marked as Complete by ' + @RunByUserName, GETDATE())
	--Update VIP_AccountInteractions Set Status = 'Complete', EndDateTime=GETDATE() Where VIP_AccountInteractionID = @VIP_AccountInteractionID

End
GO
