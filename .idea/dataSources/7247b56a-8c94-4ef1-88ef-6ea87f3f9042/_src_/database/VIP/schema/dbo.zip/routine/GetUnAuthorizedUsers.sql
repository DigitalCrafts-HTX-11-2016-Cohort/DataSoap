
CREATE PROCEDURE dbo.GetUnAuthorizedUsers
    @PortalID			int
AS

SELECT  *
FROM	dbo.vw_Users
WHERE  PortalId = @PortalID
	AND Authorised = 0
ORDER BY UserName

GO
