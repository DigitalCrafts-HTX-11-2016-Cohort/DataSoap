

-- =============================================
-- Author:		Bryan Panjavan
-- Create date: 2013-03-14
-- Description:	Get ALL accounts for initial population for SourceGas
-- =============================================
CREATE PROCEDURE [dbo].[Courier_GetAccountListAll]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

;WITH tblAccountMaxID AS
(
	SELECT
		Account_Number
		,Max_ID = MAX(VIPMARKET_SG_Pricing_ID)
	FROM
		dbo.VIPMARKET_SG_Pricing
	WHERE (1 = 1)
		AND Marketer = '41MG'
	GROUP BY
		Account_Number
)
,tblAccountsThatArePriced AS
(
	SELECT 
		price.Account_Number
	FROM 
		dbo.VIPMARKET_SG_Pricing price
			INNER JOIN tblAccountMaxID priceMaxID
				ON
				(
					 price.Account_Number = priceMaxID.Account_Number
					 AND price.VIPMARKET_SG_Pricing_ID = priceMaxID.Max_ID
				)   
	WHERE (1 = 1)   
)
	SELECT 
		--TOP 1000 
		pr.VIPMARKET_SG_ELG_PREMISE_ID
	
	
		,pr.Account_Number
		,First_Name = ISNULL(pr.First_Name,'')
		,Last_Name = ISNULL(pr.Last_Name,'')
		,Full_Name = ISNULL(pr.First_Name + ' ' + pr.Last_Name,'')
		,Telephone = ISNULL(pr.Telephone ,'')

		,Service_Address = ISNULL(pr.Service_Address,'')
		,Service_City = ISNULL(pr.Service_City,'')
		,Service_State = ISNULL(pr.Service_State,'')
		,Service_Zip = ISNULL(pr.Service_Zip,'')
		,Resi1Com2 = 
			CASE WHEN pr.Bill_Class = 'RES' THEN 1
			ELSE 2
			END
		,pr.PricingTier
		,LastYearProductDescription = Pricing_Option
	FROM 
		dbo.VIPMARKET_SG_ELG_PREMISE pr	WITH (NOLOCK)
		INNER JOIN tblAccountsThatArePriced priced WITH (NOLOCK) ON pr.Account_Number = priced.Account_Number -- ONLY get accounts that are priced...?
		--LEFT JOIN dbo.TEMP_VIPArchiveCopy_VIPMARKET_SG_ELG_PREMISE prPrevious WITH (NOLOCK) 
		--	ON 
		--		prPrevious.[Status] = 'Enrolled'
		--		AND pr.Account_Number = prPrevious.Account_Number
		--LEFT JOIN dbo.TEMP_VIPArchiveCopy_VIPMARKET_SG_Pricing pricedPrevious WITH (NOLOCK) 
		--	ON prPrevious.SelectedRow = pricedPrevious.VIPMARKET_SG_Pricing_ID
	WHERE (1 = 1)
		AND ISNULL(pr.Account_Number,'') <> ''

END


GO
