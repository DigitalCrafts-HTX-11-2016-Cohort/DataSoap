-- =============================================
-- Author:		Bryan Panjavan
-- Create date: 2013-08-08
-- Description:	Get the document types that are eligible for upload
-- =============================================
CREATE PROCEDURE dbo.VIP_DocumentTypes_GetOnesThatUserCanUpload
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT * FROM dbo.VIP_Document_Types WHERE CODE NOT LIKE '%WELCOME_LETTER%'

END
GO
