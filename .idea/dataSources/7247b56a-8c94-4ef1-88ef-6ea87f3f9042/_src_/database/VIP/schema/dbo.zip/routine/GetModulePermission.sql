
CREATE PROCEDURE dbo.[GetModulePermission]
	
	@ModulePermissionID int

AS
SELECT *
FROM dbo.vw_ModulePermissions
WHERE ModulePermissionID = @ModulePermissionID

GO
