
CREATE VIEW dbo.vw_ModulePermissions
AS
SELECT     
	MP.ModulePermissionID, 
	MP.ModuleID, 
	P.PermissionID, 
	MP.RoleID,
	CASE MP.RoleID
		when -1 then 'All Users'
		when -2 then 'Superuser'
		when -3 then 'Unauthenticated Users'
		else 	R.RoleName
	END AS 'RoleName',
	MP.AllowAccess, 
	MP.UserID,
	U.Username,
	U.DisplayName, 
	P.PermissionCode, 
	P.ModuleDefID, 
	P.PermissionKey, 
	P.PermissionName 
FROM dbo.ModulePermission AS MP 
	LEFT OUTER JOIN dbo.Permission AS P ON MP.PermissionID = P.PermissionID 
	LEFT OUTER JOIN dbo.Roles AS R ON MP.RoleID = R.RoleID
	LEFT OUTER JOIN dbo.Users AS U ON MP.UserID = U.UserID

GO
