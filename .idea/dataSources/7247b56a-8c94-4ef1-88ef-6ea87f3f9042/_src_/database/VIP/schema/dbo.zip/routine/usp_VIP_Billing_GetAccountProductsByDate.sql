
/*
	2014-01-10 - BPanjavan - Added Fixed Bill Amount

*/
CREATE procedure [dbo].[usp_VIP_Billing_GetAccountProductsByDate]
	@VIP_AccountID int,
	@Date varchar(10)
	AS
	
SELECT *,
	a.bandwidthUsageAmount - (a.bandwidthUsageAmount * (BandwidthMinPercentage * .01)) BandwidthUsageAmountLow, 
	a.bandwidthUsageAmount + (a.bandwidthUsageAmount * (BandwidthMaxPercentage * .01)) BandwidthUsageAmountHigh
 FROM
(
	SELECT 
	ap.VIP_AccountProductID, ap.VIP_ProductID, pbt.Code BillingTypeCode, ppt.Code ProductPricingCode, u.Code UtilityCode
		, ap.FixedPrice CommodityPrice
		, ap.FixedBill_Amount
		, p.ServiceFeeType,
		ap.ServiceFeeAmount, ap.VariableAdder, ap.BandwidthMaxPercentage * .01 BandwidthMaxPercentage, ap.BandwidthMinPercentage * .01 BandwidthMinPercentage, ap.BandwidthAdder, ap.UsageAllocationAmount, ap.UsageAllocationPriority, ap.StartDate, ap.EndDate,
		uom.Code ProductUOM, p.CommoidtyVariableProductIndexID, p.UsageAllocationAvailable, p.BandwidthAvailable, 
		case when p.BandwidthAvailable = 1 then 'Bandwidth'
			 when p.UsageAllocationAvailable = 1 then 'UsageAllocation'
			 else '' 
			 end [Type],
		(
			Select top 1 usageamount from vip_usage where vip_usagetypeid = 1 and vip_accountid = @VIP_AccountID
			and month(StartDate) = month(@Date)
		) bandwidthUsageAmount, 
		--ap.bandwidthUsageAmount - (ap.bandwidthUsageAmount * (BandwidthMinPercentage * .01)) BandwidthUsageAmountLow, 
		--ap.bandwidthUsageAmount + (ap.bandwidthUsageAmount * (BandwidthMaxPercentage * .01)) BandwidthUsageAmountHigh,
		BandwidthLowAdder, BandwidthHighAdder,		
		ap.BrokerCommisionRate, ap.BrokerCommisionRate_Intolerance  
	FROM VIP_AccountProducts ap
		INNER JOIN VIP_Products p ON ap.VIP_ProductID = p.VIP_ProductID
		INNER JOIN VIP_ProductBillingTypes pbt ON p.VIP_ProductBillingTypeID = pbt.VIP_ProductBillingTypeID
		INNER JOIN VIP_ProductPricingTypes ppt ON p.VIP_ProductPricingTypeID = ppt.VIP_ProductPricingTypeID
		INNER JOIN VIP_Utilities u ON p.VIP_UtilityID = u.VIP_UtilityID
		INNER JOIN VIP_UnitsOfMeasure uom ON p.VIP_UnitOfMeasureID = uom.VIP_UnitOfMeasureID
	WHERE VIP_AccountID = @VIP_AccountID
		AND @Date BETWEEN StartDate AND EndDate + ' 11:59:59'
) a
ORDER BY a.UsageAllocationPriority
GO
