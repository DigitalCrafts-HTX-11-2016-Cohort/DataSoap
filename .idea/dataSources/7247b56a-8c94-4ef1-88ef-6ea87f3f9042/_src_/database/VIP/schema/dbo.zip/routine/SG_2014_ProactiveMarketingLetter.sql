
--/*
-- - Author: Bryan Panjavan
-- - Description:
--	EXECUTE [dbo].SG_2014_ProactiveMarketingLetter

--*/
CREATE PROCEDURE [dbo].SG_2014_ProactiveMarketingLetter
AS

	SELECT --TOP 100
		VIPMARKET_SG_ProactiveMarketingLetter_ID
		,CompanyName = UPPER(LEFT(First_Name ,1))+LOWER(SUBSTRING(First_Name ,2,LEN(First_Name )))
					+ ISNULL(' ' + UPPER(LEFT(Last_Name ,1))+LOWER(SUBSTRING(Last_Name ,2,LEN(Last_Name ))),'')

		,BillingAddress = MailingAddress
		,BillingCity = MailingCity
		,BillingState = MailingState
		,BillingZipCode = MailingZip

		,DateTimeStamp = CONVERT(varchar(50), GETDATE(),112)

		,OP1 =  '$'+STUFF(convert(varchar,convert(money,price.FixedBillUnlimitedRate1),1), 1, 0,
						REPLICATE('', 12 - LEN(convert(varchar,convert(money,price.FixedBillUnlimitedRate1),1))))

		,OC1 = CASE
				WHEN Service_State = 'NE' THEN '49314'
				WHEN Service_State = 'WY' AND pr.DivisionRegion = 'CASPER' THEN '77134'
				WHEN Service_State = 'WY' AND pr.DivisionRegion = 'GILLETTE' THEN '77136'
				WHEN Service_State = 'WY' AND pr.DivisionRegion = 'TORRINGTON' THEN '77138'
			END
		
		,OP2 =  '$'+STUFF(convert(varchar,convert(money,price.FixedBillUnlimitedRate2),1), 1, 0,
						REPLICATE('', 12 - LEN(convert(varchar,convert(money,price.FixedBillUnlimitedRate2),1))))
		,OC2 = CASE
				WHEN Service_State = 'NE' THEN '49315'
				WHEN Service_State = 'WY' AND pr.DivisionRegion = 'CASPER' THEN '77135'
				WHEN Service_State = 'WY' AND pr.DivisionRegion = 'GILLETTE' THEN '77137'
				WHEN Service_State = 'WY' AND pr.DivisionRegion = 'TORRINGTON' THEN '77139'
				END
		
		,pr.*
	FROM
		[dbo].[VIPMARKET_SG_ProactiveMarketingLetter] ml
		INNER JOIN dbo.VIPMARKET_SG_ELG_PREMISE pr ON ml.Account_Number = pr.Account_Number
		INNER JOIN VIPMarket_SG_Pricing price ON price.VIPMARKET_SG_Pricing_ID = ml.SelectedRow
	WHERE DateSent IS NULL

	ORDER BY
		pr.Account_Number

--RETURN 0



--BEGIN TRAN

--UPDATE [dbo].[VIPMARKET_SG_ProactiveMarketingLetter] SET DateSent = GETDATE(), DocumentName = '' WHERE VIPMARKET_SG_ProactiveMarketingLetter_ID = 1

--ROLLBACK
GO
