
CREATE PROCEDURE dbo.[GetModulePermissionsByModuleID]
	
	@ModuleID int, 
	@PermissionID int

AS
SELECT *
FROM dbo.vw_ModulePermissions
WHERE (@ModuleID = -1 
			OR ModuleID = @ModuleID
			OR (ModuleID IS NULL AND PermissionCode = 'SYSTEM_MODULE_DEFINITION')
		)
	AND	(PermissionID = @PermissionID OR @PermissionID = -1)

GO
