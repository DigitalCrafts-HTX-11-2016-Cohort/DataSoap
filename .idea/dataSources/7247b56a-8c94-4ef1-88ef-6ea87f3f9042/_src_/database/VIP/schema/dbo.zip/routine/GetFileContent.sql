
CREATE procedure dbo.GetFileContent

@FileId   int,
@PortalID int

as

select Content
from   dbo.Files
where  FileId = @FileId
and    ((dbo.Files.PortalId = @PortalID) or (@PortalID is null and dbo.Files.PortalId is null))


GO
