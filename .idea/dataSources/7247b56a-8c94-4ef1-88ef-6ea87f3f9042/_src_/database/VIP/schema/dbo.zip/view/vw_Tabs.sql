
CREATE VIEW dbo.vw_Tabs  

AS
	SELECT     
		TabID, 
		TabOrder, 
		PortalID, 
		TabName, 
		IsVisible, 
		ParentId, 
		[Level], 
		CASE WHEN LEFT(LOWER(T.IconFile), 6) = 'fileid' THEN (SELECT Folder + FileName FROM dbo.Files WHERE 'fileid=' + CONVERT(varchar, dbo.Files.FileID) = T.IconFile) ELSE T.IconFile END AS IconFile, 
		DisableLink, 
		Title, 
		Description, 
		KeyWords, 
		IsDeleted, 
        SkinSrc, 
        ContainerSrc, 
        TabPath, 
        StartDate, 
        EndDate, 
        Url, 
        CASE WHEN EXISTS (SELECT 1 FROM  dbo.Tabs T2 WHERE T2.ParentId = T.TabId) THEN 'true' ELSE 'false' END AS HasChildren, 
        RefreshInterval, 
        PageHeadText, 
        IsSecure, 
        PermanentRedirect
	FROM dbo.Tabs AS T

GO
