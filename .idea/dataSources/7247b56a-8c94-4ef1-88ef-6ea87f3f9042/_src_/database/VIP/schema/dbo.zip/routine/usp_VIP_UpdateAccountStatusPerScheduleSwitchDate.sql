-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_VIP_UpdateAccountStatusPerScheduleSwitchDate]
	
AS

insert into VIP_AccountInteractionAudit
(VIP_AccountInteractionID, AuditType, AuditLevel, AuditMessage, AuditDateTime)
Select 
distinct VIP_AccountInteractionID, 'Information','High','Account has been terminated as of ' + 
	(
		Select distinct convert(varchar(8),VIP_Accounts.SCH_EnrollSwitchDate,1) from VIP_AccountInteractions
		inner join VIP_Accounts on VIP_Accounts.VIP_AccountID =  VIP_AccountInteractions.VIP_AccountID
		where VIP_AccountInteractions.VIP_AccountInteractionID = VIP_AccountInteractionAudit.VIP_AccountInteractionID
	) + ' per the current customer snapshot file due to customer switching provider',
	GETDATE()
	from VIP_AccountInteractionAudit where VIP_AccountInteractionID in
(
	Select VIP_AccountInteractionID from VIP_AccountInteractions where VIP_AccountID in
	(
		Select vip_accountid from VIP_Accounts 
		where 
		SCH_EnrollSwitchDate < DATEADD(d,1, CONVERT(varchar(8), GETDATE(), 1)) and SwitchFromRetailer = 'VISTA'
		and AccountStatus <> 'Terminated'
	) and VIP_AccountInteractionTypeID = (Select VIP_AccountInteractionTypeID from VIP_AccountInteractionTypes where Code = 'RETAILER_DROP')
)
	
--locate vip accounts with an interaction that already exists and set to complete
update VIP_AccountInteractions 
set Status = 'Complete', EndDateTime=GETDATE()
where VIP_AccountID in
(
	Select vip_accountid from VIP_Accounts 
	where 
	SCH_EnrollSwitchDate < DATEADD(d,1, CONVERT(varchar(8), GETDATE(), 1)) and SwitchFromRetailer = 'VISTA'
	and AccountStatus <> 'Terminated'
) and VIP_AccountInteractionTypeID = (Select VIP_AccountInteractionTypeID from VIP_AccountInteractionTypes where Code = 'RETAILER_DROP')



-----------------------------------------
--insert interaction if it does not exists 
insert into VIP_AccountInteractions
(VIP_AccountInteractionTypeID, VIP_AccountID, VIP_AccountInteractionGUID, InitiatedByUserID, Status, StartDateTime, EndDateTime)
Select 
(Select VIP_AccountInteractionTypeID from VIP_AccountInteractionTypes where code = 'SWITCHED_PROVIDER'),
VIP_AccountID,
NEWID(),
0,
'Complete',
GETDATE(),
GETDATE()
 from VIP_Accounts 
where 
SCH_EnrollSwitchDate < DATEADD(d,1, CONVERT(varchar(8), GETDATE(), 1)) and SwitchFromRetailer = 'VISTA'
and AccountStatus <> 'Terminated'
and VIP_AccountID not in(Select VIP_Accountid from VIP_AccountInteractions where VIP_AccountInteractionTypeID = 12)


insert into VIP_AccountInteractionAudit
(VIP_AccountInteractionID, AuditType, AuditLevel, AuditMessage, AuditDateTime)
Select 
distinct VIP_AccountInteractionID, 'Information','High','Account has been terminated as of ' + 
	(
		Select distinct convert(varchar(8),VIP_Accounts.SCH_EnrollSwitchDate,1) from VIP_Accounts		
		where VIP_Accounts.VIP_AccountID = VIP_AccountInteractions.VIP_AccountID
	) + ' per the current customer snapshot file due to customer switching provider',
	GETDATE()
	 from VIP_AccountInteractions where VIP_AccountID in
	(
		Select vip_accountid from VIP_Accounts 
		where 
		SCH_EnrollSwitchDate < DATEADD(d,1, CONVERT(varchar(8), GETDATE(), 1)) and SwitchFromRetailer = 'VISTA'
		and AccountStatus <> 'Terminated'
	) and VIP_AccountInteractionTypeID = (Select VIP_AccountInteractionTypeID from VIP_AccountInteractionTypes where Code = 'UTILITY_DROP')


--set the account status to terminated
update VIP_Accounts set AccountStatus = 'Terminated'
where 
SCH_EnrollSwitchDate < DATEADD(d,1, CONVERT(varchar(8), GETDATE(), 1)) and SwitchFromRetailer = 'VISTA'
and AccountStatus <> 'Terminated'

GO
