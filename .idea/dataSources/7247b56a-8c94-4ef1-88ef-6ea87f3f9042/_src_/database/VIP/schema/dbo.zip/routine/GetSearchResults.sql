
CREATE procedure dbo.GetSearchResults
	@PortalID int,
	@Word nVarChar(100)
AS
SELECT si.SearchItemID,
	sw.Word,
	siw.Occurrences,
	siw.Occurrences + 1000 as Relevance,
	m.ModuleID,
	tm.TabID,
	si.Title,
	si.Description,
	si.Author,
	si.PubDate,
	si.SearchKey,
	si.Guid,
	si.ImageFileId,
	u.FirstName + ' ' + u.LastName As AuthorName,
	m.PortalId
FROM    dbo.SearchWord sw
	INNER JOIN dbo.SearchItemWord siw ON sw.SearchWordsID = siw.SearchWordsID
	INNER JOIN dbo.SearchItem si ON siw.SearchItemID = si.SearchItemID
	INNER JOIN dbo.Modules m ON si.ModuleId = m.ModuleID
	LEFT OUTER JOIN dbo.TabModules tm ON si.ModuleId = tm.ModuleID
	INNER JOIN dbo.Tabs t ON tm.TabID = t.TabID
	LEFT OUTER JOIN dbo.Users u ON si.Author = u.UserID
WHERE   (((m.StartDate Is Null) OR (GetDate() > m.StartDate)) AND ((m.EndDate Is Null) OR (GetDate() < m.EndDate)))
	AND (((t.StartDate Is Null) OR (GetDate() > t.StartDate)) AND ((t.EndDate Is Null) OR (GetDate() < t.EndDate)))
	AND (sw.Word = @Word) 
	AND (t.IsDeleted = 0) 
	AND (m.IsDeleted = 0) 
	AND (t.PortalID = @PortalID)
ORDER BY Relevance DESC

GO
