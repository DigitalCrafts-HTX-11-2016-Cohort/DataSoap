

CREATE PROCEDURE dbo.MCISS_CacheGet
	@name nvarchar(250)
AS

SELECT
	top 1 *
FROM dbo.MCISS_Cache
WHERE
	[name] = @name
GO
