
CREATE PROCEDURE [dbo].[usp_VIP_GetAccountProductPricingHistory]
	@VIP_AccountID int
AS

SELECT ap.VIP_AccountProductID, ap.VIP_AccountID, ap.VIP_ProductID, p.ProductName, ap.FixedPrice, ap.VariableAdder,
	ap.ServiceFeeAmount, ap.BandwidthPercentage, ap.BandwidthAdder, ap.UsageAllocationAmount, ap.UsageAllocationPriority,
	pbt.Name AS [BillingType], ppt.Name AS [PricingType], p.CommoidtyVariableProductIndexID, p.UtilityProductCode,
	ISNULL(vpip.VariableProductIndexPrice, ap.FixedPrice) Price, ISNULL(vpip.VariableProductServiceFee, ap.ServiceFeeAmount) ServiceFee,
	ISNULL(vpip.EffectiveStartDate, ap.StartDate) StartDate, ISNULL(vpip.EffectiveEndDate, ap.EndDate) EndDate, vpip.EffectiveStartDate
FROM VIP_AccountProducts AS ap
	INNER JOIN VIP_Products AS p ON ap.VIP_ProductID = p.VIP_ProductID
	LEFT OUTER JOIN VIP_VariableProductIndexPrices vpip ON p.CommoidtyVariableProductIndexID = vpip.VIP_VariableProductIndexID
	INNER JOIN VIP_ProductBillingTypes pbt ON p.VIP_ProductBillingTypeID = pbt.VIP_ProductBillingTypeID
	INNER JOIN VIP_ProductPricingTypes ppt ON p.VIP_ProductPricingTypeID = ppt.VIP_ProductPricingTypeID
WHERE ap.VIP_AccountID = @VIP_AccountID
ORDER BY PricingType, vpip.EffectiveStartDate
GO
