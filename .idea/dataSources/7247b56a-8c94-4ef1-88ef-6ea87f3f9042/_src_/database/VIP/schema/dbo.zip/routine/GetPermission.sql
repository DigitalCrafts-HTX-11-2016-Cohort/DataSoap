
CREATE PROCEDURE dbo.GetPermission
	@PermissionID int
AS

SELECT
	[PermissionID],
	[PermissionCode],
	[ModuleDefID],
	[PermissionKey],
	[PermissionName]
FROM
	dbo.Permission
WHERE
	[PermissionID] = @PermissionID


GO
