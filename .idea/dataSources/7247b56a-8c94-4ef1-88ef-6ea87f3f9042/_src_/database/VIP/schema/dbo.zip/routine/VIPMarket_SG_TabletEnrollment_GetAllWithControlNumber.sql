




-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[VIPMarket_SG_TabletEnrollment_GetAllWithControlNumber]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT TOP 500
		te.VIPMarket_SG_TabletEnrollmentID
		,te.[Status]
		,te.VIPMARKET_SG_ELG_PREMISE_ID
		,te.AccountNumber
		,te.ControlNumber
		,te.EmailAddress
		,te.VIPMARKET_SG_PriceRateCode_ID
		,te.PriceRateCode
		,te.DateReceived -- Date we got it is technically the date sold

	--	,prem.VIPMARKET_SG_ELG_PREMISE_ID
		,PremiseStatus = prem.[Status]
		--,prem.Email
		--,prem.PriceOption
		--,prem.SelectedRow
		--,prem.UserID
		--,prem.Enrollment_Date
		--,prem.Confirmation_ID
	--	*
	FROM 
		dbo.VIPMarket_SG_TabletEnrollment te
		LEFT JOIN dbo.VIPMARKET_SG_ELG_PREMISE prem
			ON te.VIPMARKET_SG_ELG_PREMISE_ID = prem.VIPMARKET_SG_ELG_PREMISE_ID
	WHERE (1 = 1)
		AND te.[Status] IN ('New','Ready to Submit')
		AND ISNULL(te.ControlNumber,'') <> ''
		and enrollmentcreatedon >= '2013-04-05'

		AND te.AccountNumber NOT IN ('211013251864','211013416887','211013332821','221010628097','221013094993','221010802305','221011575046','211013946673','221013018586','221012442707','211014117963','211014100872','221012147285') -- Special block requested by Paul
--		AND te.RepID NOT LIKE '%9999%'

		-- Hold anything that comes in from WY after 12:45 PM
		AND NOT
		(
			prem.Service_State = 'WY'
			AND te.EnrollmentCreatedon >= '2013-04-25 12:45:00'
		)        

	ORDER BY 
		te.DateReceived ASC -- very important we do this, reward the first guy

END


GO
