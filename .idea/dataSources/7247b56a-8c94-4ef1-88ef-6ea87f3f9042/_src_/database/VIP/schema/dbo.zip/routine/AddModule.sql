
CREATE PROCEDURE dbo.AddModule
    
	@PortalID                      int,
	@ModuleDefId                   int,
	@ModuleTitle                   nvarchar(256),
	@AllTabs                       bit,
	@Header                        ntext,
	@Footer                        ntext,
	@StartDate                     datetime,
	@EndDate                       datetime,
	@InheritViewPermissions        bit,
	@IsDeleted                     bit

AS

INSERT INTO dbo.Modules ( 
  PortalId,
  ModuleDefId,
  ModuleTitle,
  AllTabs,
  Header,
  Footer, 
  StartDate,
  EndDate,
  InheritViewPermissions,
  IsDeleted
)
values (
  @PortalID,
  @ModuleDefId,
  @ModuleTitle,
  @AllTabs,
  @Header,
  @Footer, 
  @StartDate,
  @EndDate,
  @InheritViewPermissions,
  @IsDeleted
)

select SCOPE_IDENTITY()


GO
