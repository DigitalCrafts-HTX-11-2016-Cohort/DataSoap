
CREATE Procedure [dbo].[usp_VIP_Dynamics_CustomerIDGetPrefixResults]
	@Prefix			varchar(4)
AS

	SELECT DynamicsCustomerID
	FROM VIP_BillingPoints
	WHERE SUBSTRING(DynamicsCustomerID, 1, 4) = @Prefix
	ORDER BY DynamicsCustomerID
GO
