CREATE VIEW dbo.VIP_AccountInteractionAuditView
AS
Select VIP_AccountInteractionAuditID, VIP_AccountInteractionID,
AuditType, AuditLevel, CONVERT(varchar(1000), AuditMessage) AuditMessage, AuditDateTime
, '' Archived 
 from VIP_AccountInteractionAudit
union
Select VIP_AccountInteractionAuditID, VIP_AccountInteractionID,
AuditType, AuditLevel, CONVERT(varchar(1000), AuditMessage) AuditMessage, AuditDateTime
, 'Archived' Archived 
from VIP_Archive..VIP_AccountInteractionAudit
GO
