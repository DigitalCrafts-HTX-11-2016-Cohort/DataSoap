
create procedure dbo.GetSearchSettings

	@ModuleID	int

AS

select     	tm.ModuleID, 
			settings.SettingName, 
			settings.SettingValue
from	dbo.Tabs searchTabs INNER JOIN
		dbo.TabModules searchTabModules ON searchTabs.TabID = searchTabModules.TabID INNER JOIN
        dbo.Portals p ON searchTabs.PortalID = p.PortalID INNER JOIN
        dbo.Tabs t ON p.PortalID = t.PortalID INNER JOIN
        dbo.TabModules tm ON t.TabID = tm.TabID INNER JOIN
        dbo.ModuleSettings settings ON searchTabModules.ModuleID = settings.ModuleID
where   searchTabs.TabName = N'Search Admin'
and		tm.ModuleID = @ModuleID


GO
