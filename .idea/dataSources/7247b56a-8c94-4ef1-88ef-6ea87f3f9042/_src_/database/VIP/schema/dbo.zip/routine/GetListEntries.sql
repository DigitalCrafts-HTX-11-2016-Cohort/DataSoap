
CREATE PROCEDURE dbo.[GetListEntries]

	@ListName nvarchar(50),
	@ParentKey nvarchar(150)

AS
SELECT *
	FROM dbo.vw_Lists
	WHERE ([ListName] = @ListName OR @ListName='')
		AND ([ParentKey]=@ParentKey OR @ParentKey = '')
	ORDER BY [Level], [ListName], [SortOrder], [Text]

GO
