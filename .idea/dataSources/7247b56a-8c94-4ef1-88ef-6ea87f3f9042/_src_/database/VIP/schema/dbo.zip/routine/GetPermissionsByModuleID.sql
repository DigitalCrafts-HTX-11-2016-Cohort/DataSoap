
CREATE PROCEDURE dbo.GetPermissionsByModuleID
	@ModuleID int
AS

SELECT  PermissionID,
	PermissionCode,
	ModuleDefID,
	PermissionKey,
	PermissionName
FROM    dbo.Permission
WHERE   ModuleDefID = (SELECT ModuleDefID FROM dbo.Modules WHERE ModuleID = @ModuleID)
OR 	PermissionCode = 'SYSTEM_MODULE_DEFINITION'
ORDER BY PermissionID

GO
