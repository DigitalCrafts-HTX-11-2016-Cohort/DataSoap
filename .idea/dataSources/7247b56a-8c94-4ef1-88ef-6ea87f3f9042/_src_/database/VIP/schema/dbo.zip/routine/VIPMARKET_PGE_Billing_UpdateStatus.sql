-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE VIPMARKET_PGE_Billing_UpdateStatus
	@VIPMarket_PGE_BillingID int
	,@Status VARCHAR(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	UPDATE VIPMarket_PGE_Billing SET [Status] = @Status WHERE VIP_ESPBillingID = @VIPMarket_PGE_BillingID
END
GO
