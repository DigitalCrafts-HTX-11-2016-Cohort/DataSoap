
/*
 - 2015-12-29 - BPanjavan - Keeping this around for legacy, but making it directly reference the new standard view
*/
CREATE VIEW dbo.VIPMARKET_PGE_DASRView
AS
SELECT     * FROM B2B.v_VIPMARKET_PGE_DASRView

GO
