-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[VIPMarket_NICOR_AccountStatusReport_HU]
AS
BEGIN

declare @Year varchar(10), @YearM1 varchar(10), @YearM2 varchar(10), @YearM3 varchar(10), @YearM4 VARCHAR(10), @YearM5 VARCHAR(10);
set @Year = '2013';
set @YearM1 = CONVERT(integer, @Year) - 1;
set @YearM2 = CONVERT(integer, @Year) - 2;
set @YearM3 = CONVERT(integer, @Year) - 3;
set @YearM4 = CONVERT(integer, @Year) - 4;
set @YearM5 = CONVERT(integer, @Year) + 1;
select 
	   [VIP ID] = CalUsage.vip_accountid, 
	   [Acct No] = CalUsage.UtilityAccountNumber,
	   [Customer] = Customer,
	   [Status] = CalUsage.AccountStatus, 
	   --[Sch Enroll Dt] = isnull(CONVERT(varchar(11), CalUsage.ACT_EnrollSwitchDate), ''),
	   --[Act Enroll Dt] = isnull(CONVERT(varchar(11), CalUsage.ACT_EnrollSwitchDate), ''),
	   [Est Drop Dt] = 
		  CASE 
			WHEN CalUsage.EST_DropDate = '1900-01-01' then '' 
			else CONVERT(varchar(11), CalUsage.EST_DropDate) 
		  end,
	   [Class] = (select top 1 CustomerType from VIPMARKET_NICOR_TRNSCRPT where AccountNumber = UtilityAccountNumber order by VIPMARKET_NICOR_TRNSCRPTID Desc),
	   [Utility] = VIP_Utilities.Code, 
	   [Core] = CalUsage.CoreCustomer,
	   [Mktr] = VIP_Marketers.Code,
	   [YEAR] = @YearM4,
	   --'JanUsg' = sum(case when UsgFOM = @YearM4 + '-01-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   --'FebUsg' = sum(case when UsgFOM = @YearM4 + '-02-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   --'MarUsg' = sum(case when UsgFOM = @YearM4 + '-03-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   --'AprUsg' = sum(case when UsgFOM = @YearM4 + '-04-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   --'MayUsg' = sum(case when UsgFOM = @YearM4 + '-05-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   --'JunUsg' = sum(case when UsgFOM = @YearM4 + '-06-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   --'JulUsg' = sum(case when UsgFOM = @YearM4 + '-07-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   --'AugUsg' = sum(case when UsgFOM = @YearM4 + '-08-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   --'SepUsg' = sum(case when UsgFOM = @YearM4 + '-09-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'OctUsg' = sum(case when UsgFOM = @YearM4 + '-10-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'NovUsg' = sum(case when UsgFOM = @YearM4 + '-11-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'DecUsg' = sum(case when UsgFOM = @YearM4 + '-12-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'YearUsg' = sum(case when year(UsgFOM) = @YearM4 then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   
	   [YEAR] = @YearM3,
	   'JanUsg' = sum(case when UsgFOM = @YearM3 + '-01-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'FebUsg' = sum(case when UsgFOM = @YearM3 + '-02-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'MarUsg' = sum(case when UsgFOM = @YearM3 + '-03-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'AprUsg' = sum(case when UsgFOM = @YearM3 + '-04-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'MayUsg' = sum(case when UsgFOM = @YearM3 + '-05-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'JunUsg' = sum(case when UsgFOM = @YearM3 + '-06-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'JulUsg' = sum(case when UsgFOM = @YearM3 + '-07-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'AugUsg' = sum(case when UsgFOM = @YearM3 + '-08-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'SepUsg' = sum(case when UsgFOM = @YearM3 + '-09-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'OctUsg' = sum(case when UsgFOM = @YearM3 + '-10-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'NovUsg' = sum(case when UsgFOM = @YearM3 + '-11-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'DecUsg' = sum(case when UsgFOM = @YearM3 + '-12-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'YearUsg' = sum(case when year(UsgFOM) = @YearM3 then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   
	   [YEAR] = @YearM2,
	   'JanUsg' = sum(case when UsgFOM = @YearM2 + '-01-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'FebUsg' = sum(case when UsgFOM = @YearM2 + '-02-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'MarUsg' = sum(case when UsgFOM = @YearM2 + '-03-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'AprUsg' = sum(case when UsgFOM = @YearM2 + '-04-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'MayUsg' = sum(case when UsgFOM = @YearM2 + '-05-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'JunUsg' = sum(case when UsgFOM = @YearM2 + '-06-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'JulUsg' = sum(case when UsgFOM = @YearM2 + '-07-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'AugUsg' = sum(case when UsgFOM = @YearM2 + '-08-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'SepUsg' = sum(case when UsgFOM = @YearM2 + '-09-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'OctUsg' = sum(case when UsgFOM = @YearM2 + '-10-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'NovUsg' = sum(case when UsgFOM = @YearM2 + '-11-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'DecUsg' = sum(case when UsgFOM = @YearM2 + '-12-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'YearUsg' = sum(case when year(UsgFOM) = @YearM2 then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),

	   [YEAR] = @YearM1,
	   'JanUsg' = sum(case when UsgFOM = @YearM1 + '-01-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'FebUsg' = sum(case when UsgFOM = @YearM1 + '-02-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'MarUsg' = sum(case when UsgFOM = @YearM1 + '-03-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'AprUsg' = sum(case when UsgFOM = @YearM1 + '-04-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'MayUsg' = sum(case when UsgFOM = @YearM1 + '-05-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'JunUsg' = sum(case when UsgFOM = @YearM1 + '-06-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'JulUsg' = sum(case when UsgFOM = @YearM1 + '-07-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'AugUsg' = sum(case when UsgFOM = @YearM1 + '-08-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'SepUsg' = sum(case when UsgFOM = @YearM1 + '-09-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'OctUsg' = sum(case when UsgFOM = @YearM1 + '-10-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'NovUsg' = sum(case when UsgFOM = @YearM1 + '-11-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'DecUsg' = sum(case when UsgFOM = @YearM1 + '-12-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'YearUsg' = sum(case when year(UsgFOM) = @YearM1 then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   [YEAR] = @Year,
	   'JanUsg' = sum(case when UsgFOM = @Year + '-01-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'FebUsg' = sum(case when UsgFOM = @Year + '-02-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'MarUsg' = sum(case when UsgFOM = @Year + '-03-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'AprUsg' = sum(case when UsgFOM = @Year + '-04-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'MayUsg' = sum(case when UsgFOM = @Year + '-05-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'JunUsg' = sum(case when UsgFOM = @Year + '-06-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'JulUsg' = sum(case when UsgFOM = @Year + '-07-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'AugUsg' = sum(case when UsgFOM = @Year + '-08-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'SepUsg' = sum(case when UsgFOM = @Year + '-09-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'OctUsg' = sum(case when UsgFOM = @Year + '-10-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'NovUsg' = sum(case when UsgFOM = @Year + '-11-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'DecUsg' = sum(case when UsgFOM = @Year + '-12-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'YearUsg' = sum(case when year(UsgFOM) = @Year then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   	[YEAR] = @YearM5,
	   'JanUsg' = sum(case when UsgFOM = @YearM5 + '-01-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'FebUsg' = sum(case when UsgFOM = @YearM5 + '-02-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'MarUsg' = sum(case when UsgFOM = @YearM5 + '-03-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'AprUsg' = sum(case when UsgFOM = @YearM5 + '-04-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'MayUsg' = sum(case when UsgFOM = @YearM5 + '-05-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'JunUsg' = sum(case when UsgFOM = @YearM5 + '-06-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'JulUsg' = sum(case when UsgFOM = @YearM5 + '-07-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'AugUsg' = sum(case when UsgFOM = @YearM5 + '-08-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'SepUsg' = sum(case when UsgFOM = @YearM5 + '-09-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'OctUsg' = sum(case when UsgFOM = @YearM5 + '-10-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'NovUsg' = sum(case when UsgFOM = @YearM5 + '-11-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'DecUsg' = sum(case when UsgFOM = @YearM5 + '-12-01' then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'YearUsg' = sum(case when year(UsgFOM) = @YearM5 then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end),
	   'x' = @YearM5,
	   [VIP ID] = CalUsage.vip_accountid, 
	   [Acct No] = CalUsage.UtilityAccountNumber,
	   [Status] = CalUsage.AccountStatus, 
	   [Est Drop Dt] = 
		  CASE 
			WHEN CalUsage.EST_DropDate = '1900-01-01' then '' 
			else CONVERT(varchar(11), CalUsage.EST_DropDate) 
		  end,
	   [Class] = VIP_AccountClasses.Code,
	   [Utility] = VIP_Utilities.Code, 
	   [Core] = CalUsage.CoreCustomer,
	   [Mktr] = VIP_Marketers.Code
  from 
(
select accts.vip_accountid, 
	 UtilityServiceAccountID,
	 UtilityAccountNumber, 
	 Customer,
	 AccountStatus, 
	 ACT_EnrollSwitchDate, 
	 EST_DropDate,  
		  CoreCustomer,
	 vip_usageid, 
	 UsgFOM, 
	 UsgEOM,  
	 StartDate, 
	 EndDate, 
	 UsgValue = UsageAmount,
		UsgDaysIn =
			case 
				when StartDate <= d.UsgFOM and EndDate > d.UsgEOM then DATEDIFF(D, d.UsgFOM, d.UsgEOM) + 1
				when StartDate <= d.UsgFOM and EndDate < d.UsgEOM then DATEDIFF(D, d.UsgFOM, EndDate)
				when StartDate > d.UsgFOM and EndDate > d.UsgEOM then DATEDIFF(D, StartDate, d.UsgEOM) + 1
				else DATEDIFF(D, StartDate, EndDate)
			end,
		UsgTotalDays = DATEDIFF(D, StartDate, EndDate),
			VIP_UtilityID,
			VIP_MarketerID,
			VIP_AccountClassID		
  from 
	(
		select 
			vip_accountsview.vip_accountid, 
			vip_accountsview.UtilityServiceAccountID,
			UtilityAccountNumber, 
			AccountStatus, 
			ACT_EnrollSwitchDate, 
			EST_DropDate,
			  CoreCustomer = 
			  Case VIP_AccountsView.CoreCustomer  
				When 1 Then 'Yes' 
				Else 'No' 
			  End,
			VIP_UtilityID,
			VIP_MarketerID,
			VIP_AccountClassID,
			Customer = CASE WHEN RTRIM(CompanyName) = '' THEN RTRIM(BillingFirstName) + ' ' + RTRIM(BillingLastName) ELSE RTRIM(CompanyName) END
		  from VIP_AccountsView (nolock)
		  where VIP_AccountsView.VIP_UtilityID = 21
	) as accts
    inner join VIP_UsageView U
		inner join 
		(
			select UsgFOM = dateadd(yy,(yr-1900),dateadd(mm,mn-1,dy-1)), UsgEOM=dateadd(dy, -1, dateadd(yy,(yr-1900),dateadd(mm,mn,dy-1))), yr, mn, dy
			  from (
				select yr = 2009 union select yr = 2010 
				union select yr = 2011 union select yr = 2012 union select yr = 2013 union select yr = 2014 union select yr = 2015 union select yr = 2016 union select yr = 2017 union select yr = 2018 union select yr = 2019 union select yr = 2020
				union select yr = 2021 union select yr = 2022 union select yr = 2023 union select yr = 2024 union select yr = 2025 union select yr = 2026 union select yr = 2027 union select yr = 2028 union select yr = 2029 union select yr = 2030
			  ) as xy,
				   (select mn = 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9 union select 10 union select 11 union select 12) as xm,
				   (select dy = 1) as xd
		) as d	
		  on U.StartDate < d.UsgEOM
		  and U.EndDate >= d.UsgFOM
		  and VIP_UsageTypeID in (1, 2, 5)
      on U.VIP_AccountID = accts.vip_accountId
) as CalUsage 
		    left join VIP_Utilities  (nolock)
		      on VIP_Utilities.VIP_UtilityID = CalUsage.VIP_UtilityID
		    left join VIP_Marketers  (nolock)
		      on VIP_Marketers.VIP_MarketerID = CalUsage.VIP_MarketerID
		    left join VIP_AccountClasses  (nolock)
		      on VIP_AccountClasses.VIP_AccountClassID = CalUsage.VIP_AccountClassID
  group by 
		CalUsage.vip_accountid, 
		CalUsage.UtilityServiceAccountId,
		UtilityAccountNumber,
		Customer,
		CalUsage.AccountStatus, 
		isnull(CONVERT(varchar(11), CalUsage.ACT_EnrollSwitchDate), ''), 
		CalUsage.EST_DropDate,
        VIP_AccountClasses.Code,
		VIP_Utilities.Code, 
		CalUsage.CoreCustomer,
		VIP_Marketers.Code
  order by sum(case when year(UsgFOM) = @YearM1 then case when UsgTotalDays = 0 then 0 else (UsgValue / UsgTotalDays) * UsgDaysIn end else 0 end) desc


END
GO
