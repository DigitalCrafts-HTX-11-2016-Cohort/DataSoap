
CREATE PROCEDURE dbo.GetSearchItems

@PortalID int,
@TabId int,
@ModuleId int

AS

SELECT si.*,
       'AuthorName' = u.FirstName + ' ' + u.LastName,
       t.TabId
FROM   dbo.SearchItem si
	LEFT OUTER JOIN dbo.Users u ON si.Author = u.UserID
	INNER JOIN dbo.Modules m ON si.ModuleId = m.ModuleID 
	INNER JOIN dbo.TabModules tm ON m.ModuleId = tm.ModuleID 
	INNER JOIN dbo.Tabs t ON tm.TabID = t.TabID
	INNER JOIN dbo.Portals p ON t.PortalID = p.PortalID
WHERE (p.PortalId = @PortalID or @PortalID is null)
	AND   (t.TabId = @TabId or @TabId is null)
	AND   (m.ModuleId = @ModuleId or @ModuleId is null)
ORDER BY PubDate DESC


GO
