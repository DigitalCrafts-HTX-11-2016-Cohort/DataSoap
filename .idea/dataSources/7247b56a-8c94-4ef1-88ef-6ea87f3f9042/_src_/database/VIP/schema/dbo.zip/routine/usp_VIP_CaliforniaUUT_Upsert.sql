-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE usp_VIP_CaliforniaUUT_Upsert
	@City varchar(50), 
	@UtiltiyTaxName varchar(20),
	@UtilityTaxClass varchar(20),
	@UtilityTaxPercentage numeric(18,5)	

AS
BEGIN

IF EXISTS(Select * from dbo.VIP_CaliforniaUUT where City = @City and UtilityTaxName = @UtiltiyTaxName and UtilityTaxClass like '%' + @UtilityTaxClass + '%')	
Begin
	Update VIP_CaliforniaUUT set 	
	UtilityTaxClass = @UtilityTaxClass,
	UtilityTaxPercentage = @UtilityTaxPercentage,
	DatePosted = getdate()
	where City = @City and UtilityTaxName = @UtiltiyTaxName and UtilityTaxClass like '%' + @UtilityTaxClass + '%'
End
else
begin
	Insert Into VIP_CaliforniaUUT
	(City, UtilityTaxName, UtilityTaxClass, UtilityTaxPercentage, DatePosted)
	values
	(@City, @UtiltiyTaxName, @UtilityTaxClass, @UtilityTaxPercentage, getdate())
end

END
GO
