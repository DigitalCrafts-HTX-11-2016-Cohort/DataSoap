-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE usp_VIP_MarketerEntryRemoveOldDeals	
AS

delete VIPMARKET_Meters where VIP_BatchEnrollEntryID in
(
	Select VIP_BatchEnrollEntryID from VIP_BatchEnrollmentEntries 
	where BatchEnrollmentStatus = 'Broker-Pending' 
	and DATEDIFF(d,getdate(), DATEADD(d,30, LoadedDateTime)) <= 0 
)

delete VIPMARKET_Usage where VIP_BatchEnrollEntryID in
(
	Select VIP_BatchEnrollEntryID from VIP_BatchEnrollmentEntries 
	where BatchEnrollmentStatus = 'Broker-Pending' 
	and DATEDIFF(d,getdate(), DATEADD(d,30, LoadedDateTime)) <= 0 
)

delete VIP_BatchEnrollmentEntries_Notes where VIP_BatchEnrollEntryID in
(
	Select VIP_BatchEnrollEntryID from VIP_BatchEnrollmentEntries 
	where BatchEnrollmentStatus = 'Broker-Pending' 
	and DATEDIFF(d,getdate(), DATEADD(d,30, LoadedDateTime)) <= 0 
)

delete VIP_BatchEnrollmentEntries where VIP_BatchEnrollEntryID in
(
	Select VIP_BatchEnrollEntryID from VIP_BatchEnrollmentEntries 
	where BatchEnrollmentStatus = 'Broker-Pending' 
	and DATEDIFF(d,getdate(), DATEADD(d,30, LoadedDateTime)) <= 0 
)
GO
