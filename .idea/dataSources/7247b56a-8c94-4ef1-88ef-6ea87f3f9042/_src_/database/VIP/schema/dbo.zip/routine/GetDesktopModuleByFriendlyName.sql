
CREATE procedure dbo.GetDesktopModuleByFriendlyName

	@FriendlyName    nvarchar(128)

as

select *
from   dbo.DesktopModules
where  FriendlyName = @FriendlyName


GO
