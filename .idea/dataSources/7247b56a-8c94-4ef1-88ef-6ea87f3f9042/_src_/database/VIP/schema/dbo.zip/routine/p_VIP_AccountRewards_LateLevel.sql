

CREATE PROC dbo.p_VIP_AccountRewards_LateLevel
    (
      @userName VARCHAR(100) = ''
    )
AS
    BEGIN

        DECLARE @LateLimit DECIMAL = 15.00
        --DECLARE @userName VARCHAR(100) = '235'
        BEGIN TRAN;

        WITH    allRewards
                  AS ( SELECT   VIP_AccountID ,
                                Reward_Date ,
                                ROW_NUMBER() OVER ( PARTITION BY VIP_AccountID ORDER BY Reward_Date DESC ) AS RowNumber
                       FROM     dbo.VIP_AccountRewards
                     ),
                latestReward
                  AS ( SELECT   *
                       FROM     allRewards
                       WHERE    allRewards.RowNumber = 2
                     ),
                LateLevels
                  AS ( SELECT   lateLevels.VIP_AccountID ,
                                MAX(LateLevel) AS LateLevel
                       FROM     [Accounting].[mv_Rpt_Aging_FromAgingMV_ToATransactionsCreditRatingBalanceAsOf] lateLevels
                                LEFT JOIN latestReward rwd ON rwd.VIP_AccountID = lateLevels.VIP_AccountID
                       WHERE    ( rwd.VIP_AccountID IS NULL
                                  AND DATEDIFF(DAY, AsOfDate, GETDATE()) <= 90
                                )
                                OR ( rwd.VIP_AccountID IS NOT NULL
                                     AND lateLevels.AsOfDate > rwd.Reward_Date
                                   )
                       GROUP BY lateLevels.VIP_AccountID
                     )--SELECT * FROM LateLevels INNER JOIN dbo.VIP_AccountRewards ON VIP_AccountRewards.VIP_AccountID = LateLevels.VIP_AccountID ORDER BY VIP_AccountRewards.VIP_AccountID
					 ,
                perfectCustomers
                  AS ( SELECT   rwd.VIP_AccountID ,
                                0.00 AS LateLevel
                       FROM     dbo.VIP_AccountRewards rwd
                                LEFT JOIN [Accounting].[mv_Rpt_Aging_FromAgingMV_ToATransactionsCreditRatingBalanceAsOf] lateLevels ON lateLevels.VIP_AccountID = rwd.VIP_AccountID
                                                              --AND lateLevels.LateLevel IS NOT NULL
                       WHERE    rwd.GoodStanding_Flag = 0
                                AND rwd.ExportedOn IS NULL
                                AND rwd.DeletedOn IS NULL
                                AND rwd.RejectedOn IS NULL
                                AND lateLevels.LateLevel IS NULL
                     ),
                allGoodStanding_Unexported_Rewards
                  AS ( SELECT   *
                       FROM     LateLevels
                       UNION ALL
                       SELECT   *
                       FROM     perfectCustomers
                     )
            --SELECT * FROM allGoodStanding_Unexported_Rewards
            UPDATE  rewards
            SET     rewards.ModifiedOn = GETDATE() ,
                    rewards.ModifiedBy = @userName ,
                    rewards.RejectedOn = CASE WHEN allGoodStanding_Unexported_Rewards.LateLevel > @LateLimit
                                              THEN GETDATE()
                                         END ,
                    rewards.Notes = CASE WHEN allGoodStanding_Unexported_Rewards.LateLevel > @LateLimit
                                         THEN 'This account is not currently in good standing as they have exceeded the late limit.'
                                         ELSE ''
                                    END ,
                    rewards.GoodStanding_Flag = CASE WHEN allGoodStanding_Unexported_Rewards.LateLevel <= @LateLimit
                                                     THEN 1
                                                     ELSE 0
                                                END
			--SELECT *
            FROM    dbo.VIP_AccountRewards rewards
                    INNER JOIN allGoodStanding_Unexported_Rewards ON allGoodStanding_Unexported_Rewards.VIP_AccountID = rewards.VIP_AccountID
            WHERE   GoodStanding_Flag = 0
                    AND RejectedOn IS NULL
                    AND DeletedOn IS NULL
                    AND ExportedOn IS NULL

        COMMIT

    END


GO
