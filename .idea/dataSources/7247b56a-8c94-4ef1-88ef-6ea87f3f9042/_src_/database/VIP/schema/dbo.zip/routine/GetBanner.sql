
create procedure dbo.GetBanner

@BannerId int,
@VendorId int,
@PortalID int

as

select B.BannerId,
       B.VendorId,
       'ImageFile' = case when F.FileName is null then B.ImageFile else F.Folder + F.FileName end,
       B.BannerName,
       B.Impressions,
       B.CPM,
       B.Views,
       B.ClickThroughs,
       B.StartDate,
       B.EndDate,
       'CreatedByUser' = U.FirstName + ' ' + U.LastName,
       B.CreatedDate,
       B.BannerTypeId,
       B.Description,
       B.GroupName,
       B.Criteria,
       B.URL,        
       B.Width,
       B.Height
from   dbo.Banners B 
inner join dbo.Vendors V ON B.VendorId = V.VendorId 
left outer join dbo.Users U ON B.CreatedByUser = U.UserID
left outer join dbo.Files F on B.ImageFile = 'FileId=' + convert(varchar,F.FileID)
where  B.BannerId = @BannerId
and    B.VendorId = @VendorId
GO
