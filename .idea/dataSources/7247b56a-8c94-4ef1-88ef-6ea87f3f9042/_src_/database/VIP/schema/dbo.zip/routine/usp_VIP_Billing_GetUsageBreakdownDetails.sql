
/*
 - 2015-11-20 - BPanjavan - Dealt with Usage Breakdown Date FLattening it out as a result of mass-market swing calculations
*/
CREATE procedure [dbo].[usp_VIP_Billing_GetUsageBreakdownDetails]
	@VIP_UsageID int,
	@VIP_InvoiceID int
	AS

declare @UsageStartDate smalldatetime
declare @UsageEndDate smalldatetime

Select @UsageStartDate = (Select StartDate from vip_usage where vip_usageid = @VIP_UsageID)
Select @UsageEndDate = (Select EndDate from vip_usage where vip_usageid = @VIP_UsageID)

Select *, 
case when Inverse = 0 then 0
else (UsageAmount/Inverse)-UsageAmount end 
FuelAmount 
from
(
	SELECT @VIP_InvoiceID VIP_InvoiceID, u.VIP_AccountID, ub.VIP_UsageBreakdownID, ub.VIP_UsageBreakdownTypeID, ub.VIP_UsageID, 0 VIP_ProductID,
		ubt.Code UsageBreakdownTypeCode, '' ProductUOM, 0.0 VariableAdder, 0.0 AdjustedCommodityPrice, ub.UsageAmount, ub.UsageAmount AdjustedUsageAmount,
		u.UnitOfMeasure UsageAmountUOM,	UsageDate = CONVERT(DATETIME, CONVERT(VARCHAR(50), ub.UsageDate,112) ), 0.0 CommodityTotal, '' ServiceFeeType, 0.0 ServiceFeeBlank, ub.TransportAmount, 0.0 AdjustedTransportAmount, 0.0 TransportTotal,
		 0.0 AdjustedFuelAmount, 0.0 FuelTotal, 0 IsUsageAllocation,
		 --ub.FuelAmount, --0.0 CommodityPrice
		ISNULL(
		(
			Select top 1 inverse from dbo.VIP_UtilityFuel where vip_utilityid in
			(
				Select vip_utilityid from vip_accounts where vip_accountid = u.VIP_AccountID
			) and effectivedate <= ub.UsageDate order by effectivedate desc
		),0) Inverse,	
		ISNULL(
		(
			Select top 1 Line_Loss from dbo.VIP_UtilityFuel where vip_utilityid in
			(
				Select vip_utilityid from vip_accounts where vip_accountid = u.VIP_AccountID
			) and effectivedate < ub.UsageDate order by effectivedate desc
		),0) Line_Loss,
		(
			Select VIP_VariableProductIndexPrices.VariableProductServiceFee from 
			VIP_VariableProductIndexes 
			inner join VIP_VariableProductIndexPrices 
			on VIP_VariableProductIndexPrices.VIP_VariableProductIndexID = VIP_VariableProductIndexes.VIP_VariableProductIndexID
			where Code in
			(
				Select VIP_Products.UtilityProductCode from VIP_AccountProducts 
				inner join VIP_Products on VIP_Products.VIP_ProductID = VIP_AccountProducts.VIP_ProductID
				where VIP_AccountID = u.VIP_AccountID
				and StartDate <= ub.UsageDate and EndDate >= ub.UsageDate
			)
			and EffectiveStartDate <= ub.UsageDate and EffectiveEndDate > ub.UsageDate
		) ServiceFee,
		(Select sum(usageamount) from VIP_Usage where VIP_UsageID = @VIP_UsageID) TotalUsageAmount,
		(
			Select avg(VIP_VariableProductIndexPrices.VariableProductIndexPrice)
			from VIP_AccountProducts 
			inner join VIP_Products on VIP_Products.VIP_ProductID = VIP_AccountProducts.VIP_ProductID
			inner join VIP_VariableProductIndexes on VIP_VariableProductIndexes.VIP_VariableProductIndexID = VIP_Products.CommoidtyVariableProductIndexID
			inner join VIP_VariableProductIndexPrices on VIP_VariableProductIndexPrices.VIP_VariableProductIndexID = VIP_VariableProductIndexes.VIP_VariableProductIndexID
			where VIP_AccountID = u.VIP_AccountID
			and VIP_VariableProductIndexPrices.EffectiveStartDate <= ub.UsageDate and VIP_VariableProductIndexPrices.EffectiveEndDate >= ub.UsageDate
		) CommodityPrice,
		(
			Select avg(VIP_VariableProductIndexPrices.VariableProductIndexPrice)
			from VIP_AccountProducts 
			inner join VIP_Products on VIP_Products.VIP_ProductID = VIP_AccountProducts.VIP_ProductID
			inner join VIP_VariableProductIndexes on VIP_VariableProductIndexes.VIP_VariableProductIndexID = VIP_Products.BandwidthVariableProductIndexID
			inner join VIP_VariableProductIndexPrices on VIP_VariableProductIndexPrices.VIP_VariableProductIndexID = VIP_VariableProductIndexes.VIP_VariableProductIndexID
			where VIP_AccountID = u.VIP_AccountID		
			and VIP_VariableProductIndexPrices.EffectiveStartDate <= ub.UsageDate and VIP_VariableProductIndexPrices.EffectiveEndDate >= ub.UsageDate
			--and VIP_VariableProductIndexPrices.EffectiveStartDate <= ub.UsageDate and VIP_VariableProductIndexPrices.EffectiveEndDate + '23:59:59' > ub.UsageDate
		) GasDailyAverage,
		ISNULL(
			(
				Select top 1 Fuel
				from VIP_AccountProducts 
				where VIP_AccountID = u.VIP_AccountID
				and VIP_AccountProducts.StartDate <= ub.UsageDate and VIP_AccountProducts.EndDate >= ub.UsageDate
			) 
		, 0) Fuel
	FROM VIP_UsageBreakdowns ub
		INNER JOIN VIP_UsageBreakdownTypes ubt ON ub.VIP_UsageBreakdownTypeID = ubt.VIP_UsageBreakdownTypeID
		INNER JOIN VIP_Usage u ON ub.VIP_UsageID = u.VIP_UsageID
	WHERE ub.VIP_UsageID = @VIP_UsageID
) a
ORDER BY VIP_UsageBreakdownID, UsageDate
GO
