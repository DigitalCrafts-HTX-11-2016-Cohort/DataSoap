
CREATE VIEW dbo.[vw_Lists]
AS
	SELECT     
		EntryID, 
		ListName, 
		Value, 
		Text, 
		[Level], 
		SortOrder, 
		DefinitionID, 
		ParentID, 
		Description,
		PortalID, 
		SystemList,
		dbo.GetListParentKey(ParentID, ListName, N'ParentKey', 0) AS ParentKey, 
		dbo.GetListParentKey(ParentID, ListName, N'Parent', 0) AS Parent, 
		dbo.GetListParentKey(ParentID, ListName, N'ParentList', 0) AS ParentList,
		(SELECT MAX(SortOrder) FROM dbo.[Lists] WHERE (ListName = L.ListName) AND (ParentID = L.ParentID)) AS MaxSortOrder,
		(SELECT COUNT(EntryID) FROM dbo.[Lists] AS Lists_1 WHERE (ListName = L.ListName) AND (ParentID = L.ParentID)) AS EntryCount,
		(SELECT COUNT(DISTINCT ParentID) FROM dbo.[Lists] AS Lists_2 WHERE (ParentID = L.EntryID)) AS HasChildren
	FROM  dbo.[Lists] AS L

GO
