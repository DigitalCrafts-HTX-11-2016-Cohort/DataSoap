CREATE procedure dbo.AddPortalAlias

@PortalID int,
@HTTPAlias nvarchar(200)

as

INSERT INTO dbo.PortalAlias 
(PortalID, HTTPAlias)
VALUES
(@PortalID, @HTTPAlias)

select SCOPE_IDENTITY()


GO
