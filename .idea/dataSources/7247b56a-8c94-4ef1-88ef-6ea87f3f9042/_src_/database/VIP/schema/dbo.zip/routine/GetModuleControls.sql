
CREATE PROCEDURE dbo.GetModuleControls
	
	@ModuleDefId int

AS
	SELECT *     
	FROM dbo.ModuleControls
	WHERE  ((ModuleDefId is null and @ModuleDefId is null) or (ModuleDefId = @ModuleDefId))
	ORDER BY  ControlKey, ViewOrder
GO
