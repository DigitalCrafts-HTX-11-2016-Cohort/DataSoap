


CREATE PROCEDURE [dbo].[usp_VIP_InvoiceItemMasks]
	@VIP_InvoiceID int
AS

SELECT ii.VIP_InvoiceItemID, ii.PeriodStartDate, ii.PeriodEndDate, ii.StartUsage, ii.EndUsage, u.StartDate UsageStartDate,
	u.EndDate UsageEndDate, u.BeginRead UsageStartRead, u.EndRead UsageEndRead, iit.DefaultMask,
	(SELECT MaskText FROM VIP_AccountInvoiceItemTypeMasks WHERE VIP_AccountID = ii.VIP_AccountID AND VIP_InvoiceItemTypeID = ii.VIP_InvoiceItemTypeID) AccountMask
FROM VIP_InvoiceItems ii
	INNER JOIN VIP_InvoiceItemTypes iit ON ii.VIP_InvoiceItemTypeID = iit.VIP_InvoiceItemTypeID
	LEFT OUTER JOIN VIP_Usage u ON ii.VIP_UsageID = u.VIP_UsageID
WHERE VIP_InvoiceID = @VIP_InvoiceID and addeditem = 0
GO
