
CREATE PROCEDURE dbo.[GetRolesByUser]
    
	@UserID        int,
	@PortalID      int

AS

SELECT dbo.Roles.RoleName,
       dbo.Roles.RoleId
	FROM dbo.UserRoles
		INNER JOIN dbo.Users on dbo.UserRoles.UserId = dbo.Users.UserId
		INNER JOIN dbo.Roles on dbo.UserRoles.RoleId = dbo.Roles.RoleId
	WHERE  dbo.Users.UserId = @UserID
		AND    dbo.Roles.PortalId = @PortalID
		AND    (EffectiveDate <= getdate() or EffectiveDate is null)
		AND    (ExpiryDate >= getdate() or ExpiryDate is null)

GO
