

/* ========================================================
-- Author:		Bryan Panjavan\Debra Johnson
-- Created:     18Jul2013
-- Modified:    01Aug2013
-- Location:    IEX-SQL-01.VIP
-- Department:  Billing
-- Description: Automate the process of sending a “credit transaction” to NICOR
--              Modified to exclude accounts returned to VISTA for collection
-- Version:     v2
	2015-09-29 - BPanjavan - Add filter to exclude for accounts that are in Terminated status: AND acc.AccountStatus <> 'Terminated'
	2015-10-22 - BPanjavam - Replaced my name with the VIP User Name
 ========================================================*/

CREATE PROCEDURE [dbo].[VIPMarket_NICOR_SUPLBIILL_InsertDirectPaymentsToVista]
(
	@userName VARCHAR(100) = ''-- the generic process passes this in, but it's not used in this procedure
)
AS

BEGIN TRY

    /*
    NICOR Customer payment to Outboudn Supplier bill record

    */
    BEGIN TRAN

    -- Query NICOR payments
    ;WITH tblNICORDirectPayments AS
    (
	    SELECT 
		    acc.UtilityAccountNumber
		    ,acc.CompanyName
		    ,acc.ServiceFirstName
		    ,acc.ServiceLastName
		    ,pmt.PaymentAmount
		    ,pmt.PaymentDate
		    ,pmt.CheckNumber
		    ,pmt.PaidTo
	    FROM 
		    dbo.VIP_Accounts acc
		    INNER JOIN VIP_Utilities util ON acc.VIP_UtilityID = util.VIP_UtilityID
		    INNER JOIN VIP_BillingPointAccounts bpa ON acc.VIP_AccountID = bpa.VIP_AccountID
		    INNER JOIN VIP_Payments pmt ON pmt.VIP_BillingPointID = bpa.VIP_BillingPointID
	    WHERE (1 = 1)
		    AND util.Code = 'NICOR'
		    AND PaidTo = 'Vista Energy Marketing'
			AND pmt.PaidTo NOT IN('ETF')
			AND acc.AccountStatus <> 'Terminated'
    )
    ,tblLatestInvoice AS
    (
	    SELECT
		    inv.*
	    FROM
		    VIPMARKET_NICOR_SUPLBILL inv
		    INNER JOIN 
		    (
			    SELECT
				    VIPMARKET_NICOR_SUPLBILLID = MAX(VIPMARKET_NICOR_SUPLBILLID)
				    ,AccountNumber
			    FROM
				    VIPMARKET_NICOR_SUPLBILL
			    GROUP BY
				    AccountNumber		
		    ) mk1
		    ON inv.VIPMARKET_NICOR_SUPLBILLID = mk1.VIPMARKET_NICOR_SUPLBILLID
			    AND inv.AccountNumber = mk1.AccountNumber
    )
    ,tblDroppedBalance AS
    (
	    SELECT
		    AccountNumber
		    ,TransactionAmount = SUM(CONVERT(DECIMAL(18,8), TransactionAmount) )
		    ,TransactionDate = MAX(TransactionDate)
	    FROM    
		    dbo.VIPMARKET_NICOR_CUSTPMNT
	    WHERE   
		    TransactionCode = 'T'
	    GROUP BY
		    AccountNumber
    )
    insert into vipmarket_nicor_suplbill (SupplierId, PoolId, PremiseId, AccountNumber, Charge1, Charge1Description, Charge2, Charge2Description, Charge3, Charge3Description, BillPeriodBeginDate, BillPeriodEndDate, RecordType, UtilityContractId, SupplierContractId, BillNumber, Status, StatusDescription, InsertBy, UpdateBy, LastResponseType, AccountInteractionGuid)
    SELECT 
	    inv.SupplierId
	    ,inv.PoolId
	    ,inv.PremiseId
	    ,inv.AccountNumber
	    ,Charge1 = CONVERT(decimal(18,2),pmt.PaymentAmount * -1.0)
	    ,Charge1Description = 'SPPMTRCD'
	    ,Charge2 = 0
	    ,Charge2Description = ''
	    ,Charge3 = 0
	    ,Charge3Description = ''
	    ,inv.BillPeriodBeginDate
	    ,inv.BillPeriodEndDate
	    ,RecordType = 'A'
	    ,inv.UtilityContractId
	    ,inv.SupplierContractId
	    ,inv.BillNumber
	    ,[Status] = 'Loaded'
	    ,StatusDescription = 'Check#[' + pmt.CheckNumber + '] ARDate[' + CONVERT(varchar(50),pmt.PaymentDate,1) + ']'
	    ,InsertBy = 'NICOR_Invoice_CTS'
	    ,UpdateBy = 'NICOR_Invoice_CTS'
	    ,LastResponseType = ''
	    ,INV.AccountInteractionGuid

	    --,tblNICORTerms.EstimatedEndDate
	    --,CASE WHEN CONVERT(VARCHAR(50), pmt.PaymentDate) >= tblNICORTerms.EstimatedEndDate THEN 'Y' ELSE 'N' END

    --	,tblDroppedBalance.*
    FROM
	    tblLatestInvoice inv
	    INNER JOIN tblNICORDirectPayments pmt
		    ON inv.AccountNumber = pmt.UtilityAccountNumber
    	
	    LEFT JOIN VIPMARKET_NICOR_SUPLBILL pmtAdjustmentOut
		    ON pmt.UtilityAccountNumber = pmtAdjustmentOut.AccountNumber
			    AND pmtAdjustmentOut.RecordType = 'A'
			    AND CONVERT(decimal(18,2),pmt.PaymentAmount * -1.0) = pmtAdjustmentOut.Charge1
			    AND pmtAdjustmentOut.Charge1Description = 'SPPMTRCD'
			    AND pmtAdjustmentOut.InsertDate >= pmt.PaymentDate -- this should help not throw out the baby with the bath-water

			    -- Can't rely on this field since it gets wiped out
			    --AND pmtAdjustmentOut.StatusDescription LIKE '%' + pmt.CheckNumber + '%'
			    --AND pmtAdjustmentOut.StatusDescription LIKE '%' + CONVERT(varchar(50), pmt.PaymentDate, 1) + '%'
	    --LEFT JOIN tblNICORTerms
	    --	ON pmt.UtilityAccountNumber = tblNICORTerms.AccountNumber

	    LEFT JOIN tblDroppedBalance										
		    ON pmt.UtilityAccountNumber = tblDroppedBalance.AccountNumber
    WHERE (1 = 1)
	    AND pmtAdjustmentOut.VIPMARKET_NICOR_SUPLBILLID IS NULL
      AND   tblDroppedBalance.AccountNumber IS NULL	-- !! - VERY IMPORTANT, we ONLY want to send payments for customers who haven't had their balances dropped to us


		PRINT('[dbo].[VIPMarket_NICOR_SUPLBIILL_InsertDirectPaymentsToVista] - Execution Complete.  Committing Transaction')
		COMMIT
  
		SELECT 'SUCCESS' -- return a table since the IT Ops Generic process requires it      

	END TRY
	BEGIN CATCH
		PRINT('Execution Error.  Rolling back transaction')
		ROLLBACK
		
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;
		
		SET @ErrorMessage = ERROR_MESSAGE()
		SET @ErrorSeverity = ERROR_SEVERITY()
		SET @ErrorState = ERROR_STATE()
		
		PRINT('ERROR_NUMBER: ' + CONVERT(varchar(100), ERROR_NUMBER()) )
		PRINT('ERROR_SEVERITY: ' + CONVERT(varchar(100), @ErrorSeverity) )
		PRINT('ERROR_STATE: ' + CONVERT(varchar(100), @ErrorState) )
		PRINT('ERROR_PROCEDURE: ' + CONVERT(varchar(100), ERROR_PROCEDURE()) )
		PRINT('ERROR_LINE: ' + CONVERT(varchar(100), ERROR_LINE()) )
		PRINT('ERROR_MESSAGE: ' + CONVERT(varchar(100), @ErrorMessage) )

		-- Bubble up the error
		RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
	END CATCH
GO
