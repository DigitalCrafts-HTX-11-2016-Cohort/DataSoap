
CREATE procedure dbo.AddHostSetting

@SettingName   nvarchar(50),
@SettingValue  nvarchar(256),
@SettingIsSecure bit

as

insert into dbo.HostSettings (
  SettingName,
  SettingValue,
  SettingIsSecure
) 
values (
  @SettingName,
  @SettingValue,
  @SettingIsSecure
)


GO
