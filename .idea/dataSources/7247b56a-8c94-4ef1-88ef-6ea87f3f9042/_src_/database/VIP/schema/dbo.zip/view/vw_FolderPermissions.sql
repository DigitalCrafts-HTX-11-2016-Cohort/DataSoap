
CREATE VIEW dbo.vw_FolderPermissions
AS
SELECT     
	FP.FolderPermissionID, 
	F.FolderID, 
	F.FolderPath, 
	P.PermissionID, 
	FP.RoleID, 
	CASE FP.RoleID
		when -1 then 'All Users'
		when -2 then 'Superuser'
		when -3 then 'Unauthenticated Users'
		else 	R.RoleName
	END AS 'RoleName',
	FP.AllowAccess, 
	FP.UserID,
	U.Username,
	U.DisplayName, 
	P.PermissionCode, 
	P.PermissionKey, 
	P.PermissionName, 
	F.PortalID
FROM dbo.FolderPermission AS FP 
	LEFT OUTER JOIN dbo.Folders AS F ON FP.FolderID = F.FolderID 
	LEFT OUTER JOIN dbo.Permission AS P ON FP.PermissionID = P.PermissionID 
	LEFT OUTER JOIN dbo.Roles AS R ON FP.RoleID = R.RoleID
	LEFT OUTER JOIN dbo.Users AS U ON FP.UserID = U.UserID

GO
