
CREATE PROCEDURE dbo.[CanDeleteSkin]
	@SkinType char(1),
	@SkinFolderName nvarchar(200) 
AS
BEGIN

    if exists(select * from dbo.Skins where SkinSrc like '%![' + @SkinType + '!]' + @SkinFolderName + '%' ESCAPE '!')
		select 0
	else
	begin
        if exists(select * from dbo.Tabs where (SkinSrc like '%![' + @SkinType + '!]' + @SkinFolderName + '%' ESCAPE '!') or (ContainerSrc like '%![' + @SkinType + '!]' + @SkinFolderName + '%' ESCAPE '!'))
            select 0
        else
        begin
            if exists(select * from dbo.TabModules where ContainerSrc like '%![' + @SkinType + '!]' + @SkinFolderName + '%' ESCAPE '!')
                select 0
            else
                select 1
        end
	end
	
END

GO
