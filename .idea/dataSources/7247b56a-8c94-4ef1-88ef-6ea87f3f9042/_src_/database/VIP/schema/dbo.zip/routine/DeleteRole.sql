
CREATE procedure dbo.DeleteRole

@RoleId int

as

delete 
from dbo.FolderPermission
where  RoleId = @RoleId

delete 
from dbo.ModulePermission
where  RoleId = @RoleId

delete 
from dbo.TabPermission
where  RoleId = @RoleId

delete 
from dbo.Roles
where  RoleId = @RoleId


GO
