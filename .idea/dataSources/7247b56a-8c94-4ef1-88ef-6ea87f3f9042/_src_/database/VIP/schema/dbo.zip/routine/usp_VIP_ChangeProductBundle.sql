-- =============================================
-- Author:		<Jared Becker,ChangeProductBundle>
-- Create date: <5/2/2014>
-- Description:	<The idea behind this is to be able 
--to pass a bundleID with an account ID and have it update the accountproduct and bundle tables to the correct ID>
-- =============================================
CREATE PROCEDURE  [dbo].[usp_VIP_ChangeProductBundle]
 @AccountID INT,
 @ProductBundleID INT,
 @ForTestingYES VARCHAR(5) ='no'
AS
BEGIN

	SET NOCOUNT ON;

 BEGIN TRY
    BEGIN TRAN


    DECLARE @ReturnMessage VARCHAR(100)
    DECLARE @ReturnStatus VARCHAR(100)
    --DECLARE @ForTestingYES VARCHAR(5)



	----TO RUN Test SCENARIOS USE The FOLLOWING:
    --SET @ForTestingYES = 'Yes'
    --SET @AccountID = '188663'
    --SET @ProductBundleID = '43'
    SET @ReturnMessage = 'The ProductIDs that where applied to this accountID are: '


    IF OBJECT_ID('tempdb..#tempBundler') IS NOT NULL
        DROP TABLE #tempBundler
    IF OBJECT_ID('tempdb..#oldProductID') IS NOT NULL
        DROP TABLE #oldProductID

--OriginalProductID and new product id temp tables created here

    SELECT  ROW_NUMBER() OVER ( ORDER BY startdate ASC ) RowNumber ,
            VIP_AccountProductID ,
            vip_accountID ,
            vip_productid
	INTO    #oldProductID
    FROM    dbo.VIP_AccountProducts
    WHERE   VIP_AccountID = @AccountID --257697
   ORDER BY StartDate ASC

    SELECT  ROW_NUMBER() OVER ( ORDER BY VIP_ProductBundleItemID ) BundlerRowNumber ,
            VIP_ProductBundleItemID AS NewProductBundleItemID,
			VIP_ProductID AS NewProductID
    INTO    #tempbundler
    FROM    dbo.VIP_ProductBundleItems
    WHERE   VIP_ProductBundleID = @ProductBundleID --242
   ORDER BY VIP_ProductBundleItemID asc

	--Will only Show up if @ForTestingYES is set = 'Yes'
    IF @ForTestingYES = 'Yes'
        BEGIN
            SELECT  'New ProductINfo' AS TempBundlerTable ,
                    *
            FROM    #tempBundler
            SELECT  'OldProductIDINFO' AS SomeOldInfo ,
                    *
            FROM    #oldProductID

            ForTestingBranch:
        END

	/*Branch one is for all validation purposes. If there is anything caught here pass goto branch three to skip any database changes. 
	We may want to change this so each error is written to a table variable so all errors found can be presented at once to the user.*/
    Branch_one:
    IF ( SELECT COUNT(newproductbundleitemID)
         FROM   #tempbundler
       ) <> ( SELECT COUNT(vip_productid)
             FROM   #oldProductID
           )
        BEGIN
            SET @ReturnMessage = 'Sorry, The number of new products does not match the number of old products. No New Products applied to this account'
            GOTO Branch_three 
        END
        ELSE
            GOTO branch_two

	--The actually processing is done here in branch_two. If any errors found here they will be bubbled through the try catch.
	
    Branch_two:
		--Will only Show up if @ForTestingYES is set = 'Yes'
    IF @ForTestingYES = 'Yes'
        BEGIN
            SELECT  'Before Updates to VIP_Accounts' AS Before ,
                    *
            FROM    vip_accounts
            WHERE   VIP_AccountID = @AccountID
            SELECT  'Before AccountProducts  Table as been Updated' AS Before_accountProducts ,
                    *
            FROM    vip_accountproducts
            WHERE   VIP_AccountID = @AccountID


        END
    --Back to the real world...
    UPDATE  VIP_Accounts
    SET     VIP_ProductBundleID = @ProductBundleID
    WHERE   VIP_AccountID = @AccountID

	--Will only Show up if @ForTestingYES is set = 'Yes'
    IF @ForTestingYES = 'Yes'
        BEGIN
            SELECT  'After Updates to VIP_Accounts' AS AFTER ,
                    *
            FROM    vip_accounts
            WHERE   VIP_AccountID = @AccountID
        END
	
	--Back to the real world...
    DECLARE CUR CURSOR
    FOR
        SELECT  *
        FROM    #oldProductID
    OPEN CUR 
    DECLARE @RowNumfrom#oldProductID INT
    DECLARE @VIP_AccountProductID INT
    DECLARE @vip_accountID INT
    DECLARE @vip_productID INT
    FETCH NEXT FROM CUR INTO @RowNumfrom#oldProductID, @VIP_AccountProductID,
        @vip_accountID, @vip_productID
    DECLARE @NewProductID INT
	DECLARE @NewProductBundleItemID INT
    WHILE @@FETCH_STATUS = 0
        BEGIN
            SET @NewproductID = ( SELECT    NewProductID
                                  FROM      #tempbundler
                                  WHERE     BundlerRowNumber = @RowNumfrom#oldProductID
                                )
			SET @NewProductBundleItemID = ( SELECT    NewProductBundleItemID
                                  FROM      #tempbundler
                                  WHERE     BundlerRowNumber = @RowNumfrom#oldProductID
                                )
            SET @ReturnMessage = @ReturnMessage + ' '
                + CONVERT(VARCHAR(10), @NewProductID) + ','
            UPDATE  dbo.VIP_AccountProducts
            SET     VIP_ProductID = @NewproductID
			, ServiceFeeAmount = .16
            WHERE   VIP_AccountProductID = @VIP_AccountProductID
                    AND VIP_AccountID = @vip_accountID

            DELETE  FROM #tempbundler
            WHERE   NewProductBundleItemID = @NewProductBundleItemID
            FETCH NEXT FROM CUR INTO @RowNumfrom#oldProductID,
                @VIP_AccountProductID, @vip_accountID, @vip_productID

        END
    CLOSE Cur
    DEALLOCATE Cur



    SET @ReturnMessage = 'Success'
    SET @ReturnStatus = 'Good'


	--Will only Show up if @ForTestingYES is set = 'Yes'
    IF @ForTestingYES = 'Yes'
        BEGIN
            SELECT  'After AccountProducts  Table as been Updated' AS AFTER_accountProducts ,
                    *
            FROM    vip_accountproducts
            WHERE   VIP_AccountID = @AccountID

            SELECT  'Emptyness' AS ThisShouldAllBeEmpty ,
                    *
            FROM    #tempbundler
        END
	--Back to the real world
 END TRY

 BEGIN CATCH 
    ROLLBACK
    DECLARE @errorNum INT ,
        @ErrorMessage VARCHAR(4000) ,
        @STATE INT
    SELECT  @errorNum = ERROR_NUMBER() ,
            @ErrorMessage = ERROR_MESSAGE() ,
            @state = XACT_STATE()
--IF @state = -1 ROLLBACK
    -- BPP - save this in case we change our mind
	--RAISERROR (@errorNum,@errorMessage,@state);
    SET @ReturnMessage = 'Error: ' + @ErrorMessage + ', Error Num: '
        + @errorNum
    GOTO branch_three
    --RAISERROR (@errorNum,@errorMessage,@state);
 END CATCH 

--This will choose between testing and not. It lives in both real and testing! 
 IF @ForTestingYES = 'no'
    BEGIN
        PRINT 'This was not testing'
        --ROLLBACK
    Commit
        GOTO Branch_three
    END
 ELSE
    IF @ForTestingYES = 'Yes'
	PRINT 'I was Rolled Back because of Testing.'
	SET @ReturnMessage =@ReturnMessage + ': Everything was Rolled Back due to @ForTestingYes being set to Yes, if yo forserious, set it to No.'
        ROLLBACK 
 GOTO Branch_three

 Branch_three:
 SELECT @returnStatus AS Status ,
        @ReturnMessage AS Message
END

GO
