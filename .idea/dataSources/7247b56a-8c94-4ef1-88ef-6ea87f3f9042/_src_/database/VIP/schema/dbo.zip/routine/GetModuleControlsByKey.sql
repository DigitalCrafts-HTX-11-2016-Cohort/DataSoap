
CREATE PROCEDURE dbo.GetModuleControlsByKey
	
	@ControlKey        nvarchar(50),
	@ModuleDefId       int

AS
	SELECT *     
	FROM dbo.ModuleControls
	WHERE  ((ControlKey is null and @ControlKey is null) or (ControlKey = @ControlKey))
		AND    ((ModuleDefId is null and @ModuleDefId is null) or (ModuleDefId = @ModuleDefId))
		AND    ControlType >= -1
	ORDER BY ViewOrder
GO
