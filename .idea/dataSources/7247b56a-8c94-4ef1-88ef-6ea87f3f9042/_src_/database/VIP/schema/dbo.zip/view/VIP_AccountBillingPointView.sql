
CREATE VIEW [dbo].[VIP_AccountBillingPointView]
AS
SELECT     a.VIP_AccountID, a.VIP_ContractID, a.VIP_RetailerID, a.VIP_UtilityID, a.VIP_AccountClassID, a.VIP_MarketerID, a.VIP_MarketerAgentID, a.VIP_ProductBundleID, 
                      a.VIP_AccountBillingTypeID, a.VIP_BatchEnrollmentEntryID, a.VIP_AccountGUID, a.AccountStatus, a.UtilityAccountNumber, a.UtilityServiceAccountID, 
                      a.UtilityMeterNumber, a.RetailerAccountNumber, a.CompanyName, a.ServiceFirstName, a.ServiceLastName, a.ServiceAddress1, a.ServiceAddress2, a.ServiceCity, 
                      a.ServiceState, a.ServiceCounty, a.ServiceZipCode, a.ServicePhone, a.ServiceEmail, a.BillingFirstName, a.BillingLastName, a.BillingAddress1, a.BillingAddress2, 
                      a.BillingCity, a.BillingState, a.BillingZipCode, a.BillingCounty, a.BillingPhone, a.BillingEmail, a.LifeSupport, a.TaxExempt, a.CoreCustomer, 
                      a.ServiceAgreementStartDate, a.ServiceAgreementEndDate, a.RequireFuelChargesToGenerateInvoice, a.RequireTransportChargesToBill, a.ContractedUsageAvailable, 
                      a.ContractedUsage_UnitOfMeasureID, a.ContractedUsage_January, a.ContractedUsage_February, a.ContractedUsage_March, a.ContractedUsage_April, 
                      a.ContractedUsage_May, a.ContractedUsage_June, a.ContractedUsage_July, a.ContractedUsage_August, a.ContractedUsage_September, a.ContractedUsage_October, 
                      a.ContractedUsage_November, a.ContractedUsage_December, a.EnrollmentAcceptDate, a.DateSold, a.ContractMonths, bpa.VIP_BillingPointAccountID, 
                      bpa.VIP_BillingPointID, bpa.VIP_AccountID AS Expr1, bpa.DateCreated, pb.VIP_BillingPointID AS Expr2, pb.BillingPointName, pb.BillingPointCode, pb.BillingTrigger, 
                      pb.BillingAttentionTo, pb.Address1, pb.Address2, pb.City, pb.State, pb.ZipCode, pb.Country, pb.Phone, pb.Email, pb.DynamicsCustomerId
FROM         dbo.VIP_Accounts AS a INNER JOIN
                      dbo.VIP_BillingPointAccounts AS bpa ON a.VIP_AccountID = bpa.VIP_AccountID INNER JOIN
                      dbo.VIP_BillingPoints AS pb ON bpa.VIP_BillingPointID = pb.VIP_BillingPointID

GO
