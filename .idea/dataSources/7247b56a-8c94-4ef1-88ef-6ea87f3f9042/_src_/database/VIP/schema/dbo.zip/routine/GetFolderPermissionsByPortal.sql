
CREATE procedure dbo.[GetFolderPermissionsByPortal]
	@PortalId  int
	
	AS
	
	SELECT *
	FROM dbo.vw_FolderPermissions
	WHERE 	PortalID = @PortalID OR (PortalId IS NULL AND @PortalId IS NULL)

GO
