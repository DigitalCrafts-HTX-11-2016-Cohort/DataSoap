
CREATE PROCEDURE dbo.GetModuleControlByKeyAndSrc
	
	@ModuleDefId int,
	@ControlKey nvarchar(50),
	@ControlSrc nvarchar(256)

AS
	SELECT *     
	FROM dbo.ModuleControls
	WHERE ((ModuleDefId is null and @ModuleDefId is null) or (ModuleDefID = @ModuleDefID))
		AND ((ControlKey is null and @ControlKey is null) or (ControlKey = @ControlKey))
		AND ((ControlSrc is null and @ControlSrc is null) or (ControlSrc = @ControlSrc))
GO
