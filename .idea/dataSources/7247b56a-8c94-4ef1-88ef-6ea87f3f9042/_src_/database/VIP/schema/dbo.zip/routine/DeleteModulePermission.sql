

CREATE PROCEDURE dbo.DeleteModulePermission
	@ModulePermissionID int
AS

DELETE FROM dbo.ModulePermission
WHERE
	[ModulePermissionID] = @ModulePermissionID


GO
