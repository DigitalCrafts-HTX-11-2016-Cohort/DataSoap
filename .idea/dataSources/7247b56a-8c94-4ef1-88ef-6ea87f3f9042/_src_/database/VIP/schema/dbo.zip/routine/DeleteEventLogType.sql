

CREATE PROCEDURE dbo.DeleteEventLogType
	@LogTypeKey nvarchar(35)
AS
DELETE FROM dbo.EventLogTypes
WHERE	LogTypeKey = @LogTypeKey


GO
