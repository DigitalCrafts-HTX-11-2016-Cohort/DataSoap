
CREATE PROCEDURE dbo.AddScheduleItemSetting

@ScheduleID     int,
@Name           nvarchar(50),
@Value			nvarchar(256)

as

IF EXISTS ( SELECT * FROM dbo.ScheduleItemSettings WHERE ScheduleID = @ScheduleID AND SettingName = @Name)
BEGIN 
	UPDATE	dbo.ScheduleItemSettings
	SET		SettingValue = @Value
	WHERE	ScheduleID = @ScheduleID
	AND		SettingName = @Name
END 
ELSE 
BEGIN 
	INSERT INTO dbo.ScheduleItemSettings (
		ScheduleID,
		SettingName,
		Settingvalue
	)
	VALUES (
		@ScheduleID,
		@Name,
		@Value
	)
END


GO
