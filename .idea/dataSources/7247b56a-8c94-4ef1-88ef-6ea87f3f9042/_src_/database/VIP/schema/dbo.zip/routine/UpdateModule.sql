
CREATE PROCEDURE dbo.UpdateModule

	@ModuleId               int,
	@ModuleTitle            nvarchar(256),
	@AllTabs                bit, 
	@Header                 ntext,
	@Footer                 ntext,
	@StartDate              datetime,
	@EndDate                datetime,
	@InheritViewPermissions	bit,
	@IsDeleted              bit

AS

UPDATE dbo.Modules
SET    ModuleTitle = @ModuleTitle,
       AllTabs = @AllTabs,
       Header = @Header,
       Footer = @Footer, 
       StartDate = @StartDate,
       EndDate = @EndDate,
       InheritViewPermissions = @InheritViewPermissions,
       IsDeleted = @IsDeleted
WHERE  ModuleId = @ModuleId


GO
