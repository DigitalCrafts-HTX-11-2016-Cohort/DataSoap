
CREATE PROCEDURE dbo.GetEventLogType
AS
SELECT *
FROM dbo.EventLogTypes


GO
