
/* =============================================
-- Author:		Bryan Panjavan
 - Description:
	- 2013-10-29 - BPanjavan - Initial Creation
  =============================================*/
CREATE PROCEDURE dbo.MetaConfig_KeyValue_InsertOrUpdate
(
	@metaKey varchar(100)
	,@value varchar(8000)
)
AS
BEGIN
	IF EXISTS(SELECT * FROM dbo.MetaConfig_KeyValue WHERE [Key] = @metaKey)
	BEGIN
		UPDATE dbo.MetaConfig_KeyValue SET Value = @value WHERE [Key] = @metaKey
	END
	ELSE
	BEGIN
		INSERT INTO dbo.MetaConfig_KeyValue
				( [Key], Value )
		VALUES  ( @metaKey, -- Key - varchar(100)
				  @value  -- Value - varchar(8000)
				  )
	END
END

GO
