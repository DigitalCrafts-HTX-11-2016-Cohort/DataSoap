
/*
	2015-04-22 - BPanjavan - Added #temp_mv_AccountSearch_ThinView for performance
						Separated out the Joins with OR's (ewww) into separate SQL statements
	2013-09-27 - BPanjavan - Updated to use AccountServicePoint.v_AccountSearch_ThinView to get previous utility account #
*/

CREATE PROCEDURE [dbo].[usp_VIP_UpdatePGEDailyBillingAccountID]

AS

-- 2015-04-22 - BPanjavan - Creating a temp table and indexing it for performance
--------------------------
SELECT VIP_AccountID, UtilityServiceAccountID, Previous_UtilityServiceAccountID 
INTO #temp_mv_AccountSearch_ThinView
FROM AccountServicePoint.v_AccountSearch_ThinView

CREATE NONCLUSTERED INDEX [IX_mv_AccountSearch_ThinView] ON #temp_mv_AccountSearch_ThinView
(UtilityServiceAccountID ASC, Previous_UtilityServiceAccountID ASC)
INCLUDE ( 	VIP_AccountID) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
----------------------

-- Timing: > 30 seconds
-------------------------------
UPDATE  be
SET     be.VIP_AccountID = acc.VIP_AccountID
FROM    VIPMARKET_PGE_Billing be
        INNER JOIN #temp_mv_AccountSearch_ThinView acc ON be.Parent_SAID = acc.UtilityServiceAccountID
WHERE   ( 1 = 1 )
        AND be.VIP_AccountID = 0

UPDATE  be
SET     be.VIP_AccountID = acc.VIP_AccountID
FROM    VIPMARKET_PGE_Billing be
        INNER JOIN #temp_mv_AccountSearch_ThinView acc ON be.Parent_SAID = acc.Previous_UtilityServiceAccountID
WHERE   ( 1 = 1 )
        AND be.VIP_AccountID = 0

UPDATE  be
SET     be.VIP_AccountID = acc.VIP_AccountID
FROM    VIPMARKET_PGE_Billing be
        INNER JOIN #temp_mv_AccountSearch_ThinView acc ON be.DA_XREF = acc.UtilityServiceAccountID
WHERE   ( 1 = 1 )
        AND be.VIP_AccountID = 0

UPDATE  be
SET     be.VIP_AccountID = acc.VIP_AccountID
FROM    VIPMARKET_PGE_Billing be
        INNER JOIN #temp_mv_AccountSearch_ThinView acc ON be.DA_XREF = acc.Previous_UtilityServiceAccountID
WHERE   ( 1 = 1 )
        AND be.VIP_AccountID = 0

UPDATE  VIPMARKET_PGE_Billing
SET     VIP_AccountID = ( SELECT TOP 1
                                    VIP_Accountid
                          FROM      VIP_Accounts_Reconciliation
                          WHERE     UtilityServiceAccountid = Parent_SAID
                        )
WHERE   VIP_AccountID = 0

UPDATE  VIPMARKET_PGE_Billing
SET     VIP_AccountID = 0 ,
        Status = 'Error - Missing Account Id'
WHERE   VIP_AccountID IS NULL


GO
