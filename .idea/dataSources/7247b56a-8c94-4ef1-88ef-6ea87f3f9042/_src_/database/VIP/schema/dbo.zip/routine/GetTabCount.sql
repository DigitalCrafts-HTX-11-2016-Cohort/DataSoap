
CREATE PROCEDURE dbo.[GetTabCount]
	
	@PortalID	int

AS

DECLARE @AdminTabId int
SET @AdminTabId = (SELECT AdminTabId 
						FROM dbo.Portals 
						WHERE PortalID = @PortalID)

SELECT COUNT(*) - 1 
FROM  dbo.Tabs
WHERE (PortalID = @PortalID) 
	AND (TabID <> @AdminTabId) 
	AND (ParentId <> @AdminTabId OR ParentId IS NULL)

GO
