
create procedure dbo.GetSiteLog4

@PortalID int,
@PortalAlias nvarchar(50),
@StartDate datetime,
@EndDate datetime

as

select Referrer,
 'Requests' = count(*),
 'LastRequest' = max(DateTime)
from dbo.SiteLog
where dbo.SiteLog.PortalId = @PortalID
and dbo.SiteLog.DateTime between @StartDate and @EndDate
and Referrer is not null
and Referrer not like '%' + @PortalAlias + '%'
group by Referrer
order by Requests desc


GO
