
CREATE PROCEDURE dbo.UpdateFolderPermission
	@FolderPermissionID int, 
	@FolderID int, 
	@PermissionID int, 
	@RoleID int ,
	@AllowAccess bit,
        @UserID int
AS

UPDATE dbo.FolderPermission SET
	[FolderID] = @FolderID,
	[PermissionID] = @PermissionID,
	[RoleID] = @RoleID,
	[AllowAccess] = @AllowAccess,
        [UserID] = @UserID
WHERE
	[FolderPermissionID] = @FolderPermissionID

GO
