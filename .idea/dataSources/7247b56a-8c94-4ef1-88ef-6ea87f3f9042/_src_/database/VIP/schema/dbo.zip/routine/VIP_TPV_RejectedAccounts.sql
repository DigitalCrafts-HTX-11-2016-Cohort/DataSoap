
-- =============================================
-- Author:		Bryan Panjavan
-- Create date: 2013-07-25
-- Description:	
				-- Populates the notes in the Batch Enrollment Entries notes field for NO TPV Accounts

-- 2013-07-29 - Added @userName parameter to add it to Coordinator automated process, @userName not used in this proc
-- 2013-07-25 - Picked up from Larry's script, fixed issues with it duplicating notes
-- =============================================
CREATE PROCEDURE [dbo].[VIP_TPV_RejectedAccounts]
(
	@userName VARCHAR(100) = ''-- the generic process passes this in, but it's not used in this procedure
)
AS

--BEGIN TRAN

--Insert notes data 
;with tblBENotes_Max as
(
	SELECT
		beNotes.*
	FROM
		dbo.VIP_BatchEnrollmentEntries_Notes beNotes
		INNER JOIN
			(
				Select vip_batchenrollentryid, NotesID_MAX = max(VIP_BatchEnrollmentEntries_NotesID)
				 from dbo.VIP_BatchEnrollmentEntries_Notes
				 where convert(varchar(50),Notes) in('No TPV Record Found','TPV review failed')	 	 
				group by vip_batchenrollentryid

			) beNotesMax
			ON 
				beNotes.vip_batchenrollentryid = beNotesMax.vip_batchenrollentryid
				AND beNotes.VIP_BatchEnrollmentEntries_NotesID = beNotesMax.NotesID_MAX
)
,VIPMarket_TPV_MAX AS
(
	SELECT 
		VIPMARKET_TPV.* 
	FROM 
		VIPMARKET_TPV 
		INNER JOIN 
		(
			SELECT
				ImportDate_MAX = MAX(ImportDate)
				,ACCT
			FROM
				dbo.VIPMARKET_TPV
			WHERE ISNULL(PASSED_REVIEW,'') <> 'Y'
			GROUP BY
				ACCT				      
		) VIPMARKET_TPV_MAX
			ON 
				VIPMARKET_TPV.ACCT = VIPMARKET_TPV_MAX.ACCT
				AND VIPMARKET_TPV.ImportDate = VIPMARKET_TPV_MAX.ImportDate_MAX
)
insert into dbo.VIP_BatchEnrollmentEntries_Notes (VIP_BatchEnrollEntryID, Notes, NoteDate, CreatedByUserID)
-- look for all accounts that need notes
Select 
--	*,
	vip_batchenrollentryid, Comments, NoteDate, UserID  from
(
	Select a.vip_batchenrollentryid, 	
	case when TPV.PASSED_REVIEW is null then 'No TPV Record Found'
		 when TPV.PASSED_REVIEW = 'N' then 'TPV review failed' 
		 when TPV.PASSED_REVIEW = '-' then 'TPV review failed' 
		 else TPV.PASSED_REVIEW END Comments,
	getdate() NoteDate,
	2 UserID, convert(varchar(50),nt.Notes) Notes,
	count(*) Attempts
	from 
	(
		Select vip_batchenrollentryid, utilityserviceaccountid AccountNumber, 'SAID' FieldName, 
		utilityserviceaccountid,
		utilityaccountnumber,
		CompanyName, ServiceFirstName, ServiceLastName	
		from vip_batchenrollmententries BE
		where batchenrollmentstatus = 'No TPV' and utilityserviceaccountid <> '' 		
		union
		Select vip_batchenrollentryid, utilityaccountnumber AccountNumber, 'AccountNumber' FieldName, 
		utilityserviceaccountid,
		utilityaccountnumber,
		CompanyName, ServiceFirstName, ServiceLastName
		from vip_batchenrollmententries BE
		where batchenrollmentstatus = 'No TPV' and utilityaccountnumber <> ''		
	) a
	left outer join VIPMarket_TPV_MAX tpv on a.AccountNumber = tpv.ACCT 		
	left outer join tblBENotes_Max nt on a.vip_batchenrollentryid = nt.vip_batchenrollentryid
	--where a.vip_batchenrollentryid = 167758 		
	group by a.vip_batchenrollentryid, 	
	case when TPV.PASSED_REVIEW is null then 'No TPV Record Found'
		 when TPV.PASSED_REVIEW = 'N' then 'TPV review failed' 
		 when TPV.PASSED_REVIEW = '-' then 'TPV review failed' 
		 else TPV.PASSED_REVIEW END,
		 convert(varchar(50),nt.Notes)
) b
where (Notes <> Comments) or Notes is null

--COMMIT

---------QUERY ALL THE ACCOUNTS WITH NO TPV
Select TOP 10
	utilityserviceaccountid SAID, utilityaccountnumber ActNo, isnull(TPV.ACCT,'No Record Found') TPV_Account, CompanyName, ServiceFirstName, ServiceLastName,
case when TPV.PASSED_REVIEW is null then 'N'
     when TPV.PASSED_REVIEW = '-' then 'N' 
     else TPV.PASSED_REVIEW END PASSED_REVIEW,
ISNULL(tpv.ImportFileName,'-') ImportFileName, isnull(convert(varchar(10),tpv.ImportDate,101),'-') ImportDate, 
count(*) Attempts
from 
(
	Select utilityserviceaccountid AccountNumber, 'SAID' FieldName, 
	utilityserviceaccountid,
	utilityaccountnumber,
	CompanyName, ServiceFirstName, ServiceLastName	
	from vip_batchenrollmententries BE
	where batchenrollmentstatus = 'No TPV' and utilityserviceaccountid <> '' 
	union
	Select utilityaccountnumber AccountNumber, 'AccountNumber' FieldName, 
	utilityserviceaccountid,
	utilityaccountnumber,
	CompanyName, ServiceFirstName, ServiceLastName
	from vip_batchenrollmententries BE
	where batchenrollmentstatus = 'No TPV' and utilityaccountnumber <> ''
	
) a 
left outer join dbo.VIPMARKET_TPV tpv on a.AccountNumber = tpv.ACCT 
group by utilityserviceaccountid , utilityaccountnumber , isnull(TPV.ACCT,'No Record Found') , CompanyName, ServiceFirstName, ServiceLastName,
case when TPV.PASSED_REVIEW is null then 'N'
     when TPV.PASSED_REVIEW = '-' then 'N' 
     else TPV.PASSED_REVIEW END 
, ISNULL(tpv.ImportFileName,'-'), isnull(convert(varchar(10),tpv.ImportDate,101),'-')  

--GO


GO
