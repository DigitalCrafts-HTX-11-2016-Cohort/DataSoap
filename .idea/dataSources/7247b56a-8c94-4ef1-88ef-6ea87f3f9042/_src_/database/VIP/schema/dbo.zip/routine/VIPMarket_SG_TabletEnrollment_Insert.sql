


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[VIPMarket_SG_TabletEnrollment_Insert]
(
	@userName VARCHAR(50),
	@EnrollmentSubmissionID varchar(100),
	@ComputerName varchar(100),
	@RepID varchar(100) = NULL,
	@VIPMARKET_SG_ELG_PREMISE_ID varchar(100),
	@AccountNumber varchar(100),
	@FullName varchar(100),
	@ControlNumber varchar(100),
	@EmailAddress varchar(100),
	@BirthMonth varchar(100),
	@VIPMARKET_SG_PriceRateCode_ID varchar(100),
	@PriceRateCode varchar(100),
	@EnrollmentCreatedon varchar(100),
	@EnrollmentCompletedWithCustomerOn varchar(100),
	@EnrollmentSubmittedToCentralOn varchar(100),
	@EnrollmentStatusInt varchar(100),
	@Geo_AccuracyInMeters varchar(100),
	@Geo_Latitude varchar(100),
	@Geo_Longitude varchar(100),
	@HaveISubmittedMyDelegationForm varchar(100),
	@HaveISubmittedMyTPV varchar(100),
	@DateReceived DATETIME,
	@Status VARCHAR(50)
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF NOT EXISTS(SELECT * FROM dbo.VIPMarket_SG_TabletEnrollment WHERE EnrollmentSubmissionID = @EnrollmentSubmissionID)
	BEGIN

    -- Insert statements for procedure here
	INSERT INTO [dbo].[VIPMarket_SG_TabletEnrollment]
           ([CreatedOn]
           ,[CreatedBy]
           ,[ModifiedOn]
           ,[ModifiedBy]
           ,[VIPMARKET_SG_ELG_PREMISE_ID]
           ,[EnrollmentSubmissionID]
           ,[ComputerName]
           ,[RepID]
           ,[AccountNumber]
           ,[FullName]
           ,[ControlNumber]
           ,[EmailAddress]
           ,[BirthMonth]
           ,[VIPMARKET_SG_PriceRateCode_ID]
           ,[PriceRateCode]
           ,[EnrollmentCreatedon]
           ,[EnrollmentCompletedWithCustomerOn]
           ,[EnrollmentSubmittedToCentralOn]
           ,[EnrollmentStatusInt]
           ,[Geo_AccuracyInMeters]
           ,[Geo_Latitude]
           ,[Geo_Longitude]
           ,[HaveISubmittedMyDelegationForm]
           ,[HaveISubmittedMyTPV]
           ,[DateReceived]
           ,[Status])
     VALUES
           (
			GETDATE()
			,@userName
			,GETDATE()
			,@userName
           ,@VIPMARKET_SG_ELG_PREMISE_ID
			,@EnrollmentSubmissionID
           ,@ComputerName
           ,@RepID
           ,@AccountNumber
           ,@FullName
           ,@ControlNumber
           ,@EmailAddress
           ,@BirthMonth
           ,@VIPMARKET_SG_PriceRateCode_ID
           ,@PriceRateCode
           ,@EnrollmentCreatedon
           ,@EnrollmentCompletedWithCustomerOn
           ,@EnrollmentSubmittedToCentralOn
           ,@EnrollmentStatusInt
           ,@Geo_AccuracyInMeters
           ,@Geo_Latitude
           ,@Geo_Longitude
           ,@HaveISubmittedMyDelegationForm
           ,@HaveISubmittedMyTPV
		   ,@DateReceived
		   ,@Status
		   )

	END
END


GO
