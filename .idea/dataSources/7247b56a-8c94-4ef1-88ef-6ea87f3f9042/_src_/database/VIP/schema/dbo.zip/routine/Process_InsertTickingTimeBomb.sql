

-- =============================================
-- Author:		Brandon Rudd
-- Create date: 2016-06-07
-- Description:	Deal with NICOR Usage to Invoice Exceptions

-- =============================================
CREATE PROCEDURE [dbo].[Process_InsertTickingTimeBomb]
	-- Add the parameters for the stored procedure here
@VIP_AccountID INT
, @UserID INT 
, @RecordID VARCHAR(25)
, @RecordIDType VARCHAR(50)
, @Type VARCHAR(20)
, @EffectiveDate SMALLDATETIME
, @NewValue VARCHAR(50)
, @OldValue VARCHAR(50)

AS
BEGIN

INSERT INTO dbo.TimeBomb
VALUES  ( @VIP_AccountID , -- VIP_AccountID - int
		  GETDATE() , -- DateCreated - smalldatetime
		  @UserID , --UserID - int
          @RecordID , -- RecordID - varchar(25)
          @RecordIDType , -- RecordIDType - varchar(50)
          @Type , -- Type - varchar(20)
          @EffectiveDate , -- EffectiveDate - smalldatetime
          @NewValue , -- NewValue - varchar(50)
          @OldValue , -- OldValue - varchar(50)
          'Ticking'  -- Status - varchar(15)
        )

END


GO
