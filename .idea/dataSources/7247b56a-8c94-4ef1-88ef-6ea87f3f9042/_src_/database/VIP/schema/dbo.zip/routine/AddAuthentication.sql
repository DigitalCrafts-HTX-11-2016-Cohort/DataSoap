
CREATE PROCEDURE dbo.AddAuthentication
	@PackageID				int,
	@AuthenticationType     nvarchar(100),
	@IsEnabled				bit,
	@SettingsControlSrc     nvarchar(250),
	@LoginControlSrc		nvarchar(250),
	@LogoffControlSrc		nvarchar(250)
AS
	INSERT INTO Authentication (
		PackageID,
		AuthenticationType,
		IsEnabled,
		SettingsControlSrc,
		LoginControlSrc,
		LogoffControlSrc
	)
	VALUES (
		@PackageID,
		@AuthenticationType,
		@IsEnabled,
		@SettingsControlSrc,
		@LoginControlSrc,
		@LogoffControlSrc
	)

	SELECT SCOPE_IDENTITY()
GO
