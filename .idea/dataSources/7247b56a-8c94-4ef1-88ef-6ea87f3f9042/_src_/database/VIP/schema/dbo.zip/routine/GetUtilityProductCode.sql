

CREATE FUNCTION [dbo].[GetUtilityProductCode]
(	
	@VIP_AccountID int,
	@BillingDate varchar(10)	
)
RETURNS TABLE
AS
RETURN 
(
	SELECT p.UtilityProductCode
	FROM VIP_AccountProducts AS ap
		INNER JOIN VIP_Products AS p ON ap.VIP_ProductID = p.VIP_ProductID
		LEFT OUTER JOIN VIP_VariableProductIndexPrices vpip ON p.CommoidtyVariableProductIndexID = vpip.VIP_VariableProductIndexID
	WHERE ap.VIP_AccountID = @VIP_AccountID
		AND @BillingDate BETWEEN vpip.EffectiveStartDate and vpip.EffectiveEndDate
)

GO
