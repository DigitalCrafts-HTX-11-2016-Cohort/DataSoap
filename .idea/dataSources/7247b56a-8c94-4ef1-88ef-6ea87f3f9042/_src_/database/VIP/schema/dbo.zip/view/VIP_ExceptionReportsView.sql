CREATE VIEW dbo.VIP_ExceptionReportsView
AS
SELECT     TOP (100) PERCENT dbo.VIP_Utilities.Code AS Utility, dbo.VIP_Accounts.UtilityAccountNumber, dbo.VIP_Accounts.UtilityServiceAccountID, 
                      dbo.VIP_AccountInteractionTypes.Code, dbo.VIP_AccountInteractions.Status, dbo.VIP_AccountInteractionAudit.AuditMessage, 
                      dbo.VIP_AccountInteractionAudit.AuditDateTime, DATEDIFF(dd, dbo.VIP_AccountInteractionAudit.AuditDateTime, GETDATE()) AS LagTime, 
                      CASE dbo.VIP_Accounts.EnrollmentAcceptDate WHEN '1900-01-01 00:00:00' THEN getdate() ELSE ISNULL(dbo.VIP_Accounts.EnrollmentAcceptDate, getdate()) 
                      END AS EnrollmentAcceptDate, DATEDIFF(dd, dbo.VIP_Accounts.EnrollmentAcceptDate, GETDATE()) AS DaysSinceEnrollment, dbo.VIP_Accounts.VIP_AccountID, 
                      dbo.VIP_Accounts.AccountStatus, dbo.VIP_Accounts.CoreCustomer
FROM         dbo.VIP_Accounts INNER JOIN
                      dbo.VIP_AccountInteractions ON dbo.VIP_AccountInteractions.VIP_AccountID = dbo.VIP_Accounts.VIP_AccountID INNER JOIN
                      dbo.VIP_AccountInteractionTypes ON 
                      dbo.VIP_AccountInteractionTypes.VIP_AccountInteractionTypeID = dbo.VIP_AccountInteractions.VIP_AccountInteractionTypeID INNER JOIN
                      dbo.VIP_AccountInteractionAudit ON dbo.VIP_AccountInteractionAudit.VIP_AccountInteractionID = dbo.VIP_AccountInteractions.VIP_AccountInteractionID INNER JOIN
                      dbo.VIP_Utilities ON dbo.VIP_Utilities.VIP_UtilityID = dbo.VIP_Accounts.VIP_UtilityID
GO
