
--EXECUTE VIPMarket_SG_Pricing_Load_AdditionalStep_STAGING_Table

/*
	- 2017-04-05 - BPanjavan - Update Fixed Bill Codes for Wyoming for 2017
*/
CREATE PROCEDURE VIPMarket_SG_Pricing_Load_AdditionalStep_STAGING_Table AS
BEGIN
	-- 2015-04-02 - Per Drew, do NOT allow Fixed Bill for any account with FB >= 5000
	-- 2016-01-08 - Per Drew, do NOT allow Fixed Bill for any account with FB >= 1000
	-- 2016-04-05 - Per Drew, do NOT allow Fixed Bill for any account with FB >= 500
	UPDATE dbo.VIPMARKET_SG_Pricing_STAGING SET FixedBillUnlimitedRate1 = FixedBillUnlimitedRate1 * -1.0 WHERE FixedBillUnlimitedRate1 >= 500
	UPDATE dbo.VIPMARKET_SG_Pricing_STAGING SET FixedBillUnlimitedRate2 = FixedBillUnlimitedRate2 * -1.0 WHERE FixedBillUnlimitedRate2 >= 500
	UPDATE dbo.VIPMARKET_SG_Pricing_STAGING SET FixedBillUnlimitedRate3 = FixedBillUnlimitedRate3 * -1.0 WHERE FixedBillUnlimitedRate2 >= 500

	-- 2016-04-07 - From Brandon update all pricing codes in the staging table so they copy correctly into the pricing table
	UPDATE  price
	SET     price.FixedBillUnlimitedCode1 = CASE 
											 WHEN prem.Service_State = 'NE'
											 THEN '47838'
											 WHEN prem.DivisionRegion = 'CASPER'
                                             THEN '77107'
                                             WHEN prem.DivisionRegion = 'GILLETTE'
                                             THEN '77110'
                                             WHEN prem.DivisionRegion = 'TORRINGTON'
                                             THEN '77113'
                                        END
		, price.FixedBillUnlimitedCode2 = CASE  
												WHEN prem.Service_State = 'NE'
												THEN '47839'
												WHEN prem.DivisionRegion = 'CASPER'
												THEN '77108'
												WHEN prem.DivisionRegion = 'GILLETTE'
												THEN '77111'
												WHEN prem.DivisionRegion = 'TORRINGTON'
												THEN '77114'
                                          END
		, price.FixedBillUnlimitedCode3 = CASE  
												WHEN prem.Service_State = 'NE'
												THEN '47840'
												WHEN prem.DivisionRegion = 'CASPER'
												THEN '77109'
												WHEN prem.DivisionRegion = 'GILLETTE'
												THEN '77112'
												WHEN prem.DivisionRegion = 'TORRINGTON'
												THEN '77115'
                                          END
		, price.GLTPORCode1 = CASE 
									WHEN prem.DivisionRegion = 'CASPER'
									THEN '77116'
									WHEN prem.DivisionRegion = 'GILLETTE'
									THEN '77117'
									WHEN prem.DivisionRegion = 'TORRINGTON'
									THEN '77118'
							  END
FROM    dbo.VIPMARKET_SG_Pricing_STAGING price
        INNER JOIN dbo.VIPMARKET_SG_ELG_PREMISE prem ON prem.Account_Number = price.Account_Number

-- 2016-04-13 - If Fixed Pricing is specifically -2, negatize ALL other pricing because they've all been taken off
	UPDATE dbo.VIPMARKET_SG_Pricing_STAGING 
		SET 
			FixedBillUnlimitedRate1 = ABS(FixedBillUnlimitedRate1) * -1.0,FixedBillUnlimitedRate2 = ABS(FixedBillUnlimitedRate2) * -1.0, FixedBillUnlimitedRate3 = ABS(FixedBillUnlimitedRate3) * -1.0 
			,GLTPORRate1 = -2, GLTPORRate2 = -2, GLTPORRate3 = -2
		WHERE FixedPriceRate = -2.0


END

GO
