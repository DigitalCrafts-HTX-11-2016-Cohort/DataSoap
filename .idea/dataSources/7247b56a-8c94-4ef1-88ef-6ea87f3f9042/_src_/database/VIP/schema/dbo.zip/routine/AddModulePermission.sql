
CREATE PROCEDURE dbo.AddModulePermission
	@ModuleID int,
	@PermissionID int,
	@RoleID int,
	@AllowAccess bit,
	@UserID int
AS

INSERT INTO dbo.ModulePermission (
	[ModuleID],
	[PermissionID],
	[RoleID],
	[AllowAccess],
	[UserID]
) VALUES (
	@ModuleID,
	@PermissionID,
	@RoleID,
	@AllowAccess,
	@UserID
)

select SCOPE_IDENTITY()

GO
