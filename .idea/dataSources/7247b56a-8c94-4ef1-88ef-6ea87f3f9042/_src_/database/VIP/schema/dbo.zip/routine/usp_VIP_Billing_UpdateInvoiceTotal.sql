

CREATE PROCEDURE [dbo].[usp_VIP_Billing_UpdateInvoiceTotal]
	@VIP_InvoiceID int
	
AS

	UPDATE VIP_Invoices
	SET InvoiceAmount = (SELECT SUM(Total) FROM VIP_InvoiceItems WHERE VIP_InvoiceID = @VIP_InvoiceID)
	WHERE VIP_InvoiceID = @VIP_InvoiceID
GO
