

CREATE VIEW [dbo].[CT_PaymentInfo]
AS
select Utility = U.Code,
       A.VIP_AccountID,
       A.UtilityAccountNumber,
	   P.VIP_BillingPointID,
	   P.VIP_PaymentID,
	   P.PaymentAmount,
	   P.PaymentDate,
	   P.Status
  from VIP_Utilities U (nolock)
    inner join VIP_AccountsView A (nolock)
      on A.VIP_UtilityID = U.VIP_UtilityID
    inner join VIP_BillingPointAccountsView BPA (nolock)
      on BPA.VIP_AccountID = A.VIP_AccountID
    inner join VIP_Payments P (nolock)
      on P.VIP_BillingPointID = BPA.VIP_BillingPointID
  where StateCode IN ('CT')


GO
