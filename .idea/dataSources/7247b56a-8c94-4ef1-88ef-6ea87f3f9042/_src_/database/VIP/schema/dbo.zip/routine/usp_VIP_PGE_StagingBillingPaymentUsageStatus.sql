
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

	-- 2013-09-27 - BPanjavan - Changed first statement to set status to pending if the account ID is NOT 0


-- =============================================
CREATE PROCEDURE [dbo].[usp_VIP_PGE_StagingBillingPaymentUsageStatus]
AS

--Search for billing data in staging that now has been reconciled in vip to process billing data
update VIPMARKET_PGE_Billing 
set Status = 'Pending'
where VIP_AccountID <> 0
 and status = 'Error - Missing Account Id'

--Search for payment data in staging that now has been reconciled in vip to process billing data
update VIPMARKET_PGE_Payment
set Status = 'Loaded', Description = ''
where 
DAXRef in(Select UtilityServiceAccountID from vip_accounts)
and Status = 'Error' and Description = 'There is no account to reference for this payment'

--search for usage data in staging that now has been reconciled in vip to process billing data
update VIPMARKET_PGE_Usage 
set STATUS = 'Loaded'
where 
CustomerID in (Select UtilityServiceAccountID from vip_accounts)
and STATUS = 'ERROR - No VIP_AccountInteractions were found for ID VIP_AccountInteractionID'


GO
