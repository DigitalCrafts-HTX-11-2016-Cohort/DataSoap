
create procedure dbo.GetProfile

@UserID    int, 
@PortalID  int

as

select *
from   dbo.Profile
where  UserId = @UserID 
and    PortalId = @PortalID


GO
