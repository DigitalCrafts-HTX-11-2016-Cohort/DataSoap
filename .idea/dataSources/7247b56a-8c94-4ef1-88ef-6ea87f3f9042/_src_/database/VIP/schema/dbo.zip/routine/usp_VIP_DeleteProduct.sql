
CREATE PROCEDURE usp_VIP_DeleteProduct @ProductName varchar(100)
	
AS

Delete dbo.VIP_Products where ProductName = @ProductName
GO
