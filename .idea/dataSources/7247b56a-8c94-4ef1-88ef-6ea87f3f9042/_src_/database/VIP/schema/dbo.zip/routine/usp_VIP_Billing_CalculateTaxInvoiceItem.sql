
/*
 - 2016-06-28 - BPanjavan - Invoice Errors due to multiple innvoice item types with same name, changed this line to this: Select @VIP_InvoiceItemTypeID = 	(SELECT TOP 1 VIP_InvoiceItemTypeID FROM VIP_InvoiceItemTypes WHERE InvoiceItemType = @InvoiceItemType ORDER BY VIP_InvoiceItemTypeID)
*/
CREATE PROCEDURE [dbo].[usp_VIP_Billing_CalculateTaxInvoiceItem]
	@VIP_InvoiceID int,
	@VIP_AccountID int,
	@InvoiceItemType varchar(100),
	@Amount numeric(18, 5),
	@Price numeric(18, 5)
AS

-----------------------------
DECLARE @VIP_InvoiceItemTypeID int
DECLARE @ZipCode varchar(5)
DECLARE @InvoiceDate smalldatetime

-- Get the amount of the invoice from the database, not from the parameter

--deduct non taxable items
SET @Amount = ( SELECT ISNULL(SUM(ISNULL(ii.total,0)),0) 
						FROM VIP_InvoiceItems ii
							INNER JOIN dbo.VIP_InvoiceItemTypes iit
								ON ii.VIP_InvoiceItemTypeID = iit.VIP_InvoiceItemTypeID
									AND iit.CalculateSalesTax = 1
					WHERE ii.VIP_InvoiceID = @VIP_InvoiceID
				)
--------------------------------------
Select @VIP_InvoiceItemTypeID = 	(SELECT TOP 1 VIP_InvoiceItemTypeID FROM VIP_InvoiceItemTypes WHERE InvoiceItemType = @InvoiceItemType ORDER BY VIP_InvoiceItemTypeID)

Select @InvoiceDate = (Select InvoiceDate from VIP_Invoices where VIP_InvoiceID = @VIP_InvoiceID)

--if the item type is not found them insert the new value in the table
if @VIP_InvoiceItemTypeID is null 
begin	
	Select @ZipCode = (Select ServiceZipCode from VIP_Accounts where VIP_AccountID = @VIP_AccountID)

	insert into dbo.VIP_InvoiceItemTypes
	(InvoiceItemType, Description, GPItemID, Suqenence, DefaultMask)
		
	Select top 1 DESCS, DESCS, DESCS, 1, DESCS from VIP_Tax_DETAIL where GEOCODE in
	(
		Select GEOCODE  from VIP_Tax_ZIP 
		where ZIP = left(@ZipCode,5) and DESCS = @InvoiceItemType
	)
	order by EFFDATE desc
end
-----------------------------------

Select @VIP_InvoiceItemTypeID = (SELECT TOP 1 VIP_InvoiceItemTypeID FROM VIP_InvoiceItemTypes WHERE InvoiceItemType = @InvoiceItemType ORDER BY VIP_InvoiceItemTypeID)
DECLARE @PeriodStartDate smalldatetime = (SELECT MIN(PeriodStartDate) FROM VIP_InvoiceItems WHERE VIP_InvoiceID = @VIP_InvoiceID)
DECLARE @PeriodEndDate smalldatetime = (SELECT MAX(PeriodEndDate) FROM VIP_InvoiceItems WHERE VIP_InvoiceID = @VIP_InvoiceID)

INSERT INTO VIP_InvoiceItems
VALUES (@VIP_InvoiceItemTypeID, @VIP_InvoiceID, @VIP_AccountID, NULL, NULL, @Amount, @Price, (@Amount * @Price), 'EA', @PeriodStartDate, @PeriodEndDate, 0, 0, null,0, 1, null)

GO
