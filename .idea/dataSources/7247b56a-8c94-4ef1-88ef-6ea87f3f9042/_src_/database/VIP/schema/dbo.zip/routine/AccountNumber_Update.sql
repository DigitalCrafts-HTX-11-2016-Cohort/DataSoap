


CREATE PROC dbo.AccountNumber_Update
    (
      @VIP_AccountID INT ,
      @New_UtilityAccountNumber VARCHAR(30) ,
      @Current_UtilityAccountNumber VARCHAR(30)
    )
AS
    BEGIN

        IF ( SELECT VIP_AccountID
             FROM   dbo.VIP_Accounts
             WHERE  VIP_AccountID = @VIP_AccountID
                    AND UtilityAccountNumber = @Current_UtilityAccountNumber
           ) IS NOT NULL
            BEGIN
                BEGIN TRAN

                UPDATE  dbo.VIP_Accounts
                SET     UtilityAccountNumber = @New_UtilityAccountNumber
                WHERE   VIP_AccountID = @VIP_AccountID
                        AND UtilityAccountNumber = @Current_UtilityAccountNumber

                INSERT  INTO dbo.VIP_AccountInteractions
                VALUES  ( 19, -- VIP_AccountInteractionTypeID - int
                          @VIP_AccountID, -- VIP_AccountID - int
                          NEWID(), -- VIP_AccountInteractionGUID - varchar(40)
                          2, -- InitiatedByUserID - int
                          'Complete', -- Status - varchar(20)
                          GETDATE(), -- StartDateTime - datetime
                          GETDATE(), -- EndDateTime - datetime
                          NULL  -- EffectiveDate_Override - datetime
                          )

                INSERT  INTO dbo.VIP_AccountNotes
                        ( VIP_AccountID ,
                          CreatedByUserID ,
                          CreationDateTime ,
                          Note
                        )
                VALUES  ( @VIP_AccountID , -- VIP_AccountID - int
                          2 , -- CreatedByUserID - int
                          GETDATE() , -- CreationDateTime - smalldatetime
                          'UtilityAccountNumber was updated from '
                          + @Current_UtilityAccountNumber + ' to '
                          + @New_UtilityAccountNumber + '.'  -- Note - varchar(max)
                        )

                COMMIT
            END
        ELSE
            BEGIN

                PRINT 'An account does not exist with that VIP_AccountID and UtilityAccountNumber.'

            END

    END
GO
