
CREATE PROCEDURE dbo.GetSearchItemWordBySearchItem
	@SearchItemID int
AS

SELECT
	[SearchItemWordID],
	[SearchItemID],
	[SearchWordsID],
	[Occurrences]
FROM
	dbo.SearchItemWord
WHERE
	[SearchItemID]=@SearchItemID


GO
