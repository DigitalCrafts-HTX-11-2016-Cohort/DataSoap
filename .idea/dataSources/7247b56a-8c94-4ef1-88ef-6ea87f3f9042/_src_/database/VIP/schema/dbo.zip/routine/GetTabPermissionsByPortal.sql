
CREATE PROCEDURE dbo.[GetTabPermissionsByPortal]
	
	@PortalID int

AS
SELECT *
FROM dbo.vw_TabPermissions TP
WHERE 	PortalID = @PortalID OR (PortalId IS NULL AND @PortalID IS NULL)

GO
