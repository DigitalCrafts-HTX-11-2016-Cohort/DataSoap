CREATE VIEW dbo.VIP_VIPMARKET_PGE_PaymentView
AS
SELECT     *, '' Archive
FROM         dbo.VIPMARKET_PGE_Payment
UNION
SELECT     *, 'Archived' Archive
FROM         VIP_Archive..VIPMARKET_PGE_Payment
GO
