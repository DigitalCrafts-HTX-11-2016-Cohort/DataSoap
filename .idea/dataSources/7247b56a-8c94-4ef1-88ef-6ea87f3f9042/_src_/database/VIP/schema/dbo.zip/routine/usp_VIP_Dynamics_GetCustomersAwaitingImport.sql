
CREATE PROCEDURE [dbo].[usp_VIP_Dynamics_GetCustomersAwaitingImport]
AS

SELECT ai.VIP_AccountID, ai.VIP_AccountInteractionGUID, COUNT(u.VIP_UsageID) UsageCount
FROM VIP_AccountInteractions ai
	INNER JOIN VIP_Usage u ON ai.VIP_AccountID = u.VIP_AccountID
WHERE ai.VIP_AccountInteractionTypeID = 25
	AND ai.Status = 'Pending'
GROUP BY ai.VIP_AccountID, ai.VIP_AccountInteractionGUID
HAVING COUNT(u.VIP_UsageID) > 0

UNION

SELECT ai.VIP_AccountID, ai.VIP_AccountInteractionGUID, COUNT(i.VIP_InvoiceID) UsageCount
FROM VIP_AccountInteractions ai
	INNER JOIN VIP_BillingPointAccounts bpa ON ai.VIP_AccountID = bpa.VIP_AccountID
	INNER JOIN VIP_Invoices i ON bpa.VIP_BillingPointID = i.VIP_BillingPointID
WHERE ai.VIP_AccountInteractionTypeID = 25
	AND ai.Status = 'Pending'
GROUP BY ai.VIP_AccountID, ai.VIP_AccountInteractionGUID
HAVING COUNT(i.VIP_InvoiceID) > 0
GO
