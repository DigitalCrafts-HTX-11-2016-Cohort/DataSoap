
CREATE PROCEDURE dbo.DeleteSearchWord
	@SearchWordsID int
AS

DELETE FROM dbo.SearchWord
WHERE
	[SearchWordsID] = @SearchWordsID


GO
