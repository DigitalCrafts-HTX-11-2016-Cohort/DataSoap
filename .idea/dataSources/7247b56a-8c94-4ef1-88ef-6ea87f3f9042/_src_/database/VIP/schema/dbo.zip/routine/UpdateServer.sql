
CREATE PROCEDURE dbo.UpdateServer 
    @ServerName			nvarchar(50),
    @CreatedDate		datetime,
    @LastActivityDate	datetime 
AS

	DECLARE @ServerID int
	SET @ServerID = (SELECT ServerID FROM dbo.WebServers WHERE ServerName = @ServerName)

	IF @ServerID IS NULL
		BEGIN
			-- Insert
			INSERT INTO dbo.WebServers (
				ServerName,
				CreatedDate,
				LastActivityDate
			)
			VALUES (
				@ServerName,
				@CreatedDate,
				@LastActivityDate
			)
		END
	ELSE
		BEGIN
			-- Update
			UPDATE dbo.WebServers 
				SET LastActivityDate = @LastActivityDate	
				WHERE  ServerName = @ServerName
		END
GO
