
CREATE PROCEDURE dbo.[AddDefaultPropertyDefinitions]
	@PortalID int

AS
	DECLARE @TextDataType as int
	SELECT @TextDataType = (SELECT EntryID FROM dbo.Lists WHERE ListName = 'DataType' AND Value = 'Text')
	DECLARE @CountryDataType as int
	SELECT @CountryDataType = (SELECT EntryID FROM dbo.Lists WHERE ListName = 'DataType' AND Value = 'Country')
	DECLARE @RegionDataType as int
	SELECT @RegionDataType = (SELECT EntryID FROM dbo.Lists WHERE ListName = 'DataType' AND Value = 'Region')
	DECLARE @TimeZoneDataType as int
	SELECT @TimeZoneDataType = (SELECT EntryID FROM dbo.Lists WHERE ListName = 'DataType' AND Value = 'TimeZone')
	DECLARE @LocaleDataType as int
	SELECT @LocaleDataType = (SELECT EntryID FROM dbo.Lists WHERE ListName = 'DataType' AND Value = 'Locale')
	DECLARE @RichTextDataType as int
	SELECT @RichTextDataType = (SELECT EntryID FROM dbo.Lists WHERE ListName = 'DataType' AND Value = 'RichText')
	
	DECLARE @RC int

	--Add Name Properties
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @TextDataType, '', 'Name','Prefix', 0, '', 1, 1, 50
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @TextDataType, '', 'Name','FirstName' ,0, '', 3, 1, 50
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @TextDataType, '', 'Name','MiddleName' ,0, '', 5, 1, 50
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @TextDataType, '', 'Name','LastName' ,0, '', 7, 1, 50
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @TextDataType, '', 'Name','Suffix' ,0, '', 9, 1, 50
	
	--Add Address Properties
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @TextDataType, '', 'Address','Unit' ,0, '', 11, 1, 50
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @TextDataType, '', 'Address','Street' ,0, '', 13, 1, 50
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @TextDataType, '', 'Address','City' ,0, '', 15, 1, 50
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @RegionDataType, '', 'Address','Region' ,0, '', 17, 1, 0
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @CountryDataType, '', 'Address','Country' ,0, '', 19, 1, 0
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @TextDataType, '', 'Address','PostalCode' ,0, '', 21, 1, 50

	--Add Contact Info Properties
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @TextDataType, '', 'Contact Info','Telephone' ,0, '', 23, 1, 50
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @TextDataType, '', 'Contact Info','Cell' ,0, '', 25, 1, 50
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @TextDataType, '', 'Contact Info','Fax' ,0, '', 27, 1, 50
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @TextDataType, '', 'Contact Info','Website' ,0, '', 29, 1, 50
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @TextDataType, '', 'Contact Info','IM' ,0, '', 31, 1, 50

	--Add Preferences Properties
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @RichTextDataType, '', 'Preferences','Biography' ,0, '', 33, 1, 0
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @TimeZoneDataType, '', 'Preferences','TimeZone' ,0, '', 35, 1, 0
	EXECUTE @RC = dbo.[AddPropertyDefinition] @PortalID, -1, @LocaleDataType, '', 'Preferences','PreferredLocale' ,0, '', 37, 1, 0


GO
