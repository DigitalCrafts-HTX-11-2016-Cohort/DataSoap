
CREATE VIEW dbo.[vw_Portals]
AS
	SELECT     
		PortalID, 
		PortalName, 
		CASE WHEN LEFT(LOWER(LogoFile), 6) = 'fileid' 
			THEN
				(SELECT Folder + FileName  
					FROM dbo.Files 
					WHERE 'fileid=' + convert(varchar,dbo.Files.FileID) = LogoFile
				) 
			ELSE 
				LogoFile  
			END 
		AS LogoFile,
		FooterText, 
		ExpiryDate, 
		UserRegistration, 
		BannerAdvertising, 
		AdministratorId, 
		Currency, 
		HostFee, 
		HostSpace, 
		PageQuota, 
		UserQuota, 
		AdministratorRoleId, 
		RegisteredRoleId, 
		Description, 
		KeyWords, 
		CASE WHEN LEFT(LOWER(BackgroundFile), 6) = 'fileid' 
			THEN
				(SELECT Folder + FileName  
					FROM dbo.Files 
					WHERE 'fileid=' + convert(varchar,dbo.Files.FileID) = BackgroundFile
				) 
			ELSE 
				BackgroundFile  
			END 
		AS BackgroundFile,
		GUID, 
		PaymentProcessor, 
		ProcessorUserId, 
		ProcessorPassword, 
		SiteLogHistory,
		Email, 
		DefaultLanguage, 
		TimezoneOffset, 
		AdminTabId, 
		HomeDirectory, 
		SplashTabId, 
		HomeTabId, 
		LoginTabId, 
		UserTabId,
		(SELECT TOP 1 TabID FROM dbo.Tabs WHERE (PortalID IS NULL) AND (ParentId IS NULL)) AS SuperTabId,
		(SELECT TOP 1 RoleName FROM dbo.Roles WHERE (RoleID = P.AdministratorRoleId)) AS AdministratorRoleName,
		(SELECT TOP 1 RoleName FROM dbo.Roles WHERE (RoleID = P.RegisteredRoleId)) AS RegisteredRoleName
	FROM dbo.Portals AS P
	LEFT OUTER JOIN dbo.Users AS U ON P.AdministratorId = U.UserID
GO
