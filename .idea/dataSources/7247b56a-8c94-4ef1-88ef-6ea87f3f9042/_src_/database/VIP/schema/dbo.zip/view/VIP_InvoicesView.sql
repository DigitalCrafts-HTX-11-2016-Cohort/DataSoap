
/*
 - 2017-02-03 - BPanjavan - Taking this over to use for Emerald, will add new columns
 
 Note to self and others.  Do NOT removed that stupid "Archived" column, that is a remnant of when we were "archiving" data in VIP_Archive.  I don't dwell on the past

SELECT TOP 100 * FROM [dbo].[VIP_InvoicesView] WHERE CustomerName <> '' ORDER BY VIP_InvoiceID DESC
SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'VIP_InvoicesView' ORDER BY ORDINAL_POSITION

*/
CREATE VIEW [dbo].[VIP_InvoicesView]
AS
    SELECT  
		inv.* ,
        '' Archived
		,accuView.VIP_AccountID
		,CustomerName = accuView.Derrive_CustomerName
    FROM    
		dbo.VIP_Invoices inv
		LEFT JOIN dbo.VIP_BillingPointAccounts bpa ON bpa.VIP_BillingPointID = inv.VIP_BillingPointID
		LEFT JOIN AccountServicePoint.mv_VIP_AccountCumulativeView_v2 accuView ON accuView.VIP_AccountID = bpa.VIP_AccountID
--UNION
--SELECT     *, 'Archived' Archived
--FROM         VIP_Archive..VIP_Invoices

GO
