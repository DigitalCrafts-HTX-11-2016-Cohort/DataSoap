
create procedure dbo.AddPortalDesktopModule

@PortalID int,
@DesktopModuleId int

as

insert into dbo.PortalDesktopModules ( 
  PortalId,
  DesktopModuleId
)
values (
  @PortalID,
  @DesktopModuleId
)

select SCOPE_IDENTITY()


GO
