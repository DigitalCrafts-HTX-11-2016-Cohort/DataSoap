CREATE VIEW dbo.VIP_PaymentBreakdownView
AS
SELECT     *, '' Archived
FROM         dbo.VIP_PaymentBreakdowns
UNION
SELECT     *, 'Archived' Archived
FROM         VIP_Archive..VIP_PaymentBreakdowns
GO
