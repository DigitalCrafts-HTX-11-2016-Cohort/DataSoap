
CREATE procedure dbo.[UpdateTabOrder]
	@TabId		int,
	@TabOrder	int,
	@Level		int,
	@ParentId	int,
	@TabPath	nvarchar(255)
AS
	UPDATE dbo.Tabs
	SET		
		TabOrder = @TabOrder,
		[Level] = @Level,
		ParentId = @ParentId,
		TabPath = @TabPath
	WHERE  TabId = @TabId

GO
