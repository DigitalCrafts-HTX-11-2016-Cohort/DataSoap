
CREATE PROCEDURE dbo.[GetTabModules]

	@TabId int

AS
SELECT	* 
FROM dbo.vw_Modules
WHERE  TabId = @TabId
ORDER BY ModuleOrder


GO
