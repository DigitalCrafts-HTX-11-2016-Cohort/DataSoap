
CREATE PROCEDURE dbo.DeleteSearchItem
	@SearchItemID int
AS

DELETE FROM dbo.SearchItem
WHERE
	[SearchItemID] = @SearchItemID


GO
