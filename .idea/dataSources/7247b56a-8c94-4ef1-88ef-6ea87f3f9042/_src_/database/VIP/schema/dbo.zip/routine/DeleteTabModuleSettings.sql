
create procedure dbo.DeleteTabModuleSettings
@TabModuleId      int
as

DELETE FROM dbo.TabModuleSettings 
WHERE TabModuleId = @TabModuleId


GO
