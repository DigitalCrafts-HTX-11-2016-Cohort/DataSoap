-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_VIP_GetDailyUsage]
	@VIP_Accountid int, @VIP_MeterID int,
	@StartDate smalldatetime, @EndDate smalldatetime
AS

Select *, IntoleranceAmount + ToleranceAmount + (DeficientUsageAmount * DefficientCommodityPrice)  DailyCharge,
case when Fuel = 1 then
	ISNULL(
	(	
		TolerantUsage/
			(
				Select top 1 inverse from dbo.VIP_UtilityFuel where vip_utilityid in
				(
					Select vip_utilityid from vip_accounts where vip_accountid = @VIP_Accountid
				) and EffectiveDate <= @StartDate order by EffectiveDate desc
			)- TolerantUsage
	) ,0) 
	else
	0 end TolerantFuelAmount,
case when Fuel = 1 and BandwidhtZone = 'High' then
	ISNULL(
	(
		IntolerantUsage/
			(
				Select top 1 inverse from dbo.VIP_UtilityFuel where vip_utilityid in
				(
					Select vip_utilityid from vip_accounts where vip_accountid = @VIP_Accountid
				) and EffectiveDate <= @StartDate order by EffectiveDate desc
			) - IntolerantUsage
	) ,0)
	when Fuel = 1 and BandwidhtZone = 'Low' then		
		ISNULL(
		(
			DeficientUsageAmount/
				(
					Select top 1 inverse from dbo.VIP_UtilityFuel where vip_utilityid in
					(
						Select vip_utilityid from vip_accounts where vip_accountid = @VIP_Accountid
					) and EffectiveDate <= @StartDate order by EffectiveDate desc
				) - DeficientUsageAmount
		) ,0)
	else
	0 end InTolerantFuelAmount
 from 
(
	Select *, 
	--calculate the intolerance amount when the usage exceeds the max bandwidth
	--(IntoleranceIndexPrice + InToleranceCreditDebit) * IntolerantUsage IntoleranceAmount,
	(IntoleranceIndexPrice + BandwidthHighAdder) * IntolerantUsage IntoleranceAmount,

	--if the usage amount is greater than the max tolerance amount then multiply by the max tolerance amount
	--multiply the usage amount * the gas daily average if the amount falls within the bandwidth
	case when UsageAmount > MaxToleranceUsageAmount then
			(ToleranceIndexPrice + VariableAdder) * MaxToleranceUsageAmount 
		 when UsageAmount >= MinToleranceUsageAmount and UsageAmount <= MaxToleranceUsageAmount then
			(ToleranceIndexPrice + VariableAdder) * UsageAmount
		 when UsageAmount < MinToleranceUsageAmount then
			((ToleranceIndexPrice + VariableAdder) * UsageAmount) 
			--+
			--( 
			--	(MinToleranceUsageAmount - UsageAmount) 
			--	*
			--	((BandwidthIndexPrice + variableadder) - (GasDailyAverage + BandwidthLowAdder))
			--)
		 else 
			(ToleranceIndexPrice + VariableAdder) * UsageAmount
	 end ToleranceAmount,	
	 
	case when UsageAmount < MinToleranceUsageAmount then		     
		MinToleranceUsageAmount - UsageAmount		  
		else 0
	 end DeficientUsageAmount,
	 
	 case when UsageAmount < MinToleranceUsageAmount then
		((ContractedIndexPrice + variableadder) - (GasDailyAverage - BandwidthLowAdder))	 
		else 0
	 end DefficientCommodityPrice,
	  	 
	 ContractedIndexPrice - GasDailyAverage LowerBandwidthIndexPrice,
	 case when UsageAmount < MinToleranceUsageAmount then
			   MinToleranceUsageAmount - UsageAmount 
		  else 0	 
	 end DiffUsageMinTolerance,	 	 
	 case when UsageReportedUOM = 'CCF' and UsageType = 'DAILY' and ProductUOM = 'DEKATHERMS' then
			  'Dktherm=(UsgRep x BTUFactor) / 10'
		  when UsageReportedUOM = 'CCF' and UsageType = 'NON-DAILY' and ProductUOM = 'DEKATHERMS' then
			  'Dktherm=(((HeatFactor x HDD) + BaseLoad) * BTUFactor) / 10'			  	  
		  
		  when UsageReportedUOM = 'MCF' and UsageType = 'DAILY' and ProductUOM = 'DEKATHERMS' then
			  'Dktherm=(UsgRep x BTUFactor)'
		  when UsageReportedUOM = 'MCF' and UsageType = 'NON-DAILY' and ProductUOM = 'DEKATHERMS' then
			  'Dktherm=(((HeatFactor x HDD) + BaseLoad) * BTUFactor)'
		  
		  when UsageReportedUOM = 'CCF' and UsageType = 'DAILY' and ProductUOM = 'THERMS' then
			  'Therm=UsgRep x BTUFactor'
		  when UsageReportedUOM = 'CCF' and UsageType = 'NON-DAILY' and ProductUOM = 'THERMS' then
			  'Therm=((HeatFactor x HDD) + BaseLoad) * BTUFactor'			  
		  when UsageReportedUOM = 'MCF' and UsageType = 'DAILY' and ProductUOM = 'THERMS' then
			  'Therm=(UsgRep x BTUFactor) * 10'
		  when UsageReportedUOM = 'MCF' and UsageType = 'NON-DAILY' and ProductUOM = 'THERMS' then
			  'Therm=(((HeatFactor x HDD) + BaseLoad) * BTUFactor) * 10'
		  end Formula,
	case when BandwidhtZone = 'Low' and BandwidthLowAdder <> 0 then convert(varchar(10),BandwidthLowAdder) else '' end GDAdjustmentLow
	 from 
		(
		Select *,
		case when b.UsageAmount > b.MaxToleranceUsageAmount then 'High'
			 when b.UsageAmount < b.MinToleranceUsageAmount then 'Low'
			 else 'Mid' end BandwidhtZone,
		case when b.UsageAmount > b.MaxToleranceUsageAmount then 'True' else 'False' end MaxTolVisible,
		case when b.UsageAmount < b.MinToleranceUsageAmount then 'True' else 'False' end MinTolVisible,
		case when b.UsageAmount >= b.MinToleranceUsageAmount and b.UsageAmount <= b.MaxToleranceUsageAmount then 'True' else 'False' end MarginalVisible,

		isnull(
		case when b.UsageAmount > b.MaxToleranceUsageAmount then b.UsageAmount - b.MaxToleranceUsageAmount end
		,0) IntolerantUsage,
		
		isnull(
		case when b.UsageAmount > b.MaxToleranceUsageAmount then b.MaxToleranceUsageAmount else b.UsageAmount end
		,0) TolerantUsage,		
			 GasDailyAverage as IntoleranceIndexPrice,		 
		
			 ContractedIndexPrice as ToleranceIndexPrice,
		case when b.UsageAmount > b.MaxToleranceUsageAmount then 'Swing Adder'
			 when b.UsageAmount < b.MinToleranceUsageAmount then '(MinTolUsg-Usg)x(ContPrice-(GDA-GDAdjustment))'
			 else '-' end InToleranceHeader,
			 	 
		case when b.UsageAmount > b.MaxToleranceUsageAmount then BandwidthHighAdder
			 when b.UsageAmount < b.MinToleranceUsageAmount then 			 
			( 
				(MinToleranceUsageAmount - UsageAmount) 
				*
				((ContractedIndexPrice + VariableAdder) - (GasDailyAverage + BandwidthLowAdder))
			)
			 else 0 end InToleranceCreditDebit
		 from 
		(
			Select *,
			convert(numeric(10,2), (a.ContractedUsage * (a.MaxTolerancePercentage * .01) + a.ContractedUsage)) MaxToleranceUsageAmount,
			convert(numeric(10,2),(a.ContractedUsage - (a.ContractedUsage * (a.MinTolerancePercentage * .01)))) MinToleranceUsageAmount
			 from
			(
				Select *, 	
				(
					Select top 1 Fuel from vip_accountproducts where vip_accountid = @VIP_Accountid and
					(StartDate <= SeedDate and enddate >= SeedDate)
				) Fuel,
				isnull(
				(
					Select top 1 usageamount from vip_usage where vip_accountid = @VIP_Accountid and VIP_UsageTypeID = 1
					and month(StartDate) = Month(SeedDate) order by startdate 
				) / DATEDIFF(d, Convert(varchar(2),month(SeedDate)) + '/1/' + convert(varchar(4), year(SeedDate)),
				    dateadd(m,1, convert(varchar(2),month(SeedDate)) + '/1/' + convert(varchar(4), year(SeedDate)))) ,0) ContractedUsage,				
				isnull(
				(
					Select top 1 variableproductindexprice from vip_variableproductindexprices where vip_variableproductindexID in
					(
						Select BandwidthVariableProductIndexID from vip_products where vip_productid in
						(
							Select vip_productid from vip_accountproducts where vip_accountid = @VIP_Accountid and
							(StartDate <= SeedDate and enddate >= SeedDate)
						)
					) and EffectiveStartDate <= SeedDate and EffectiveEndDate >= SeedDate
				),0) BandwidthIndexPrice,						
				isnull(
				(
					Select top 1 variableproductindexprice from vip_variableproductindexprices where vip_variableproductindexID in
					(
						Select BandwidthVariableProductIndexID from vip_products where vip_productid in
						(
							Select vip_productid from vip_accountproducts where vip_accountid = @VIP_Accountid and
							(StartDate <= @StartDate and EndDate >= @EndDate)
						)
					) and EffectiveStartDate = vip_seeddates.SeedDate 
				),0) GasDailyAverage,
				isnull(
				(
					Select top 1 variableproductindexprice from vip_variableproductindexprices where vip_variableproductindexID in
					(
						Select CommoidtyVariableProductIndexID from vip_products where vip_productid in
						(
							Select vip_productid from vip_accountproducts where vip_accountid = @VIP_Accountid and
							(StartDate <= @StartDate and EndDate >= @EndDate)
						)
					) and (EffectiveStartDate <= vip_seeddates.SeedDate and EffectiveEndDate >= vip_seeddates.SeedDate)
					--and EffectiveStartDate = vip_seeddates.SeedDate 
				),0) ContractedIndexPrice,
				(			
					Select Name from dbo.VIP_ProductPricingTypes where VIP_ProductPricingTypeID in
					(
						Select VIP_ProductPricingTypeID from vip_products where vip_productid in
						(
							Select vip_productid from vip_accountproducts where vip_accountid = @VIP_Accountid and
							(StartDate <= SeedDate and enddate >= SeedDate)
						)
					)
				) ProductPricingType,				
				(			
					Select Name from dbo.VIP_UnitsOfMeasure where vip_unitofmeasureid in
					(
						Select vip_unitofmeasureid from vip_products where vip_productid in
						(
							Select vip_productid from vip_accountproducts where vip_accountid = @VIP_Accountid and
							(StartDate <= SeedDate and enddate >= SeedDate)
						)
					)
				) ProductUOM,			
				(
					Select FixedPrice from vip_accountproducts 
					where vip_accountid = @VIP_Accountid and
					(StartDate <= SeedDate and enddate >= SeedDate)
				) FixedPrice,
				case 
				 when month(SeedDate) = 1 then 'J' + convert(varchar(2), day(SeedDate))
				 when month(SeedDate) = 2 then 'F' + convert(varchar(2), day(SeedDate))
				 when month(SeedDate) = 3 then 'M' + convert(varchar(2), day(SeedDate))
				 when month(SeedDate) = 4 then 'A' + convert(varchar(2), day(SeedDate))
				 when month(SeedDate) = 5 then 'M' + convert(varchar(2), day(SeedDate))
				 when month(SeedDate) = 6 then 'J' + convert(varchar(2), day(SeedDate))
				 when month(SeedDate) = 7 then 'J' + convert(varchar(2), day(SeedDate))
				 when month(SeedDate) = 8 then 'A' + convert(varchar(2), day(SeedDate))
				 when month(SeedDate) = 9 then 'S' + convert(varchar(2), day(SeedDate))
				 when month(SeedDate) = 10 then 'O' + convert(varchar(2), day(SeedDate))
				 when month(SeedDate) = 11 then 'N' + convert(varchar(2), day(SeedDate))
				 when month(SeedDate) = 12 then 'D' + convert(varchar(2), day(SeedDate))
				 end MonthDay,		
				convert(varchar(10), SeedDate, 101) SeedDateNew,
					isnull(
					(
						Select VariableAdder from vip_accountproducts 
						where vip_accountid = @VIP_Accountid
						and startdate <= vip_seeddates.SeedDate and enddate >= vip_seeddates.SeedDate	
					),0) VariableAdder,
					isnull(
					(	
						Select convert(numeric(10,2), usageamount) From dbo.VIP_UsageDaily 
						where VIP_Accountid = @VIP_Accountid and VIP_MeterID = @VIP_MeterID
						and usagedate = vip_seeddates.SeedDate 
					), 0) UsageAmount,
					isnull(
					(
						Select convert(numeric(10,2),BandwidthUsageAmount) from vip_accountproducts 
						where vip_accountid = @VIP_Accountid 
						and startdate <= vip_seeddates.SeedDate and enddate >= vip_seeddates.SeedDate	
					),0) BandwidthUsageAmount,
					isnull(
					(
						Select convert(numeric(10,0), BandwidthMaxPercentage) from vip_accountproducts 
						where vip_accountid = @VIP_Accountid
						and startdate <= vip_seeddates.SeedDate and enddate >= vip_seeddates.SeedDate
					),0) MaxTolerancePercentage,
					isnull(
					(
						Select  convert(numeric(10,0), BandwidthMinPercentage) from vip_accountproducts 
						where vip_accountid = @VIP_Accountid
						and startdate <= vip_seeddates.SeedDate and enddate >= vip_seeddates.SeedDate	
					),0) MinTolerancePercentage,			
					isnull(
					(
						Select  convert(numeric(10,5), BandwidthLowAdder) from vip_accountproducts 
						where vip_accountid = @VIP_Accountid
						and startdate <= vip_seeddates.SeedDate and enddate >= vip_seeddates.SeedDate	
					),0) BandwidthLowAdder,
					isnull(
					(
						Select  convert(numeric(10,5), BandwidthHighAdder) from vip_accountproducts 
						where vip_accountid = @VIP_Accountid
						and startdate <= vip_seeddates.SeedDate and enddate >= vip_seeddates.SeedDate	
					),0) BandwidthHighAdder,			
					isnull(
					(	
						Select UsageType From dbo.VIP_UsageDaily 
						where VIP_Accountid = @VIP_Accountid and VIP_MeterID = @VIP_MeterID
						and usagedate = vip_seeddates.SeedDate 
					), '-') UsageType,
					
					isnull(
					(	
						Select UsageReported From dbo.VIP_UsageDaily 
						where VIP_Accountid = @VIP_Accountid and VIP_MeterID = @VIP_MeterID
						and usagedate = vip_seeddates.SeedDate 
					), 0) UsageReported,
					isnull(
					(	
						Select UOM From dbo.VIP_UsageDaily 
						where VIP_Accountid = @VIP_Accountid and VIP_MeterID = @VIP_MeterID
						and usagedate = vip_seeddates.SeedDate 
					), '-') UsageReportedUOM,													
					(
						Select top 1 Name from dbo.VIP_VariableProductIndexes where VIP_VariableProductIndexID in
						(
							Select commoidtyvariableproductindexid from vip_products where vip_productid in
							(
								Select vip_productid from vip_accountproducts where vip_accountid = @VIP_Accountid
								and startdate <= vip_seeddates.SeedDate and enddate >= vip_seeddates.SeedDate
							)
						)
					) TolerantIndexName,
					(
						Select top 1 Name from dbo.VIP_VariableProductIndexes where VIP_VariableProductIndexID in
						(
							Select BandwidthVariableProductIndexID from vip_products where vip_productid in
							(
								Select vip_productid from vip_accountproducts where vip_accountid = @VIP_Accountid
								and startdate <= vip_seeddates.SeedDate and enddate >= vip_seeddates.SeedDate
							)
						)
					) IntolerantIndexName,
					isnull(
					(	
						Select Baseload From dbo.VIP_UsageDaily 
						where VIP_Accountid = @VIP_Accountid and VIP_MeterID = @VIP_MeterID
						and usagedate = vip_seeddates.SeedDate 
					), 0) Baseload,	
					isnull(
					(	
						Select HeatFactor From dbo.VIP_UsageDaily 
						where VIP_Accountid = @VIP_Accountid and VIP_MeterID = @VIP_MeterID
						and usagedate = vip_seeddates.SeedDate 
					), 0) HeatFactor,
					isnull(
					(	
						Select HDD From dbo.VIP_UsageDaily 
						where VIP_Accountid = @VIP_Accountid and VIP_MeterID = @VIP_MeterID
						and usagedate = vip_seeddates.SeedDate 
					), 0) HDD,
					isnull(
					(	
						Select BTUFactor From dbo.VIP_UsageDaily 
						where VIP_Accountid = @VIP_Accountid and VIP_MeterID = @VIP_MeterID
						and usagedate = vip_seeddates.SeedDate 
					), 0) BTUFactor
				 from vip_seeddates
				where SeedDate between @StartDate and @EndDate
			) a
		) b
	) c
) d
GO
