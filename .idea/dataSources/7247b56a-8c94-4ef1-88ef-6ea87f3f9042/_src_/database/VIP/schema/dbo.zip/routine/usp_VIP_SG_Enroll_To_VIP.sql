-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_VIP_SG_Enroll_To_VIP]
	@AccountNumber varchar(12)
AS

DECLARE @intErrorCode INT

declare @VIP_BatchEnrollmentEntryID int
declare @VIP_MeterID int

BEGIN TRAN

--DECLARE @message_string VARCHAR(255)  
--SET @message_string = ''  
--RAISERROR(@message_string, 16, 1)


------------------------------------------------- INSERT ACCOUNT DATA  ----------------------------
insert into dbo.VIP_BatchEnrollmentEntries
(
VIP_RetailerID,
VIP_UtilityID,
VIP_AccountClassID,
VIP_MarketerID,
VIP_MarketerAgentID,
VIP_ProductBundleID,
ProcessingGUID,
BatchEnrollmentStatus,
BatchEnrollmentFile,
UtilityAccountNumber,
UtilityServiceAccountID,
UtilityMeterNumber,
TaxExempt,
LifeSupport,
CompanyName,
ServiceFirstName,
ServiceLastName,
ServiceAddress1,
ServiceAddress2,
ServiceCity,
ServiceStateCode,
ServiceCounty,
ServiceZipCode,
ServicePhone,
ServiceEmail,
BillingFirstName,
BillingLastName,
BillingAddress1,
BillingAddress2,
BillingCity,
BillingStateCode,
BillingCounty,
BillingZipCode,
BillingPhone,
BillingEmail,
ContractMonths,
MasterAccountID,
VerificationID,
DateSold,
Notes,
ContractStartDate,
ContractEndDate,
LoadedDateTime,
CoreCustomer,
Consolidated_Pin,
Confirmation_Rate_Code,
RetailerAccountNumber
)
	Select 
	1, -- VIP_RetailerID
	(Select VIP_UtilityID from VIP_Utilities where Code = 'SG'), -- VIP_UtilityID
	case when Bill_Class = 'RES' then 1 else 2 end, --VIP_AccountClassID	
	(
		Select  
		  case when rolename = 'SG_CSS_Group' then (Select VIP_MarketerID from VIP_Marketers where Code = 'CSS5')
			   else (Select VIP_MarketerID from VIP_Marketers where Code = 'VEM')
			   end Marketer
		from Roles where RoleID in
		(
			Select roleid from UserRoles where userid in
			(
				Select userid from Users where UserID = VIPMARKET_SG_ELG_PREMISE.userid
			)
		) and RoleName in('SG_VISTA_Group','SG_CSS_Group','SG_VIP_Web_Enrollment','SG_VISTA_Admin_Group')
	),--VIP_Marketer			
	(
		Select  
		  case when rolename = 'SG_CSS_Group' then (Select VIP_MarketerAgentID from VIP_MarketerAgents where FirstName = 'CSS5')
			   else (Select VIP_MarketerAgentID from VIP_MarketerAgents where FirstName = 'VEM')
			   end Marketer
		from Roles where RoleID in
		(
			Select roleid from UserRoles where userid in
			(
				Select userid from Users where UserID = VIPMARKET_SG_ELG_PREMISE.userid
			)
		) and RoleName in('SG_VISTA_Group','SG_CSS_Group','SG_VIP_Web_Enrollment','SG_VISTA_Admin_Group')
	),--vip_marketeragent	
	-1 ProductBundleID, --VIP_ProductBundleid
	NEWID() ProcessingGuid, --ProcessingGuid
	 'Loaded' BatchEnrollmentStatus, --batch enrollment status
	'' BatchEnrollmentFile, --bath enrollment file name
	Account_Number, --Utility Account Number
	Customer_Number, --Utility Service Accountid
	Meter_Number, --UtilityMeterNumber
	0, --Tax Exempt
	0, --Life Support	
	case when LEN(Last_Name) > 30 then Last_Name else '' end, --Company name
	First_Name,  --Service FirstName
	case when LEN(Last_Name) <= 30 then Last_Name else '' end,  --Service LastName
	Service_Address,  --ServiceAddress1
	'',--ServiceAddress2
	Service_City, --ServiceCity
	Service_State, --ServiceStateCode
	'', --ServiceCounty
	Service_Zip, --ServiceZipCode
	Telephone,--ServicePhone
	Email,--ServiceEmail
	First_Name,--BillingFirstName
	case when LEN(Last_Name) <= 30 then Last_Name else '' end,--BillingLastName
	MailingAddress,--BillingAddress1
	'',--BillingAddress2
	MailingCity,--BillingCity
	MailingState, --BillingStateCode
	'',--BillingCounty
	MailingZip,--BillingZipCode
	Telephone,--BillingPhone
	Email,--BillingEmail
	12,--ContractMonths
	(select left(replace(NEWID(),'-',''), 20)),--MasterAccountID
	Confirmation_ID,--VerificationID
	ConfDatetime,--DateSold
	'',--Notes
	convert(varchar(10), getdate(), 101),--ContractStartDate
	convert(varchar(10), DATEADD(YYYY,1, getdate()), 101), --ContractEndDate
	getdate(),--LoadedDateTime
	'Y',--CoreCustomer
	Consolidated_Pin,
	Confirmation_Code,
	Premise_Number
	 from dbo.VIPMARKET_SG_ELG_PREMISE where status = 'Enrolled'
	 and account_number = @AccountNumber
	 	 
	 set @VIP_BatchEnrollmentEntryID = (Select max(VIP_BatchEnrollEntryID) from VIP_BatchEnrollmentEntries )--@@IDENTITY
	 --select @VIP_BatchEnrollmentEntryID
	 
	 -----------------------------   INSERT METER  ----------------------------------
 	 insert into dbo.VIPMARKET_Meters
 	 (
		 VIP_BatchEnrollEntryID,
		 MeterNumber,
		 StartDate,
		 EndDate,
		 VIP_UtilityPipelineID,
		 BaseLoad,
		 FlowStartDate,
		 DailyUsage
	 )	 
	 Select 
		@VIP_BatchEnrollmentEntryID,--VIP_BatchEnrollEntryID, 
		Meter_Number,--MeterNumber, 
		convert(varchar(10), getdate(), 101), --StartDate
		convert(varchar(10), DATEADD(YYYY,1, getdate()), 101),--EndDate
		0,--VIP_UtilityPipelineID, 
		0.00000,--BaseLoad, 
		'1900-01-01 00:00:00', --FlowStartDate, 
		0--DailyUsage
		from dbo.VIPMARKET_SG_ELG_PREMISE 
	where status = 'Enrolled' and account_number = @AccountNumber
	
	Set @VIP_MeterID = (Select max(VIPMARKET_MeterID) from VIPMARKET_Meters )
	
	-------------------------------    USAGE    --------------------------------------
	
	
	insert into dbo.VIPMARKET_Usage
	(
	VIP_BatchEnrollEntryID, 
	VIPMARKET_MeterID, 
	VIP_UsageTypeID, 
	VIP_AccountInteractionGUID, 
	StartDate, 
	EndDate, 
	BeginRead, 
	EndRead, 
	UsageAmount, 
	UnitOfMeasure, 
	TransportAmount, 
	FuelAmount, 
	MeterChannel
	)	
	Select  
	@VIP_BatchEnrollmentEntryID,--VIP_BatchEnrollEntryID, 
	@VIP_MeterID,--VIPMARKET_MeterID 
	1,--VIP_UsageTypeID
	NEWID(),--VIP_AccountInteractionGUID, 
	'1/1/2011',--StartDate
	'1/31/2011',--EndDate, 
	0, --BeginRead, 
	0, --EndRead, 
	Jan_Prem_Usage,--UsageAmount, 
	'THERMS',--UnitOfMeasure
	0.00,--TransportAmount, 
	0.00,--FuelAmount, 
	''--MeterChannel
	from dbo.VIPMARKET_SG_ELG_PREMISE where status = 'Enrolled' and account_number = @AccountNumber
	union
	Select  
	@VIP_BatchEnrollmentEntryID,--VIP_BatchEnrollEntryID, 
	@VIP_MeterID,--VIPMARKET_MeterID 
	1,--VIP_UsageTypeID
	NEWID(),--VIP_AccountInteractionGUID, 
	'2/1/2011',--StartDate
	'2/28/2011',--EndDate, 
	0, --BeginRead, 
	0, --EndRead, 
	Feb_Prem_Usage,--UsageAmount, 
	'THERMS',--UnitOfMeasure
	0.00,--TransportAmount, 
	0.00,--FuelAmount, 
	''--MeterChannel
	from dbo.VIPMARKET_SG_ELG_PREMISE where status = 'Enrolled' and account_number = @AccountNumber
	union
	Select  
	@VIP_BatchEnrollmentEntryID,--VIP_BatchEnrollEntryID, 
	@VIP_MeterID,--VIPMARKET_MeterID 
	1,--VIP_UsageTypeID
	NEWID(),--VIP_AccountInteractionGUID, 
	'3/1/2011',--StartDate
	'3/31/2011',--EndDate, 
	0, --BeginRead, 
	0, --EndRead, 
	Mar_Prem_Usage,--UsageAmount, 
	'THERMS',--UnitOfMeasure
	0.00,--TransportAmount, 
	0.00,--FuelAmount, 
	''--MeterChannel
	from dbo.VIPMARKET_SG_ELG_PREMISE where status = 'Enrolled' and account_number = @AccountNumber
	union
	Select  
	@VIP_BatchEnrollmentEntryID,--VIP_BatchEnrollEntryID, 
	@VIP_MeterID,--VIPMARKET_MeterID 
	1,--VIP_UsageTypeID
	NEWID(),--VIP_AccountInteractionGUID, 
	'4/1/2011',--StartDate
	'4/30/2011',--EndDate, 
	0, --BeginRead, 
	0, --EndRead, 
	Apr_Prem_Usage,--UsageAmount, 
	'THERMS',--UnitOfMeasure
	0.00,--TransportAmount, 
	0.00,--FuelAmount, 
	''--MeterChannel
	from dbo.VIPMARKET_SG_ELG_PREMISE where status = 'Enrolled' and account_number = @AccountNumber
	union
	Select  
	@VIP_BatchEnrollmentEntryID,--VIP_BatchEnrollEntryID, 
	@VIP_MeterID,--VIPMARKET_MeterID 
	1,--VIP_UsageTypeID
	NEWID(),--VIP_AccountInteractionGUID, 
	'5/1/2011',--StartDate
	'5/31/2011',--EndDate, 
	0, --BeginRead, 
	0, --EndRead, 
	May_Prem_Usage,--UsageAmount, 
	'THERMS',--UnitOfMeasure
	0.00,--TransportAmount, 
	0.00,--FuelAmount, 
	''--MeterChannel
	from dbo.VIPMARKET_SG_ELG_PREMISE where status = 'Enrolled' and account_number = @AccountNumber
	union
	Select  
	@VIP_BatchEnrollmentEntryID,--VIP_BatchEnrollEntryID, 
	@VIP_MeterID,--VIPMARKET_MeterID 
	1,--VIP_UsageTypeID
	NEWID(),--VIP_AccountInteractionGUID, 
	'6/1/2011',--StartDate
	'6/30/2011',--EndDate, 
	0, --BeginRead, 
	0, --EndRead, 
	Jun_Prem_Usage,--UsageAmount, 
	'THERMS',--UnitOfMeasure
	0.00,--TransportAmount, 
	0.00,--FuelAmount, 
	''--MeterChannel
	from dbo.VIPMARKET_SG_ELG_PREMISE where status = 'Enrolled' and account_number = @AccountNumber
	union
	Select  
	@VIP_BatchEnrollmentEntryID,--VIP_BatchEnrollEntryID, 
	@VIP_MeterID,--VIPMARKET_MeterID 
	1,--VIP_UsageTypeID
	NEWID(),--VIP_AccountInteractionGUID, 
	'7/1/2011',--StartDate
	'7/31/2011',--EndDate, 
	0, --BeginRead, 
	0, --EndRead, 
	Jul_Prem_Usage,--UsageAmount, 
	'THERMS',--UnitOfMeasure
	0.00,--TransportAmount, 
	0.00,--FuelAmount, 
	''--MeterChannel
	from dbo.VIPMARKET_SG_ELG_PREMISE where status = 'Enrolled' and account_number = @AccountNumber
	union
	Select  
	@VIP_BatchEnrollmentEntryID,--VIP_BatchEnrollEntryID, 
	@VIP_MeterID,--VIPMARKET_MeterID 
	1,--VIP_UsageTypeID
	NEWID(),--VIP_AccountInteractionGUID, 
	'8/1/2011',--StartDate
	'8/31/2011',--EndDate, 
	0, --BeginRead, 
	0, --EndRead, 
	Aug_Prem_Usage,--UsageAmount, 
	'THERMS',--UnitOfMeasure
	0.00,--TransportAmount, 
	0.00,--FuelAmount, 
	''--MeterChannel
	from dbo.VIPMARKET_SG_ELG_PREMISE where status = 'Enrolled' and account_number = @AccountNumber
	union
	Select  
	@VIP_BatchEnrollmentEntryID,--VIP_BatchEnrollEntryID, 
	@VIP_MeterID,--VIPMARKET_MeterID 
	1,--VIP_UsageTypeID
	NEWID(),--VIP_AccountInteractionGUID, 
	'9/1/2011',--StartDate
	'9/30/2011',--EndDate, 
	0, --BeginRead, 
	0, --EndRead, 
	Sep_Prem_Usage,--UsageAmount, 
	'THERMS',--UnitOfMeasure
	0.00,--TransportAmount, 
	0.00,--FuelAmount, 
	''--MeterChannel
	from dbo.VIPMARKET_SG_ELG_PREMISE where status = 'Enrolled' and account_number = @AccountNumber
	union
	Select  
	@VIP_BatchEnrollmentEntryID,--VIP_BatchEnrollEntryID, 
	@VIP_MeterID,--VIPMARKET_MeterID 
	1,--VIP_UsageTypeID
	NEWID(),--VIP_AccountInteractionGUID, 
	'10/1/2011',--StartDate
	'10/31/2011',--EndDate, 
	0, --BeginRead, 
	0, --EndRead, 
	Oct_Prem_Usage,--UsageAmount, 
	'THERMS',--UnitOfMeasure
	0.00,--TransportAmount, 
	0.00,--FuelAmount, 
	''--MeterChannel
	from dbo.VIPMARKET_SG_ELG_PREMISE where status = 'Enrolled' and account_number = @AccountNumber
	union
	Select  
	@VIP_BatchEnrollmentEntryID,--VIP_BatchEnrollEntryID, 
	@VIP_MeterID,--VIPMARKET_MeterID 
	1,--VIP_UsageTypeID
	NEWID(),--VIP_AccountInteractionGUID, 
	'11/1/2011',--StartDate
	'11/30/2011',--EndDate, 
	0, --BeginRead, 
	0, --EndRead, 
	Nov_Prem_Usage,--UsageAmount, 
	'THERMS',--UnitOfMeasure
	0.00,--TransportAmount, 
	0.00,--FuelAmount, 
	''--MeterChannel
	from dbo.VIPMARKET_SG_ELG_PREMISE where status = 'Enrolled' and account_number = @AccountNumber
	union
	Select  
	@VIP_BatchEnrollmentEntryID,--VIP_BatchEnrollEntryID, 
	@VIP_MeterID,--VIPMARKET_MeterID 
	1,--VIP_UsageTypeID
	NEWID(),--VIP_AccountInteractionGUID, 
	'12/1/2011',--StartDate
	'12/31/2011',--EndDate, 
	0, --BeginRead, 
	0, --EndRead, 
	Dec_Prem_Usage,--UsageAmount, 
	'THERMS',--UnitOfMeasure
	0.00,--TransportAmount, 
	0.00,--FuelAmount, 
	''--MeterChannel
	from dbo.VIPMARKET_SG_ELG_PREMISE where status = 'Enrolled' and account_number = @AccountNumber

	
	
	--------------------------------------  ACCOUNT PRODUCT -------------------------------
Insert Into dbo.VIPMARKET_AccountProducts	
(
VIP_BatchEnrollEntryID, 
VIP_ProductID, 
UtilityCode, 
RetailerCode, 
FixedPrice, 
VariableAdder, 
ServiceFeeAmount, 
BandwidthMaxPercentage, 
BandwidthAdder, 
BandwidthUsageAmount, 
UsageAllocationAmount, 
UsageAllocationPriority, 
StartDate, 
EndDate, 
BrokerCommisionRate, 
BandwidthMinPercentage, 
BandwidthHighAdder, 
BandwidthLowAdder, 
BrokerCommisionRate_Intolerance, 
Fuel
)	
Select  
@VIP_BatchEnrollmentEntryID,--VIP_BatchEnrollEntryID, 
VIP_ProductID, 
(Select CODE from VIP_Utilities where Code = 'SG'),--UtilityCode, 
'VEM',--RetailerCode, 
(
	Select case when Code = 'FIXED' then
	(
		Select 
		case when PriceOption in('Blended', 'Fixed') then FixedPriceRate
			 when PriceOption in('WA') then Weighted_Fixed_Average
			 else 0 end dum
		from dbo.VIPMARKET_SG_Pricing a
		inner join VIPMARKET_SG_ELG_PREMISE b on b.SelectedRow = a.VIPMARKET_SG_Pricing_ID
		where b.Account_Number = @AccountNumber
		--Select FixedPriceRate
		--from dbo.VIPMARKET_SG_Pricing where VIPMARKET_SG_Pricing_ID in 
		--(
		--	Select case when PriceOption in('Blended','Fixed') then SelectedRow else 0 end from VIPMARKET_SG_ELG_PREMISE 
		--	where account_number = @AccountNumber
		--)	
	) else 0 end
	from vip_productPricingTypes where vip_productPricingTypeID in
	(
		Select vip_productPricingTypeID from vip_products
		where vip_productid = VIP_ProductBundleItems.VIP_ProductID
	)
) FixedPrice,--FixedPrice, 
(
	Select case when Code = 'VARIABLE' then
	(
		Select IndexRate
		from dbo.VIPMARKET_SG_Pricing where VIPMARKET_SG_Pricing_ID in 
		(
			Select case when PriceOption in('Blended','Index') then SelectedRow else 0 end from VIPMARKET_SG_ELG_PREMISE 
			where account_number = @AccountNumber
		)	
	) else 0 end
	from vip_productPricingTypes where vip_productPricingTypeID in
	(
		Select vip_productPricingTypeID from vip_products
		where vip_productid = VIP_ProductBundleItems.VIP_ProductID
	) 
) VariableAdder,--VariableAdder, 
0,--ServiceFeeAmount
0,--BandwidthMaxPercentage,
0,--BandwidthAdder
0,--BandwidthUsageAmount, 
0,--UsageAllocationAmount, 
0,--UsageAllocationPriority, 
convert(varchar(10), getdate(), 101),--StartDate, 
convert(varchar(10), DATEADD(YYYY,1, getdate()), 101),--EndDate, 
0,--BrokerCommisionRate, 
0,--BandwidthMinPercentage, 
0,--BandwidthHighAdder, 
0,--BandwidthLowAdder, 
0,--BrokerCommisionRate_Intolerance, 
0--Fuel
 from VIP_ProductBundleItems where VIP_ProductBundleID in
(
	Select
	case when Bill_Class = 'RES' and PriceOption = 'Index' and service_state = 'WY' then
			(Select VIP_ProductBundleID from VIP_ProductBundles where Code = 'SG_WY_INDEX_PRODUCT_RESIDENTIAL')
		 when Bill_Class = 'RES' and PriceOption in('Fixed','WA') and service_state = 'WY' then
			(Select VIP_ProductBundleID from VIP_ProductBundles where Code = 'SG_WY_FIXED_PRODUCT_RESIDENTIAL')
		 when Bill_Class = 'RES' and PriceOption = 'Blended' and service_state = 'WY' then
			(Select VIP_ProductBundleID from VIP_ProductBundles where Code = 'SG_WY_FIXED_PRODUCT_BLENDED_RESIDENTIAL')     
		 when Bill_Class = 'COM' and PriceOption = 'Index' and service_state = 'WY' then
			(Select VIP_ProductBundleID from VIP_ProductBundles where Code = 'SG_WY_INDEX_PRODUCT_COMMERCIAL')
		 when Bill_Class = 'COM' and PriceOption IN('Fixed','WA') and service_state = 'WY' then
			(Select VIP_ProductBundleID from VIP_ProductBundles where Code = 'SG_WY_FIXED_PRODUCT_COMMERCIAL')
		 when Bill_Class = 'COM' and PriceOption = 'Blended' and service_state = 'WY' then
			(Select VIP_ProductBundleID from VIP_ProductBundles where Code = 'SG_WY_FIXED_PRODUCT_BLENDED_COMMERCIAL')         
		 when Bill_Class = 'RES' and PriceOption = 'Index' and service_state = 'NE' then
			(Select VIP_ProductBundleID from VIP_ProductBundles where Code = 'SG_NE_INDEX_PRODUCT_RESIDENTIAL')     
		 when Bill_Class = 'RES' and PriceOption IN('Fixed','WA') and service_state = 'NE' then
			(Select VIP_ProductBundleID from VIP_ProductBundles where Code = 'SG_NE_FIXED_PRODUCT_RESIDENTIAL')
		 when Bill_Class = 'RES' and PriceOption = 'Blended' and service_state = 'NE' then
			(Select VIP_ProductBundleID from VIP_ProductBundles where Code = 'SG_NE_FIXED_PRODUCT_BLENDED_RESIDENTIAL')		
		 when Bill_Class = 'COM' and PriceOption = 'Index' and service_state = 'NE' then
			(Select VIP_ProductBundleID from VIP_ProductBundles where Code = 'SG_NE_INDEX_PRODUCT_COMMERCIAL')
		 when Bill_Class = 'COM' and PriceOption IN ('Fixed','WA') and service_state = 'NE' then
			(Select VIP_ProductBundleID from VIP_ProductBundles where Code = 'SG_NE_FIXED_PRODUCT_COMMERCIAL')
		 when Bill_Class = 'COM' and PriceOption = 'Blended' and service_state = 'NE' then
			(Select VIP_ProductBundleID from VIP_ProductBundles where Code = 'SG_NE_FIXED_PRODUCT_BLENDED_COMMERCIAL')
	end ProductBundleID --VIP_ProductBundleid	
	from dbo.VIPMARKET_SG_ELG_PREMISE where 
	account_number = @AccountNumber
)

----------------------------------     NOTES  --------------------------------
insert into dbo.VIP_BatchEnrollmentEntries_Notes
(VIP_BatchEnrollEntryID, Notes, NoteDate, CreatedByUserID)
select @VIP_BatchEnrollmentEntryID, Notes, getdate(), 2 from VIPMARKET_SG_ELG_PREMISE_Notes 
 where VIPMARKET_SG_ELG_PREMISE_ID IN
 (
	 select VIPMARKET_SG_ELG_PREMISE_ID from VIPMARKET_SG_ELG_PREMISE
	 where account_number = @AccountNumber
 ) order by PostedDate

	
	SELECT @intErrorCode = @@ERROR
    IF (@intErrorCode <> 0) GOTO PROBLEM

COMMIT TRAN

PROBLEM:
IF (@intErrorCode <> 0) BEGIN
PRINT 'Unexpected error occurred!'
    ROLLBACK TRAN
END

GO
