

CREATE PROCEDURE dbo.AddDesktopModule
    
	@ModuleName		nvarchar(128),
	@FolderName		nvarchar(128),
	@FriendlyName		nvarchar(128),
	@Description		nvarchar(2000),
	@Version		nvarchar(8),
	@IsPremium		bit,
	@IsAdmin		bit,
	@BusinessController 	nvarchar(200),
	@SupportedFeatures	int,
	@CompatibleVersions	nvarchar(500),
    @Dependencies           nvarchar(400),
    @Permissions      nvarchar(400)

AS

	INSERT INTO dbo.DesktopModules (
		ModuleName,
		FolderName,
		FriendlyName,
		Description,
		Version,
		IsPremium,
		IsAdmin,
		BusinessControllerClass,
		SupportedFeatures,
		CompatibleVersions,
		Dependencies,
		Permissions
	)
	VALUES (
		@ModuleName,
		@FolderName,
		@FriendlyName,
		@Description,
		@Version,
		@IsPremium,
		@IsAdmin,
		@BusinessController,
		@SupportedFeatures,
		@CompatibleVersions,
		@Dependencies,
		@Permissions
	)

	SELECT SCOPE_IDENTITY()

GO
