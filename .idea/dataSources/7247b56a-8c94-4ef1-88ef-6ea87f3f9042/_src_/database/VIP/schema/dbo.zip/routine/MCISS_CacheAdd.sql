
CREATE PROCEDURE dbo.MCISS_CacheAdd
	@name nvarchar(250),
	@cachecontent ntext,
	@lastupdate datetime,
	@type char

AS
delete  from dbo.MCISS_Cache where name=@name;
INSERT INTO dbo.MCISS_Cache (
	[name],[cachecontent],[lastupdate],[type]
) VALUES (
	@name,@cachecontent,@lastupdate,@type
)

select SCOPE_IDENTITY()
GO
