


-- =============================================
-- Author:		Larry G
-- Create date: 9/26/2012
-- Description:	data will be exported to a text file and ftp'd to 5linx

-- 	-- 2015-02-04 - BPanjavan - Replace with subtring and substitute newline characters to handle DIVE Export issue
--	-- 2016-09-19 - BPanjavan - Quick Fix - Per Drew, limit 5LINX to post-May 2016
-- =============================================
CREATE PROCEDURE [dbo].[usp_VIP_5LINX_AccountStatusFile]
	-- Add the parameters for the stored procedure here
	@MarketerID varchar(5), @IncludeUsage BIT, @AccountClass VARCHAR(15)
AS

----DECLARE @MarketerID varchar(5)
----DECLARE @IncludeUsage BIT
----DECLARE @AccountClass VARCHAR(15)

----SET @MarketerID = 'DIVE'
----SET @IncludeUsage = 0
----SET @AccountClass = ''

IF @IncludeUsage = 1
    BEGIN
        SELECT  '' BLANK ,
                '' AGENTID ,
                '' OrderIdentifier ,
                be.ServiceFirstName FirstName ,
                '' MiddleInitial ,
                be.ServiceLastName LastName ,
                be.CompanyName BusinessName ,
                be.ServiceAddress1 Address1 ,
                be.ServiceAddress2 Address2 ,
                be.ServiceCity City ,
                be.ServiceStateCode State ,
                be.ServiceZipCode Zip ,
                'EN' ProductType ,
                CASE WHEN ( SELECT  COUNT(*)
                            FROM    dbo.VIP_Accounts
                            WHERE   VIP_BatchEnrollmentEntryID = be.VIP_BatchEnrollEntryID
                          ) = 1
                     THEN CASE WHEN be.BatchEnrollmentStatus = 'Blocked'
                               THEN 'CLOSED'
                               WHEN be.BatchEnrollmentStatus = 'Admin-Hold'
                               THEN 'PENDING'
                               WHEN AccountStatus IN ( 'Pending Enrollment',
                                                       'Enrolling', 'No TPV' )
                               THEN 'PENDING'
                               WHEN AccountStatus = 'Enrolled' THEN 'ACTIVE'
                               WHEN AccountStatus IN ( 'Terminated',
                                                       'Terminating' )
                               THEN 'CLOSED'
                               WHEN AccountStatus IN ( 'Enrollment Cancelled',
                                                       'Enrollment Ineligible',
                                                       'Enrollment Rejected' )
                               THEN 'CLOSED'
                               ELSE ( SELECT TOP 1
                                                CASE WHEN AccountStatus IN (
                                                          'Pending Enrollment',
                                                          'Enrolling' )
                                                     THEN 'PENDING'
                                                     WHEN AccountStatus = 'Enrolled'
                                                     THEN 'ACTIVE'
                                                     WHEN AccountStatus IN (
                                                          'Terminated',
                                                          'Terminating' )
                                                     THEN 'CLOSED'
                                                     WHEN AccountStatus IN (
                                                          'Enrollment Cancelled',
                                                          'Enrollment Ineligible',
                                                          'Enrollment Rejected' )
                                                     THEN 'CLOSED'
                                                END
                                      FROM      VIP_Accounts_Reconciliation
                                                INNER JOIN VIP_Accounts ON VIP_Accounts.VIP_AccountID = VIP_Accounts_Reconciliation.VIP_Accountid
                                      WHERE     VIP_Accounts_Reconciliation.UtilityServiceAccountid = be.UtilityServiceAccountID
                                    )
                          END
                     WHEN ( SELECT  COUNT(*)
                            FROM    dbo.VIP_Accounts
                            WHERE   VIP_BatchEnrollmentEntryID = be.VIP_BatchEnrollEntryID
                          ) = 0
                     THEN CASE WHEN be.VIP_BatchEnrollEntryID < VIP_Accounts.VIP_BatchEnrollmentEntryID
                               THEN 'CLOSED'
                               WHEN be.BatchEnrollmentStatus = 'Blocked'
                               THEN 'CLOSED'
                               WHEN be.BatchEnrollmentStatus = 'Admin-Hold'
                               THEN 'PENDING'
                               WHEN AccountStatus IN ( 'Pending Enrollment',
                                                       'Enrolling' )
                               THEN 'PENDING'
                               WHEN AccountStatus = 'Enrolled' THEN 'ACTIVE'
                               ELSE 'CLOSED'
                          END
                END Status ,
                CONVERT(VARCHAR(10), GETDATE(), 101) FileDate ,
                '' BLANK ,

	-- 2015-02-04 - BPanjavan - Replace with subtring and substitute newline characters to handle DIVE Export issue
                SUBSTRING(REPLACE(REPLACE(CASE WHEN be.VIP_BatchEnrollEntryID < VIP_Accounts.VIP_BatchEnrollmentEntryID
                                               THEN 'Closed'
                                               WHEN be.BatchEnrollmentStatus = 'Blocked'
                                               THEN 'Account was blocked'
                                               WHEN be.BatchEnrollmentStatus = 'Admin-Hold'
                                               THEN ''
                                               WHEN be.BatchEnrollmentStatus = 'No TPV'
                                               THEN 'No TPV on record'
                                               WHEN AccountStatus IN (
                                                    'Pending Enrollment',
                                                    'Enrolling' )
                                               THEN 'Enrollment Pending'
                                               WHEN AccountStatus = 'Enrolled'
                                               THEN 'Account has been enrolled successfully'
                                               WHEN AccountStatus IN (
                                                    'Terminated' )
                                               THEN 'Account was terminated'
                                               WHEN AccountStatus IN (
                                                    'Terminating' )
                                               THEN 'Account has been subitted for termination.  Termination Pending...'
                                               WHEN AccountStatus IN (
                                                    'Enrollment Rejected' )
                                               THEN ( SELECT TOP 1
                                                              CASE
                                                              WHEN AuditMessage LIKE '%Market file creation error%'
                                                              THEN 'Market Transaction Error'
                                                              ELSE CONVERT(VARCHAR(500), REPLACE(REPLACE(AuditMessage,
                                                              CHAR(13), ''),
                                                              CHAR(10), ''))
                                                              END
                                                              + CASE
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%RCUSTID1%'
                                                              THEN ' (Wrong SAID)'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%RCUSTID3%'
                                                              THEN ' (Wrong ZIP Code)'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%SPRATE%'
                                                              THEN ' (Wrong Rate Class)'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%PREVDA1%'
                                                              THEN ' (Blocked by Pending DASR)'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%RELPEND2%'
                                                              THEN ' (Customer is on hold by Utility)'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%ALREADY SIGNED%'
                                                              THEN ' (ALREADY SIGNED)'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%INACTIVE ACCOUNT%'
                                                              THEN ' (INACTIVE ACCOUNT0'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%INVALID ACCOUNT NUMBER%'
                                                              THEN ' (INVALID ACCOUNT NUMBER)'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%INVALID CONTRACT CHANGE%'
                                                              THEN ' (INVALID CONTRACT CHANGE)'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%ONE YEAR ENROLLMENT RESTRICTION%'
                                                              THEN ' (ONE YEAR ENROLLMENT RESTRICTION)'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%SYNTAX14%'
                                                              THEN ' (NO BILLING NAME)'
                                                              ELSE ''
                                                              END
                                                      FROM    VIP_AccountInteractions vint
                                                              INNER JOIN VIP_AccountInteractionAudit vinta ON vinta.VIP_AccountInteractionID = vint.VIP_AccountInteractionID
                                                      WHERE   vint.VIP_AccountID = VIP_Accounts.VIP_AccountID
                                                              AND VIP_AccountInteractionTypeID = 1
                                                              AND AuditType IN (
                                                              'Checkpoint',
                                                              'Exception',
                                                              'Manual Intervention' )
                                                      ORDER BY AuditType DESC ,
                                                              AuditDateTime DESC
                                                    )
                                               WHEN AccountStatus IN (
                                                    'Enrollment Cancelled' )
                                               THEN 'Enrollment was cancelled'
                                               WHEN AccountStatus IN (
                                                    'Enrollment Ineligible' )
                                               THEN 'Account is eneligible for enrollment - '
                                                    + ( SELECT TOP 1
                                                              CONVERT(VARCHAR(500), REPLACE(REPLACE(AuditMessage,
                                                              CHAR(13), ''),
                                                              CHAR(10), ''))
                                                        FROM  VIP_AccountInteractions vint
                                                              INNER JOIN VIP_AccountInteractionAudit vinta ON vinta.VIP_AccountInteractionID = vint.VIP_AccountInteractionID
                                                        WHERE vint.VIP_AccountID = VIP_Accounts.VIP_AccountID
                                                              AND VIP_AccountInteractionTypeID = 1
                                                              AND AuditType = 'Checkpoint'
                                                        ORDER BY AuditType DESC ,
                                                              AuditDateTime DESC
                                                      )
                                               ELSE ( SELECT TOP 1
                                                              'Reconciled with '
                                                              + VIP_Accounts.UtilityServiceAccountID
                                                      FROM    VIP_Accounts_Reconciliation
                                                              INNER JOIN VIP_Accounts ON VIP_Accounts.VIP_AccountID = VIP_Accounts_Reconciliation.VIP_Accountid
                                                      WHERE   VIP_Accounts_Reconciliation.UtilityServiceAccountid = be.UtilityServiceAccountID
                                                    )
                                          END, CHAR(13), ''), CHAR(10), ''), 1,
                          500) Reason ,
                '' BLANK ,
                '' DateOfBirth ,
                util.Code ProductSupplier ,
                'GAS' ProductName ,
                CONVERT(VARCHAR(10), be.DateSold, 101) OrderDate ,
                '' BLANK ,
                ISNULL(CASE WHEN AccountStatus IN ( 'Enrolled', 'Terminated',
                                                    'Terminating' )
                            THEN CONVERT(VARCHAR(10), EnrollmentAcceptDate, 101)
                            ELSE ''
                       END, '') OrderActiveDate ,
                ISNULL(( SELECT TOP 1
                                CONVERT(VARCHAR(10), EndDateTime, 101)
                         FROM   VIP_AccountInteractionsView
                         WHERE  VIP_AccountID = VIP_Accounts.VIP_AccountID
                                AND VIP_AccountInteractionTypeID IN ( 12, 13 )
                         ORDER BY VIP_AccountInteractionID DESC
                       ), '') OrderCancelDate ,
                be.ServicePhone Phone ,
                '' BLANK ,
                be.ServiceEmail Email ,
                '' BLANK ,
                ISNULL(be.MasterAccountID,
                       ( SELECT TOP 1
                                MasterAccountID
                         FROM   VIP_BatchEnrollmentEntries
                         WHERE  VIP_BatchEnrollmentEntryID = VIP_Accounts.VIP_BatchEnrollmentEntryID
                       )) MasterAccountid , --MASTER ACCOUNTID
                '' BLANK ,
                '' BLANK ,
                ISNULL(( SELECT SUM(UsageAmount)
                         FROM   VIP_Usage
                         WHERE  VIP_AccountID = VIP_Accounts.VIP_AccountID
                                AND VIP_UsageTypeID IN (
                                SELECT  VIP_UsageTypeID
                                FROM    dbo.VIP_UsageTypes
                                WHERE   Code = 'HISTORICAL' )
                       ), 0) AnnualHUD
        FROM    VIP_BatchEnrollmentEntries be
                LEFT OUTER JOIN VIP_Accounts ON --VIP_Accounts.Utilityserviceaccountid = be.Utilityserviceaccountid
be.VIP_BatchEnrollEntryID = VIP_Accounts.VIP_BatchEnrollmentEntryID
                INNER JOIN VIP_MarketerAgents magt ON magt.VIP_MarketerAgentID = be.VIP_MarketerAgentID
                INNER JOIN VIP_Utilities util ON util.VIP_UtilityID = be.VIP_UtilityID
                INNER JOIN dbo.VIP_AccountClasses ac ON ac.VIP_AccountClassID = be.VIP_AccountClassID
        WHERE   be.VIP_MarketerID IN ( SELECT   VIP_MarketerID
                                       FROM     VIP_Marketers
                                       WHERE    Code = @MarketerID )
                AND ac.Code LIKE '%' + @AccountClass + '%'

				AND be.DateSold >= '2016-05-01' -- BPanjavan - Quick Fix - Per Drew, limit 5LINX to post-May 2016
--and VIP_Accounts.Residual = 0
-- and be.utilityserviceaccountid in
-- (
--'0099912846'
------'9352117010',
----'5203868053'
--)
        ORDER BY VIP_Accounts.UtilityServiceAccountID ,
                be.MasterAccountID; --vip_accountid
    END; 
ELSE
    BEGIN
        SELECT  '' BLANK ,
                '' AGENTID ,
                '' OrderIdentifier ,
                be.ServiceFirstName FirstName ,
                '' MiddleInitial ,
                be.ServiceLastName LastName ,
                be.CompanyName BusinessName ,
                be.ServiceAddress1 Address1 ,
                be.ServiceAddress2 Address2 ,
                be.ServiceCity City ,
                be.ServiceStateCode State ,
                be.ServiceZipCode Zip ,
                'EN' ProductType ,
                CASE WHEN ( SELECT  COUNT(*)
                            FROM    dbo.VIP_Accounts
                            WHERE   VIP_BatchEnrollmentEntryID = be.VIP_BatchEnrollEntryID
                          ) = 1
                     THEN CASE WHEN be.BatchEnrollmentStatus = 'Blocked'
                               THEN 'CLOSED'
                               WHEN be.BatchEnrollmentStatus = 'Admin-Hold'
                               THEN 'PENDING'
                               WHEN AccountStatus IN ( 'Pending Enrollment',
                                                       'Enrolling' )
                               THEN 'PENDING'
                               WHEN AccountStatus = 'Enrolled' THEN 'ACTIVE'
                               WHEN AccountStatus IN ( 'Terminated',
                                                       'Terminating' )
                               THEN 'CLOSED'
                               WHEN AccountStatus IN ( 'Enrollment Cancelled',
                                                       'Enrollment Ineligible',
                                                       'Enrollment Rejected' )
                               THEN 'CLOSED'
                               ELSE ( SELECT TOP 1
                                                CASE WHEN AccountStatus IN (
                                                          'Pending Enrollment',
                                                          'Enrolling' )
                                                     THEN 'PENDING'
                                                     WHEN AccountStatus = 'Enrolled'
                                                     THEN 'ACTIVE'
                                                     WHEN AccountStatus IN (
                                                          'Terminated',
                                                          'Terminating' )
                                                     THEN 'CLOSED'
                                                     WHEN AccountStatus IN (
                                                          'Enrollment Cancelled',
                                                          'Enrollment Ineligible',
                                                          'Enrollment Rejected' )
                                                     THEN 'CLOSED'
                                                END
                                      FROM      VIP_Accounts_Reconciliation
                                                INNER JOIN VIP_Accounts ON VIP_Accounts.VIP_AccountID = VIP_Accounts_Reconciliation.VIP_Accountid
                                      WHERE     VIP_Accounts_Reconciliation.UtilityServiceAccountid = be.UtilityServiceAccountID
                                    )
                          END
                     WHEN ( SELECT  COUNT(*)
                            FROM    dbo.VIP_Accounts
                            WHERE   VIP_BatchEnrollmentEntryID = be.VIP_BatchEnrollEntryID
                          ) = 0
                     THEN CASE WHEN be.VIP_BatchEnrollEntryID < VIP_Accounts.VIP_BatchEnrollmentEntryID
                               THEN 'CLOSED'
                               WHEN be.BatchEnrollmentStatus = 'Blocked'
                               THEN 'CLOSED'
                               WHEN be.BatchEnrollmentStatus = 'Admin-Hold'
                               THEN 'PENDING'
                               WHEN AccountStatus IN ( 'Pending Enrollment',
                                                       'Enrolling' )
                               THEN 'PENDING'
                               WHEN AccountStatus = 'Enrolled' THEN 'ACTIVE'
                               ELSE 'CLOSED'
                          END
                END Status ,
                CONVERT(VARCHAR(10), GETDATE(), 101) FileDate ,
                '' BLANK ,
	
	-- 2015-02-04 - BPanjavan - Replace with subtring and substitute newline characters to handle DIVE Export issue
                SUBSTRING(REPLACE(REPLACE(CASE WHEN be.VIP_BatchEnrollEntryID < VIP_Accounts.VIP_BatchEnrollmentEntryID
                                               THEN 'Closed'
                                               WHEN be.BatchEnrollmentStatus = 'Blocked'
                                               THEN 'Account was blocked'
                                               WHEN be.BatchEnrollmentStatus = 'Admin-Hold'
                                               THEN ''
                                               WHEN AccountStatus IN (
                                                    'Pending Enrollment',
                                                    'Enrolling' )
                                               THEN 'Enrollment Pending'
                                               WHEN AccountStatus = 'Enrolled'
                                               THEN 'Account has been enrolled successfully'
                                               WHEN AccountStatus IN (
                                                    'Terminated' )
                                               THEN 'Account was terminated'
                                               WHEN AccountStatus IN (
                                                    'Terminating' )
                                               THEN 'Account has been subitted for termination.  Termination Pending...'
                                               WHEN AccountStatus IN (
                                                    'Enrollment Rejected' )
                                               THEN ( SELECT TOP 1
                                                              CASE
                                                              WHEN AuditMessage LIKE '%Market file creation error%'
                                                              THEN 'Market Transaction Error'
                                                              ELSE CONVERT(VARCHAR(500), REPLACE(REPLACE(AuditMessage,
                                                              CHAR(13), ''),
                                                              CHAR(10), ''))
                                                              END
                                                              + CASE
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%RCUSTID1%'
                                                              THEN ' (Wrong SAID)'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%RCUSTID3%'
                                                              THEN ' (Wrong ZIP Code)'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%SPRATE%'
                                                              THEN ' (Wrong Rate Class)'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%PREVDA1%'
                                                              THEN ' (Blocked by Pending DASR)'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%RELPEND2%'
                                                              THEN ' (Customer is on hold by Utility)'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%ALREADY SIGNED%'
                                                              THEN ' (ALREADY SIGNED)'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%INACTIVE ACCOUNT%'
                                                              THEN ' (INACTIVE ACCOUNT0'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%INVALID ACCOUNT NUMBER%'
                                                              THEN ' (INVALID ACCOUNT NUMBER)'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%INVALID CONTRACT CHANGE%'
                                                              THEN ' (INVALID CONTRACT CHANGE)'
                                                              WHEN CONVERT(VARCHAR(500), AuditMessage) LIKE '%ONE YEAR ENROLLMENT RESTRICTION%'
                                                              THEN ' (ONE YEAR ENROLLMENT RESTRICTION)'
                                                              ELSE ''
                                                              END
                                                      FROM    VIP_AccountInteractions vint
                                                              INNER JOIN VIP_AccountInteractionAudit vinta ON vinta.VIP_AccountInteractionID = vint.VIP_AccountInteractionID
                                                      WHERE   vint.VIP_AccountID = VIP_Accounts.VIP_AccountID
                                                              AND VIP_AccountInteractionTypeID = 1
                                                              AND AuditType IN (
                                                              'Checkpoint',
                                                              'Exception' )
                                                      ORDER BY AuditType DESC ,
                                                              AuditDateTime DESC
                                                    )
                                               WHEN AccountStatus IN (
                                                    'Enrollment Cancelled' )
                                               THEN 'Enrollment was cancelled'
                                               WHEN AccountStatus IN (
                                                    'Enrollment Ineligible' )
                                               THEN 'Account is eneligible for enrollment - '
                                                    + ( SELECT TOP 1
                                                              CONVERT(VARCHAR(500), REPLACE(REPLACE(AuditMessage,
                                                              CHAR(13), ''),
                                                              CHAR(10), ''))
                                                        FROM  VIP_AccountInteractions vint
                                                              INNER JOIN VIP_AccountInteractionAudit vinta ON vinta.VIP_AccountInteractionID = vint.VIP_AccountInteractionID
                                                        WHERE vint.VIP_AccountID = VIP_Accounts.VIP_AccountID
                                                              AND VIP_AccountInteractionTypeID = 1
                                                              AND AuditType = 'Checkpoint'
                                                      )
                                               ELSE ( SELECT TOP 1
                                                              'Reconciled with '
                                                              + VIP_Accounts.UtilityServiceAccountID
                                                      FROM    VIP_Accounts_Reconciliation
                                                              INNER JOIN VIP_Accounts ON VIP_Accounts.VIP_AccountID = VIP_Accounts_Reconciliation.VIP_Accountid
                                                      WHERE   VIP_Accounts_Reconciliation.UtilityServiceAccountid = be.UtilityServiceAccountID
                                                    )
                                          END, CHAR(13), ''), CHAR(10), ''), 1,
                          500) Reason ,
                '' BLANK ,
                '' DateOfBirth ,
                util.Code ProductSupplier ,
                'GAS' ProductName ,
                CONVERT(VARCHAR(10), be.DateSold, 101) OrderDate ,
                '' BLANK ,
                ISNULL(CASE WHEN AccountStatus IN ( 'Enrolled', 'Terminated',
                                                    'Terminating' )
                            THEN CONVERT(VARCHAR(10), EnrollmentAcceptDate, 101)
                            ELSE ''
                       END, '') OrderActiveDate ,
                ISNULL(( SELECT TOP 1
                                CONVERT(VARCHAR(10), EndDateTime, 101)
                         FROM   VIP_AccountInteractionsView
                         WHERE  VIP_AccountID = VIP_Accounts.VIP_AccountID
                                AND VIP_AccountInteractionTypeID IN ( 12, 13 )
                         ORDER BY VIP_AccountInteractionID DESC
                       ), '') OrderCancelDate ,
                be.ServicePhone Phone ,
                '' BLANK ,
                be.ServiceEmail Email ,
                '' BLANK ,
                ISNULL(be.MasterAccountID,
                       ( SELECT TOP 1
                                MasterAccountID
                         FROM   VIP_BatchEnrollmentEntries
                         WHERE  VIP_BatchEnrollmentEntryID = VIP_Accounts.VIP_BatchEnrollmentEntryID
                       )) MasterAccountid , --MASTER ACCOUNTID
                '' BLANK ,
                '' BLANK
        FROM    VIP_BatchEnrollmentEntries be
                LEFT OUTER JOIN VIP_Accounts ON --VIP_Accounts.Utilityserviceaccountid = be.Utilityserviceaccountid
be.VIP_BatchEnrollEntryID = VIP_Accounts.VIP_BatchEnrollmentEntryID
                INNER JOIN VIP_MarketerAgents magt ON magt.VIP_MarketerAgentID = be.VIP_MarketerAgentID
                INNER JOIN VIP_Utilities util ON util.VIP_UtilityID = be.VIP_UtilityID
                INNER JOIN dbo.VIP_AccountClasses ac ON ac.VIP_AccountClassID = be.VIP_AccountClassID
        WHERE   be.VIP_MarketerID IN ( SELECT   VIP_MarketerID
                                       FROM     VIP_Marketers
                                       WHERE    Code = @MarketerID )
                AND ac.Code LIKE '%' + @AccountClass + '%'
				AND be.DateSold >= '2016-05-01' -- BPanjavan - Quick Fix - Per Drew, limit 5LINX to post-May 2016
--and VIP_Accounts.Residual = 0
-- and be.utilityserviceaccountid in
--(
----'0099912846'
--------'9352117010',
------'5203868053'
--)
        ORDER BY 
 --VIP_Accounts.utilityserviceaccountid,  
                be.MasterAccountID; --vip_accountid
    END;


GO
