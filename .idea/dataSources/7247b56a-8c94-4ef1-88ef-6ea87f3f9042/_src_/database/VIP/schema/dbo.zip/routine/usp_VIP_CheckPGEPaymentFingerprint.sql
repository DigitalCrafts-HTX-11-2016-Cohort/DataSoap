CREATE PROCEDURE [dbo].[usp_VIP_CheckPGEPaymentFingerprint]
	@Fingerprint varchar(200)
AS
SELECT *
FROM
(
	SELECT
		replace(replace(ESPName + DAXRef + AcctNo + CustName + cast(DueToESP as varchar) + convert(varchar, DatePaid, 101), ' ', ''), '''', '') Fingerprint
	FROM vip_VIPMARKET_PGE_Paymentview
) a
WHERE Fingerprint = @Fingerprint
GO
