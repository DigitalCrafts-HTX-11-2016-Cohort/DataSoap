
CREATE PROCEDURE VIPMarket_SG_Email_AccountExclude_Insert
(
	@AccountNumber varchar(100)
)
AS
BEGIN

INSERT INTO VIPMarket_SG_Email_AccountExclude
VALUES (GETDATE(), @AccountNUmber, 0)

END

GO
