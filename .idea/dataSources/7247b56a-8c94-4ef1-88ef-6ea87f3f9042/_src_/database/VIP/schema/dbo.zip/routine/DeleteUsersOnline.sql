
create procedure dbo.DeleteUsersOnline

	@TimeWindow	int
	
as
	-- Clean up the anonymous users table
	DELETE from dbo.AnonymousUsers WHERE LastActiveDate < DateAdd(minute, -@TimeWindow, GetDate())	

	-- Clean up the users online table
	DELETE from dbo.UsersOnline WHERE LastActiveDate < DateAdd(minute, -@TimeWindow, GetDate())


GO
