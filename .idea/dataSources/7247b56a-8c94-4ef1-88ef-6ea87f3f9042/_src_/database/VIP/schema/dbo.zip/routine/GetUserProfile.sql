
CREATE procedure dbo.[GetUserProfile]

	@UserID int

AS
SELECT
	ProfileID,
	UserID,
	PropertyDefinitionID,
	'PropertyValue' = case when (PropertyValue Is Null) then PropertyText else PropertyValue end,
	Visibility,
	LastUpdatedDate
	FROM	dbo.UserProfile
	WHERE   UserId = @UserID

GO
