


CREATE PROCEDURE dbo.DeleteTabPermission
	@TabPermissionID int
AS

DELETE FROM dbo.TabPermission
WHERE
	[TabPermissionID] = @TabPermissionID


GO
