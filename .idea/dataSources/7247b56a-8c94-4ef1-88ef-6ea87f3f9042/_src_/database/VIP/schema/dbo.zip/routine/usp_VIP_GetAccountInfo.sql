
CREATE PROCEDURE [dbo].[usp_VIP_GetAccountInfo]
	@VIP_AccountID int
	
AS

	SELECT a.VIP_ContractID, c.ContractName, c.StartDate, c.EndDate
	FROM VIP_Accounts a
		INNER JOIN VIP_Contracts c ON a.VIP_ContractID = c.VIP_ContractID
	WHERE a.VIP_AccountID = @VIP_AccountID

	SELECT a.VIP_AccountID, a.CompanyName, a.ServiceFirstName AS [ServiceFirstName], a.ServiceLastName AS [ServiceLastName],
		a.ServiceAddress1 AS [ServiceAddress1], a.ServiceAddress2 AS [ServiceAddress2], a.ServiceCity AS [ServiceCity],
		a.ServiceState AS [ServiceState], a.ServiceZipCode AS [ServiceZipCode], a.ServiceCounty AS [ServiceCountry], a.TaxExempt
	FROM VIP_Accounts a
	WHERE a.VIP_AccountID = @VIP_AccountID

	SELECT a.VIP_AccountID, pba.VIP_BillingPointID, bp.BillingPointName, bp.BillingPointCode, bp.BillingTrigger, bp.BillingAttentionTo,
		bp.Address1 AS [BillingAddress1], bp.Address2 AS [BillingAddress2], bp.City AS [BillingCity], bp.State AS [BillingState],
		bp.ZipCode AS [BillingZipCode], bp.Country AS [BillingCountry]
	FROM VIP_Accounts a
		INNER JOIN VIP_BillingPointAccounts pba ON a.VIP_AccountID = pba.VIP_AccountID
		INNER JOIN VIP_BillingPoints bp ON pba.VIP_BillingPointID = bp.VIP_BillingPointID
	WHERE a.VIP_AccountID = @VIP_AccountID

	SELECT a.VIP_AccountID, ap.VIP_AccountProductID, ap.VIP_ProductID, p.ProductName, ap.UtilityCode, ap.RetailerCode, ap.FixedPrice AS [Price], ap.VariableAdder AS [Adder],
		ap.VariableAdder, ap.ServiceFeeAmount, ap.BandwidthPercentage, ap.BandwidthAdder, ap.UsageAllocationAmount, ap.UsageAllocationPriority,
		ap.StartDate, ap.EndDate, pbt.Code AS [BillingTypeCode], u.Code AS [UtilityCode], ppt.Code AS [ProductPricingCode], uom.Name AS [UnitOfMeasure], p.ServiceFeeType
	FROM VIP_Accounts a
		INNER JOIN VIP_AccountProducts ap ON a.VIP_AccountID = ap.VIP_AccountID
		INNER JOIN VIP_Products p ON ap.VIP_ProductID = p.VIP_ProductID
		INNER JOIN VIP_ProductBillingTypes pbt ON p.VIP_ProductBillingTypeID = pbt.VIP_ProductBillingTypeID
		INNER JOIN VIP_Utilities u ON p.VIP_UtilityID = u.VIP_UtilityID
		INNER JOIN VIP_ProductPricingTypes ppt ON p.VIP_ProductPricingTypeID = ppt.VIP_ProductPricingTypeID
		INNER JOIN VIP_UnitsOfMeasure uom ON p.VIP_UnitOfMeasureID = uom.VIP_UnitOfMeasureID
	WHERE a.VIP_AccountID = @VIP_AccountID
	
	SELECT u.VIP_UsageID, ut.Code, u.StartDate, u.EndDate, u.UsageAmount, u.UnitOfMeasure, u.TransportAmount, u.FuelAmount, 0.00 AS [Price]
	FROM VIP_Usage u
		INNER JOIN VIP_UsageTypes ut ON u.VIP_UsageTypeID = ut.VIP_UsageTypeID
	WHERE VIP_AccountID = @VIP_AccountID
		AND ut.Code IN ('ACTUAL', 'ESTIMATED', 'CANCELLED')
		AND u.VIP_UsageID NOT IN (SELECT VIP_UsageID FROM VIP_InvoiceItems WHERE VIP_AccountID = @VIP_AccountID AND VIP_UsageID IS NOT NULL)

	SELECT *
	FROM VIP_CaliforniaUUT
	WHERE City = (SELECT ServiceCity FROM VIP_Accounts WHERE VIP_AccountID = @VIP_AccountID)
		AND UtilityTaxName = 'Gas'
GO
