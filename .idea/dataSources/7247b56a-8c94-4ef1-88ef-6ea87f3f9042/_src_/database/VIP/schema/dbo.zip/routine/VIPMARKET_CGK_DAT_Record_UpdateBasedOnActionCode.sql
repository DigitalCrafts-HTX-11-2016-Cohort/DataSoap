/* =============================================
-- Author:		Bryan Panjavan
 - Description:
	- 2013-10-28 - BPanjavan - Initial Creation
	- 2013-11-27 - BPanjavan - New Operations for termination, re-enrollment
  =============================================*/
CREATE PROCEDURE dbo.VIPMARKET_CGK_DAT_Record_UpdateBasedOnActionCode
(
	@datRecordID int
	,@action varchar(100)
	,@userID VARCHAR(50)
	,@updateTheAccount bit = 1 -- By default this will also update the account, like when this is called in the UI
	,@utilityRateCode varchar(50) = '' -- When we set it to MARK_FOR_ENROLL, we need the Utility Rate Code
)
AS
BEGIN
	
BEGIN TRAN

-- 2012-08-15 - BPanjavan - Still looking for a way to avoid having to re-populate the whole damn table again
	BEGIN TRY
		DECLARE @vip_AccountInteractionID INT


		IF (@action = 'DELETE_RECORD')
		BEGIN
			INSERT INTO dbo.VIPMARKET_CGK_DAT
						( VIPMARKET_CGK_DAT_KEYNAME ,
						  CreatedBy ,
						  CreatedOn ,
						  ModifiedBy ,
						  ModifiedOn ,
						  DeletedOn ,
						  VIPMARKET_CGK_DAT_ParentID ,
						  TransactionDate ,
						  CancelledDate ,
						  VIP_AccountID ,
						  SetToReExport ,
						  Mkt_ActionCode ,
						  Mkt_PCID ,
						  Mkt_SEQUENCE ,
						  Mkt_CHECKDIGIT ,
						  Mkt_Filler001 ,
						  Mkt_RATECODE ,
						  Mkt_NOMINATIONGROUP ,
						  Mkt_ENROLLMENTTYPE
						)
				SELECT  VIPMARKET_CGK_DAT_KEYNAME ,
				        @userID ,
				        GETDATE() ,
				        @userID ,
				        GETDATE() ,
				        GETDATE() , -- we're deleting this record
				        VIPMARKET_CGK_DATID, --The old one becomes the parent  --VIPMARKET_CGK_DAT_ParentID ,
				        TransactionDate ,
				        CancelledDate ,
				        VIP_AccountID ,
				        SetToReExport ,
				        Mkt_ActionCode ,
				        Mkt_PCID ,
				        Mkt_SEQUENCE ,
				        Mkt_CHECKDIGIT ,
				        Mkt_Filler001 ,
				        Mkt_RATECODE ,
				        Mkt_NOMINATIONGROUP ,
				        Mkt_ENROLLMENTTYPE 
					FROM dbo.VIPMARKET_CGK_DAT
						WHERE VIPMARKET_CGK_DATID = @datRecordID

			IF (@updateTheAccount = 1)
			BEGIN
				-- Find the latest account interaction enrolling for the account and cancel it out
				SET @vip_AccountInteractionID =
				(
					SELECT TOP 1 VIP_AccountInteractionID
					FROM 
						dbo.VIPMARKET_CGK_DAT dat
						INNER JOIN dbo.VIP_AccountInteractions ai 
							ON dat.VIP_AccountID = ai.VIP_AccountID
						INNER JOIN dbo.VIP_AccountInteractionTypes ait ON ai.VIP_AccountInteractionTypeID = ait.VIP_AccountInteractionTypeID
					WHERE (1 = 1)
						AND ait.Code = 'ENROLLMENT_CORE'
						AND ai.[Status] = 'Processing'
						AND VIPMARKET_CGK_DATID = @datRecordID
				)
				UPDATE dbo.VIP_AccountInteractions
					SET 
						[Status] = 'Complete' 
						,EndDateTime = GETDATE()
				WHERE VIP_AccountInteractionID = @vip_AccountInteractionID

					UPDATE acc
						SET acc.AccountStatus = 'Enrollment Cancelled'
					FROM 
						dbo.VIPMARKET_CGK_DAT dat
						INNER JOIN dbo.VIP_Accounts acc 
							ON dat.VIP_AccountID = acc.VIP_AccountID
					WHERE (1 = 1)
						AND VIPMARKET_CGK_DATID = @datRecordID
		
				IF (@vip_AccountInteractionID IS NOT NULL)
				BEGIN
					INSERT INTO dbo.VIP_AccountInteractionAudit
							( VIP_AccountInteractionID ,
								AuditType ,
								AuditLevel ,
								AuditMessage ,
								AuditDateTime
							)
					VALUES  ( @vip_AccountInteractionID , -- VIP_AccountInteractionID - int
								'Information' , -- AuditType - varchar(50)
								'Medium' , -- AuditLevel - varchar(20)
								'Enrollment cancelled through CGK DAT Transaction Manager' , -- AuditMessage - text
								GETDATE()  -- AuditDateTime - smalldatetime
							)
				END          

			END          
		END      
		ELSE IF (@action = 'MARK_FOR_DELETION')
		BEGIN

			INSERT INTO dbo.VIPMARKET_CGK_DAT
						( VIPMARKET_CGK_DAT_KEYNAME ,
						  CreatedBy ,
						  CreatedOn ,
						  ModifiedBy ,
						  ModifiedOn ,
						  DeletedOn ,
						  VIPMARKET_CGK_DAT_ParentID ,
						  TransactionDate ,
						  CancelledDate ,
						  VIP_AccountID ,
						  SetToReExport ,
						  Mkt_ActionCode ,
						  Mkt_PCID ,
						  Mkt_SEQUENCE ,
						  Mkt_CHECKDIGIT ,
						  Mkt_Filler001 ,
						  Mkt_RATECODE ,
						  Mkt_NOMINATIONGROUP ,
						  Mkt_ENROLLMENTTYPE
						)
				SELECT  VIPMARKET_CGK_DAT_KEYNAME ,
				        @userID ,
				        GETDATE() ,
				        @userID ,
				        GETDATE() ,
				        DeletedOn , -- we're deleting this record
				        VIPMARKET_CGK_DATID, --The old one becomes the parent  --VIPMARKET_CGK_DAT_ParentID ,
				        TransactionDate ,
				        CancelledDate ,
				        VIP_AccountID ,
				        SetToReExport ,
				        'D' , -- D to delete from the DAT file
				        Mkt_PCID ,
				        Mkt_SEQUENCE ,
				        Mkt_CHECKDIGIT ,
				        Mkt_Filler001 ,
				        Mkt_RATECODE ,
				        Mkt_NOMINATIONGROUP ,
				        Mkt_ENROLLMENTTYPE 
					FROM dbo.VIPMARKET_CGK_DAT
				WHERE VIPMARKET_CGK_DATID = @datRecordID

			IF (@updateTheAccount = 1)
			BEGIN
				-- Find the latest account interaction enrolling for the account and cancel it out
				SET @vip_AccountInteractionID =
				(
					SELECT TOP 1 VIP_AccountInteractionID
					FROM 
						dbo.VIPMARKET_CGK_DAT dat
						INNER JOIN dbo.VIP_AccountInteractions ai 
							ON dat.VIP_AccountID = ai.VIP_AccountID
						INNER JOIN dbo.VIP_AccountInteractionTypes ait ON ai.VIP_AccountInteractionTypeID = ait.VIP_AccountInteractionTypeID
					WHERE (1 = 1)
						AND ait.Code = 'ENROLLMENT_CORE'
						AND ai.[Status] = 'Processing'
						AND VIPMARKET_CGK_DATID = @datRecordID
				)
				UPDATE dbo.VIP_AccountInteractions
					SET 
						[Status] = 'Complete' 
						,EndDateTime = GETDATE()
				WHERE VIP_AccountInteractionID = @vip_AccountInteractionID
		
				UPDATE acc
						SET acc.AccountStatus = 'Enrollment Cancelled'
					FROM 
						dbo.VIPMARKET_CGK_DAT dat
						INNER JOIN dbo.VIP_Accounts acc 
							ON dat.VIP_AccountID = acc.VIP_AccountID
					WHERE (1 = 1)
						AND VIPMARKET_CGK_DATID = @datRecordID

				IF (@vip_AccountInteractionID IS NOT NULL)
				BEGIN
					INSERT INTO dbo.VIP_AccountInteractionAudit
							( VIP_AccountInteractionID ,
								AuditType ,
								AuditLevel ,
								AuditMessage ,
								AuditDateTime
							)
					VALUES  ( @vip_AccountInteractionID , -- VIP_AccountInteractionID - int
								'Information' , -- AuditType - varchar(50)
								'Medium' , -- AuditLevel - varchar(20)
								'Enrollment cancelled through CGK DAT Transaction Manager' , -- AuditMessage - text
								GETDATE()  -- AuditDateTime - smalldatetime
							)
				END          
			END
		END      
		ELSE IF (@action = 'MARK_FOR_TERMINATION')
		BEGIN

			INSERT INTO dbo.VIPMARKET_CGK_DAT
						( VIPMARKET_CGK_DAT_KEYNAME ,
						  CreatedBy ,
						  CreatedOn ,
						  ModifiedBy ,
						  ModifiedOn ,
						  DeletedOn ,
						  VIPMARKET_CGK_DAT_ParentID ,
						  TransactionDate ,
						  CancelledDate ,
						  VIP_AccountID ,
						  SetToReExport ,
						  Mkt_ActionCode ,
						  Mkt_PCID ,
						  Mkt_SEQUENCE ,
						  Mkt_CHECKDIGIT ,
						  Mkt_Filler001 ,
						  Mkt_RATECODE ,
						  Mkt_NOMINATIONGROUP ,
						  Mkt_ENROLLMENTTYPE
						)
				SELECT  VIPMARKET_CGK_DAT_KEYNAME ,
				        @userID ,
				        GETDATE() ,
				        @userID ,
				        GETDATE() ,
				        DeletedOn , -- we're deleting this record
				        VIPMARKET_CGK_DATID, --The old one becomes the parent  --VIPMARKET_CGK_DAT_ParentID ,
				        TransactionDate ,
				        CancelledDate ,
				        VIP_AccountID ,
				        SetToReExport ,
				        '2' , -- 2 to turn into a termination
				        Mkt_PCID ,
				        Mkt_SEQUENCE ,
				        Mkt_CHECKDIGIT ,
				        Mkt_Filler001 ,
				        Mkt_RATECODE ,
				        Mkt_NOMINATIONGROUP ,
				        Mkt_ENROLLMENTTYPE 
					FROM dbo.VIPMARKET_CGK_DAT
				WHERE VIPMARKET_CGK_DATID = @datRecordID

			IF (@updateTheAccount = 1)
			BEGIN
				-- Find the latest account interaction enrolling for the account and cancel it out
				SET @vip_AccountInteractionID =
				(
					SELECT TOP 1 VIP_AccountInteractionID
					FROM 
						dbo.VIPMARKET_CGK_DAT dat
						INNER JOIN dbo.VIP_AccountInteractions ai 
							ON dat.VIP_AccountID = ai.VIP_AccountID
						INNER JOIN dbo.VIP_AccountInteractionTypes ait ON ai.VIP_AccountInteractionTypeID = ait.VIP_AccountInteractionTypeID
					WHERE (1 = 1)
						AND ait.Code = 'ENROLLMENT_CORE'
						AND ai.[Status] = 'Processing'
						AND VIPMARKET_CGK_DATID = @datRecordID
				)
				UPDATE dbo.VIP_AccountInteractions
					SET 
						[Status] = 'Complete' 
						,EndDateTime = GETDATE()
				WHERE VIP_AccountInteractionID = @vip_AccountInteractionID
		
				UPDATE acc
						SET acc.AccountStatus = 'Enrollment Cancelled'
					FROM 
						dbo.VIPMARKET_CGK_DAT dat
						INNER JOIN dbo.VIP_Accounts acc 
							ON dat.VIP_AccountID = acc.VIP_AccountID
					WHERE (1 = 1)
						AND VIPMARKET_CGK_DATID = @datRecordID

				IF (@vip_AccountInteractionID IS NOT NULL)
				BEGIN
					INSERT INTO dbo.VIP_AccountInteractionAudit
							( VIP_AccountInteractionID ,
								AuditType ,
								AuditLevel ,
								AuditMessage ,
								AuditDateTime
							)
					VALUES  ( @vip_AccountInteractionID , -- VIP_AccountInteractionID - int
								'Information' , -- AuditType - varchar(50)
								'Medium' , -- AuditLevel - varchar(20)
								'Enrollment cancelled through CGK DAT Transaction Manager' , -- AuditMessage - text
								GETDATE()  -- AuditDateTime - smalldatetime
							)
				END          
			END
		END      
		ELSE IF (@action = 'STOP_SENDING') -- Stop submitting the DAT record for pending export
		BEGIN

			INSERT INTO dbo.VIPMARKET_CGK_DAT
						( VIPMARKET_CGK_DAT_KEYNAME ,
						  CreatedBy ,
						  CreatedOn ,
						  ModifiedBy ,
						  ModifiedOn ,
						  DeletedOn ,
						  VIPMARKET_CGK_DAT_ParentID ,
						  TransactionDate ,
						  CancelledDate ,
						  VIP_AccountID ,
						  SetToReExport ,
						  Mkt_ActionCode ,
						  Mkt_PCID ,
						  Mkt_SEQUENCE ,
						  Mkt_CHECKDIGIT ,
						  Mkt_Filler001 ,
						  Mkt_RATECODE ,
						  Mkt_NOMINATIONGROUP ,
						  Mkt_ENROLLMENTTYPE,
						  SetNotToExportDate
						)
				SELECT  VIPMARKET_CGK_DAT_KEYNAME ,
				        @userID ,
				        GETDATE() ,
				        @userID ,
				        GETDATE() ,
				        DeletedOn , -- we're deleting this record
				        VIPMARKET_CGK_DATID, --The old one becomes the parent  --VIPMARKET_CGK_DAT_ParentID ,
				        TransactionDate ,
				        CancelledDate ,
				        VIP_AccountID ,
				        SetToReExport ,
				        Mkt_ActionCode, -- D to delete from the DAT file
				        Mkt_PCID ,
				        Mkt_SEQUENCE ,
				        Mkt_CHECKDIGIT ,
				        Mkt_Filler001 ,
				        Mkt_RATECODE ,
				        Mkt_NOMINATIONGROUP ,
				        Mkt_ENROLLMENTTYPE ,
						GETDATE()

					FROM dbo.VIPMARKET_CGK_DAT
				WHERE VIPMARKET_CGK_DATID = @datRecordID

		END      
		ELSE IF (@action = 'MARK_FOR_ENROLL') -- Set the current request to enroll
		BEGIN

			INSERT INTO dbo.VIPMARKET_CGK_DAT
						( VIPMARKET_CGK_DAT_KEYNAME ,
						  CreatedBy ,
						  CreatedOn ,
						  ModifiedBy ,
						  ModifiedOn ,
						  DeletedOn ,
						  VIPMARKET_CGK_DAT_ParentID ,
						  TransactionDate ,
						  CancelledDate ,
						  VIP_AccountID ,
						  SetToReExport ,
						  Mkt_ActionCode ,
						  Mkt_PCID ,
						  Mkt_SEQUENCE ,
						  Mkt_CHECKDIGIT ,
						  Mkt_Filler001 ,
						  Mkt_RATECODE ,
						  Mkt_NOMINATIONGROUP ,
						  Mkt_ENROLLMENTTYPE,
						  SetNotToExportDate
						)
				SELECT  VIPMARKET_CGK_DAT_KEYNAME ,
				        @userID ,
				        GETDATE() ,
				        @userID ,
				        GETDATE() ,
				        DeletedOn , -- we're deleting this record
				        VIPMARKET_CGK_DATID, --The old one becomes the parent  --VIPMARKET_CGK_DAT_ParentID ,
				        TransactionDate ,
				        CancelledDate ,
				        VIP_AccountID ,
				        SetToReExport ,
				        '3', -- To Enroll
				        Mkt_PCID ,
				        Mkt_SEQUENCE ,
				        Mkt_CHECKDIGIT ,
				        Mkt_Filler001 ,
				        @utilityRateCode ,
				        Mkt_NOMINATIONGROUP ,
				        Mkt_ENROLLMENTTYPE ,
						NULL

					FROM dbo.VIPMARKET_CGK_DAT
				WHERE VIPMARKET_CGK_DATID = @datRecordID

		END      

		COMMIT

	END TRY
	BEGIN CATCH
		PRINT('Execution Error.  Rolling back transaction')
		ROLLBACK
		
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;
		
		SET @ErrorMessage = ERROR_MESSAGE()
		SET @ErrorSeverity = ERROR_SEVERITY()
		SET @ErrorState = ERROR_STATE()
		
		PRINT('ERROR_NUMBER: ' + CONVERT(varchar(100), ERROR_NUMBER()) )
		PRINT('ERROR_SEVERITY: ' + CONVERT(varchar(100), @ErrorSeverity) )
		PRINT('ERROR_STATE: ' + CONVERT(varchar(100), @ErrorState) )
		PRINT('ERROR_PROCEDURE: ' + CONVERT(varchar(100), ERROR_PROCEDURE()) )
		PRINT('ERROR_LINE: ' + CONVERT(varchar(100), ERROR_LINE()) )
		PRINT('ERROR_MESSAGE: ' + CONVERT(varchar(100), @ErrorMessage) )

		-- Bubble up the error
		RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
	END CATCH




END


GO
