
CREATE procedure dbo.AddModuleDefinition

	@DesktopModuleId int,    
	@FriendlyName    nvarchar(128),
	@DefaultCacheTime int

as

insert into dbo.ModuleDefinitions (
  DesktopModuleId,
  FriendlyName,
  DefaultCacheTime
)
values (
  @DesktopModuleId,
  @FriendlyName,
  @DefaultCacheTime
)

select SCOPE_IDENTITY()


GO
