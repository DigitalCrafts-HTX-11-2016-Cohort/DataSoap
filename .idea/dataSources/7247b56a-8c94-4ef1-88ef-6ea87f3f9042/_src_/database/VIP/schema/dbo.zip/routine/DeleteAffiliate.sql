
create procedure dbo.DeleteAffiliate

@AffiliateId int

as

delete
from   dbo.Affiliates
where  AffiliateId = @AffiliateId


GO
