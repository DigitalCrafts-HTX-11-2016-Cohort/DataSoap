
CREATE PROCEDURE dbo.GetUserRoles  
@PortalId  int,
@UserId    int

AS

SELECT     
    R.*,
    UR.UserRoleID, 
    U.UserID, 
    U.DisplayName, 
    U.Email, 
    UR.EffectiveDate, 
    UR.ExpiryDate, 
    UR.IsTrialUsed
FROM dbo.UserRoles UR
    INNER JOIN dbo.Users U ON UR.UserID = U.UserID 
    INNER JOIN dbo.Roles R ON UR.RoleID = R.RoleID 
WHERE
    U.UserID = @UserId AND R.PortalID = @PortalId

GO
