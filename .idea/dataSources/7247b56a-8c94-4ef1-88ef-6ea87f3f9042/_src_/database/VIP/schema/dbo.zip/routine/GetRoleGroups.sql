
CREATE PROCEDURE dbo.[GetRoleGroups]

	@PortalID		int
	
AS

SELECT
	RoleGroupId,
	PortalId,
	RoleGroupName,
	Description
FROM dbo.RoleGroups
WHERE  PortalId = @PortalID


GO
