-- =============================================
-- Author:		LARRY G
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_VIP_RemoveAccountProducts]
	-- Add the parameters for the stored procedure here
	@VIPAccountid INT, @ProdDate smalldatetime
AS

BEGIN TRY
	BEGIN TRANSACTION

	 Delete VIP_AccountProducts where VIP_AccountProductID IN
	 (
	   Select VIP_AccountProductID from 
	   (
		  SELECT vip_accountid,actprod.VIP_AccountProductID, actprod.StartDate, actprod.EndDate, prod.UtilityProductCode 
		  from VIP_AccountProducts actprod 
		  INNER JOIN vip_products prod ON prod.VIP_ProductID = actprod.VIP_ProductID 
		  where VIP_AccountID = @VIPAccountid 
		  AND (StartDate >= @ProdDate AND EndDate >= @ProdDate) 
		  AND prod.UtilityProductCode NOT IN 
		  (
			  SELECT ESP_Rate_Schedule FROM dbo.VIPMARKET_PGE_Billing WHERE Parent_SAID in
			  (
				SELECT UtilityServiceAccountID FROM vip_accounts WHERE vip_accountid = actprod.VIP_AccountID
				union
				SELECT UtilityServiceAccountID FROM dbo.VIP_Accounts_Reconciliation WHERE vip_accountid = actprod.VIP_AccountID 
			  ) AND Bill_Dt >= @ProdDate
		  )
	   ) a 
	)

	IF EXISTS 
	(
		SELECT TOP 1 StartDate from VIP_AccountProducts 
		where VIP_AccountID = @VIPAccountid 
		and EndDate >= @ProdDate 
		order by StartDate desc
	)

	BEGIN

		DECLARE @StDate SMALLDATETIME
		SELECT @StDate = 
		(
			SELECT TOP 1 StartDate from VIP_AccountProducts 
			where VIP_AccountID = @VIPAccountid 
			and EndDate >= @ProdDate 
			order by StartDate desc
		)

		Update VIP_AccountProducts set EndDate = @ProdDate where VIP_AccountProductID in
		(
			  Select top 1 VIP_AccountProductID from VIP_AccountProducts 
			  where VIP_AccountID = @VIPAccountid 
			  and EndDate >= @ProdDate order by StartDate desc
		)
	END

	COMMIT TRAN -- No Errors, so go ahead

END TRY

BEGIN CATCH
	ROLLBACK TRAN
	
    DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

    SELECT 
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();

    -- Use RAISERROR inside the CATCH block to return error
    -- information about the original error that caused
    -- execution to jump to the CATCH block.
    RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );        
END CATCH
GO
