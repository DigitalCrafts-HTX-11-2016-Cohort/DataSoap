
create procedure dbo.GetUsers

@PortalID int

as

select *
from dbo.Users U
left join dbo.UserPortals UP on U.UserId = UP.UserId
where ( UP.PortalId = @PortalID or @PortalID is null )
order by U.FirstName + ' ' + U.LastName


GO
