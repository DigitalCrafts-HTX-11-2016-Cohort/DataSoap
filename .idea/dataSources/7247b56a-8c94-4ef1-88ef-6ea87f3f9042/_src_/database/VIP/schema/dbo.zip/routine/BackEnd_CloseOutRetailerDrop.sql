
-- =============================================
-- Author:		Bryan Panjavan
-- Create date: 3/7/2013
-- Description:	Back-end Script - Close out any retailer drops on the account
-- =============================================
CREATE PROCEDURE [dbo].[BackEnd_CloseOutRetailerDrop]
(
	@VIP_AccountID int
)
AS
BEGIN

	BEGIN TRY
		PRINT('Executing.  Begin Transaction')
		BEGIN TRAN

	DECLARE @userName VARCHAR(100)
	SET @userName = (SELECT suser_sname())

	INSERT INTO [dbo].[VIP_AccountInteractionAudit]
			   ([VIP_AccountInteractionID]
			   ,[AuditType]
			   ,[AuditLevel]
			   ,[AuditMessage]
			   ,[AuditDateTime])
		 --VALUES
			--   (<VIP_AccountInteractionID, int,>
			--   ,<AuditType, varchar(50),>
			--   ,<AuditLevel, varchar(20),>
			--   ,<AuditMessage, text,>
			--   ,<AuditDateTime, smalldatetime,>)
		-- Insert the account interaction audit
		SELECT 
			ai.VIP_AccountInteractionID
			,'Manual Intervention'
			,'Medium'
			,@userName + ' - CLOSE PENDING TERMINATION'
			,GETDATE()
		FROM 
			dbo.VIP_AccountInteractions ai
			INNER JOIN dbo.VIP_AccountInteractionTypes ait ON ai.VIP_AccountInteractionTypeID = ait.VIP_AccountInteractionTypeID
				AND ait.Code = 'RETAILER_DROP'
		WHERE 
			VIP_AccountID = @VIP_AccountID	
			AND ai.[Status] = 'Processing'
			AND	ai.EndDateTime = '1900-01-01'

		-- close the termination
		UPDATE
			ai 
				SET 
					ai.[Status] = 'Complete'  
					,ai.[EndDateTime] = GETDATE()
		FROM 
			dbo.VIP_AccountInteractions ai
			INNER JOIN dbo.VIP_AccountInteractionTypes ait ON ai.VIP_AccountInteractionTypeID = ait.VIP_AccountInteractionTypeID
				AND ait.Code = 'RETAILER_DROP'
		WHERE 
			VIP_AccountID = @VIP_AccountID	
			AND ai.[Status] = 'Processing'
			AND	ai.EndDateTime = '1900-01-01'
  
        -- close the termination
		SELECT TOP 1
			ai.VIP_AccountInteractionID
			,'Manual Intervention'
			,'Medium'
			,@userName + ' - CLOSE PENDING TERMINATION'
			,GETDATE()
			,*
		FROM 
			dbo.VIP_AccountInteractions ai
			INNER JOIN dbo.VIP_AccountInteractionTypes ait ON ai.VIP_AccountInteractionTypeID = ait.VIP_AccountInteractionTypeID
				AND ait.Code = 'RETAILER_DROP'
			INNER JOIN dbo.VIP_AccountInteractionAudit aia ON aia.VIP_AccountInteractionID = ai.VIP_AccountInteractionID
		WHERE 
			VIP_AccountID = @VIP_AccountID	
			--AND ai.[Status] = 'Processing'
			--AND	ai.EndDateTime = '1900-01-01'
		ORDER BY VIP_AccountInteractionAuditID DESC

		PRINT('Execution Complete.  Committing Transaction')
		COMMIT

	END TRY
	BEGIN CATCH
		PRINT('Execution Error.  Rolling back transaction')
		ROLLBACK
	
		PRINT('ERROR_NUMBER: ' + CONVERT(varchar(100), ERROR_NUMBER()) )
		PRINT('ERROR_SEVERITY: ' + CONVERT(varchar(100), ERROR_SEVERITY()) )
		PRINT('ERROR_STATE: ' + CONVERT(varchar(100), ERROR_STATE()) )
		PRINT('ERROR_PROCEDURE: ' + CONVERT(varchar(100), ERROR_PROCEDURE()) )
		PRINT('ERROR_LINE: ' + CONVERT(varchar(100), ERROR_LINE()) )
		PRINT('ERROR_MESSAGE: ' + CONVERT(varchar(100), ERROR_MESSAGE()) )
	END CATCH

	-- Open Transaction Count
	IF (@@TRANCOUNT = 0)
	BEGIN
		PRINT('Transaction Status: GOOD')
	END
	ELSE
	BEGIN
		PRINT('Transaction Status: WARNING -> OPEN TRANSACTION COUNT: ' + CONVERT(varchar(100), @@TRANCOUNT)	)
	END

END

GO
