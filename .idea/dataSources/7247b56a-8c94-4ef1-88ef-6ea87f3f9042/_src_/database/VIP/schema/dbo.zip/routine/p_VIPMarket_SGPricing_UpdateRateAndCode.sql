CREATE PROCEDURE dbo.p_VIPMarket_SGPricing_UpdateRateAndCode
(
	@VIPMARKET_SG_Pricing_ID INT
	,@username VARCHAR(50)
	,@PriceOption VARCHAR(50)
	,@PriceCode VARCHAR(50) = NULL
	,@rate varchar(50)--DECIMAL(18,8)
)
AS
BEGIN TRAN

	----DECLARE @VIPMARKET_SG_Pricing_ID INT
	----DECLARE @username VARCHAR(50)
	----DECLARE @PriceOption VARCHAR(50)
	----DECLARE @PriceCode VARCHAR(50)
	DECLARE @rateDecimal DECIMAL(18,8)

	----SET @VIPMARKET_SG_Pricing_ID = 4176807
	----SET @username = '141'
	----SET @PriceOption = 'FBILLUNL2'
	----SET @PriceCode = '77108'
	----SET @rate = 65.26

	SET @rateDecimal = CONVERT(DECIMAL(18,8), @rate)


	UPDATE dbo.VIPMARKET_SG_Pricing
		SET 
			FixedPriceRate = CASE WHEN @PriceOption = 'Fixed' THEN @rateDecimal ELSE FixedPriceRate END
			, FixedpriceCode = CASE WHEN @PriceOption = 'Fixed' THEN ISNULL(@PriceCode, FixedpriceCode) ELSE FixedpriceCode END

			,FixedPriceRate2 = CASE WHEN @PriceOption = 'Fixed2' THEN @rateDecimal ELSE FixedPriceRate2 END
			, FixedpriceCode2 = CASE WHEN @PriceOption = 'Fixed2' THEN ISNULL(@PriceCode, FixedpriceCode2) ELSE FixedpriceCode2 END

			,FixedBillUnlimitedRate1 = CASE WHEN @PriceOption = 'FBILLUNL1' THEN @rateDecimal ELSE FixedBillUnlimitedRate1 END
			, FixedBillUnlimitedCode1 = CASE WHEN @PriceOption = 'FBILLUNL1' THEN ISNULL(@PriceCode, FixedBillUnlimitedCode1) ELSE FixedBillUnlimitedCode1 END

			,FixedBillUnlimitedRate2 = CASE WHEN @PriceOption = 'FBILLUNL2' THEN @rateDecimal ELSE FixedBillUnlimitedRate2 END
			, FixedBillUnlimitedCode2 = CASE WHEN @PriceOption = 'FBILLUNL2' THEN ISNULL(@PriceCode, FixedBillUnlimitedCode2) ELSE FixedBillUnlimitedCode2 END

			,IndexRate = CASE WHEN @PriceOption = 'Index' THEN @rateDecimal ELSE IndexRate END
			, IndexCode = CASE WHEN @PriceOption = 'Index' THEN ISNULL(@PriceCode, IndexCode) ELSE IndexCode END

			,IndexRate2 = CASE WHEN @PriceOption = 'Index2' THEN @rateDecimal ELSE IndexRate2 END
			, IndexCode2 = CASE WHEN @PriceOption = 'Index2' THEN ISNULL(@PriceCode, IndexCode2) ELSE IndexCode2 END

	WHERE VIPMARKET_SG_Pricing_ID = @VIPMARKET_SG_Pricing_ID

--	SELECT TOP 100 * FROM dbo.VIPMARKET_SG_Pricing WHERE VIPMARKET_SG_Pricing_ID = @VIPMARKET_SG_Pricing_ID
COMMIT
GO
