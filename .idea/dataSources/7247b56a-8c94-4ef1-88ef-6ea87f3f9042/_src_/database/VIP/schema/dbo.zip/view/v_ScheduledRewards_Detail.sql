
-- select * from dbo.v_ScheduledRewards_Detail

CREATE  VIEW dbo.v_ScheduledRewards_Detail
AS
    WITH    RewardsAccounts
              AS ( SELECT   accp.VIP_AccountID ,
                        --reward.VIP_RewardID ,
                            reward.RewardGroup ,
                        --reward.VIP_ProductID ,
                            reward.RewardAmount ,
                            reward.Limit ,
                            reward.AmountRequired ,
                            reward.AmountRequired_UnitOfMeasure
                   FROM     dbo.VIP_Rewards reward
                            INNER JOIN dbo.VIP_AccountProducts accp ON accp.VIP_ProductID = reward.VIP_ProductID
                   GROUP BY accp.VIP_AccountID ,
                        --reward.VIP_RewardID ,
                            reward.RewardGroup ,
                        --reward.VIP_ProductID ,
                            reward.RewardAmount ,
                            reward.Limit ,
                            reward.AmountRequired ,
                            reward.AmountRequired_UnitOfMeasure
                 ),
            MonthlyCalendarization
              AS ( SELECT   *
                   FROM     Accounting.CalendarDateAllRange
                   WHERE    CalendarDate BETWEEN '2017-01-01'
                                         AND     '2024-12-31'
                            AND DATEPART(DAY, CalendarDate) = 1
                 ),
            GiftCardDateRange
              AS ( SELECT   ra.* ,
                            capv.FirstAccountProduct_StartDate ,
                            DATEADD(MONTH,
                                    ra.Limit / ra.RewardAmount
                                    * ra.AmountRequired,
                                    capv.FirstAccountProduct_StartDate) AS FinalGiftCardDate
                   FROM     RewardsAccounts ra
                            INNER JOIN Products.mv_VIP_CumulativeAccountProductsView capv ON capv.VIP_AccountID = ra.VIP_AccountID
                 ),
            RowNumberPartition
              AS ( SELECT   * , 
						--DATEADD(DAY,
      --                                                        1 - DATEPART(DAY,
      --                                                        gcdr.FirstAccountProduct_StartDate),
      --                                                        gcdr.FirstAccountProduct_StartDate) AS StartingDay,
						--DATEADD(DAY,
      --                                                        1 - DATEPART(DAY,
      --                                                        gcdr.FinalGiftCardDate),
      --                                                        gcdr.FinalGiftCardDate) AS FinalDay,
                            ROW_NUMBER() OVER ( PARTITION BY gcdr.VIP_AccountID ORDER BY mc.CalendarDate ) AS RowNumber
                   FROM     GiftCardDateRange gcdr
                            INNER JOIN MonthlyCalendarization mc ON mc.CalendarDate BETWEEN DATEADD(DAY,
                                                              1 - DATEPART(DAY,
                                                              gcdr.FirstAccountProduct_StartDate),
                                                              gcdr.FirstAccountProduct_StartDate)
                                                              AND
                                                              DATEADD(DAY,
                                                              1 - DATEPART(DAY,
                                                              gcdr.FinalGiftCardDate),
                                                              gcdr.FinalGiftCardDate)
                 ),
            GetRewardMonths
              AS ( SELECT   * ,
                            DATEPART(MONTH, CalendarDate) AS Month ,
                            DATEPART(YEAR, CalendarDate) AS Year ,
                            DATEADD(DAY,
                                    DATEPART(DAY,
                                             FirstAccountProduct_StartDate)
                                    - 1, RowNumberPartition.CalendarDate) AS Reward_Date
                   FROM     RowNumberPartition
                   WHERE    ( RowNumber - 1 ) % AmountRequired = 0
                            AND RowNumber <> 1
    --ORDER BY VIP_AccountID ,
    --        CalendarDate
                 )
    SELECT  GetRewardMonths.VIP_AccountID ,
            acv.AccountStatus ,
            Reward_Date ,
            AmountRequired_UnitOfMeasure ,
            AmountRequired ,
            Limit ,
            RewardAmount ,
            RewardGroup ,
            FirstAccountProduct_StartDate ,
            FinalGiftCardDate
    FROM    GetRewardMonths
            INNER JOIN AccountServicePoint.mv_VIP_AccountCumulativeView_v2 acv ON acv.VIP_AccountID = GetRewardMonths.VIP_AccountID


GO
