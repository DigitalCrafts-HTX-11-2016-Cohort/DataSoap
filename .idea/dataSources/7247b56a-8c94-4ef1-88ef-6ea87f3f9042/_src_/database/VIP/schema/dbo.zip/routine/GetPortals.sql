
CREATE PROCEDURE dbo.[GetPortals]

AS
SELECT *
FROM dbo.vw_Portals
ORDER BY PortalName

GO
