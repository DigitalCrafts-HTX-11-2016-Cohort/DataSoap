
CREATE PROCEDURE dbo.[AddRoleGroup]

	@PortalID         int,
	@RoleGroupName    nvarchar(50),
	@Description      nvarchar(1000)

AS

INSERT INTO dbo.RoleGroups (
  PortalId,
  RoleGroupName,
  Description
)
VALUES (
  @PortalID,
  @RoleGroupName,
  @Description
)

SELECT SCOPE_IDENTITY()


GO
