
CREATE PROCEDURE [dbo].[usp_VIP_Dynamics_CustomerIDInUse]
	@CustomerID		varchar(10)
AS
BEGIN

	SELECT DynamicsCustomerID
	FROM VIP_BillingPoints
	WHERE DynamicsCustomerID = @CustomerID

END
GO
