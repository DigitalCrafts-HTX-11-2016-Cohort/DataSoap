
CREATE PROCEDURE dbo.GetEventLog
	@PortalID int,
	@LogTypeKey nvarchar(35),
	@PageSize int,
	@PageIndex int
AS

	DECLARE @PageLowerBound int
	DECLARE @PageUpperBound int
	-- Set the page bounds
	SET @PageLowerBound = @PageSize * @PageIndex
	SET @PageUpperBound = @PageLowerBound + @PageSize + 1

	CREATE TABLE #PageIndex 
	(
		IndexID		int IDENTITY (1, 1) NOT NULL,
		LogGUID	varchar(36) COLLATE database_default
	)

	INSERT INTO #PageIndex (LogGUID)
	SELECT dbo.EventLog.LogGUID
	FROM dbo.EventLog
	INNER JOIN dbo.EventLogConfig
		ON dbo.EventLog.LogConfigID = dbo.EventLogConfig.ID
	WHERE (LogPortalID = @PortalID or @PortalID IS NULL)
		AND (dbo.EventLog.LogTypeKey = @LogTypeKey or @LogTypeKey IS NULL)
	ORDER BY LogCreateDate DESC


	SELECT dbo.EventLog.*
	FROM dbo.EventLog
	INNER JOIN dbo.EventLogConfig
		ON dbo.EventLog.LogConfigID = dbo.EventLogConfig.ID
	INNER JOIN #PageIndex PageIndex
		ON dbo.EventLog.LogGUID = PageIndex.LogGUID
	WHERE PageIndex.IndexID			> @PageLowerBound	
		AND	PageIndex.IndexID			< @PageUpperBound	
	ORDER BY
		PageIndex.IndexID	

	SELECT COUNT(*) as TotalRecords
	FROM #PageIndex

GO
