
create procedure dbo.DeletePortalDesktopModules

@PortalID        int,
@DesktopModuleId int

as

delete
from   dbo.PortalDesktopModules
where  ((PortalId = @PortalID) or (@PortalID is null and @DesktopModuleId is not null))
and    ((DesktopModuleId = @DesktopModuleId) or (@DesktopModuleId is null and @PortalID is not null))


GO
