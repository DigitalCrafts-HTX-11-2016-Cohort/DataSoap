
CREATE PROCEDURE dbo.GetPropertyDefinitionsByPortal

	@PortalID	int

AS
SELECT	dbo.ProfilePropertyDefinition.*
	FROM	dbo.ProfilePropertyDefinition
	WHERE  (PortalId = @PortalID OR (PortalId IS NULL AND @PortalID IS NULL))
		AND Deleted = 0
	ORDER BY ViewOrder


GO
