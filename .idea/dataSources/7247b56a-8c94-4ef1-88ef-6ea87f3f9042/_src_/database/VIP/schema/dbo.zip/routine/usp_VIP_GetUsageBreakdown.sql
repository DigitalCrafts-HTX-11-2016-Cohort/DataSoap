CREATE procedure [dbo].[usp_VIP_GetUsageBreakdown]
	@VIP_UsageID int
	AS
--SELECT *
--FROM VIP_UsageBreakdowns ub
--	INNER JOIN VIP_UsageBreakdownTypes ubt ON ub.VIP_UsageBreakdownTypeID = ubt.VIP_UsageBreakdownTypeID
--WHERE ub.VIP_UsageID = @VIP_UsageID
--ORDER BY ub.UsageDate desc


SELECT *
FROM VIP_UsageBreakdownsView ub
	INNER JOIN VIP_UsageBreakdownTypes ubt ON ub.VIP_UsageBreakdownTypeID = ubt.VIP_UsageBreakdownTypeID
WHERE ub.VIP_UsageID = @VIP_UsageID
ORDER BY ub.UsageDate desc
GO
