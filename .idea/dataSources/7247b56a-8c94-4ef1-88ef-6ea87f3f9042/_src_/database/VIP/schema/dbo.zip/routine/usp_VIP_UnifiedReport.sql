-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE usp_VIP_UnifiedReport
	-- Add the parameters for the stored procedure here
	@InvoiceStatus varchar(100),
	@StartDate smalldatetime, @EndDate smalldatetime,	
	@SAID varchar(20),
	@UtiliyAcctNo varchar(20),
	 @CustomerName varchar(50),
	@Utility varchar(50),
	@Marketer varchar(50),
	@AccountClass varchar(50),
	@AccountStatus varchar(50),
	@CoreCustomer int,
	@VIP_MarketerAgentID int,
	@RepStartDate smalldatetime,
	@RepEndDate smalldatetime	
	
AS
Select *, a.ShadowBillingTotal - a.UtilityInvoices Margin, 
   case 
		when a.UtilityInvoices = 0 then 100
		when a.ShadowBillingTotal = 0 then 100
		when a.UtilityInvoices > a.ShadowBillingTotal then							
			(1 - (a.ShadowBillingTotal / a.UtilityInvoices)) * 100
		when a.ShadowBillingTotal > a.UtilityInvoices  then							
			(1 - (a.UtilityInvoices	/ a.ShadowBillingTotal)) * 100
		end
	GapPercent  
from 
(
	Select
		  VIP_Accounts.CompanyName + VIP_Accounts.BillingFirstName + VIP_Accounts.BillingLastName CustomerName,
		  VIP_Accounts.UtilityServiceAccountID,
		  VIP_Accounts.UtilityAccountNumber,
		  VIP_Accounts.VIP_AccountID,
		  VIP_Accounts.AccountStatus,
		  dateadd(d, 0, datediff(d, 0, VIP_Accounts.EnrollmentAcceptDate)) EnrollmentAcceptDate,
		  VIP_AccountClasses.Code AccountClass,
		  VIP_Utilities.Code Utility,
		  CoreCustomer =
		  Case VIP_Accounts.CoreCustomer 
				When 1 Then 'Yes'
				Else 'No'
		  End,
		  VIP_Marketers.Code Marketer,
		  VIP_Accounts.VIP_MarketerAgentID,
		  (Select FirstName + ' ' + LastName from VIP_MarketerAgents where VIP_MarketerAgentID = VIP_Accounts.VIP_MarketerAgentID) MarketerAgentName,
		  (
			Select isnull(SUM(usageamount),0) from
			(
				Select UsageDate, usageamount
				from VIP_InvoiceBreakdownsView
				inner join VIP_InvoicesView on VIP_InvoicesView.VIP_InvoiceID = VIP_InvoiceBreakdownsView.VIP_InvoiceID
				where VIP_InvoiceBreakdownsView.VIP_AccountID = VIP_Accounts.VIP_AccountID 
				and VIP_InvoicesView.InvoiceTypeCode not in ('Shadow')
				and (VIP_InvoiceBreakdownsView.UsageDate Between @StartDate and @EndDate 
				and VIP_InvoiceBreakdownsView.ReportedDate Between @RepStartDate and @RepEndDate)
				and VIP_InvoicesView.Status in(@InvoiceStatus) and (EndUsage = 0 or EndUsage is null)
				group by UsageDate, UsageAmount
			) a
		) TotalUsage,		
		    (
				Select isnull(sum(Total),0) from
				(
					Select Usagedate, VIP_InvoiceBreakdownsView.Total, VIP_InvoiceBreakdownsView.VIP_InvoiceID
					From VIP_InvoiceBreakdownsView 
					inner join VIP_InvoicesView on VIP_InvoicesView.VIP_InvoiceID = VIP_InvoiceBreakdownsView.vip_invoiceid
					Where VIP_InvoiceBreakdownsView.VIP_AccountID = VIP_Accounts.VIP_AccountID 
					And (VIP_InvoiceBreakdownsView.UsageDate Between @StartDate and @EndDate 
					and VIP_InvoiceBreakdownsView.ReportedDate Between @RepStartDate and @RepEndDate)
					and VIP_InvoiceBreakdownsView.VIP_AccountID = VIP_Accounts.VIP_AccountID 
					and VIP_InvoicesView.Status in(@InvoiceStatus) and (EndUsage = 0 or EndUsage is null)
				) a
			) UtilityInvoices,	
							
			(
			Select isnull(Sum(VIP_InvoiceBreakdownsView.Total),0)
				From VIP_InvoiceBreakdownsView 
				inner join VIP_InvoicesView on VIP_InvoicesView.VIP_InvoiceID = VIP_InvoiceBreakdownsView.vip_invoiceid
				Where VIP_InvoiceBreakdownsView.VIP_AccountID = VIP_Accounts.VIP_AccountID 
				And (VIP_InvoiceBreakdownsView.UsageDate Between @StartDate and @EndDate  
				and VIP_InvoiceBreakdownsView.ReportedDate Between @RepStartDate and @RepEndDate)
				and VIP_InvoiceBreakdownsView.VIP_AccountID = VIP_Accounts.VIP_AccountID
				and VIP_InvoicesView.Status in('Shadow Calculated') and (EndUsage = 0 or EndUsage is null)	
			) ShadowBillingAmount,			
			(
			Select isnull(Sum(VIP_InvoiceBreakdownsView.ServiceFee),0)
				From VIP_InvoiceBreakdownsView 
				inner join VIP_InvoicesView on VIP_InvoicesView.VIP_InvoiceID = VIP_InvoiceBreakdownsView.vip_invoiceid
				Where VIP_InvoiceBreakdownsView.VIP_AccountID = VIP_Accounts.VIP_AccountID 
				And (VIP_InvoiceBreakdownsView.UsageDate Between @StartDate and @EndDate 
				and VIP_InvoiceBreakdownsView.ReportedDate Between @RepStartDate and @RepEndDate)
				and VIP_InvoiceBreakdownsView.VIP_AccountID = VIP_Accounts.VIP_AccountID
				and VIP_InvoicesView.Status in('Shadow Calculated') and (EndUsage = 0 or EndUsage is null)			
			) ShadowBillingServiceFee,			
			(
			Select Sum(ISNULL(VIP_InvoiceBreakdownsView.Total,0) + isnull(VIP_InvoiceBreakdownsView.ServiceFee,0)) 
				From VIP_InvoiceBreakdownsView 
				inner join VIP_InvoicesView on VIP_InvoicesView.VIP_InvoiceID = VIP_InvoiceBreakdownsView.vip_invoiceid
				Where VIP_InvoiceBreakdownsView.VIP_AccountID = VIP_Accounts.VIP_AccountID 
				And (VIP_InvoiceBreakdownsView.UsageDate Between @StartDate and @EndDate 
				and VIP_InvoiceBreakdownsView.ReportedDate Between @RepStartDate and @RepEndDate)
				and VIP_InvoiceBreakdownsView.VIP_AccountID = VIP_Accounts.VIP_AccountID
				and VIP_InvoicesView.Status in('Shadow Calculated') and (EndUsage = 0 or EndUsage is null)	
			) ShadowBillingTotal,		  			
		  (
			Select ISNULL(SUM(VIP_PaymentBreakdownView.PaymentAmount),0)
			From VIP_PaymentBreakdownView
			Inner Join VIP_PaymentsView on VIP_PaymentBreakdownView.VIP_PaymentID = VIP_PaymentsView.VIP_PaymentID 
			Inner Join VIP_BillingPointAccountsView on VIP_PaymentsView.VIP_BillingPointID = VIP_BillingPointAccountsView.VIP_BillingPointID 
			Where VIP_BillingPointAccountsView.VIP_AccountID = VIP_Accounts.VIP_AccountID 
			And VIP_PaymentBreakdownView.PaymentDate Between @StartDate and @EndDate 	
		  ) TotalPayments
	From
		  VIP_Accounts Inner Join VIP_AccountClasses on VIP_Accounts.VIP_AccountClassID = VIP_AccountClasses.VIP_AccountClassID 
		  Inner Join VIP_Marketers on VIP_Accounts.VIP_MarketerID = VIP_Marketers.VIP_MarketerID 
		  Inner Join VIP_Utilities on VIP_Accounts.VIP_UtilityID = VIP_Utilities.VIP_UtilityID
) a
where 
a.UtilityServiceAccountID like '%' + @SAID + '%' and
a.UtilityAccountNumber like '%' + @UtiliyAcctNo + '%' and
a.CustomerName like '%' + @CustomerName + '%' and
a.Utility in(@Utility) and
a.Marketer in(@Marketer) and
a.AccountClass in(@AccountClass) and
a.AccountStatus in(@AccountStatus) and
a.CoreCustomer in(@CoreCustomer) and
a.VIP_MarketerAgentID in(@VIP_MarketerAgentID) and
(
	a.VIP_AccountID in
	(
		Select distinct vip_accountid from VIP_InvoiceBreakdownsView where UsageDate between @StartDate and @EndDate 			
	) and 
	a.VIP_AccountID in
	(
		Select distinct vip_accountid from VIP_InvoiceBreakdownsView where ReportedDate between @RepStartDate and @RepEndDate 			
	)
)
order by a.ShadowBillingTotal - a.UtilityInvoices desc
GO
