
create procedure dbo.GetSearchItem
	@ModuleId int,
	@SearchKey varchar(100) 
AS

select
	[SearchItemID],
	[Title],
	[Description],
	[Author],
	[PubDate],
	[ModuleId],
	[SearchKey],
	[Guid],
	[HitCount],
	ImageFileId
from
	dbo.SearchItem
where
	[ModuleID] = @ModuleID AND
	[SearchKey] = @SearchKey


GO
