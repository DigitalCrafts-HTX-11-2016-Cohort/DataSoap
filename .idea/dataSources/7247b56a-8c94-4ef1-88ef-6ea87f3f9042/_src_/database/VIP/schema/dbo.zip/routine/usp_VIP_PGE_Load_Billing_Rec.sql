-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE usp_VIP_PGE_Load_Billing_Rec
@ESP varchar(10), 
@Bill_Dt smalldatetime, 
@Acct_ID varchar(10), 
@DA_XREF varchar(10), 
@Parent_SAID varchar(10), 
@SAID varchar(10), 
@Rate_Schedule_Code varchar(10), 
@ESP_Rate_Schedule varchar(10), 
@Commodity varchar(10), 
@Revenue_Class_Cd varchar(10), 
@Bseg_ID varchar(12), 
@Bill_From_Dt smalldatetime, 
@Bill_To_Dt smalldatetime, 
@Usage decimal(18,5), 
@Energy_Amt decimal(18,5), 
@UUT_Amt decimal(18,5), 
@Current_UUT decimal(18,5), 
@TownOrTerr_Cd varchar(5), 
@TownOrTer_Desc varchar(50), 
@Over5K varchar(1), 
@AlertDuplicateRecords varchar(1), 
@Bseg_Status varchar(10), 
@BillingDays int, 
@VIP_AccountID int, 
@VIP_DailyFee decimal(18,5), 
@PGE_BillingMinusVIPDailyFee decimal(18,5), 
@PGE_GasPrice decimal(18,5), 
@VIP_GasPrice decimal(18,5), 
@PGE_GasPriceMinusVIPGasPrice decimal(18,5), 
@VIP_RateDifference decimal(18,5),  
@FileName varchar(75),
@LoadTemp bit
AS

declare @ValidateString varchar(500)
declare @Status varchar(50)

Select @Status = 'Pending'

Select @ValidateString = 
convert(varchar(10),@Bill_Dt,101) + @Acct_ID + @DA_XREF + @Parent_SAID + @SAID + @Rate_Schedule_Code + @ESP_Rate_Schedule + 
@Bseg_ID + convert(varchar(10),@Bill_From_Dt,101) + convert(varchar(10),@Bill_To_Dt,101) + convert(varchar(40), @Usage) + convert(varchar(40), @Energy_Amt)

if @LoadTemp = 1
BEGIN
	--IF EXISTS
	--(
	--	SELECT *
	--	FROM
	--	(
	--		SELECT
	--			replace(convert(varchar, Bill_Dt, 101)
	--			+ Acct_ID
	--			+ DA_XREF
	--			+ Parent_SAID
	--			+ SAID
	--			+ Rate_Schedule_Code
	--			+ ESP_Rate_Schedule
	--			+ Bseg_ID
	--			+ convert(varchar(10), Bill_From_Dt, 101)
	--			+ convert(varchar(10), Bill_To_Dt, 101)
	--			+ cast(Usage as varchar)
	--			+ cast(Energy_Amt as varchar), ' ', '') Fingerprint
	--		FROM VIPMARKET_PGE_Billing_Temp
	--	) a
	--	WHERE Fingerprint = @ValidateString
	--)
	--BEGIN
	--	Select @Status = 'Duplicate'		
	--END
	--ELSE
	--BEGIN
	--	Select @Status = 'Pending'		
	--END

	--Print @Status

	insert into VIPMARKET_PGE_Billing_Temp
	(
		ESP, Bill_Dt, Acct_ID, DA_XREF, Parent_SAID, SAID, 
		Rate_Schedule_Code, ESP_Rate_Schedule, Commodity, Revenue_Class_Cd, 
		Bseg_ID, Bill_From_Dt, Bill_To_Dt, Usage, Energy_Amt, UUT_Amt, Current_UUT, 
		TownOrTerr_Cd, TownOrTer_Desc, Over5K, AlertDuplicateRecords, Bseg_Status, 
		BillingDays, VIP_AccountID, VIP_DailyFee, PGE_BillingMinusVIPDailyFee, 
		PGE_GasPrice, VIP_GasPrice, PGE_GasPriceMinusVIPGasPrice, VIP_RateDifference, 
		Status, FileName
	)
	values
	(
	@ESP, 
	convert(varchar(10),@Bill_Dt,101), 
	@Acct_ID, 
	@DA_XREF, 
	@Parent_SAID, 
	@SAID, 
	@Rate_Schedule_Code, 
	@ESP_Rate_Schedule, 
	@Commodity, 
	@Revenue_Class_Cd, 
	@Bseg_ID, 
	convert(varchar(10),@Bill_From_Dt,101), 
	convert(varchar(10),@Bill_To_Dt,101) , 
	@Usage , 
	@Energy_Amt , 
	@UUT_Amt , 
	@Current_UUT , 
	@TownOrTerr_Cd , 
	@TownOrTer_Desc , 
	@Over5K , 
	@AlertDuplicateRecords , 
	@Bseg_Status , 
	@BillingDays , 
	@VIP_AccountID , 
	@VIP_DailyFee , 
	@PGE_BillingMinusVIPDailyFee , 
	@PGE_GasPrice , 
	@VIP_GasPrice , 
	@PGE_GasPriceMinusVIPGasPrice , 
	@VIP_RateDifference , 
	@Status , 
	@FileName 
	)
END

ELSE

BEGIN
	--IF EXISTS
	--	(
	--		SELECT *
	--		FROM
	--		(
	--			SELECT
	--				replace(convert(varchar, Bill_Dt, 101)
	--				+ Acct_ID
	--				+ DA_XREF
	--				+ Parent_SAID
	--				+ SAID
	--				+ Rate_Schedule_Code
	--				+ ESP_Rate_Schedule
	--				+ Bseg_ID
	--				+ convert(varchar(10), Bill_From_Dt, 101)
	--				+ convert(varchar(10), Bill_To_Dt, 101)
	--				+ cast(Usage as varchar)
	--				+ cast(Energy_Amt as varchar), ' ', '') Fingerprint
	--			FROM VIPMARKET_PGE_Billing
	--		) a
	--		WHERE Fingerprint = @ValidateString
	--	)
	--	BEGIN
	--		Select @Status = 'Duplicate'		
	--	END
	--	ELSE
	--	BEGIN
	--		Select @Status = 'Pending'		
	--	END

	insert into VIPMARKET_PGE_Billing
	(
	ESP, Bill_Dt, Acct_ID, DA_XREF, Parent_SAID, SAID, 
	Rate_Schedule_Code, ESP_Rate_Schedule, Commodity, Revenue_Class_Cd, 
	Bseg_ID, Bill_From_Dt, Bill_To_Dt, Usage, Energy_Amt, UUT_Amt, Current_UUT, 
	TownOrTerr_Cd, TownOrTer_Desc, Over5K, AlertDuplicateRecords, Bseg_Status, 
	BillingDays, VIP_AccountID, VIP_DailyFee, PGE_BillingMinusVIPDailyFee, 
	PGE_GasPrice, VIP_GasPrice, PGE_GasPriceMinusVIPGasPrice, VIP_RateDifference, 
	Status, FileName
	)
	values
	(
	@ESP, 
	convert(varchar(10),@Bill_Dt,101), 
	@Acct_ID, 
	@DA_XREF, 
	@Parent_SAID, 
	@SAID, 
	@Rate_Schedule_Code, 
	@ESP_Rate_Schedule, 
	@Commodity, 
	@Revenue_Class_Cd, 
	@Bseg_ID, 
	convert(varchar(10),@Bill_From_Dt,101) , 
	convert(varchar(10),@Bill_To_Dt,101) , 
	@Usage , 
	@Energy_Amt , 
	@UUT_Amt , 
	@Current_UUT , 
	@TownOrTerr_Cd , 
	@TownOrTer_Desc , 
	@Over5K , 
	@AlertDuplicateRecords , 
	@Bseg_Status , 
	@BillingDays , 
	@VIP_AccountID , 
	@VIP_DailyFee , 
	@PGE_BillingMinusVIPDailyFee , 
	@PGE_GasPrice , 
	@VIP_GasPrice , 
	@PGE_GasPriceMinusVIPGasPrice , 
	@VIP_RateDifference , 
	@Status , 
	@FileName 
	)
END
GO
