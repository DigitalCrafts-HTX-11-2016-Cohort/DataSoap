
create procedure dbo.GetDesktopModule

@DesktopModuleId int

as

select *
from   dbo.DesktopModules
where  DesktopModuleId = @DesktopModuleId


GO
