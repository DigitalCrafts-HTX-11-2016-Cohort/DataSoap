
/* =============================================
-- Author:		Bryan Panjavan
 - Description:
		- Used in outbound termination processing and enrollment processing
		- These processes need to know if there is an existing request PENDING export for their account

		- 2013-11-04 - BPanjavan - Initial Creation
		- 2013-11-26 - BPanjavan - Left join for Has Final Confirm so the termination process can use this
		- 2013-11-27 - BPanjavan - Left join for Has Final Confirm so the termination process can use this
  =======================================

*/
CREATE PROCEDURE VIPMarket_CGK_DAT_GetExistingRequests
AS
BEGIN
	SELECT 
		dat.[Status]
		,dat.VIPMARKET_CGK_DATID
		,dat.VIP_AccountID
		,dat.TransactionDate
		,dat.Mkt_ActionCode
		,dat.ExportDate

		,HasFinalConfirm = CASE WHEN finalConfirm.EnrollmentResponseID IS NOT NULL THEN 1 ELSE 0 END
	FROM 
		[dbo].[VIPMarket_DATView] dat
		LEFT JOIN B2B.v_CGK_EnrollmentResponse_BaseView finalConfirm-- Final Confirms
			ON finalConfirm.IsFinalConfirm = 1 AND finalConfirm.EnrollmentResponse = 'ACCEPT'
				AND dat.Mkt_PCID = finalConfirm.CustomerPCIDNumber
				AND dat.Mkt_SEQUENCE = finalConfirm.CustomerSequenceNumber
				AND dat.Mkt_CHeckDigit = finalConfirm.CustomerCheckDigitNumber
				AND dat.TransactionDate < finalConfirm.ReceivedDate
	WHERE (1 = 1) 
		AND dat.[Status] = 'Pending Export'
END
GO
