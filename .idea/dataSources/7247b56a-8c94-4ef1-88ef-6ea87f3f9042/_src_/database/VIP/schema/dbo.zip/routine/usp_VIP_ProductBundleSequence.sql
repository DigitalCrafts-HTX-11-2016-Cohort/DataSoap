-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE usp_VIP_ProductBundleSequence
@ProductBundleId int, @Sequence int, @Function varchar(10)
AS

if @Function = 'Remove'
	begin
	Delete dbo.VIP_ProductBundleItems 
	where VIP_ProductBundleID = @ProductBundleID and sequence = @Sequence

	Update dbo.VIP_ProductBundleItems 
	set sequence = sequence - 1
	where VIP_ProductBundleID = @ProductBundleID and sequence > @Sequence
end
GO
