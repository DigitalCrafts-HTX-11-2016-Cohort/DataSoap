
CREATE procedure dbo.[Dashboard_GetDbFileInfo]
AS
	
	SELECT 
		CASE LOWER(RIGHT(filename,3))
			WHEN 'mdf' THEN 'DATA'
			WHEN 'ldf' THEN 'LOG'
			ELSE 'UNKNOWN'
		END as FileType,
		Name,
		size*8 as Size,
        filename
	FROM sysfiles

GO
