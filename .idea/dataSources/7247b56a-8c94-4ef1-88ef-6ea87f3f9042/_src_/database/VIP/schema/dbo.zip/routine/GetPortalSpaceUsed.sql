
CREATE PROCEDURE dbo.GetPortalSpaceUsed
	@PortalID int
AS

SELECT 'SpaceUsed' = SUM(CAST(Size as bigint))
FROM   Files
WHERE  ((PortalId = @PortalID) OR (@PortalID is null and PortalId is null))


GO
