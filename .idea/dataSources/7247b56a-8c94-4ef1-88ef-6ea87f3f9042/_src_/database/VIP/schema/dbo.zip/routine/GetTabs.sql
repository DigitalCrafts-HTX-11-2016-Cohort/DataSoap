
CREATE PROCEDURE dbo.[GetTabs]

@PortalID int

AS
SELECT *
FROM   dbo.vw_Tabs
WHERE  PortalId = @PortalID OR (PortalID IS NULL AND @PortalID IS NULL)
ORDER BY TabOrder, TabName

GO
