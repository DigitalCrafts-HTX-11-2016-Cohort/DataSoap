
CREATE PROCEDURE dbo.GetSearchWords
AS

SELECT
	[SearchWordsID],
	[Word],
	[HitCount]
FROM
	dbo.SearchWord


GO
