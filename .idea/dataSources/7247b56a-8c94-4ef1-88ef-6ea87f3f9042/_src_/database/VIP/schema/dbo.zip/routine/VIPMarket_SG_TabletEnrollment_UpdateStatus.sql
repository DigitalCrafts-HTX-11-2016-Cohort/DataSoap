


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[VIPMarket_SG_TabletEnrollment_UpdateStatus]
(
	@userName VARCHAR(50),
	@VIPMarket_SG_TabletEnrollmentID INT,
	@Status VARCHAR(50),
	@StatusReason VARCHAR(400)
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	UPDATE dbo.VIPMarket_SG_TabletEnrollment
	SET 
		[Status] = @Status,
		StatusReason = @StatusReason,
		ModifiedBy = @userName,
	    ModifiedOn = GETDATE()
	WHERE
		VIPMarket_SG_TabletEnrollmentID = @VIPMarket_SG_TabletEnrollmentID

END


GO
