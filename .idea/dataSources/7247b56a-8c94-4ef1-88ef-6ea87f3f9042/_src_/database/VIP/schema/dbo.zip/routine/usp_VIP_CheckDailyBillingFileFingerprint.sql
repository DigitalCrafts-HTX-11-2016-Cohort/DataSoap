
CREATE PROCEDURE [dbo].[usp_VIP_CheckDailyBillingFileFingerprint]
	@Fingerprint varchar(200)
AS
SELECT *
FROM
(
	SELECT
		replace(convert(varchar, Bill_Dt, 101)
		+ Acct_ID
		+ DA_XREF
		+ Parent_SAID
		+ SAID
		+ Rate_Schedule_Code
		+ ESP_Rate_Schedule
		+ Bseg_ID
		+ convert(varchar, Bill_From_Dt, 101)
		+ convert(varchar, Bill_To_Dt, 101)
		+ cast(Usage as varchar)
		+ cast(Energy_Amt as varchar), ' ', '') Fingerprint
	FROM VIP_VIPMARKET_PGE_BillingView
) a
WHERE Fingerprint = @Fingerprint
GO
