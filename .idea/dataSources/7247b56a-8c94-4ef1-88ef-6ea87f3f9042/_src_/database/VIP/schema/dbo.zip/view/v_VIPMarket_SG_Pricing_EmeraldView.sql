CREATE VIEW dbo.v_VIPMarket_SG_Pricing_EmeraldView AS
SELECT --TOP 100 
		VIPMARKET_SG_Pricing_ID ,
       Account_Number ,
       FPrt = CONVERT(DECIMAL(18,3), FixedPriceRate ),
       FPcd = FixedpriceCode ,
       FPrt2 = CONVERT(DECIMAL(18,3), FixedPriceRate2 ),
       FPcd2 = FixedPriceCode2 ,
       FPrt3 = CONVERT(DECIMAL(18,3), FixedPriceRate3 ),
       FPcd3 = FixedPriceCode3 ,
       IXrt = CONVERT(DECIMAL(18,3), IndexRate ),
       IXcd = IndexCode ,
       IXrt2 = CONVERT(DECIMAL(18,3), IndexRate2 ),
       IXcd2 = IndexCode2 ,
       FBrt1 = CONVERT(DECIMAL(18,2), FixedBillUnlimitedRate1 ),
       FBcd1 = FixedBillUnlimitedCode1 ,
       FBrt2 = CONVERT(DECIMAL(18,2), FixedBillUnlimitedRate2 ),
       FBcd2 = FixedBillUnlimitedCode2 ,
       FBrt3 = CONVERT(DECIMAL(18,2), FixedBillUnlimitedRate3 ),
       FBcd3 = FixedBillUnlimitedCode3 ,
       GLTPORRate1 = CONVERT(DECIMAL(18,3), GLTPORRate1 ),
       GLTPORCode1 ,
       ImportDate ,
       ImportFileName 
       --GLTPORRate2 ,
       --GLTPORCode2 ,
       --GLTPORRate3 ,
       --GLTPORCode3 ,
       --ServicePointID 
FROM dbo.VIPMARKET_SG_Pricing

GO
