-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	
	-- 2017-04-06 - BPanjavan - Excluding Nebraska on 4/6
-- =============================================
CREATE PROCEDURE [dbo].[usp_VIP_SG_SupplierSignUp]
@UserGroup varchar(25), @State varchar(3)
AS

  
----      --UPDATE THE CONFIRMATION DATES
---- ----  update VIPMARKET_SG_ELG_PREMISE
---- ----  set confdatetime = 
---- ----  (
---- ---- 	substring(substring(submittedfilename,13, 14) , 5, 2)  + '/' +
----	----substring(substring(submittedfilename,13, 14) , 7, 2)  + '/' +
----	----left(substring(submittedfilename,13, 14),4)
---- ----  ) where status <> '' and submittedfilename <> ''   


Select TOP 50000
VIPMARKET_SG_ELG_PREMISE.account_number [Account Number], Control_Number [Control Number],
pricingVertical.PriceOption, Service_State, Bill_Class,
PriceCode = pricingVertical.RateCOde,
PriceRate = pricingVertical.Price,
Last_Name + ', ' + First_Name Customername,
ConfDatetime TimeStampDate,
(
	Select rolename from roles where rolename in('SG_VISTA_Group','SG_CSS_Group','SG_VISTA_Admin_Group','SG_VIP_Web_Enrollment','SG_41MG_Group')
	and roleid in
	(
		Select roleid from userroles 
		where UserID = VIPMARKET_SG_ELG_PREMISE.userid
	)
) UserGroup,
(
	Select username from
	(
		Select 
		Account_Number,
		left(users.FirstName,1) + users.LastName + '-' + convert(varchar(12), ROW_NUMBER() OVER(ORDER BY ConfDatetime ASC)) username from VIPMARKET_SG_ELG_PREMISE a
		inner join users on users.userid = a.userid
		where users.UserID = VIPMARKET_SG_ELG_PREMISE.userid 
	) a 
	where a.Account_Number = VIPMARKET_SG_ELG_PREMISE.Account_Number
) BrokerName, 
Confirmation_ID,
(
	Select 
	 SUM( 
			convert(numeric(18,2),b.Jan_Prem_Usage) +
			convert(numeric(18,2),b.Feb_Prem_Usage) +
			convert(numeric(18,2),b.Mar_Prem_Usage) +
			convert(numeric(18,2),b.Apr_Prem_Usage) +
			convert(numeric(18,2),b.May_Prem_Usage) +
			convert(numeric(18,2),b.Jun_Prem_Usage) +
			convert(numeric(18,2),b.Jul_Prem_Usage) +
			convert(numeric(18,2),b.Aug_Prem_Usage) +
			convert(numeric(18,2),b.Sep_Prem_Usage) +
			convert(numeric(18,2),b.Oct_Prem_Usage) +
			convert(numeric(18,2),b.Nov_Prem_Usage) +
			convert(numeric(18,2),b.Dec_Prem_Usage) 
		) AccountTotalUsage
	from dbo.VIPMARKET_SG_ELG_PREMISE b where account_number = VIPMARKET_SG_ELG_PREMISE.Account_Number
) Volume, DivisionRegion
from dbo.VIPMARKET_SG_ELG_PREMISE 
inner join VIPMARKET_SG_Pricing pricing on pricing.VIPMARKET_SG_Pricing_ID = VIPMARKET_SG_ELG_PREMISE.selectedrow
INNER JOIN Enrollment.v_VIPMarket_SG_GetPricing_Vertical pricingVertical ON pricingVertical.VIPMARKET_SG_Pricing_ID = pricing.VIPMARKET_SG_Pricing_ID
																		AND pricingVertical.PriceOption = VIPMARKET_SG_ELG_PREMISE.PriceOption

WHERE status = 'Sale Accepted' 
and Service_State = @State
--	AND Service_State IN ('NE') -- 2017-04-06 - Turn off Nebraska until open enrollment for them
and userid in
(
	Select distinct userroles.userid 
	from userroles inner join users on users.UserID = userroles.UserID 
	where roleid in 
	(
		Select roleid from roles where RoleName like '%' + @UserGroup + '%'
	)
	--union
	--Select userid from users where issuperuser = 1 and userid = 6
	 --will send to larry garner
)
----and VIPMARKET_SG_ELG_PREMISE.account_number NOT IN
----(
----	Select account_Number from
----	(
----		Select pricing.account_number  from dbo.VIPMARKET_SG_ELG_PREMISE 
----		inner join VIPMARKET_SG_Pricing pricing on pricing.VIPMARKET_SG_Pricing_ID = VIPMARKET_SG_ELG_PREMISE.selectedrow
----		where status = 'Sale Accepted' and priceoption in('Blended')
----		and pricing.Blendcode = '00000'
----		union
----		Select pricing.account_number  from dbo.VIPMARKET_SG_ELG_PREMISE 
----		inner join VIPMARKET_SG_Pricing pricing on pricing.VIPMARKET_SG_Pricing_ID = VIPMARKET_SG_ELG_PREMISE.selectedrow
----		where status = 'Sale Accepted' and priceoption in('Blended2')
----		and pricing.Blendcode2 = '00000'
----	) a
----)

order by Telephone

GO
