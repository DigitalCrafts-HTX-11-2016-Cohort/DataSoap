

create procedure dbo.DeleteVendor

@VendorId int

as

delete
from dbo.Vendors
where  VendorId = @VendorId


GO
