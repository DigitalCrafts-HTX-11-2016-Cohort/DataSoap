-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_VIP_Billing_CNG_ProcessEBill]	
AS
Select *,
isnull(
(
	Select count(*) from dbo.VIP_UtilityPipeLineBTUFactor where VIP_UtilityPipelineID in
	(
		Select VIP_UtilityPipelineID from VIP_Meters where VIP_MeterID = a.MeterID
	) and (Startdate <= a.FromDate and EndDate >= a.FromDate)
),0) BTU
 from 
(
	Select VIPMARKET_CNG_EBill_ID,
	Accountno,
	dbo.VIPMARKET_CNG_EBill.MeterNo,
	isnull(
	(Select vip_accountid from VIP_Accounts where UtilityAccountNumber = dbo.VIPMARKET_CNG_EBill.AccountNo),
	 0) VIP_Accountid,
	 isnull(
	(Select vip_meterid from VIP_Meters where MeterNumber = dbo.VIPMARKET_CNG_EBill.MeterNo),
	0) MeterID,
	2 UsageType,
	newid() InteractionGuid,
	FromDate,
	ToDate,
	PreviousReading, CurrentReading, 
	BilledUsage, 'DEKATHERMS' UOM, ImportFileName
	 from dbo.VIPMARKET_CNG_EBill 
	where status = 'Loaded' 	
) a
GO
