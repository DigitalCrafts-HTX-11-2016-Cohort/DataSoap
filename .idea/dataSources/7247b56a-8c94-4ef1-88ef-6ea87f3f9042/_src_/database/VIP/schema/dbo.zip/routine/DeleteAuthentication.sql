
CREATE PROCEDURE dbo.DeleteAuthentication
	@AuthenticationID int
AS
	DELETE 
		FROM   Authentication
		WHERE AuthenticationID = @AuthenticationID
GO
