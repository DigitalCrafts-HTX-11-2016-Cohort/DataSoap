
CREATE PROCEDURE dbo.[UpdateUserRole] 
    @UserRoleId int, 
	@EffectiveDate	datetime = null,
	@ExpiryDate		datetime = null
AS

UPDATE dbo.UserRoles 
	SET ExpiryDate = @ExpiryDate,
		EffectiveDate = @EffectiveDate	
	WHERE  UserRoleId = @UserRoleId

GO
