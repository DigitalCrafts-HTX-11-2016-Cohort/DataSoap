
/*
	-- BGE - 2012-04-05 Update to allow for sequence field on invoice items
	2014-01-03 - BPanjavan - Took out THIS line: AND ServiceFeeType = 'DAILY', not all service fees are DAILY, ex: Fixed Bill
	2014-07-21 - BPanjavan - Changes for Adjustments
	2016-08-24 - BPanjavan - Adjustments can have multiple breakdowns, group by AdjustmentID
	2016-11-06 - BPanjavan - Added UOM Distinction to distinct Gas Sales from Electricity Sales, Add Electricity Sales
*/
CREATE PROCEDURE [dbo].[usp_VIP_Billing_CalculateInvoiceItems]
	@VIP_InvoiceID int
AS

BEGIN TRAN
------------
-- [Gas Sales]
INSERT INTO VIP_InvoiceItems
SELECT (Select top 1 vip_invoiceitemtypeid from vip_invoiceitemtypes where invoiceitemtype = 'Gas Sales') GasSales
, VIP_InvoiceID, VIP_AccountID, i.VIP_ProductID, VIP_UsageID, 
SUM(AdjustedUsageAmount) Amount, 
--SUM(CommodityTotal) / SUM(AdjustedUsageAmount) AdjustedCommodityPrice, 
--SUM(CommodityTotal) / case when SUM(AdjustedUsageAmount) = 0 then 1 else SUM(AdjustedUsageAmount) end AdjustedCommodityPrice, 
convert(numeric(18,2),SUM(CommodityTotal) / case when SUM(AdjustedUsageAmount) = 0 then 1 else SUM(AdjustedUsageAmount) end) AdjustedCommodityPrice, 
SUM(CommodityTotal) Total, ProductUOM,
	(SELECT MIN(UsageStartDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID /*AND i.AdjustedCommodityPrice = AdjustedCommodityPrice*/) PeriodStartDate,
	(SELECT MAX(UsageDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID /*AND i.AdjustedCommodityPrice = AdjustedCommodityPrice*/) PeriodEndDate,
	(SELECT MIN(StartUsage) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID),
	(SELECT MAX(EndUsage) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID),
	i.ChargeGroup_InvoiceItemText,0, 0, null
FROM VIP_InvoiceBreakdowns i INNER JOIN dbo.VIP_Products p ON p.VIP_ProductID = i.VIP_ProductID INNER JOIN dbo.VIP_UnitsOfMeasure uom ON uom.VIP_UnitOfMeasureID = p.VIP_UnitOfMeasureID
WHERE VIP_InvoiceID = @VIP_InvoiceID and EndUsage is null and SwingTolerance in('M','L','A','B')
	AND i.VIP_AdjustmentID IS NULL
	AND uom.Code IN ('THERMS','DEKATHERMS','CCF','MCF') 
GROUP BY VIP_InvoiceID, VIP_UsageID, VIP_AccountID, i.VIP_ProductID, ProductUOM, i.ChargeGroup_InvoiceItemText

-- [Gas Sales Swing Tolerance (Deficient)]
INSERT INTO VIP_InvoiceItems
SELECT (Select top 1 vip_invoiceitemtypeid from vip_invoiceitemtypes where invoiceitemtype = 'Gas Sales (Deficient Usage)')
, VIP_InvoiceID, VIP_AccountID, VIP_ProductID, VIP_UsageID, SUM(AdjustedIntolerantUsageAmount) Amount, 
SUM(IntoleranceCommodityTotal) / case when SUM(AdjustedIntolerantUsageAmount) = 0 then 1 else SUM(AdjustedIntolerantUsageAmount) end AdjustedIntolerantCommodityPrice, 
SUM(IntoleranceCommodityTotal) Total, ProductUOM,
	(SELECT MIN(UsageStartDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID /*AND i.AdjustedIntolerantCommodityPrice = AdjustedIntolerantCommodityPrice*/) PeriodStartDate,
	(SELECT MAX(UsageDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID /*AND i.AdjustedIntolerantCommodityPrice = AdjustedIntolerantCommodityPrice*/) PeriodEndDate,
	(SELECT MIN(StartUsage) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID),
	(SELECT MAX(EndUsage) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID),
	i.ChargeGroup_InvoiceItemText,0, 0, null
FROM VIP_InvoiceBreakdowns i
WHERE VIP_InvoiceID = @VIP_InvoiceID and EndUsage is null and SwingTolerance IN('L','A')
	AND i.VIP_AdjustmentID IS NULL
--GROUP BY VIP_InvoiceID, VIP_UsageID, VIP_AccountID, VIP_ProductID, AdjustedIntolerantCommodityPrice, ProductUOM
GROUP BY VIP_InvoiceID, VIP_UsageID, VIP_AccountID, VIP_ProductID, ProductUOM, i.ChargeGroup_InvoiceItemText
HAVING SUM(AdjustedIntolerantUsageAmount) <> 0


-- [Gas Sales Swing Tolerance (Excess)]
INSERT INTO VIP_InvoiceItems
SELECT (Select top 1 vip_invoiceitemtypeid from vip_invoiceitemtypes where invoiceitemtype = 'Gas Sales (Excess Usage)')
, VIP_InvoiceID, VIP_AccountID, VIP_ProductID, VIP_UsageID, SUM(AdjustedIntolerantUsageAmount) Amount, 
SUM(IntoleranceCommodityTotal) / case when SUM(AdjustedIntolerantUsageAmount) = 0 then 1 else SUM(AdjustedIntolerantUsageAmount) end AdjustedIntolerantCommodityPrice, 
SUM(IntoleranceCommodityTotal) Total, ProductUOM,
	(SELECT MIN(UsageStartDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID /*AND i.AdjustedIntolerantCommodityPrice = AdjustedIntolerantCommodityPrice*/) PeriodStartDate,
	(SELECT MAX(UsageDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID /*AND i.AdjustedIntolerantCommodityPrice = AdjustedIntolerantCommodityPrice*/) PeriodEndDate,
	(SELECT MIN(StartUsage) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID),
	(SELECT MAX(EndUsage) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID),
	i.ChargeGroup_InvoiceItemText,0, 0, null
FROM VIP_InvoiceBreakdowns i
WHERE VIP_InvoiceID = @VIP_InvoiceID and EndUsage is null and SwingTolerance IN('H','B')
AND i.VIP_AdjustmentID IS NULL
--GROUP BY VIP_InvoiceID, VIP_UsageID, VIP_AccountID, VIP_ProductID, AdjustedIntolerantCommodityPrice, ProductUOM
GROUP BY VIP_InvoiceID, VIP_UsageID, VIP_AccountID, VIP_ProductID, ProductUOM, i.ChargeGroup_InvoiceItemText
HAVING SUM(AdjustedIntolerantUsageAmount) <> 0

--[FUEL]
INSERT INTO VIP_InvoiceItems
SELECT (Select top 1 vip_invoiceitemtypeid from vip_invoiceitemtypes where invoiceitemtype = 'Utility Fuel') Fuel
, VIP_InvoiceID, VIP_AccountID, VIP_ProductID, VIP_UsageID, 
SUM(AdjustedFuelAmount) Amount, 
SUM(FuelTotal) / SUM(AdjustedFuelAmount) as AdjustedCommodityPrice, 
SUM(FuelTotal) Total, ProductUOM,
	(SELECT MIN(UsageStartDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID /*AND AdjustedCommodityPrice = i.AdjustedCommodityPrice*/) PeriodStartDate,
	(SELECT MAX(UsageDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID /*AND AdjustedCommodityPrice = i.AdjustedCommodityPrice*/) PeriodEndDate,
	0,
	0,
	i.ChargeGroup_InvoiceItemText,0,0, null
FROM VIP_InvoiceBreakdowns i
WHERE VIP_InvoiceID = @VIP_InvoiceID and EndUsage is null and SwingTolerance IN('M','L','A','B')
AND i.VIP_AdjustmentID IS NULL
GROUP BY VIP_InvoiceID, VIP_UsageID, VIP_AccountID, VIP_ProductID, ProductUOM, i.ChargeGroup_InvoiceItemText
HAVING SUM(FuelAmount) <> 0

--INSERT INTO VIP_InvoiceItems
--SELECT (Select top 1 vip_invoiceitemtypeid from vip_invoiceitemtypes where invoiceitemtype = 'Utility Fuel')
--, VIP_InvoiceID, VIP_AccountID, VIP_ProductID, VIP_UsageID, SUM(AdjustedFuelAmount) Amount, AdjustedCommodityPrice, SUM(FuelTotal)Total, ProductUOM,
--	(SELECT MIN(UsageStartDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID AND AdjustedCommodityPrice = i.AdjustedCommodityPrice) PeriodStartDate,
--	(SELECT MAX(UsageDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID AND AdjustedCommodityPrice = i.AdjustedCommodityPrice) PeriodEndDate,
--	0,
--	0,
--	null,0,0
--FROM VIP_InvoiceBreakdowns i
--WHERE VIP_InvoiceID = @VIP_InvoiceID and EndUsage is null and SwingTolerance IN('L','A','B')
--GROUP BY VIP_InvoiceID, VIP_UsageID, VIP_AccountID, VIP_ProductID, AdjustedCommodityPrice, ProductUOM
--HAVING SUM(FuelAmount) <> 0

--[SWING FUEL CHARGES]
INSERT INTO VIP_InvoiceItems
SELECT (Select top 1 vip_invoiceitemtypeid from vip_invoiceitemtypes where invoiceitemtype = 'Utility Fuel (Deficient)')
, VIP_InvoiceID, VIP_AccountID, VIP_ProductID, VIP_UsageID, SUM(IntoleranceFuelAmount) Amount, 
SUM(IntoleranceFuelTotal) / SUM(IntoleranceFuelAmount) AdjustedIntolerantCommodityPrice, 
SUM(IntoleranceFuelTotal) Total, ProductUOM,
	(SELECT MIN(UsageStartDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID /*AND AdjustedIntolerantCommodityPrice = i.AdjustedIntolerantCommodityPrice*/) PeriodStartDate,
	(SELECT MAX(UsageDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID /*AND AdjustedIntolerantCommodityPrice = i.AdjustedIntolerantCommodityPrice*/) PeriodEndDate,
	0,
	0,
	i.ChargeGroup_InvoiceItemText,0,0, null
FROM VIP_InvoiceBreakdowns i 
WHERE VIP_InvoiceID = @VIP_InvoiceID and EndUsage is null and SwingTolerance IN('L','A')
AND i.VIP_AdjustmentID IS NULL
--GROUP BY VIP_InvoiceID, VIP_UsageID, VIP_AccountID, VIP_ProductID, AdjustedIntolerantCommodityPrice, ProductUOM
GROUP BY VIP_InvoiceID, VIP_UsageID, VIP_AccountID, VIP_ProductID, ProductUOM, i.ChargeGroup_InvoiceItemText
HAVING SUM(IntoleranceFuelAmount) <> 0

--[SWING FUEL EXCESS]
INSERT INTO VIP_InvoiceItems
SELECT (Select top 1 vip_invoiceitemtypeid from vip_invoiceitemtypes where invoiceitemtype = 'Utility Fuel (Excess Usage)')
, VIP_InvoiceID, VIP_AccountID, VIP_ProductID, VIP_UsageID, SUM(IntoleranceFuelAmount) Amount, 
SUM(IntoleranceFuelTotal) / SUM(IntoleranceFuelAmount) AdjustedIntolerantCommodityPrice, 
SUM(IntoleranceFuelTotal) Total, ProductUOM,
	(SELECT MIN(UsageStartDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID /*AND AdjustedIntolerantCommodityPrice = i.AdjustedIntolerantCommodityPrice*/) PeriodStartDate,
	(SELECT MAX(UsageDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID /*AND AdjustedIntolerantCommodityPrice = i.AdjustedIntolerantCommodityPrice*/) PeriodEndDate,
	0,
	0,
	i.ChargeGroup_InvoiceItemText,0,0, null
FROM VIP_InvoiceBreakdowns i 
WHERE VIP_InvoiceID = @VIP_InvoiceID and EndUsage is null and SwingTolerance IN('H','B')
AND i.VIP_AdjustmentID IS NULL
--GROUP BY VIP_InvoiceID, VIP_UsageID, VIP_AccountID, VIP_ProductID, AdjustedIntolerantCommodityPrice, ProductUOM
GROUP BY VIP_InvoiceID, VIP_UsageID, VIP_AccountID, VIP_ProductID, ProductUOM, i.ChargeGroup_InvoiceItemText
HAVING SUM(IntoleranceFuelAmount) <> 0

-- [Transportation]
INSERT INTO VIP_InvoiceItems
SELECT 6, VIP_InvoiceID, VIP_AccountID, VIP_ProductID, VIP_UsageID, SUM(AdjustedTransportAmount) Amount, 
case when TransportAllocRate > 0 then TransportAllocRate else AdjustedCommodityPrice end as AdjustedCommodityPrice, 
SUM(TransportTotal) Total, ProductUOM,
	(SELECT MIN(UsageStartDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID AND i.AdjustedCommodityPrice = AdjustedCommodityPrice) PeriodStartDate,
	(SELECT MAX(UsageDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID AND i.AdjustedCommodityPrice = AdjustedCommodityPrice) PeriodEndDate,
	0,
	0,
	i.ChargeGroup_InvoiceItemText,0,0, null
FROM VIP_InvoiceBreakdowns i
WHERE VIP_InvoiceID = @VIP_InvoiceID and EndUsage is null
AND i.VIP_AdjustmentID IS NULL
GROUP BY VIP_InvoiceID, VIP_UsageID, VIP_AccountID, VIP_ProductID, AdjustedCommodityPrice,TransportAllocRate, ProductUOM, i.ChargeGroup_InvoiceItemText
HAVING SUM(TransportTotal) <> 0

-- [Electricity Sales]
INSERT INTO VIP_InvoiceItems
SELECT (Select top 1 vip_invoiceitemtypeid from vip_invoiceitemtypes where invoiceitemtype = 'Electricity Sales') ElectricitySales
, VIP_InvoiceID, VIP_AccountID, i.VIP_ProductID, VIP_UsageID, 
SUM(AdjustedUsageAmount) Amount, 
--SUM(CommodityTotal) / SUM(AdjustedUsageAmount) AdjustedCommodityPrice, 
--SUM(CommodityTotal) / case when SUM(AdjustedUsageAmount) = 0 then 1 else SUM(AdjustedUsageAmount) end AdjustedCommodityPrice, 
convert(numeric(18,2),SUM(CommodityTotal) / case when SUM(AdjustedUsageAmount) = 0 then 1 else SUM(AdjustedUsageAmount) end) AdjustedCommodityPrice, 
SUM(CommodityTotal) Total, ProductUOM,
	(SELECT MIN(UsageStartDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID /*AND i.AdjustedCommodityPrice = AdjustedCommodityPrice*/) PeriodStartDate,
	(SELECT MAX(UsageDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID /*AND i.AdjustedCommodityPrice = AdjustedCommodityPrice*/) PeriodEndDate,
	(SELECT MIN(StartUsage) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID),
	(SELECT MAX(EndUsage) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID),
	i.ChargeGroup_InvoiceItemText,0, 0, null
FROM VIP_InvoiceBreakdowns i INNER JOIN dbo.VIP_Products p ON p.VIP_ProductID = i.VIP_ProductID INNER JOIN dbo.VIP_UnitsOfMeasure uom ON uom.VIP_UnitOfMeasureID = p.VIP_UnitOfMeasureID
WHERE VIP_InvoiceID = @VIP_InvoiceID and EndUsage is null
	AND i.VIP_AdjustmentID IS NULL
	AND uom.Code IN ('kWh') 
GROUP BY VIP_InvoiceID, VIP_UsageID, VIP_AccountID, i.VIP_ProductID, ProductUOM, i.ChargeGroup_InvoiceItemText

--[Service Fee]
DECLARE @invoiceItemTypeServiceFee INT
SET @invoiceItemTypeServiceFee = (SELECT VIP_InvoiceItemTypeID FROM dbo.VIP_InvoiceItemTypes WHERE InvoiceItemType = 'Service Fee')

INSERT INTO VIP_InvoiceItems
SELECT @invoiceItemTypeServiceFee, VIP_InvoiceID, VIP_AccountID, VIP_ProductID, VIP_UsageID, COUNT(ServiceFee) Amount, ServiceFee, SUM(ServiceFee) Total, ProductUOM,
	(SELECT MIN(UsageStartDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID) PeriodStartDate,
	(SELECT MAX(UsageDate) FROM VIP_Invoicebreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID AND VIP_ProductID = i.VIP_ProductID) PeriodEndDate,
	0,
	0,
	null,0,0, null
FROM VIP_InvoiceBreakdowns i
WHERE VIP_InvoiceID = @VIP_InvoiceID
--	AND ServiceFeeType = 'DAILY' 
	and EndUsage is null
AND i.VIP_AdjustmentID IS NULL
GROUP BY VIP_InvoiceID, VIP_UsageID, VIP_AccountID, VIP_ProductID, ServiceFee, ProductUOM, i.ChargeGroup_InvoiceItemText
HAVING SUM(ServiceFee) <> 0

-- 2014-07-21 - Get all Adjustments tied to this invoice
--[ADJUSTMENTS]
------------------------------------------------------------
-- All adjustments belong on their own invoice line
-- Use a temp-table first, since we need to upadte the adjustment with the invoice Item ID
SELECT 
	vipAdjustmentType.VIP_InvoiceItemTypeID -- TODO: Depending on teh a
	, VIP_InvoiceID, i.VIP_AccountID, VIP_ProductID, VIP_UsageID, vipAdjustment.Quantity, vipAdjustment.Price, vipAdjustment.Amount, ProductUOM,
	PeriodStartDate = ISNULL(vipAdjustment.StartDate_Inclusive, vipAdjustment.EffectiveDate), PeriodEndDate = ISNULL(vipAdjustment.EndDate_Inclusive, vipAdjustment.EffectiveDate), StartUsage = 0, EndUsage = 0, ItemText = vipAdjustment.Description_ThatWillAppearOnInvoice, AddedItem = 0, Tax = 0, Sequence = 99 -- Maximize the sequence so it appears last
	,VIP_AdjustmentID = i.VIP_AdjustmentID
	INTO #tblInvoiceItem_WithAdjustmentID
FROM VIP_InvoiceBreakdowns i
	INNER JOIN dbo.VIP_Adjustment vipAdjustment ON i.VIP_AdjustmentID = vipAdjustment.VIP_AdjustmentID
	INNER JOIN dbo.VIP_AdjustmentType vipAdjustmentType ON vipAdjustment.VIP_AdjustmentTypeID = vipAdjustmentType.VIP_AdjustmentTypeID
WHERE VIP_InvoiceID = @VIP_InvoiceID
--- 2016-08-24 - BPanjavan - Adjustments can have multiple breakdowns, group by AdjustmentID
GROUP BY 	vipAdjustmentType.VIP_InvoiceItemTypeID -- TODO: Depending on teh a
	, VIP_InvoiceID, i.VIP_AccountID, VIP_ProductID, VIP_UsageID, vipAdjustment.Quantity, vipAdjustment.Price, vipAdjustment.Amount, ProductUOM,
	ISNULL(vipAdjustment.StartDate_Inclusive, vipAdjustment.EffectiveDate), ISNULL(vipAdjustment.EndDate_Inclusive, vipAdjustment.EffectiveDate), vipAdjustment.Description_ThatWillAppearOnInvoice
	,i.VIP_AdjustmentID

-- 2014-07-22 - BPanjavan - Bascially I have to do the loop beacuse I need to update teh VIP_Adjustment with the new Invoice Item ID that's created on the invoice.  If you've got a better way, go to town!
DECLARE @intCount INT
DECLARE @intCurrentAdjustmentID INT
DECLARE @intNewInvoiceItemID INT
SET @intCount = (SELECT COUNT(1) FROM #tblInvoiceItem_WithAdjustmentID)
WHILE (@intCount > 0)
BEGIN
	SET @intCurrentAdjustmentID = (SELECT TOP 1 VIP_AdjustmentID FROM #tblInvoiceItem_WithAdjustmentID)

	INSERT INTO VIP_InvoiceItems
		SELECT VIP_InvoiceItemTypeID, VIP_InvoiceID, VIP_AccountID, VIP_ProductID, VIP_UsageID, Quantity, Price, Amount, ProductUOM, PeriodStartDate, PeriodEndDate
				, StartUsage, EndUsage, ItemText, AddedItem, Tax, Sequence FROM #tblInvoiceItem_WithAdjustmentID
				WHERE VIP_AdjustmentID = @intCurrentAdjustmentID

	SET @intNewInvoiceItemID = (SELECT SCOPE_IDENTITY())

	UPDATE VIP_Adjustment SET VIP_InvoiceItemID = @intNewInvoiceItemID WHERE VIP_AdjustmentID = @intCurrentAdjustmentID

	DELETE FROM #tblInvoiceItem_WithAdjustmentID WHERE VIP_AdjustmentID = @intCurrentAdjustmentID

	SET @intCount = (SELECT COUNT(1) FROM #tblInvoiceItem_WithAdjustmentID)
END

-- Finally Commit All
---------------
COMMIT
---- Actually now go back and remove items we shouldnt have put in 

---- Get AccountID
----- Uncomment and commit once ready for the PGE Invoice Manipulation
--DECLARE @vip_accountid INT
--SET @vip_accountid = (SELECT DISTINCT bpa.vip_accountid FROM dbo.VIP_Invoices i LEFT JOIN dbo.VIP_BillingPointAccounts bpa ON bpa.VIP_BillingPointID = i.VIP_BillingPointID WHERE i.VIP_InvoiceID = @VIP_InvoiceID)



---- See if its in the Exception Table

--IF EXISTS ( SELECT  *
--            FROM    dbo.InvoiceItem_To_Remove_Exceptions
--            WHERE   vip_accountid = @vip_accountid
--                    AND status = 'Loaded' )
--    BEGIN

--	--Remove the invoice items in question and set the itemtype table item to complete
--        BEGIN TRAN;
--        DECLARE @InvoiceItemToDelete TABLE
--            (
--              VIP_InvoiceItemType_ToRemove VARCHAR(100),
--			  InvoiceItem_To_Remove_ExceptionsID int
--            );
--        INSERT  INTO @InvoiceItemToDelete
--                SELECT  VIP_InvoiceItemType_ToRemove,InvoiceItem_To_Remove_ExceptionsID
--                FROM    InvoiceItem_To_Remove_Exceptions
--                WHERE   vip_accountID = @vip_accountid
--                        AND status = 'Loaded';
--        DELETE  FROM dbo.VIP_InvoiceItems
--        WHERE   VIP_InvoiceID = @Invoice_ID
--                AND VIP_InvoiceItemTypeID IN ( SELECT   VIP_InvoiceItemType_ToRemove                                                 
--                                               FROM     @InvoiceItemToDelete );
				 


--		UPDATE InvoiceItem_To_Remove_Exceptions SET status = 'Complete' WHERE InvoiceItem_To_Remove_ExceptionsID IN(SELECT InvoiceItem_To_Remove_ExceptionsID FROM @InvoiceItemToDelete)



--        COMMIT;
--END;	


GO
