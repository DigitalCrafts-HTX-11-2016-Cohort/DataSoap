
create procedure dbo.GetUrl

@PortalID     int,
@Url          nvarchar(255)

as

select *
from   dbo.Urls
where  PortalID = @PortalID
and    Url = @Url


GO
