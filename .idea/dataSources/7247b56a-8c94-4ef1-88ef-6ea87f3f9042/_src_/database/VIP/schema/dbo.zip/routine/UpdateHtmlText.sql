

create procedure dbo.UpdateHtmlText

	@ModuleId       int,
	@DesktopHtml    ntext,
	@DesktopSummary ntext,
	@UserID         int

as

update HtmlText
set    DesktopHtml    = @DesktopHtml,
       DesktopSummary = @DesktopSummary,
       CreatedByUser  = @UserID,
       CreatedDate    = getdate()
where  ModuleId = @ModuleId

GO
