
CREATE PROCEDURE dbo.[AddSearchItemWord]
	@SearchItemID int,
	@SearchWordsID int,
	@Occurrences int

AS

DECLARE @id int
SELECT @id = SearchItemWordID 
	FROM dbo.SearchItemWord
	WHERE SearchItemID=@SearchItemID 
		AND SearchWordsID=@SearchWordsID
 

IF @id IS NULL
	BEGIN
		INSERT INTO dbo.SearchItemWord (
			[SearchItemID],
			[SearchWordsID],
			[Occurrences]
			) 
		VALUES (
			@SearchItemID,
			@SearchWordsID,
			@Occurrences
			)

		SELECT SCOPE_IDENTITY()
	END
ELSE

	UPDATE dbo.SearchItemWord 
		SET Occurrences = @Occurrences 
		WHERE SearchItemWordID=@id 
			AND Occurrences<>@Occurrences

SELECT @id


GO
