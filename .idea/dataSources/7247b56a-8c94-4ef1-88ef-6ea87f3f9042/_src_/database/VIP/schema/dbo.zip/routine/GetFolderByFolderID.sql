
CREATE PROCEDURE dbo.GetFolderByFolderID
	@PortalID int,
	@FolderID int
AS
SELECT *
	FROM dbo.Folders
	WHERE ((PortalID = @PortalID) or (PortalID is null and @PortalID is null))
		AND (FolderID = @FolderID)

GO
