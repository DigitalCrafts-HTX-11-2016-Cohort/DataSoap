
CREATE PROCEDURE dbo.UpdatePropertyDefinition

	@PropertyDefinitionId int,
	@DataType int,
	@DefaultValue nvarchar(50),
	@PropertyCategory nvarchar(50),
	@PropertyName nvarchar(50),
	@Required bit,
	@ValidationExpression nvarchar(100),
	@ViewOrder int,
	@Visible bit,
    @Length int

AS
	UPDATE dbo.ProfilePropertyDefinition 
		SET DataType = @DataType,
			DefaultValue = @DefaultValue,
			PropertyCategory = @PropertyCategory,
			PropertyName = @PropertyName,
			Required = @Required,
			ValidationExpression = @ValidationExpression,
			ViewOrder = @ViewOrder,
			Visible = @Visible,
			Length = @Length
		WHERE PropertyDefinitionId = @PropertyDefinitionId
GO
