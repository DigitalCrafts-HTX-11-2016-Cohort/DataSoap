
CREATE PROCEDURE [dbo].[usp_VIPCheckIfMeterExist] 	
	@UtilityID int, @MeterNumber varchar(20), @AcctID int
AS
BEGIN
	
--SET NOCOUNT ON;    
	Select a.Code, b.VIP_UtilityID, c.MeterNumber, c.VIP_MeterID from dbo.VIP_Utilities a
	inner join dbo.VIP_Accounts b on b.VIP_UtilityID = a.VIP_UtilityID
	inner join dbo.VIP_Meters c on c.VIP_AccountID =  b.VIP_AccountID
	where a.VIP_UtilityID = @UtilityID and 
	c.MeterNumber = @MeterNumber and
	b.VIP_AccountID = @AcctID
	
	--and c.EndDate is null

END
GO
