-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE usp_VIP_PGE_Load_Billing_UpdateDuplicateRecs
	@Temp bit
AS

if @Temp = 1
begin
	UPDATE VIPMARKET_PGE_Billing_Temp SET status = 'Duplicate'
	where VIP_ESPBillingID in
	(
		Select VIP_ESPBillingID from 
		(
			SELECT 
			Bill_Dt,
			 Acct_ID,
			 DA_XREF,
			 Parent_SAID,
			 SAID,
			 Rate_Schedule_Code,
			 ESP_Rate_Schedule,
			 Bseg_ID,
			 Bill_From_Dt,
			 Bill_To_Dt,
			 Usage,
			 Energy_Amt,
			max(VIP_ESPBillingID) VIP_ESPBillingID,
			COUNT(*) TotalCount
			FROM VIPMARKET_PGE_Billing_Temp
			where status = 'Pending'
			GROUP BY Bill_Dt,
			 Acct_ID,
			 DA_XREF,
			 Parent_SAID,
			 SAID,
			 Rate_Schedule_Code,
			 ESP_Rate_Schedule,
			 Bseg_ID,
			 Bill_From_Dt,
			 Bill_To_Dt,
			 Usage,
			 Energy_Amt 
			HAVING COUNT(*) > 1
			--ORDER BY COUNT(*) DESC 
		) a
	)
end
else
begin
	UPDATE VIPMARKET_PGE_Billing SET status = 'Duplicate'
	where VIP_ESPBillingID in
	(
		Select VIP_ESPBillingID from 
		(
			SELECT 
			Bill_Dt,
			 Acct_ID,
			 DA_XREF,
			 Parent_SAID,
			 SAID,
			 Rate_Schedule_Code,
			 ESP_Rate_Schedule,
			 Bseg_ID,
			 Bill_From_Dt,
			 Bill_To_Dt,
			 Usage,
			 Energy_Amt,
			max(VIP_ESPBillingID) VIP_ESPBillingID,
			COUNT(*) TotalCount
			FROM VIP_VIPMARKET_PGE_BillingView
			where status = 'Pending'
			GROUP BY Bill_Dt,
			 Acct_ID,
			 DA_XREF,
			 Parent_SAID,
			 SAID,
			 Rate_Schedule_Code,
			 ESP_Rate_Schedule,
			 Bseg_ID,
			 Bill_From_Dt,
			 Bill_To_Dt,
			 Usage,
			 Energy_Amt 
			HAVING COUNT(*) > 1
			--ORDER BY COUNT(*) DESC 
		) a
	)
end
GO
