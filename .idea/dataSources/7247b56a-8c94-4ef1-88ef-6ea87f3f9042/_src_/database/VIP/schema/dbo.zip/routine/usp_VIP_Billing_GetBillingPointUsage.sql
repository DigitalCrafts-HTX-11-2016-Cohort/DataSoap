
/*
 - 2013-10-22 - BPanjavan - Change to accomodate re-invoicing
*/
CREATE PROCEDURE [dbo].[usp_VIP_Billing_GetBillingPointUsage]
@VIP_AccountID int
,@areWeReInvoicing bit = 0
AS

--DECLARE @VIP_AccountID int
--SET @VIP_AccountID = 43627


;WITH tblInvoiceItemInvoice AS
	(
		SELECT
			ii.*
			,inv.[Status]
		FROM
			VIP_InvoiceItems ii
			INNER JOIN VIP_Invoices inv ON ii.VIP_InvoiceID = inv.VIP_InvoiceID  
	)
SELECT DISTINCT u.VIP_UsageID, u.FuelAmount, u.TransportAmount
FROM VIP_Usage u
	INNER JOIN VIP_UsageTypes ut ON u.VIP_UsageTypeID = ut.VIP_UsageTypeID
	LEFT JOIN tblInvoiceItemInvoice invI ON invI.VIP_UsageID = u.VIP_UsageID
			AND invI.[Status] NOT IN ('Voided')
WHERE ut.Code IN ('ACTUAL', 'ESTIMATED', 'CANCELLED')
	AND u.VIP_AccountID = @VIP_AccountID
	AND invI.VIP_UsageID IS NULL	-- Does NOT have a non-voided invoice on it
--	AND u.VIP_UsageID NOT IN (SELECT VIP_UsageID FROM VIP_InvoiceItems WHERE VIP_UsageID IS NOT NULL)

	AND 
		(
			(
				@areWeReInvoicing = 0
				AND  U.Status not in('Review','Email','ReInvoice')
			)
			OR
			(
				@areWeReInvoicing = 1
				AND  U.Status = 'ReInvoice'
			)
		)
--UNION

--SELECT u.VIP_UsageID, u.FuelAmount, u.TransportAmount
--FROM VIP_Usage u
--WHERE VIP_UsageID IN
--	(
--		ISNULL(
--			(
--			SELECT top 1 ii.VIP_UsageID
--			FROM VIP_Invoices i
--				INNER JOIN VIP_InvoiceItems ii ON i.VIP_InvoiceID = ii.VIP_InvoiceID
--			WHERE PrecorrectionStatus  in('Reinvoice','RegenerateInvoiceBreakDown') and ii.VIP_UsageID <> 0
--				AND ii.VIP_AccountID = @VIP_AccountID
--			GROUP BY ii.VIP_UsageID
--			),
--			(
--			Select top 1 vip_usageid 
--			from VIP_InvoiceBreakdowns 
--			where VIP_InvoiceID in
--				(Select VIP_InvoiceID from vip_invoices where PrecorrectionStatus  in('Reinvoice'))
--			))
			
--	)
--	AND u.VIP_AccountID = @VIP_AccountID


GO
