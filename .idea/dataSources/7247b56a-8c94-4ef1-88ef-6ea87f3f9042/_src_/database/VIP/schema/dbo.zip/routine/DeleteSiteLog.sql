
create procedure dbo.DeleteSiteLog

@DateTime                      datetime, 
@PortalID                      int

as

delete
from dbo.SiteLog
where  PortalId = @PortalID
and    DateTime < @DateTime


GO
