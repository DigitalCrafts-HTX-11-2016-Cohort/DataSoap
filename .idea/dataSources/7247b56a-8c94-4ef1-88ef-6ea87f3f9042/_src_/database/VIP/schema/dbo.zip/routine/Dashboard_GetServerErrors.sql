
CREATE procedure dbo.[Dashboard_GetServerErrors]
AS
	SELECT
		(SELECT COUNT(*) FROM dbo.[EventLog] WHERE LogTypeKey Like '%EXCEPTION' AND LogCreateDate > DateAdd(day, -1, GetDate())) As ErrorsDay,
		(SELECT COUNT(*) FROM dbo.[EventLog] WHERE LogTypeKey Like '%EXCEPTION' AND LogCreateDate > DateAdd(week, -1, GetDate())) As ErrorsWeek,
		(SELECT COUNT(*) FROM dbo.[EventLog] WHERE LogTypeKey Like '%EXCEPTION' AND LogCreateDate > DateAdd(month, -1, GetDate())) As ErrorsMonth,
		(SELECT COUNT(*) FROM dbo.[EventLog] WHERE LogTypeKey Like '%EXCEPTION' AND LogCreateDate > DateAdd(year, -1, GetDate())) As ErrorsYear

GO
