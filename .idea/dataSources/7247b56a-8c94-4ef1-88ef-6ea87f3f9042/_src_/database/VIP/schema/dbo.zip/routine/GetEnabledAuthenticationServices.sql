
CREATE PROCEDURE dbo.GetEnabledAuthenticationServices
AS
	SELECT *
		FROM   dbo.Authentication
		WHERE  IsEnabled = 1
GO
