CREATE VIEW dbo.VIP_InvoiceItemsView
AS
SELECT     *, '' Archived
FROM         VIP_InvoiceItems
UNION
SELECT     *, 'Archived' Archived
FROM         vip_archive..VIP_InvoiceItems
GO
