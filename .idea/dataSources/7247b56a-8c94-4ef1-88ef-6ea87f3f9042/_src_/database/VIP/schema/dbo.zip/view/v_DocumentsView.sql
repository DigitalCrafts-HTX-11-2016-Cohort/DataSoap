
CREATE VIEW dbo.v_DocumentsView
AS

SELECT  b.DisplayName ,
        a.CreationDate ,
        a.Name ,
        a.Version ,
        a.AssociatedObjectID ,
        '' TPV ,
		a.VIP_Document_TypeID
FROM    dbo.VIP_Documents a
        INNER JOIN dbo.VIP_Document_Types b ON b.VIP_Document_TypeID = a.VIP_Document_TypeID
UNION 
SELECT  doc.Reason AS DisplayName ,
        doc.CreatedOn ,
        doc.StoredFileName AS Name ,
        1.00 AS Version ,
        ai.VIP_AccountID AS AssociatedObjectID ,
        '' AS TPV ,
		'' AS VIP_Document_TypeID
FROM    Documents.StoredDocument doc
        INNER JOIN dbo.VIP_AccountInteractions ai ON doc.ExternalSourceType IN ( 'RenewalLetter_VIP_AccountInteractionID', 'WeclomeLetter_VIP_AccountInteractionID')
                                                     AND doc.ExternalReferenceNumber = ai.VIP_AccountInteractionID


GO
