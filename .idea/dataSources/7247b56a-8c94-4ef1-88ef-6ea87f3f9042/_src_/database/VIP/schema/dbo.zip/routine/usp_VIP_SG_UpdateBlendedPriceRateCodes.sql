



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_VIP_SG_UpdateBlendedPriceRateCodes]
	-- Add the parameters for the stored procedure here	
AS
BEGIN
	
	-- FOr some reason accounts saved in the portal have a userID of -1
	UPDATE dbo.VIPMARKET_SG_ELG_PREMISE
	SET UserID = 90
	WHERE UserID IN (-1,0) AND Control_Number <> ''

	-- Another quick-fix for SG, Pricing Tier's are coming up NULL and the process can't update accounts
	UPDATE dbo.VIPMARKET_SG_ELG_PREMISE
	SET PricingTier = 1
	WHERE PricingTier IS NULL AND [Status] <> ''
	
	declare @SelectedRow int
	declare @ServiceState varchar(3)
	declare @Region varchar(30)
	declare @FixedPrice1 numeric(18,5)
	declare @IndexPrice1 numeric(18,5)
	declare @FixedPrice2 numeric(18,5)
	declare @IndexPrice2 numeric(18,5)
	declare @PriceOption varchar(20)
	
	DECLARE db_cursor CURSOR FOR  	
	Select premise.PriceOption, premise.selectedrow, Service_State, DivisionRegion,
	left(FixedPriceRate,5) FixedPriceRate, left(IndexRate,5) IndexRate, 
	left(FixedPriceRate2,5) FixedPriceRate2 , left(IndexRate2,5) IndexRate2
	from VIPMARKET_SG_ELG_PREMISE premise
	inner join VIPMARKET_SG_Pricing pricing on pricing.VIPMARKET_SG_Pricing_ID = premise.selectedrow
	where priceoption in('Blended','Blended2') and status IN ('Sale Accepted', 'Pending Delegation Form')
	--and BlendCode = '00000'	
	
	OPEN db_cursor
	FETCH NEXT FROM db_cursor INTO @PriceOption, @SelectedRow, @ServiceState, @Region, @FixedPrice1, @IndexPrice1, @FixedPrice2, @IndexPrice2
	
	WHILE @@FETCH_STATUS = 0
	
	BEGIN
		
		DECLARE @RateCode as varchar(10)	
		DECLARE @Term int
		DECLARE @Fixed numeric(18,5)
		DECLARE @Index numeric(18,5)		
		DECLARE @StateRegion varchar(40)			
			
		
		IF @ServiceState = 'NE'
		BEGIN
			Select @Region = ''
			Select @StateRegion = @ServiceState			
		END
		else
		BEGIN
			Select @StateRegion = @ServiceState + '/' + @Region
		END
		
		if @PriceOption = 'Blended'
		begin
			Select @Fixed = @FixedPrice1
			Select @Index = @IndexPrice1
		end
		else
		begin
			Select @Fixed = @FixedPrice2
			Select @Index = @IndexPrice2
		end
		
	PRINT @StateRegion + ' Fixed Price = ' + convert(varchar(10),@Fixed) + ' Index Price = ' + convert(varchar(10),@Index)
		--DETERMINE IF THE FIXED/INDEX COMBINATION HAS BEEN USED
	if EXISTS(
			  Select Code from dbo.VIPMARKET_SG_PriceRateCode_BlendedCombination 
			  where FixedPrice = @Fixed and 
			  indexprice = @Index and 
			  Division = @StateRegion
			 )
		begin
			/*RETURN THE CODE*/
			Select @RateCode = 
				(
					Select Code from dbo.VIPMARKET_SG_PriceRateCode_BlendedCombination 
					where FixedPrice = @Fixed and 
					indexprice = @Index and 
					Division = @StateRegion
				)
				Print 'I got here '
		end
		
	else		
		begin
			if @PriceOption = 'Blended'
			begin
				Select @Term = 1
			end
			else
			begin
				Select @Term = 2
			end
			
			declare @MinRange int
			declare @MaxRange int
			declare @LastCode int
				
		    
			--SET THE MINIMUM AND MAXIMUM RANGE OF POSSIBLE BLENDED PRICE/INDEX COMBINATIONS
			Select @MinRange = (Select Range_From from dbo.VIPMARKET_SG_PriceRateCode_Range where State = @ServiceState and Term = @Term and State = @ServiceState and Region like '%' + @Region + '%')
			Select @MaxRange = (Select Range_To from dbo.VIPMARKET_SG_PriceRateCode_Range where State = @ServiceState and Term = @Term and State = @ServiceState and Region like '%' + @Region + '%')
	    
			--GET THE LAST RATE CODE AND INCREASE IT BY 1.  IF THERE IS NO RATE CODE THE SET THE DEFAULT TO THE MINIMUM RANGE SET IN THE RANGE TABLE
			Select @RateCode = 
			case when @PriceOption = 'Blended' then
				(  
					isnull
					(
						(							
							Select top 1 * from
							 (
								 Select convert(int,max(BlendCode)) + 1 Code from VIPMARKET_SG_Pricing where Account_Number in
								(
									Select Account_Number from VIPMARKET_SG_ELG_PREMISE 
									where Service_State = @ServiceState and DivisionRegion like '%' + @Region + '%'
								) and (convert(int,BlendCode) >= @MinRange and convert(int,BlendCode) <= @MaxRange)
								UNION				
								 Select convert(int, Code) + 1 Code from dbo.VIPMARKET_SG_PriceRateCode_BlendedCombination 
								 where Division = @StateRegion and (convert(int, Code) >= @MinRange and convert(int, Code) <= @MaxRange)
							 ) a order by a.Code desc
						)				
					, @MinRange
					)
				)
				when @PriceOption = 'Blended2' then
				(  
					isnull
					(
						(							
							Select top 1 * from
							 (
								 Select convert(int,max(BlendCode2)) + 1 Code from VIPMARKET_SG_Pricing where Account_Number in
								(
									Select Account_Number from VIPMARKET_SG_ELG_PREMISE 
									where Service_State = @ServiceState and DivisionRegion like '%' + @Region + '%'
								) and (convert(int,BlendCode2) >= @MinRange and convert(int,BlendCode2) <= @MaxRange)
								UNION				
								 Select convert(int, Code) + 1 Code from dbo.VIPMARKET_SG_PriceRateCode_BlendedCombination 
								 where Division = @StateRegion and (convert(int, Code) >= @MinRange and convert(int, Code) <= @MaxRange) 
							 ) a order by a.Code desc
						)				
					, @MinRange
					)
				) end
					
			print @RateCode + ' Testing ' 
												    
			INSERT INTO dbo.VIPMARKET_SG_PriceRateCode_BlendedCombination
			(Code, Division, FixedPrice, IndexPrice, Year)
			values
			(
			   @RateCode,
			   @StateRegion, 
			   @Fixed,
			   @Index,
			   year(getdate())	
			)								
		end	
		
		--UPDATE THE BLENDED CODE FOR THE ACCOUNT
		IF @PriceOption = 'Blended' 
		begin
			update VIPMARKET_SG_Pricing set BlendCode = @RateCode where VIPMARKET_SG_Pricing_ID = @SelectedRow
		end
		else
		begin	
			update VIPMARKET_SG_Pricing set BlendCode2 = @RateCode where VIPMARKET_SG_Pricing_ID = @SelectedRow
		end	
		
		FETCH NEXT FROM db_cursor INTO @PriceOption, @SelectedRow, @ServiceState, @Region, @FixedPrice1, @IndexPrice1, @FixedPrice2, @IndexPrice2
	END
	
	CLOSE db_cursor
	DEALLOCATE db_cursor
			
	
END
GO
