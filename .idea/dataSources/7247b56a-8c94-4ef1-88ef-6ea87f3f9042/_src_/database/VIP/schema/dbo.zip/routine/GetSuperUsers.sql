
CREATE procedure dbo.GetSuperUsers

as

select U.*,
       'PortalId' = -1,
       'FullName' = U.FirstName + ' ' + U.LastName
from   dbo.Users U
where  U.IsSuperUser = 1


GO
