
/*
	Author: Bryan Panjavan
	Description: Provide canonical view of Connecticut Daily Usage

	2012-07-23 - Initial creation - 
*/

CREATE VIEW [dbo].[VIPMARKET_CT_Daily_Canonical]
AS

WITH tblUsageDaily_CNG AS
(
	SELECT
		MarketTableUsageID		= usg.VIPMARKET_CNG_UsageID
		,UtilityAccountNumber	= usg.AccountNo
		,PodID					= usg.PopID
		,MeterNumber			= NULL

		,ReadDate				= usg.ReadDate
		,Quantity				= usg.Volume
		,BeginRead				= NULL
		,EndRead				= NULL

		,UnitOfMeasure			= usg.UOM
		,BaseLoad				= NULL
		,HeatFactor				= NULL
		,BTUFactor				= NULL

		,Pipeline				= NULL
		,PoolID					= usg.PoolID
		,NumberOfMeters			= usg.NumMeters
		,ReadType				= usg.ReadType
		,UsageType				= usg.UsageType
		,[Status]				= usg.[Status]
		,Notes					= NULL
		,Received				= usg.ImportDate				
		,[FileName]				= usg.ImportFileName
	FROM
		VIPMARKET_CNG_Usage usg WITH (NOLOCK)
)
,tblUsageDaily_SCG AS
(
	SELECT
		MarketTableUsageID		= usg.VIPMarket_SCG_Usage_ID
		,UtilityAccountNumber	= usg.AccountNo
		,PodID					= usg.PodID
		,MeterNumber			= NULL
		
		,ReadDate				= usg.ReadDate
		,Quantity				= usg.Usage
		,BeginRead				= NULL
		,EndRead				= NULL

		,UnitOfMeasure			= usg.UOM
		,BaseLoad				= NULL
		,HeatFactor				= NULL
		,BTUFactor				= NULL

		,Pipeline				= NULL
		,PoolID					= usg.PoolID
		,NumberOfMeters			= usg.MeterCount
		,ReadType				= usg.ReadType
		,UsageType				= usg.UsageType
		,[Status]				= usg.[Status]
		,Notes					= usg.Notes
		,ReceivedDate			= usg.ImportDate

		,[FileName]				= usg.ImportFileName
	FROM
		VIPMARKET_SCG_Usage usg WITH (NOLOCK)
)
,tblUsageDaily_YGC AS
(
	SELECT
		MarketTableUsageID		= usg.VIPMarket_YGC_UsageID
		,UtilityAccountNumber	= usg.AccountNo
		,PodID					= NULL
		,MeterNumber			= usg.MeterNo
		
		,ReadDate				= usg.StartDate
		,Quantity				= usg.UsageAmount

		,BeginRead				= usg.BeginRead
		,EndRead				= usg.EndRead
		
		,UnitOfMeasure			= usg.UOM
		,BaseLoad				= usg.BaseLoad
		,HeatFactor				= usg.HeatFactor
		,BTUFactor				= usg.BTUFactor

		,Pipeline				= usg.Pipeline
		,PoolID					= NULL
		,NumberOfMeters			= NULL
		,ReadType				= usg.ReadType
		,UsageType				= usg.UsageType
		,[Status]				= usg.[Status]
		,Notes					= NULL
		,ReceivedDate			= usg.ImportDate

		,[FileName]				= usg.ImportFileName
	FROM
		VIPMARKET_YGC_Usage usg WITH (NOLOCK)
)
-------------------
,tblUnionAllDailyUsage AS
(
	SELECT Utility = 'CNG', * FROM tblUsageDaily_CNG
	UNION ALL SELECT Utility = 'SCG', * FROM tblUsageDaily_SCG
	UNION ALL SELECT Utility = 'YGC', * FROM tblUsageDaily_YGC
)
SELECT * FROM tblUnionAllDailyUsage


GO
