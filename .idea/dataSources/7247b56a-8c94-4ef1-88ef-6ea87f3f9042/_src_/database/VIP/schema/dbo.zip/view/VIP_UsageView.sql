
CREATE VIEW [dbo].[VIP_UsageView]
AS
SELECT     *, '' Archived
FROM         dbo.VIP_Usage
UNION
SELECT     *, 'Archived' Archived
FROM         VIP_Archive..VIP_Usage

GO
