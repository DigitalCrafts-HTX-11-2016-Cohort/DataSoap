
CREATE PROCEDURE dbo.DeleteSearchItemWord
	@SearchItemWordID int
AS

DELETE FROM dbo.SearchItemWord
WHERE
	[SearchItemWordID] = @SearchItemWordID


GO
