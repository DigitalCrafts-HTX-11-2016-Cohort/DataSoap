
CREATE PROCEDURE dbo.GetDesktopModulesByPortal

	@PortalId int

AS

SELECT distinct(dbo.DesktopModules.DesktopModuleId) AS DesktopModuleId,
       dbo.DesktopModules.FriendlyName,
       dbo.DesktopModules.Description,
       dbo.DesktopModules.Version,
       dbo.DesktopModules.IsPremium,
       dbo.DesktopModules.IsAdmin,
       dbo.DesktopModules.businesscontrollerclass,
       dbo.DesktopModules.foldername,
       dbo.DesktopModules.modulename,
       dbo.DesktopModules.supportedfeatures,
       dbo.DesktopModules.compatibleversions,
       dbo.DesktopModules.dependencies,
       dbo.DesktopModules.permissions
FROM dbo.DesktopModules
LEFT OUTER JOIN dbo.PortalDesktopModules on dbo.DesktopModules.DesktopModuleId = dbo.PortalDesktopModules.DesktopModuleId
WHERE  IsAdmin = 0
AND    ( IsPremium = 0 OR (PortalId = @PortalId AND PortalDesktopModuleId IS NOT Null)) 
ORDER BY FriendlyName

GO
