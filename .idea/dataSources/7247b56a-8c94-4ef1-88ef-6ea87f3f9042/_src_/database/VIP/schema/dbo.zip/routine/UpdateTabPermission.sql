
CREATE PROCEDURE dbo.UpdateTabPermission
	@TabPermissionID int, 
	@TabID int, 
	@PermissionID int, 
	@RoleID int ,
	@AllowAccess bit,
    @UserID int
AS

UPDATE dbo.TabPermission 
SET     
	[TabID] = @TabID,
	[PermissionID] = @PermissionID,
	[RoleID] = @RoleID,
	[AllowAccess] = @AllowAccess,
    [UserID] = @UserID
WHERE   [TabPermissionID] = @TabPermissionID

GO
