
CREATE PROCEDURE [dbo].[usp_VIP_GetPendingChangesByUtility]

	@UtilityCode varchar(20)

As

Select
VIP_Retailers.Code as RetailerCode, VIP_Retailers.DUNSNumber as RetailerDUNS, VIP_Utilities.Code as UtilityCode,
VIP_Utilities.Code as ReceiverCustomerID, VIP_Retailers.Code as RetailerCode, VIP_Retailers.DUNSNumber as RetailerDUNS, 
VIP_Accounts.CompanyName, VIP_Accounts.ServiceLastName, VIP_Accounts.ServiceFirstName,
VIP_Accounts.ServiceAddress1, VIP_Accounts.ServiceCity, VIP_Accounts.ServiceState, 
VIP_Accounts.ServiceZipCode, VIP_Accounts.ServicePhone, VIP_AccountInteractions.VIP_AccountInteractionGUID,
VIP_ProductBillingTypes.Code AS BillingOption, VIP_Products.VIP_ProductID,
VIP_Products.UtilityProductCode, VIP_Accounts.VIP_AccountID, VIP_Accounts.UtilityAccountNumber, VIP_Accounts.RetailerAccountNumber,
VIP_Accounts.UtilityServiceAccountID, VIP_AccountInteractionTypes.Code as InteractionCode,
VAC.Name AS AccountClassCode,
VIP_AccountInteractionTypes.Code


	
From 
	VIP_AccountInteractions Inner Join VIP_Accounts On VIP_AccountInteractions.VIP_AccountID = VIP_Accounts.VIP_AccountID
	Inner Join VIP_Utilities On VIP_Accounts.VIP_UtilityID = VIP_Utilities.VIP_UtilityID
	Inner Join VIP_AccountInteractionTypes On VIP_AccountInteractions.VIP_AccountInteractionTypeID = VIP_AccountInteractionTypes.VIP_AccountInteractionTypeID
	Inner Join VIP_Retailers ON VIP_Accounts.VIP_RetailerID = VIP_Retailers.VIP_RetailerID 
	Inner Join VIP_ProductBillingTypes on VIP_Accounts.VIP_AccountBillingTypeID = VIP_ProductBillingTypes.VIP_ProductBillingTypeID	
	Inner Join VIP_ProductBundles on VIP_Accounts.VIP_ProductBundleID = VIP_ProductBundles.VIP_ProductBundleID
	Inner Join VIP_ProductBundleItems on VIP_ProductBundles.VIP_ProductBundleID = VIP_ProductBundleItems.VIP_ProductBundleID
	Inner Join VIP_Products on VIP_ProductBundleItems.VIP_ProductID = VIP_Products.VIP_ProductID
	LEFT JOIN dbo.VIP_AccountClasses VAC ON VAC.VIP_AccountClassID = VIP_Accounts.VIP_AccountClassID
Where
	VIP_AccountInteractionTypes.Code in ('PRODUCT_CHANGE')
	and VIP_AccountInteractions.Status = 'Pending'
	And VIP_Utilities.Code = @UtilityCode


GO
