
create procedure dbo.GetVendorClassifications

@VendorId  int

as

select ClassificationId,
       ClassificationName,
       'IsAssociated' = case when exists ( select 1 from dbo.VendorClassification vc where vc.VendorId = @VendorId and vc.ClassificationId = Classification.ClassificationId ) then 1 else 0 end
from dbo.Classification


GO
