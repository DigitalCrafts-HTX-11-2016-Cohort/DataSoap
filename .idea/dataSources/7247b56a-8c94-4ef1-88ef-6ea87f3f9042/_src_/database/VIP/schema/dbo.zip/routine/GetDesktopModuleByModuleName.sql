
CREATE procedure dbo.GetDesktopModuleByModuleName

	@ModuleName    nvarchar(128)

as

select *
from   dbo.DesktopModules
where  ModuleName = @ModuleName


GO
