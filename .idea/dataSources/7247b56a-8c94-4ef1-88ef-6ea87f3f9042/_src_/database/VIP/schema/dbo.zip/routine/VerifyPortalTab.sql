
create procedure dbo.VerifyPortalTab

@PortalID int,
@TabId    int

as

select dbo.Tabs.TabId
from dbo.Tabs
left outer join dbo.Portals on dbo.Tabs.PortalId = dbo.Portals.PortalId
where  TabId = @TabId
and    ( dbo.Portals.PortalId = @PortalID or dbo.Tabs.PortalId is null )
and    IsDeleted = 0


GO
