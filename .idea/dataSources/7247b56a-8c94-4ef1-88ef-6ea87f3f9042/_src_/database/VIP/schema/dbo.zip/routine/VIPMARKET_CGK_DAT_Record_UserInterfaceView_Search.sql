
CREATE PROCEDURE [dbo].[VIPMARKET_CGK_DAT_Record_UserInterfaceView_Search]
(
	@searchText varchar(200)
)
AS
BEGIN
	SELECT 
		* 
	FROM 
		[dbo].[VIPMARKET_CGK_DAT_Record_UserInterfaceView]
	WHERE (1 = 1)
		AND 
			(
				Account LIKE '%' + @searchText + '%'
			)
END

GO
