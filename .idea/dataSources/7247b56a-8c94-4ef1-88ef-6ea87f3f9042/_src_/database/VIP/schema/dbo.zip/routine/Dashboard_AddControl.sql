
CREATE PROCEDURE dbo.Dashboard_AddControl  

	@PackageId							int,
	@DashboardControlKey 				nvarchar(50),
	@IsEnabled							bit,
	@DashboardControlSrc				nvarchar(250),
	@DashboardControlLocalResources 	nvarchar(250),
	@ControllerClass					nvarchar(250),
	@ViewOrder							int

AS
	IF @ViewOrder = -1
		SET @ViewOrder = (SELECT TOP 1 ViewOrder FROM Dashboard_Controls ORDER BY ViewOrder DESC) + 1

	INSERT INTO dbo.Dashboard_Controls (
		PackageId,
		DashboardControlKey,
		IsEnabled,
		DashboardControlSrc,
		DashboardControlLocalResources,
		ControllerClass,
		ViewOrder
	)
	VALUES (
		@PackageId,
		@DashboardControlKey,
		@IsEnabled,
		@DashboardControlSrc,
		@DashboardControlLocalResources,
		@ControllerClass,
		@ViewOrder
	)

	SELECT SCOPE_IDENTITY()

GO
