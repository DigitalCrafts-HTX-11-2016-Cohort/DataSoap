
CREATE PROCEDURE dbo.UpdateDocumentsSettings
@ModuleId          INT,
@ShowTitleLink     BIT,
@SortOrder         nvarchar(2000),
@DisplayColumns    nvarchar(2000),
@UseCategoriesList BIT,
@DefaultFolder     nvarchar(2000),
@CategoriesListName nvarchar(50),
@AllowUserSort     BIT

AS
UPDATE dbo.DocumentsSettings
SET    ShowTitleLink=@ShowTitleLink,
       SortOrder=@SortOrder,    
       DisplayColumns=@DisplayColumns,
       UseCategoriesList=@UseCategoriesList,
       DefaultFolder=@DefaultFolder,
       CategoriesListName=@CategoriesListName,
       AllowUserSort=@AllowUserSort
WHERE  ModuleId = @ModuleId
GO
