
CREATE PROCEDURE dbo.DeleteEventLog
	@LogGUID varchar(36)
AS
DELETE FROM dbo.EventLog
WHERE LogGUID = @LogGUID or @LogGUID IS NULL


GO
