

CREATE VIEW [dbo].[VIPMarket_SG_TabletEnrollmentView_Success]
AS
/*
 Shut up and listen.  So the output of this joins with the SG_ELG_Premise table for the Source-Gas cumulative report
 - Because we could have multiple attempts from the SG_TabletEnrollment table, we only want to get the LATEST attempt to show in the report
 - That's why it's important to show the latest success because that rep will get credit
 - However we also need to show if we have no successes and the latest attempt got rejected so that the reps can see that
 -	Not perfect but it's a consequence of the fact that reps can step over each other (or themselves)
	- BPanjavan
*/
WITH tblSuccessReject AS
(
SELECT 
	[VIPMarket_SG_TabletEnrollmentID]
      ,[VIPMARKET_SG_ELG_PREMISE_ID]
--      ,[EnrollmentSubmissionID]
	,DateReceived
      ,[ComputerName]
      ,[RepID]
      ,[AccountNumber]
      ,[HaveISubmittedMyDelegationForm]
	  ,[Status]
  FROM 
	  [dbo].[VIPMarket_SG_TabletEnrollment]
	WHERE (1 = 1)
		AND [Status] IN ('Submitted','Rejected','Enrolled','Cancelled')
)
,tblMaxSuccessReject AS
(
	SELECT 
		one.* 
	FROM 
		tblSuccessReject one
		INNER JOIN
		(
			SELECT
				MaxDateReceived  = MAX(DateReceived)
				, VIPMARKET_SG_ELG_PREMISE_ID
			FROM
				tblSuccessReject
			GROUP BY
				VIPMARKET_SG_ELG_PREMISE_ID
		) maxRecv
		ON one.DateReceived = maxRecv.MaxDateReceived
			AND one.VIPMARKET_SG_ELG_PREMISE_ID = maxRecv.VIPMARKET_SG_ELG_PREMISE_ID
)
,tblSuccess AS
(
	SELECT * FROM tblSuccessReject WHERE [Status] IN ('Submitted','Enrolled')
)
,tblMaxSuccess AS
(
	SELECT 
		one.* 
	FROM 
		tblSuccess one
		INNER JOIN
		(
			SELECT
				MaxDateReceived  = MAX(DateReceived)
				, VIPMARKET_SG_ELG_PREMISE_ID
			FROM
				tblSuccess
			GROUP BY
				VIPMARKET_SG_ELG_PREMISE_ID
		) maxRecv
		ON one.DateReceived = maxRecv.MaxDateReceived
			AND one.VIPMARKET_SG_ELG_PREMISE_ID = maxRecv.VIPMARKET_SG_ELG_PREMISE_ID
)
--SELECT * FROM tblMaxSuccess-- WHERE AccountNumber = '211013424027' ORDER BY AccountNumber
SELECT
	sr.VIPMARKET_SG_ELG_PREMISE_ID
	,ComputerName = ISNULL(ms.ComputerName, sr.ComputerName)
	,RepID = ISNULL(ms.RepID, sr.RepID)
	,sr.AccountNumber
	,CASE WHEN ISNULL(ms.HaveISubmittedMyDelegationForm,sr.HaveISubmittedMyDelegationForm) = 0 THEN 'Y'
		ELSE 'N' END AS 'UsedControlNumber'
--	,ms.VIPMARKET_SG_ELG_PREMISE_ID
FROM
	tblMaxSuccessReject sr
	LEFT JOIN tblMaxSuccess ms ON sr.VIPMARKET_SG_ELG_PREMISE_ID = ms.VIPMARKET_SG_ELG_PREMISE_ID


GO
