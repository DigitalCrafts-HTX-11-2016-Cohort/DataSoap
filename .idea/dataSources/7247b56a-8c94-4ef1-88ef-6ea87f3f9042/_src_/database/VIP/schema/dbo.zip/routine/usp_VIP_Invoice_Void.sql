


CREATE PROCEDURE [dbo].[usp_VIP_Invoice_Void]
(
@invoiceID INT
,@alsoDeleteUsage BIT
)
AS
BEGIN TRY
	PRINT('Executing.  Begin Transaction')
	DECLARE @count AS INT
			SET @count = (SELECT COUNT(1) FROM [Accounting].[Accounting_Period_Open_Close_Controlled] WHERE (SELECT CONVERT(DATE,InvoiceDate) FROM dbo.VIP_Invoices WHERE VIP_InvoiceID = @invoiceID) BETWEEN CONVERT(DATE,Accounting_Period_Start) AND CONVERT(DATE,Accounting_Period_End )AND Account_Period_Status ='Closed')
			IF @count >0 
			THROW 16, 'This General ledger period is now closed. Please see Accounting for help with this matter. Please try again if you feel this message was derived in error.',1;

	BEGIN TRAN

	------ TESTING
	----DECLARE @invoiceID INT
	----SET @invoiceID = 10838976
	----DECLARE @alsoDeleteUsage BIT
	----SET @alsoDeleteUsage = 1
	----2017-06-07 - BRudd - Changed this from getting the accountID from the ShadowInvoices table to getting the accountID from BillingPointAccounts
	DECLARE @VIP_AccountID INT
	SET @VIP_AccountID = (SELECT VIP_AccountID FROM dbo.VIP_BillingPointAccounts bpa INNER JOIN dbo.VIP_Invoices inv ON inv.VIP_BillingPointID = bpa.VIP_BillingPointID WHERE inv.VIP_InvoiceID = @invoiceID)

	-- Void the invoice
	UPDATE VIP_Invoices
		SET [Status] = 'Voided'
	WHERE VIP_InvoiceID = @invoiceID

	IF (@alsoDeleteUsage = 1)
	BEGIN

		DECLARE @tblUsagesToDelete AS TABLE
		(VIP_UsageID int)

		INSERT INTO @tblUsagesToDelete
			SELECT DISTINCT 
				ii.VIP_UsageID
			FROM
				VIP_Invoices inv
				INNER JOIN VIP_InvoiceItems ii ON inv.VIP_InvoiceID = ii.VIP_InvoiceID
			WHERE inv.VIP_InvoiceID = @invoiceID	
				AND ii.VIP_UsageID IS NOT NULL	AND ii.VIP_UsageID <> 0

		-- IF the usages exist on multiple non-voided invoices than you cannot void this invoice
		DECLARE @uniqueInvoiceCount int
			;WITH tblDistinctInvoicesForUsages AS
			(
			SELECT 
				DISTINCT ii.VIP_InvoiceID
			FROM
				@tblUsagesToDelete
				INNER JOIN VIP_InvoiceItems ii ON [@tblUsagesToDelete].VIP_UsageID = ii.VIP_UsageID
				INNER JOIN Accounting.v_ARTransactions_Invoices_NonShadowNotVoided inv
					ON ii.VIP_InvoiceID 
							= inv.ARTransactionID
			)
			SELECT @uniqueInvoiceCount = COUNT(*) FROM tblDistinctInvoicesForUsages

	
--		PRINT(@uniqueInvoiceCount)

		IF @uniqueInvoiceCount > 0
		BEGIN
			RAISERROR('Cannot remove usage(s).  Usage for this invoice is tied to additional invoices.', 15, 1)
		END

		-- Otherwise, blow away the usage and 
		UPDATE ii
		SET ii.VIP_UsageID = NULL 
		FROM 
			VIP_InvoiceITems ii
		WHERE ii.VIP_UsageID IN
	  (
		SELECT VIP_UsageID FROM @tblUsagesToDelete
	  ) 

	  DELETE FROM dbo.VIP_UsageBreakdowns 	
	  WHERE VIP_UsageID IN
	  (
		SELECT VIP_UsageID FROM @tblUsagesToDelete
	  ) 

	  DELETE FROM VIP_Usage
	  WHERE VIP_UsageID IN
	  (
		SELECT VIP_UsageID FROM @tblUsagesToDelete
	  ) 
	END

	DECLARE @message VARCHAR(MAX)
	SET @message = 'usp_VIP_Invoice_Void: ' +  CONVERT(varchar(50), @invoiceID) + ', Delete Usage: ' + CASE WHEN @alsoDeleteUsage = 1 THEN 'Yes, ' + CONVERT(VARCHAR(50), (SELECT TOP 1 VIP_UsageID FROM @tblUsagesToDelete) ) ELSE 'No' END

	EXECUTE AccountServicePoint.p_AccountInteraction_CreateCompleteInteractionAndAudit @AccountInteractionTypeCode = 'INVOICE_VOIDED', -- varchar(100)
	    @VIP_AccountID = @VIP_AccountID, -- int
	    @userID = 2, -- int
	    @auditMessage = @message
	

	PRINT('Execution Complete.  Committing Transaction')
	COMMIT

END TRY
BEGIN CATCH
	PRINT('Execution Error.  Rolling back transaction')
	ROLLBACK
	
	DECLARE @errorMessage VARCHAR(1000)
	SET @errorMessage = ERROR_MESSAGE()

	PRINT('ERROR_NUMBER: ' + CONVERT(varchar(100), ERROR_NUMBER()) )
	PRINT('ERROR_SEVERITY: ' + CONVERT(varchar(100), ERROR_SEVERITY()) )
	PRINT('ERROR_STATE: ' + CONVERT(varchar(100), ERROR_STATE()) )
	PRINT('ERROR_PROCEDURE: ' + CONVERT(varchar(100), ERROR_PROCEDURE()) )
	PRINT('ERROR_LINE: ' + CONVERT(varchar(100), ERROR_LINE()) )
	PRINT('ERROR_MESSAGE: ' + CONVERT(varchar(100), @errorMessage) )

	RAISERROR(@errorMessage,15,1)

END CATCH


GO
