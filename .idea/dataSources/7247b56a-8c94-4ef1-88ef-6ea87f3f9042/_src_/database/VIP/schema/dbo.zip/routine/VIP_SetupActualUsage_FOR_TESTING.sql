-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE VIP_SetupActualUsage_FOR_TESTING 

@CustomerID varchar(15), @MeterCreation varchar(1)	
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    
	declare @MeterNo varchar(15)
	declare @MeterID int    
    declare @UsageTypeIDE int
    declare @AccountID int
    
    select @MeterNo = (select top 1 MeterNo from dbo.VIPMARKET_PGE_Usage where customerid = @CustomerID)
    
    --clean up staging table
    delete VIPMARKET_PGE_Usage where CustomerID = @CustomerID and purpose = 'OK'
    
        --remove meter      
    if @MeterCreation = 'Y'
    begin
       Select @MeterID = (Select VIP_MeterID from dbo.VIP_Meters where MeterNumber = @MeterNo)
       delete dbo.VIP_Meters where Meternumber = @MeterNo
    END
    
    --clean up usage
    Select @UsageTypeIDE = (SELECT VIP_UsageTypeID FROM VIP_UsageTypes where Code = 'ACTUAL')    
    delete dbo.VIP_Usage WHERE VIP_MeterID = @MeterID and VIP_UsageTypeID = @UsageTypeIDE       
	
	--remove data from audit table
	select @AccountID = (SELECT VIP_AccountID from dbo.VIP_Accounts where UtilityAccountNumber = @CustomerID)
	
    Delete dbo.VIP_AccountInteractions where VIP_AccountInteractionTypeID = 8 AND VIP_AccountID = @AccountID

    Delete  dbo.VIP_AccountInteractionAudit from dbo.VIP_AccountInteractionAudit a
    INNER JOIN VIP_AccountInteractions b ON b.VIP_AccountInteractionID = a.VIP_AccountInteractionID
    where b.VIP_AccountInteractionTypeID = 8 AND b.VIP_AccountID = @AccountID
END
GO
