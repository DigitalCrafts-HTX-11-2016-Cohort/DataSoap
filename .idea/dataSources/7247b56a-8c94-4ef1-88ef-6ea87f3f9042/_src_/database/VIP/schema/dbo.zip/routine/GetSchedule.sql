
CREATE PROCEDURE dbo.GetSchedule

@Server varchar(150)

AS

SELECT S.ScheduleID, 
       S.TypeFullName, 
       S.TimeLapse, 
       S.TimeLapseMeasurement,  
       S.RetryTimeLapse, 
       S.RetryTimeLapseMeasurement, 
       S.ObjectDependencies, 
       S.AttachToEvent, 
       S.RetainHistoryNum, 
       S.CatchUpEnabled, 
       S.Enabled, 
       SH.NextStart, 
       S.Servers
FROM dbo.Schedule S
LEFT JOIN dbo.ScheduleHistory SH ON S.ScheduleID = SH.ScheduleID
WHERE (SH.ScheduleHistoryID = (SELECT TOP 1 S1.ScheduleHistoryID FROM ScheduleHistory S1 WHERE S1.ScheduleID = S.ScheduleID ORDER BY S1.NextStart DESC) OR SH.ScheduleHistoryID IS NULL)
AND (@Server IS NULL or S.Servers LIKE ',%' + @Server + '%,' or S.Servers IS NULL)
GROUP BY S.ScheduleID, S.TypeFullName, S.TimeLapse, S.TimeLapseMeasurement, S.RetryTimeLapse, S.RetryTimeLapseMeasurement, S.ObjectDependencies, S.AttachToEvent, S.RetainHistoryNum, S.CatchUpEnabled, S.Enabled, SH.NextStart, S.Servers

GO
