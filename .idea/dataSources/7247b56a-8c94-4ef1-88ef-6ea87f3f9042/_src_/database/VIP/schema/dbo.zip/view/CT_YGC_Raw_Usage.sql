CREATE VIEW CT_YGC_Raw_Usage as select * from VIPMARKET_YGC_USage (nolock)
GO
