






/*	AND dbo.VIP_BatchEnrollmentEntries.DateSold >= '2012-01-01'*/
CREATE VIEW [dbo].[VIP_AccountCumulativeView]
AS
   WITH    tblAccountInteractionAuditEnrollment_Latest
              AS ( SELECT   ai2.VIP_AccountID ,
                            aia2.AuditMessage
                   FROM     dbo.VIP_AccountInteractions AS ai2 WITH ( NOLOCK )
                            INNER JOIN dbo.VIP_AccountInteractionAudit AS aia2
                            WITH ( NOLOCK ) ON ai2.VIP_AccountInteractionID = aia2.VIP_AccountInteractionID
                            INNER JOIN ( SELECT ai.VIP_AccountID ,
                                                MAX(aia.VIP_AccountInteractionAuditID) AS VIP_AccountInteractionAuditID_Max
                                         FROM   dbo.VIP_AccountInteractions AS ai
                                                WITH ( NOLOCK )
                                                INNER JOIN ( SELECT
                                                              VIP_AccountInteractionAuditID ,
                                                              VIP_AccountInteractionID ,
                                                              AuditType ,
                                                              AuditLevel ,
                                                              AuditMessage ,
                                                              AuditDateTime
                                                             FROM
                                                              dbo.VIP_AccountInteractionAudit
                                                              WITH ( NOLOCK )
                                                             WHERE
                                                              ( AuditType = 'Checkpoint' )
                                                           ) AS aia ON ai.VIP_AccountInteractionID = aia.VIP_AccountInteractionID
                                         WHERE  ( ai.VIP_AccountInteractionTypeID = 1 )
                                         GROUP BY ai.VIP_AccountID
                                       ) AS mk1 ON ai2.VIP_AccountID = mk1.VIP_AccountID
                                                   AND aia2.VIP_AccountInteractionAuditID = mk1.VIP_AccountInteractionAuditID_Max
                 ),
            tblAccountInteractionAuditTermination_Latest
              AS ( SELECT   ai2.VIP_AccountID ,
                            aia2.AuditMessage
                   FROM     dbo.VIP_AccountInteractions AS ai2 WITH ( NOLOCK )
                            INNER JOIN dbo.VIP_AccountInteractionAudit AS aia2
                            WITH ( NOLOCK ) ON ai2.VIP_AccountInteractionID = aia2.VIP_AccountInteractionID
                            INNER JOIN ( SELECT ai.VIP_AccountID ,
                                                MAX(aia.VIP_AccountInteractionAuditID) AS VIP_AccountInteractionAuditID_Max
                                         FROM   dbo.VIP_AccountInteractions AS ai
                                                WITH ( NOLOCK )
                                                INNER JOIN ( SELECT
                                                              VIP_AccountInteractionAuditID ,
                                                              VIP_AccountInteractionID ,
                                                              AuditType ,
                                                              AuditLevel ,
                                                              AuditMessage ,
                                                              AuditDateTime
                                                             FROM
                                                              dbo.VIP_AccountInteractionAudit
                                                              WITH ( NOLOCK )
                                                             WHERE
                                                              ( 1 = 1 )
                                                              AND ( AuditType = 'Checkpoint' )
                                                              AND ( AuditMessage NOT LIKE '%VIPMARKET_PGE_DASRID%' )
                                                           ) AS aia ON ai.VIP_AccountInteractionID = aia.VIP_AccountInteractionID
                                         WHERE  ( 1 = 1 )
                                                AND ( ai.VIP_AccountInteractionTypeID IN (
                                                      12, 13 ) )
                                         GROUP BY ai.VIP_AccountID
                                       ) AS mk1 ON ai2.VIP_AccountID = mk1.VIP_AccountID
                                                   AND aia2.VIP_AccountInteractionAuditID = mk1.VIP_AccountInteractionAuditID_Max
                 ),
			tblAccountInteractionAuditTerminationRequesID_LatestAndEarliest AS
			(
				SELECT ai.VIP_AccountID ,
                    MAX(aia.VIP_AccountInteractionAuditID) AS VIP_AccountInteractionAuditID_Max,
                    MIN(aia.VIP_AccountInteractionAuditID) AS VIP_AccountInteractionAuditID_Min
                FROM   dbo.VIP_AccountInteractions AS ai
                    WITH ( NOLOCK )
                    INNER JOIN dbo.VIP_AccountInteractionAudit
                    AS aia WITH ( NOLOCK ) ON ai.VIP_AccountInteractionID = aia.VIP_AccountInteractionID
                WHERE  ( 1 = 1 )
                    AND ( ai.VIP_AccountInteractionTypeID IN (
                            12, 13 ) )
                GROUP BY ai.VIP_AccountID
			),
            tblAccountInteractionAuditTerminationRequest_Latest
              AS ( SELECT   ai2.VIP_AccountID ,
                            ai2.StartDateTime
                   FROM     dbo.VIP_AccountInteractions AS ai2 WITH ( NOLOCK )
                            INNER JOIN dbo.VIP_AccountInteractionAudit AS aia2
                            WITH ( NOLOCK ) ON ai2.VIP_AccountInteractionID = aia2.VIP_AccountInteractionID
                            INNER JOIN tblAccountInteractionAuditTerminationRequesID_LatestAndEarliest
                                       ON ai2.VIP_AccountID = tblAccountInteractionAuditTerminationRequesID_LatestAndEarliest.VIP_AccountID
                                       AND aia2.VIP_AccountInteractionAuditID = tblAccountInteractionAuditTerminationRequesID_LatestAndEarliest.VIP_AccountInteractionAuditID_Max -- MAX
                 ),
			tblAccountInteractionAuditTerminationRequest_Earliest
              AS ( SELECT   ai2.VIP_AccountID ,
                            ai2.StartDateTime
                   FROM     dbo.VIP_AccountInteractions AS ai2 WITH ( NOLOCK )
                            INNER JOIN dbo.VIP_AccountInteractionAudit AS aia2
                            WITH ( NOLOCK ) ON ai2.VIP_AccountInteractionID = aia2.VIP_AccountInteractionID
                            INNER JOIN tblAccountInteractionAuditTerminationRequesID_LatestAndEarliest
                                       ON ai2.VIP_AccountID = tblAccountInteractionAuditTerminationRequesID_LatestAndEarliest.VIP_AccountID
                                       AND aia2.VIP_AccountInteractionAuditID = tblAccountInteractionAuditTerminationRequesID_LatestAndEarliest.VIP_AccountInteractionAuditID_Min -- MIN
                 ),
            tblAccountInteractionEnrollmentStartDateEndDate
              AS ( SELECT   ai2.VIP_AccountID ,
                            ai2.StartDateTime ,
                            ai2.EndDateTime
                   FROM     dbo.VIP_AccountInteractions AS ai2 WITH ( NOLOCK )
                            INNER JOIN ( SELECT VIP_AccountID ,
                                                MAX(VIP_AccountInteractionID) AS VIP_AccountInteractionID_MAX
                                         FROM   dbo.VIP_AccountInteractions AS ai
                                                WITH ( NOLOCK )
                                         WHERE  ( VIP_AccountInteractionTypeID = 1 )
                                         GROUP BY VIP_AccountID
                                       ) AS mk1 ON ai2.VIP_AccountID = mk1.VIP_AccountID
                                                   AND mk1.VIP_AccountInteractionID_MAX = ai2.VIP_AccountInteractionID
                 ),
            tblAccountInteraction_Last
              AS ( SELECT   ai2.VIP_AccountID ,
                            CASE YEAR(EndDateTime)
                              WHEN 1900 THEN StartDateTime
                              ELSE EndDateTime
                            END AS EndDateTime_Derrived ,
                            ait2.Code
                   FROM     dbo.VIP_AccountInteractions AS ai2 WITH ( NOLOCK )
                            INNER JOIN dbo.VIP_AccountInteractionTypes AS ait2
                            WITH ( NOLOCK ) ON ai2.VIP_AccountInteractionTypeID = ait2.VIP_AccountInteractionTypeID
                            INNER JOIN ( SELECT VIP_AccountID ,
                                                MAX(VIP_AccountInteractionID) AS VIP_AccountInteractionID_MAX
                                         FROM   dbo.VIP_AccountInteractions AS ai
                                                WITH ( NOLOCK )
                                         WHERE  ( 1 = 1 )
                                                AND ( VIP_AccountInteractionTypeID IN (
                                                      1, 14, 17, 19 ) )
                                         GROUP BY VIP_AccountID
                                       ) AS mk1 ON ai2.VIP_AccountID = mk1.VIP_AccountID
                                                   AND mk1.VIP_AccountInteractionID_MAX = ai2.VIP_AccountInteractionID
                 ),
            tblUsageAmount_Historical_Sum
              AS ( SELECT   usg.VIP_AccountID ,
                            ISNULL(SUM(ISNULL(usg.UsageAmount, 0)), 0) AS SUM_UsageAmount
                   FROM     dbo.VIP_Usage AS usg WITH ( NOLOCK )
                            INNER JOIN dbo.VIP_UsageTypes AS ut WITH ( NOLOCK ) ON usg.VIP_UsageTypeID = ut.VIP_UsageTypeID
                   WHERE    ( 1 = 1 )
                            AND ( ut.Code = 'HISTORICAL' )
                   GROUP BY usg.VIP_AccountID
                 ),
				 tblFlowStartDate as
				(
					Select 
					vip_accountid, max(FlowStartDate) FlowStartDate
					from vip_meters 
					where year(FlowStartDate) <> 1900
					group by vip_accountid		
				),
				tblUsageFirstAndLast AS
				(
					SELECT
						usg.VIP_AccountID
						,UsageStartDateMIN = MIN(usg.StartDate)
						,UsageEndDateMAX = MAX(usg.EndDate)
						,UsageCount = COUNT(1)
					 FROM
						VIP_Usage usg WITH (NOLOCK)
						INNER JOIN VIP_UsageTypes ut WITH (NOLOCK)
								ON usg.VIP_UsageTypeID = ut.VIP_UsageTypeID
									AND ut.Code IN
				 (
				'ACTUAL'
				,'CANCELLED'
				,'CORRECTED'
				 )                  
					WHERE (1 = 1)   
					GROUP BY
						usg.VIP_AccountID  
				)
				,
				tblInvoiceFirstAndLast AS
				(
					SELECT
						inv.VIP_AccountID
						,LatestInvoiceDate = MAX(inv.ARDate)
						,FirstInvoiceDate = MIN(inv.ARDate)
						,InvoiceCount = COUNT(1)
					 FROM
						Accounting.v_ARTransactions_Invoices_NonShadowNotVoided inv WITH (NOLOCK)
					GROUP BY
						inv.VIP_AccountID  
				 )
				,tblProductBundle_DerrivedSimplePricingType AS
				(
					SELECT  
							pb.VIP_ProductBundleID
							,CASE
								WHEN ppt.Code = 'FIXED' 
									OR pb.Code LIKE '%FIXED'
									OR prod.ProductName LIKE '%Fixed%' 
									THEN 'FIXED'
								WHEN 
									pb.Code LIKE '%IMMEDIATESAVINGS%' 
									OR prod.RetailerProductCode LIKE '%IMMEDIATESAVINGS%'
									OR prod.ProductName LIKE '%Immediate Savings%'
									OR pbi.Months <= 2
									THEN 'IMMEDIATE_SAVINGS'
								WHEN 
									prod.ProductName LIKE '%Index%' 
									OR pb.Code LIKE '%ADDER%'
									OR prod.ProductName LIKE '%Index%'
									THEN 'VARIABLE'

								ELSE 'VARIABLE' -- BPanjavan - not sure about this one
							END ProductPricingTypeShort
					FROM    dbo.VIP_ProductBundles pb
							INNER JOIN dbo.VIP_ProductBundleItems pbi ON pb.VIP_ProductBundleID = pbi.VIP_ProductBundleID
								AND pbi.Sequence = 1
							LEFT JOIN dbo.VIP_Products prod ON pbi.VIP_ProductID = prod.VIP_ProductID
							LEFT JOIN dbo.VIP_ProductPricingTypes ppt ON prod.VIP_ProductPricingTypeID = ppt.VIP_ProductPricingTypeID
				)
    SELECT  dbo.VIP_Accounts.VIP_AccountID ,
            dbo.VIP_Utilities.Code AS UtilityCode ,
            dbo.VIP_Marketers.Code AS MarketerCode ,
            dbo.VIP_AccountClasses.Code AS AccountClass ,
            dbo.VIP_BatchEnrollmentEntries.MasterAccountID ,
			dbo.VIP_BatchEnrollmentEntries.Notes AS NotesFromBatch,
			dbo.VIP_BatchEnrollmentEntries.DateSold AS DateSoldBatchEnroll,
            dbo.VIP_BatchEnrollmentEntries.UtilityAccountNumber AS EnrollmentAccountNumber,
            dbo.VIP_BatchEnrollmentEntries.VerificationID ,
            dbo.VIP_Accounts.UtilityAccountNumber ,
            dbo.VIP_Accounts.UtilityServiceAccountID ,
            dbo.VIP_Accounts.ServiceFirstName ,
            dbo.VIP_Accounts.ServiceLastName ,
            dbo.VIP_Accounts.ServiceAddress1 ,
            dbo.VIP_Accounts.ServiceAddress2 ,
            dbo.VIP_Accounts.ServiceCity AS ServiceAddressCity ,
            { fn UCASE(dbo.VIP_Accounts.ServiceState) } AS ServiceAddressState ,
            dbo.VIP_Accounts.ServiceZipCode ,                        
            dbo.VIP_Accounts.BillingAddress1,
            dbo.VIP_Accounts.BillingAddress2,
            dbo.VIP_Accounts.BillingCity,
            dbo.VIP_Accounts.BillingState,
            dbo.VIP_Accounts.BillingZipCode,            
            dbo.VIP_Accounts.CompanyName ,
            dbo.VIP_Accounts.ServicePhone ,
            dbo.VIP_Accounts.BillingPhone ,
            dbo.VIP_Accounts.AccountStatus ,
            dbo.VIP_Accounts.DateSold AS SoldOnAccount,
            dbo.VIP_Contracts.StartDate AS ContractStartDate ,
            dbo.VIP_Contracts.EndDate AS ContractEndDate ,
            dbo.VIP_BatchEnrollmentEntries.LoadedDateTime AS DateImported ,
            dbo.VIP_Accounts.SPRateName ,
            dbo.VIP_Accounts.VIP_MarketerAgentID ,
            dbo.VIP_Accounts.VIP_MarketerID ,
            dbo.VIP_Accounts.Residual ,
            dbo.VIP_Accounts.SwitchToRetailer ,
            dbo.VIP_Accounts.Date_Dropped ,
            CASE dbo.VIP_Accounts.CoreCustomer
              WHEN 0 THEN 'Non Core'
              WHEN 1 THEN 'Core'
            END AS CoreCustomer ,
            mktrAgent.FirstName + ' ' + mktrAgent.LastName AS MarketerAgent ,
            ( SELECT TOP ( 1 )
                        dbo.VIP_Meters.MeterNumber
              FROM      dbo.VIP_Accounts AS a
                        INNER JOIN dbo.VIP_Meters ON dbo.VIP_Meters.VIP_AccountID = a.VIP_AccountID
              WHERE     ( a.VIP_AccountID = dbo.VIP_Accounts.VIP_AccountID )
              ORDER BY  dbo.VIP_Meters.StartDate DESC
            ) AS MeterNumber ,
            tblAccountInteractionAuditEnrollment_Latest.AuditMessage AS EnrollmentStatus ,
            dbo.VIP_Accounts.EnrollmentAcceptDate ,
            ISNULL(tblUsageAmount_Historical_Sum.SUM_UsageAmount, 0) AS TotalHistoricalUsageSent ,
            CASE WHEN dbo.VIP_Accounts.AccountStatus IN ( 'Enrolled',
                                                          'Enrolling',
                                                          'Pending' ) THEN ''
                 ELSE ISNULL(tblAccountInteractionAuditTermination_Latest.AuditMessage,
                             'N/A')
            END AS TerminationStatus ,
            ( SELECT    CASE WHEN COUNT(*) >= 1 THEN 'Yes'
                             ELSE 'No'
                        END AS Expr1
              FROM      dbo.VIP_Usage AS VIP_Usage_1
              WHERE     ( VIP_AccountID = dbo.VIP_Accounts.VIP_AccountID )
                        AND ( VIP_UsageTypeID = 2 )
            ) AS ActualUsageRecieved ,
            ( SELECT    CASE WHEN COUNT(*) >= 1 THEN 'Yes'
                             ELSE 'No'
                        END AS Expr1
              FROM      dbo.VIP_AccountInteractions AS VIP_AccountInteractions_2
              WHERE     ( VIP_AccountID = dbo.VIP_Accounts.VIP_AccountID )
                        AND ( VIP_AccountInteractionTypeID = 19 )
            ) AS IsCorrection ,
            tblAccountInteractionEnrollmentStartDateEndDate.StartDateTime AS EnrollmentStartDateTime ,
            tblAccountInteractionEnrollmentStartDateEndDate.EndDateTime AS EnrollmentEndDateTime ,
            tblAccountInteraction_Last.EndDateTime_Derrived AS LastAccountInteractionDate ,
            tblAccountInteraction_Last.Code AS LastAccountInteractionCode ,
            ISNULL(CONVERT(VARCHAR(11), CASE WHEN YEAR(VIP_Accounts.SCH_EnrollSwitchDate) < 2009
                                             THEN NULL
                                             ELSE VIP_Accounts.SCH_EnrollSwitchDate
                                        END, 101), '') AS SCH_EnrollSwitchDate ,
            ISNULL(CONVERT(VARCHAR(11), CASE WHEN YEAR(VIP_Accounts.ACT_EnrollSwitchDate) < 2009
                                             THEN NULL
                                             ELSE VIP_Accounts.ACT_EnrollSwitchDate
                                        END, 101), '') AS ACT_EnrollSwitchDate ,
            ISNULL(CONVERT(VARCHAR(11), CASE WHEN YEAR(VIP_Accounts.EST_DropDate) < 2009
                                             THEN NULL
                                             ELSE VIP_Accounts.EST_DropDate
                                        END, 101), '') AS EST_DropDate ,
            tblAccountInteractionAuditTerminationRequest_Earliest.StartDateTime AS 'TerminationRequestDate(Earliest)' ,
            tblAccountInteractionAuditTerminationRequest_Latest.StartDateTime AS TerminationRequestDate ,
            ( SELECT    CASE WHEN COUNT(*) > 0 THEN 'Y'
                             ELSE 'N'
                        END
              FROM      dbo.VIP_Documents
              WHERE     VIP_Document_TypeID IN (
                        SELECT  VIP_Document_TypeID
                        FROM    dbo.VIP_Document_Types
                        WHERE   Code IN ( 'SERVICE_AGREEMENT' )
                                AND AssociatedObjectID = dbo.VIP_Accounts.VIP_AccountID )
            ) ServiceAgreement ,
            ( SELECT    CASE WHEN COUNT(*) > 0 THEN 'Y'
                             ELSE 'N'
                        END
              FROM      dbo.VIP_Documents
              WHERE     VIP_Document_TypeID IN (
                        SELECT  VIP_Document_TypeID
                        FROM    dbo.VIP_Document_Types
                        WHERE   Code IN ( 'PGE_COMMERCIAL_WELCOME_LETTER',
                                          'PGE_RESIDENTIAL_WELCOME_LETTER',
                                          'NICOR_COMM_Welcome_Letter',
                                          'NICOR_RESI_Welcome_Letter' )
                                AND AssociatedObjectID = dbo.VIP_Accounts.VIP_AccountID )
            ) WelcomeLetter ,
            VIP_ProductBundles.VIP_ProductBundleID,
			VIP_ProductBundles.Name ProductBundle ,
			tblProductBundle_DerrivedSimplePricingType.ProductPricingTypeShort,
            dbo.VIP_Accounts.PromotionCode ,
            vip_marketers.DefaultResidualAccounts ,
            dbo.VIP_Accounts.ServiceEmail,
			tblFlowStartDate.FlowStartDate
			,tblUsageFirstAndLast.UsageStartDateMIN
			,tblUsageFirstAndLast.UsageEndDateMAX
			,tblUsageFirstAndLast.UsageCount
			,tblInvoiceFirstAndLast.LatestInvoiceDate
			,tblInvoiceFirstAndLast.FirstInvoiceDate
			,tblInvoiceFirstAndLast.InvoiceCount
    FROM    dbo.VIP_Accounts WITH ( NOLOCK )
            INNER JOIN dbo.VIP_Marketers WITH ( NOLOCK ) ON dbo.VIP_Accounts.VIP_MarketerID = dbo.VIP_Marketers.VIP_MarketerID
            LEFT OUTER JOIN dbo.VIP_MarketerAgents AS mktrAgent WITH ( NOLOCK ) ON dbo.VIP_Accounts.VIP_MarketerAgentID = mktrAgent.VIP_MarketerAgentID
            INNER JOIN dbo.VIP_Utilities WITH ( NOLOCK ) ON dbo.VIP_Accounts.VIP_UtilityID = dbo.VIP_Utilities.VIP_UtilityID
            INNER JOIN dbo.VIP_AccountClasses WITH ( NOLOCK ) ON dbo.VIP_AccountClasses.VIP_AccountClassID = dbo.VIP_Accounts.VIP_AccountClassID
            LEFT OUTER JOIN dbo.VIP_BatchEnrollmentEntries WITH ( NOLOCK ) ON dbo.VIP_Accounts.VIP_BatchEnrollmentEntryID = dbo.VIP_BatchEnrollmentEntries.VIP_BatchEnrollEntryID
            INNER JOIN dbo.VIP_Contracts WITH ( NOLOCK ) ON dbo.VIP_Contracts.VIP_ContractID = dbo.VIP_Accounts.VIP_ContractID
            LEFT OUTER JOIN VIP_ProductBundles WITH ( NOLOCK ) ON VIP_Accounts.VIP_ProductBundleID = VIP_ProductBundles.vip_productbundleid
            LEFT OUTER JOIN tblAccountInteractionAuditEnrollment_Latest ON dbo.VIP_Accounts.VIP_AccountID = tblAccountInteractionAuditEnrollment_Latest.VIP_AccountID
            LEFT OUTER JOIN tblAccountInteractionAuditTermination_Latest ON dbo.VIP_Accounts.VIP_AccountID = tblAccountInteractionAuditTermination_Latest.VIP_AccountID
			LEFT OUTER JOIN tblAccountInteractionEnrollmentStartDateEndDate ON dbo.VIP_Accounts.VIP_AccountID = tblAccountInteractionEnrollmentStartDateEndDate.VIP_AccountID
            LEFT OUTER JOIN tblAccountInteraction_Last ON dbo.VIP_Accounts.VIP_AccountID = tblAccountInteraction_Last.VIP_AccountID
            LEFT OUTER JOIN tblAccountInteractionAuditTerminationRequest_Latest ON dbo.VIP_Accounts.VIP_AccountID = tblAccountInteractionAuditTerminationRequest_Latest.VIP_AccountID
			LEFT OUTER JOIN tblAccountInteractionAuditTerminationRequest_Earliest ON dbo.VIP_Accounts.VIP_AccountID = tblAccountInteractionAuditTerminationRequest_Earliest.VIP_AccountID
			LEFT OUTER JOIN tblUsageAmount_Historical_Sum ON dbo.VIP_Accounts.VIP_AccountID = tblUsageAmount_Historical_Sum.VIP_AccountID
			LEFT OUTER JOIN tblFlowStartDate ON dbo.VIP_Accounts.vip_accountid = tblFlowStartDate.vip_accountid
			LEFT JOIN tblUsageFirstAndLast ON VIP_Accounts.VIP_AccountID = tblUsageFirstAndLast.VIP_AccountID
			LEFT JOIN tblInvoiceFirstAndLast ON VIP_Accounts.VIP_AccountID = tblInvoiceFirstAndLast.VIP_AccountID
			LEFT JOIN tblProductBundle_DerrivedSimplePricingType ON VIP_Accounts.VIP_ProductBundleID = tblProductBundle_DerrivedSimplePricingType.VIP_PRoductBundleID
    WHERE   ( 1 = 1 )


GO
