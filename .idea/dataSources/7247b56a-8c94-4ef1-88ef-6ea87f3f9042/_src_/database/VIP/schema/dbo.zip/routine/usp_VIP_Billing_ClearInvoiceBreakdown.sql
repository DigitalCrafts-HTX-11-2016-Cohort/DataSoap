
CREATE PROCEDURE [dbo].[usp_VIP_Billing_ClearInvoiceBreakdown]
	@VIP_InvoiceID int
AS
DELETE FROM VIP_InvoiceBreakdowns WHERE VIP_InvoiceID = @VIP_InvoiceID
GO
