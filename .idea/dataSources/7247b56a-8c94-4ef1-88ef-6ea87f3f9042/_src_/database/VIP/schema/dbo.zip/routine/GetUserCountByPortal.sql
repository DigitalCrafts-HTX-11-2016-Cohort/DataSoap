
CREATE PROCEDURE dbo.[GetUserCountByPortal]

	@PortalID int

AS

	SELECT COUNT(*) FROM dbo.vw_Users 
		WHERE PortalID = @PortalID


GO
