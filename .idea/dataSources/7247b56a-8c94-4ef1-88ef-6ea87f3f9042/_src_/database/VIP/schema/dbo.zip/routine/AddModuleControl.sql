
CREATE PROCEDURE dbo.AddModuleControl
	
	@ModuleDefID                int,
	@ControlKey                 nvarchar(50),
	@ControlTitle               nvarchar(50),
	@ControlSrc                 nvarchar(256),
	@IconFile                   nvarchar(100),
	@ControlType                int,
	@ViewOrder                  int,
	@HelpUrl                    nvarchar(200),
	@SupportsPartialRendering   bit

AS
	INSERT INTO dbo.ModuleControls (
	  ModuleDefID,
	  ControlKey,
	  ControlTitle,
	  ControlSrc,
	  IconFile,
	  ControlType,
	  ViewOrder,
	  HelpUrl,
          SupportsPartialRendering
	)
	VALUES (
	  @ModuleDefID,
	  @ControlKey,
	  @ControlTitle,
	  @ControlSrc,
	  @IconFile,
	  @ControlType,
	  @ViewOrder,
	  @HelpUrl,
          @SupportsPartialRendering
	)

	SELECT SCOPE_IDENTITY()
GO
