
CREATE PROCEDURE dbo.DeleteSearchCommonWord
	@CommonWordID int
AS

DELETE FROM dbo.SearchCommonWords
WHERE
	[CommonWordID] = @CommonWordID


GO
