
CREATE procedure dbo.DeleteSearchItems
(
	@ModuleID int
)
AS

DELETE
FROM	dbo.SearchItem
WHERE	ModuleID = @ModuleID


GO
