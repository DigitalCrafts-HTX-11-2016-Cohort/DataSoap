
CREATE PROCEDURE [dbo].[usp_VIP_AccountInvoiceMasks]
	@VIP_AccountID int
AS
SELECT iit.VIP_InvoiceItemTypeID, iit.InvoiceItemType, iit.DefaultMask, aiitm.VIP_AccountInvoiceItemTypeMaskID,
	CASE WHEN aiitm.MaskText IS NULL THEN iit.DefaultMask ELSE aiitm.MaskText END AS MaskText
FROM VIP_InvoiceItemTypes iit
	LEFT OUTER JOIN (SELECT * FROM VIP_AccountInvoiceItemTypeMasks WHERE VIP_AccountID = @VIP_AccountID) aiitm ON iit.VIP_InvoiceItemTypeID = aiitm.VIP_InvoiceItemTypeID
ORDER BY iit.Suqenence
GO
