
CREATE PROCEDURE dbo.[Dashboard_GetControls] 
	@IsEnabled bit
AS
	
	SELECT *
	  FROM dbo.[Dashboard_Controls]
		WHERE (@IsEnabled = 0) OR (IsEnabled = 1)
		ORDER BY ViewOrder

GO
