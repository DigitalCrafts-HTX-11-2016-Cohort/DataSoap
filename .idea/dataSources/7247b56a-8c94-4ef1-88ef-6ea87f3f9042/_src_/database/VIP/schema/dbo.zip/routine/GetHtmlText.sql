

create procedure dbo.GetHtmlText

	@ModuleId int

as

select *
from HtmlText
where  ModuleId = @ModuleId

GO
