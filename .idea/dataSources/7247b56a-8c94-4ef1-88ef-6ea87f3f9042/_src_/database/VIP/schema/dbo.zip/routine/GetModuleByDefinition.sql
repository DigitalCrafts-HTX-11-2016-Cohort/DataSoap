
CREATE procedure dbo.[GetModuleByDefinition]
      @PortalId int,
      @FriendlyName nvarchar(128)
AS
	SELECT dbo.vw_Modules.*   
	FROM dbo.vw_Modules 
		INNER JOIN dbo.ModuleDefinitions as MD ON dbo.vw_Modules.ModuleDefID = MD.ModuleDefID
	WHERE ((PortalId = @PortalId) or (PortalId is null and @PortalID is null))
		  AND MD.FriendlyName = @FriendlyName
		  AND IsDeleted = 0
GO
