

create procedure dbo.AddVendorClassification

@VendorId           int,
@ClassificationId   int

as

insert into dbo.VendorClassification ( 
  VendorId,
  ClassificationId
)
values (
  @VendorId,
  @ClassificationId
)

select SCOPE_IDENTITY()


GO
