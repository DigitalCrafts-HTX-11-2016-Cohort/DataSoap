


-- =============================================
-- Author:		Bryan Panjavan
-- Create date: 2013-03-12
-- Description:	Developed specifically for the Courier App to get the latest pricing for all customers
-- =============================================
CREATE PROCEDURE [dbo].[Courier_GetLatestPricingForAccounts]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- Overrides
DECLARE @tblOverrideFixedBill AS TABLE
(	Account_Number	VARCHAR(100)
	,NumberOfYears	INT
	,Rate			DECIMAL(18,8)
	,Code			VARCHAR(50)  )

DECLARE @tblOverrideFixed AS TABLE
(	Account_Number	VARCHAR(100)
	,NumberOfYears	INT
	,Rate			DECIMAL(18,8)
	,Code			VARCHAR(50)  )

-- Overrides go here:
INSERT INTO @tblOverrideFixedBill VALUES ('211013192994',2, 554.00, '79995')
INSERT INTO @tblOverrideFixedBill VALUES ('211015557513',1, 54.21, '79994')
INSERT INTO @tblOverrideFixedBill VALUES ('211013444692',1, 253.55, '79994')

INSERT INTO @tblOverrideFixed VALUES ('211016210646',2, 0.454, '76347')

-- Override Fixed Bill
;WITH tblAccountMaxID AS
(
	SELECT
		Account_Number
		,Max_ID = MAX(VIPMARKET_SG_Pricing_ID)
	FROM
		dbo.VIPMARKET_SG_Pricing
	WHERE (1 = 1)
		AND Marketer = '41MG'
	GROUP BY
		Account_Number
)
UPDATE price
	SET 
		price.FixedBillUnlimitedCode1 = CASE WHEN ov.NumberOfYears = 1 THEN ov.Code ELSE price.FixedBillUnlimitedCode1 END
		,price.FixedBillUnlimitedRate1 = CASE WHEN ov.NumberOfYears = 1 THEN ov.Rate ELSE price.FixedBillUnlimitedRate1 END
        ,price.FixedBillUnlimitedCode2 = CASE WHEN ov.NumberOfYears = 2 THEN ov.Code ELSE price.FixedBillUnlimitedCode2 END
		,price.FixedBillUnlimitedRate2 = CASE WHEN ov.NumberOfYears = 2 THEN ov.Rate ELSE price.FixedBillUnlimitedRate2 END
FROM 
	dbo.VIPMARKET_SG_Pricing price
		INNER JOIN tblAccountMaxID priceMaxID
			ON
			(
				 price.Account_Number = priceMaxID.Account_Number
				 AND price.VIPMARKET_SG_Pricing_ID = priceMaxID.Max_ID
			)   
		INNER JOIN @tblOverrideFixedBill ov
			ON price.Account_Number = ov.Account_Number
WHERE (1 = 1)

-- Override Fixed
;WITH tblAccountMaxID AS
(
	SELECT
		Account_Number
		,Max_ID = MAX(VIPMARKET_SG_Pricing_ID)
	FROM
		dbo.VIPMARKET_SG_Pricing
	WHERE (1 = 1)
		AND Marketer = '41MG'
	GROUP BY
		Account_Number
)
UPDATE price
	SET 
		price.FixedPriceCode = CASE WHEN ov.NumberOfYears = 1 THEN ov.Code ELSE price.FixedPriceCode END
		,price.FixedPriceRate = CASE WHEN ov.NumberOfYears = 1 THEN ov.Rate ELSE price.FixedPriceRate END
        ,price.FixedPriceCode2 = CASE WHEN ov.NumberOfYears = 2 THEN ov.Code ELSE price.FixedPriceCode2 END
		,price.FixedPriceRate2 = CASE WHEN ov.NumberOfYears = 2 THEN ov.Rate ELSE price.FixedPriceRate2 END
FROM 
	dbo.VIPMARKET_SG_Pricing price
		INNER JOIN tblAccountMaxID priceMaxID
			ON
			(
				 price.Account_Number = priceMaxID.Account_Number
				 AND price.VIPMARKET_SG_Pricing_ID = priceMaxID.Max_ID
			)   
		INNER JOIN @tblOverrideFixed ov
			ON price.Account_Number = ov.Account_Number
WHERE (1 = 1)

;WITH tblAccountMaxID AS
(
	SELECT
		Account_Number
		,Max_ID = MAX(VIPMARKET_SG_Pricing_ID)
	FROM
		dbo.VIPMARKET_SG_Pricing
	WHERE (1 = 1)
		AND Marketer = '41MG'
	GROUP BY
		Account_Number
)
SELECT 
	WriteToFile = 
		CONVERT(VARCHAR(100), ISNULL(price.Account_Number,'0'))
		+ '	' + CONVERT(varchar(100),VIPMARKET_SG_Pricing_ID)
		+ '	' + CONVERT(VARCHAR(50), CASE WHEN price.FixedPriceRate < 0 THEN -1 ELSE price.FixedPriceRate END)
		+ '	' + CONVERT(VARCHAR(50), price.FixedPriceRate2)
		+ '	' + CONVERT(VARCHAR(50), price.IndexRate)
		+ '	' + CONVERT(VARCHAR(50), price.IndexRate2)
		+ '	' + CONVERT(VARCHAR(50), CASE WHEN price.FixedPriceRate > 0 AND ISNULL(price.FixedBillUnlimitedRate1,0) < 0 THEN 0 ELSE
										ISNULL(price.FixedBillUnlimitedRate1,0) END)
		+ '	' + CONVERT(VARCHAR(50), CASE WHEN price.FixedPriceRate > 0 AND ISNULL(price.FixedBillUnlimitedRate2,0) < 0 THEN 0 ELSE ISNULL(price.FixedBillUnlimitedRate2,0) END)

		-- TODO: Comment out before commit
--		,price.*
--	,price.FixedPriceRate
FROM 
	dbo.VIPMARKET_SG_Pricing price
		INNER JOIN tblAccountMaxID priceMaxID
			ON
			(
				 price.Account_Number = priceMaxID.Account_Number
				 AND price.VIPMARKET_SG_Pricing_ID = priceMaxID.Max_ID
			)   
WHERE (1 = 1)

END


GO
