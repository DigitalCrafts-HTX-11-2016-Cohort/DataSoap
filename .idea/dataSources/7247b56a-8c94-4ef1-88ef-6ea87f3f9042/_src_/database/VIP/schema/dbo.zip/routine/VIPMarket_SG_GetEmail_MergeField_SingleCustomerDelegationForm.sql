

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[VIPMarket_SG_GetEmail_MergeField_SingleCustomerDelegationForm]
(
	@accountNumber VARCHAR(50)
)
AS
BEGIN


SELECT 
	AccountNumber = pr.Account_Number
		, [Offer Price] = ''
		,[Offer Price 2] = ''

		,FullName = pr.First_Name + ISNULL(' ' + pr.Last_Name,'')
		,PriceOptionText = ISNULL(pricingVertical.PriceOptionText,'')
		,PricingRateText_AndUnits = 
				ISNULL(
					CASE WHEN pricingVertical.AnchorPricingType = 'Index' THEN indexName.MarketRateIndexName + ' ' ELSE '' END
					+ pricingVertical.PricingRateText
					+ ' ' + pricingVertical.PriceOptionText_UnitOMeasure
					,'')
	FROM 
		dbo.VIPMARKET_SG_ELG_PREMISE pr 
		INNER JOIN Enrollment.v_VIPMarket_SG_GetPricing_Vertical pricingVertical 
			ON pr.SelectedRow = pricingVertical.VIPMARKET_SG_Pricing_ID AND pr.PriceOption = pricingVertical.PriceOption
		LEFT JOIN Enrollment.v_VIPMARKET_SG_ELG_PREMISE_IndexName indexName ON indexName.VIPMARKET_SG_ELG_PREMISE_ID = pr.VIPMARKET_SG_ELG_PREMISE_ID
	WHERE (1 = 1)
		AND pr.Account_Number = @accountNumber

END


GO
