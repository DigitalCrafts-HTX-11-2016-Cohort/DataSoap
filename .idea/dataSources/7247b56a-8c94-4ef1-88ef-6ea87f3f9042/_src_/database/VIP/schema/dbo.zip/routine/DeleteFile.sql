
CREATE PROCEDURE dbo.DeleteFile
	@PortalID int,
	@FileName nvarchar(100),
	@FolderID int

AS

DELETE 
FROM   dbo.Files
WHERE  FileName = @FileName
AND    FolderID = @FolderID
AND    ((PortalId = @PortalID) OR (@PortalID IS Null AND PortalId IS Null))


GO
