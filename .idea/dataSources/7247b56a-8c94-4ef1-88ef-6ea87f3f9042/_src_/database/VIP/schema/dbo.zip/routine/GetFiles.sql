
CREATE PROCEDURE dbo.[GetFiles]

@PortalID   int,
@FolderID   int

AS

SELECT 
	FileId,
             FO.PortalId,
             FileName,
             Extension,
             Size,
             Width,
             Height,
             ContentType,
             F.FolderID,
	     'Folder' = FolderPath,
             StorageLocation,
             IsCached
FROM 
	dbo.Files F
INNER JOIN 
	dbo.Folders FO on F.FolderID = FO.FolderID
WHERE   
	F.FolderID = @FolderID
AND     
	((FO.PortalId = @PortalID) or (@PortalID is NULL AND FO.PortalId is NULL))
ORDER BY FileName

GO
