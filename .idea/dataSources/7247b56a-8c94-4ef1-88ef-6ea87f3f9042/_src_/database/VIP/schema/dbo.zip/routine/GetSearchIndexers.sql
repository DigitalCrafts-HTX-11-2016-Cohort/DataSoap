
create procedure dbo.GetSearchIndexers

as

select dbo.SearchIndexer.*
from dbo.SearchIndexer


GO
