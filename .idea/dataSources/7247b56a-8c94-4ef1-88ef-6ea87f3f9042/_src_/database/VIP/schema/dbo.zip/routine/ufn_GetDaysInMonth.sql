CREATE FUNCTION [dbo].[ufn_GetDaysInMonth] ( @pDate DATETIME )

RETURNS INT AS BEGIN

SET @pDate = CONVERT(VARCHAR(10), @pDate, 101) SET @pDate = @pDate - DAY(@pDate) + 1  RETURN DATEDIFF(DD, @pDate, DATEADD(MM, 1, @pDate)) END

GO
