-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_VIP_PGEChangeAccountClassandProducts]
	@VIP_Accountid int, @AccountClass varchar(20), @ProductBundle varchar(80) 
AS

declare @NewTransactionID bigint
declare @AccountClassID int
declare @ProductBundleID int
declare @SAID varchar(11)

Select @AccountClassID = (Select VIP_AccountClassID from VIP_AccountClasses where Code = @AccountClass)
Select @ProductBundleID = (Select VIP_ProductBundleID from VIP_ProductBundles where Code = @ProductBundle)
Select @SAID = (Select UtilityServiceAccountID from VIP_Accounts where VIP_AccountID = @VIP_Accountid)

--Update the account class id
update VIP_Accounts set VIP_AccountClassID = @AccountClassID, VIP_ProductBundleID = @ProductBundleID where VIP_AccountID = @VIP_Accountid
--update VIP_Accounts set AccountStatus = 'Enrolling', VIP_AccountClassID = @AccountClassID where VIP_AccountID = @VIP_Accountid

--SET THE END DATE OF THE FIRST account product
update VIP_AccountProducts set EndDate = DATEADD(D,-1, GETDATE())
where VIP_AccountProductID in
(
	Select MIN(VIP_AccountProductID) from VIP_AccountProducts where VIP_AccountID = @VIP_Accountid
)

--remove the last account product being that it will never flip to this one
declare @AcctProdCount int
Select @AcctProdCount = (Select COUNT(*) from VIP_AccountProducts where VIP_AccountID = @VIP_Accountid)
if @AcctProdCount > 1 
begin
	delete VIP_AccountProducts where VIP_AccountProductID in
	(
		Select MAX(VIP_AccountProductID) from VIP_AccountProducts where VIP_AccountID = @VIP_Accountid
	)
end

--add new account products
Insert Into VIP_AccountProducts
(VIP_AccountID, VIP_ProductID, UtilityCode, RetailerCode, FixedPrice, VariableAdder, ServiceFeeAmount, BandwidthMaxPercentage, BandwidthAdder, StartDate, EndDate)
Select @VIP_Accountid, a.VIP_ProductID,'PGE', b.RetailerProductCode, b.DefaultFixedPrice, b.DefaultVariableAdder,
b.ServiceFeeAmount, b.BandwidthPercentage, b.DefaultBandwidthAdder,
 case a.sequence
	when 1 THEN
		getdate()
	when 2 THEN
		DATEADD(mm, 1, getdate())
 end as StartDate,
 case a.sequence
	when 1 THEN
		DATEADD(mm, a.Months, getdate() - 1)
	when 2 THEN
		DATEADD(mm, a.Months, getdate())
 end as EndDate
from dbo.VIP_ProductBundleItems a 
inner join dbo.VIP_Products b on b.VIP_ProductID= a.VIP_ProductID 
inner join VIP_ProductPricingTypes c on c.VIP_ProductPricingTypeID = b.VIP_ProductPricingTypeID 
inner join VIP_UnitsOfMeasure d ON d.VIP_UnitofMeasureID = b.VIP_UnitofMeasureID 
where  VIP_ProductBundleID = @ProductBundleID --2
order by a.sequence


---------
declare @ProductBundleCount int
Select @ProductBundleCount = (Select COUNT(*) from VIP_ProductBundleItems where VIP_ProductBundleID = @ProductBundleID)

if @ProductBundleCount > 1
begin
	insert into dbo.VIP_AccountProductsRateScheduleChange
	(VIP_AccountID, SAID, CurrentRateCode, ScheduledRateCode, Status)
	Select @VIP_Accountid, @SAID,
		(
			Select UtilityProductCode from vip_products where vip_productid in
			(
				Select VIP_ProductID from VIP_ProductBundleItems where VIP_ProductBundleID = a.VIP_ProductBundleID
				and Sequence = a.Items - 1
			)
		),
		(
			Select UtilityProductCode from vip_products where vip_productid in
			(
				Select VIP_ProductID from VIP_ProductBundleItems where VIP_ProductBundleID = a.VIP_ProductBundleID
				and Sequence = a.Items
			)
		), 'Initial'
	 from
	(
		Select VIP_Productbundleid, COUNT(*)	Items
		from VIP_ProductBundleItems where VIP_ProductBundleID = @ProductBundleID	 
		group by VIP_Productbundleid	
	) a
end



--Insert into VIP_AccountInteractions
--(VIP_AccountInteractionTypeID, VIP_AccountID, VIP_AccountInteractionGUID, InitiatedByUserID, Status, StartDateTime)
--values 
--((Select VIP_AccountInteractionTypeID from VIP_AccountInteractionTypes where Code = 'PRODUCT_CHANGE_RESUBMIT'), 
--@VIP_Accountid, newid(), 0, 'Pending', GETDATE())

--Select @NewTransactionID = @@IDENTITY

----add account interaction audit 
--Insert Into VIP_AccountInteractionAudit
--(VIP_AccountInteractionID, AuditType, AuditLevel, AuditMessage, AuditDateTime)
--Values
--(@NewTransactionID, 'Checkpoint', 'Medium', 'Account resubmitted', GETDATE())
GO
