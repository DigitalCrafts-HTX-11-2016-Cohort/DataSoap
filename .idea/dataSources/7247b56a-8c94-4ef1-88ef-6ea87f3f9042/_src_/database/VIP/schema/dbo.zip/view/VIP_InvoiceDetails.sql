
CREATE VIEW [dbo].[VIP_InvoiceDetails]
AS
SELECT i.*, bp.BillingAttentionTo, bp.DynamicsCustomerId
FROM VIP_Invoices i
	INNER JOIN VIP_BillingPoints bp ON i.VIP_BillingPointID = bp.VIP_BillingPointID


GO
