-- =============================================
-- Author: BRudd		
-- Create date: 2017-05-09
-- Description:	Authoring script from existing Welcome Letter proc.
-- =============================================

CREATE PROCEDURE dbo.usp_VIP_PGE_Authorization
(
	@VIP_AccountID INT
)
AS ;
    WITH    
            tblFirstAccountProductForAccount
              AS ( SELECT   ap.*
                   FROM     dbo.VIP_AccountProducts ap
                            INNER JOIN ( SELECT StartDate_MIN = MIN(ap.StartDate) ,
                                                ap.VIP_AccountID
                                         FROM   dbo.VIP_AccountProducts ap
                                         GROUP BY ap.VIP_AccountID
                                       ) apMinDate ON ap.VIP_AccountID = apMinDate.VIP_AccountID
                                                      AND ap.StartDate = apMinDate.StartDate_MIN
                 )

,           tblAllInfo_WithRowRank
              AS ( SELECT   a.VIP_AccountID ,
                            b.UtilityServiceAccountID ,
                            b.UtilityAccountNumber ,
                            b.BillingFirstName ,
                            b.BillingLastName ,
                            b.BillingAddress1 ,
                            CASE WHEN BillingAddress2 LIKE '%Apt%'
                                      AND b.VIP_AccountClassID = 1
                                 THEN BillingAddress2
                                 WHEN b.VIP_AccountClassID = 1
                                      AND BillingAddress2 <> ''
                                 THEN 'Apt ' + BillingAddress2
                                 ELSE BillingAddress2
                            END AS BillingAddress2 ,
                            RTRIM(b.BillingCity) BillingCity ,
                            RTRIM(b.BillingState) BillingState ,
                            LEFT(b.BillingZipCode, 5) BillingZipCode ,
                            b.CompanyName ,
                            CONVERT(VARCHAR(12), GETDATE(), 107) DocumentDate ,
                            c.Code Utility ,
                            d.Code AccountClass ,
                            e.Code MarketerCode ,
                            b.Spanish ,
                            f.Code ProductBundle ,
                            c.VIP_UtilityID ,
                            d.VIP_AccountClassID ,
                            e.VIP_MarketerID ,
                            b.VIP_ProductBundleID ,
							a.VIP_AccountInteractionID ,
                            a.VIP_AccountInteractionGUID

	--------------------------------
                            ,
                            CONVERT(VARCHAR(10), c.VIP_UtilityID) + '|'
                            + CONVERT(VARCHAR(10), d.VIP_AccountClassID) + '|'
                            + CONVERT(VARCHAR(10), e.VIP_MarketerID) + '|'
                            + CONVERT(VARCHAR(10), b.Spanish) + '|'
                            + CONVERT(VARCHAR(10), b.VIP_ProductBundleID) WelcomeLetter1 ,
                            CONVERT(VARCHAR(10), c.VIP_UtilityID) + '|'
                            + CONVERT(VARCHAR(10), d.VIP_AccountClassID) + '|'
                            + CONVERT(VARCHAR(10), e.VIP_MarketerID) + '|'
                            + CONVERT(VARCHAR(10), b.Spanish) + '|' + '0' WelcomeLetter2 , --have marketer, any product buncld id
                            CONVERT(VARCHAR(10), c.VIP_UtilityID) + '|'
                            + CONVERT(VARCHAR(10), d.VIP_AccountClassID) + '|'
                            + '0|' + --marketer code defualt to 0
	CONVERT(VARCHAR(10), b.Spanish) WelcomeLetter3 , --default -> any product bundle id, any marketer
                            CONVERT(VARCHAR(10), c.VIP_UtilityID) + '|'
                            + CONVERT(VARCHAR(10), d.VIP_AccountClassID) + '|'
                            + '0' + '|' + -- any marketer
	CONVERT(VARCHAR(10), b.Spanish) + '|'
                            + CONVERT(VARCHAR(10), b.VIP_ProductBundleID) WelcomeLetter4 --any marketer, but specific product bundle id

	---------------------------------
                            ,
                            FixedPrice = '$'
                            + CONVERT(VARCHAR, CONVERT(FLOAT, apFirst.FixedPrice)) ,
                            FixedBill_Amount = '$'
                            + CONVERT(VARCHAR, CONVERT(DECIMAL(18, 2), apFirst.FixedBill_Amount)) ,
                            UnitOfMeasure = uom.Name ,
                            TermLengthInMonths = DATEDIFF(MONTH,
                                                          apFirst.StartDate,
                                                          apFirst.EndDate) ,
                            CustomerEmailAddress = b.BillingEmail ,
                            StartDate = CONVERT(VARCHAR(50), apFirst.StartDate, 1) ,
                            salesDateplus6months = CONVERT(VARCHAR(12), DATEADD(MONTH,
                                                              6, b.DateSold), 107) ,
                            salesDateplus18months = CONVERT(VARCHAR(12), DATEADD(MONTH,
                                                              18, b.DateSold), 107) ,
                            f.Name AS ProductBundleName 
							, com.Name AS Commodity 
							, (SELECT CONVERT(VARCHAR(21), CurrentAccountProduct_EndDate, 107) FROM Products.mv_VIP_CumulativeAccountProductsView WHERE VIP_AccountID = b.VIP_AccountID) AS Product_Expiration_Date
							, renewalType.DocumentTemplate_KeyName
							--, CONVERT(VARCHAR(21),DATEADD(DAY, 30,GETDATE()), 107) AS Product_Expiration_Date --this is only while unit testing, 
                   FROM     VIP_AccountInteractions a
                            INNER JOIN VIP_Accounts b ON b.VIP_AccountID = a.VIP_AccountID
                            INNER JOIN AccountServicePoint.VIP_Account_AddressView addressView ON addressView.VIP_AccountID = b.VIP_AccountID -- 2017-01-23 - BPanjavan - Make sure they HAVE a copmlete address
                                                              AND addressView.IsBillingAddressComplete = 1
                            INNER JOIN VIP_Utilities c ON c.VIP_UtilityID = b.VIP_UtilityID
							INNER JOIN dbo.VIP_Commodities com ON com.VIP_CommodityID = c.VIP_CommodityID
                            INNER JOIN VIP_AccountClasses d ON d.VIP_AccountClassID = b.VIP_AccountClassID
                            INNER JOIN VIP_Marketers e ON e.VIP_MarketerID = b.VIP_MarketerID
                            INNER JOIN VIP_ProductBundles f ON b.VIP_ProductBundleID = f.VIP_ProductBundleID
                            INNER JOIN tblFirstAccountProductForAccount apFirst ON apFirst.VIP_AccountID = a.VIP_AccountID
                            INNER JOIN VIP_Products prod ON apFirst.VIP_ProductID = prod.VIP_ProductID
                            INNER JOIN VIP_UnitsOfMeasure uom ON prod.VIP_UnitOfMeasureID = uom.VIP_UnitOfMeasureID
							INNER JOIN dbo.VIP_AccountClasses class ON class.VIP_AccountClassID = b.VIP_AccountClassID
							INNER JOIN dbo.RenewalLetter_Matrix renewalType ON renewalType.VIP_AccountInteractionTypeID = a.VIP_AccountInteractionTypeID
																			   AND (renewalType.ServiceState = b.ServiceState OR renewalType.ServiceState = 'ALL')
																			   AND (renewalType.UtilityCode = apFirst.UtilityCode OR renewalType.UtilityCode = 'ALL')
																			   AND (renewalType.AccountClass = class.Code OR renewalType.AccountClass = 'ALL')
																			   AND (renewalType.Commodity = com.Code OR renewalType.Commodity = 'ALL')
                   WHERE    a.VIP_AccountID = @VIP_AccountID
							--a.VIP_AccountInteractionTypeID IN (
       --                     SELECT DISTINCT VIP_AccountInteractionTypeID FROM dbo.RenewalLetter_Matrix)
       --                     AND Status = 'Pending'

                 )
        SELECT TOP 10000
                VIP_AccountID ,
                UtilityServiceAccountID ,
                UtilityAccountNumber ,
                BillingFirstName ,
                BillingLastName ,
                BillingAddress1 ,
                BillingAddress2 ,
                BillingCity ,
                BillingState ,
                BillingZipCode ,
                CompanyName ,
                DocumentDate ,
                Utility ,
                AccountClass ,
                MarketerCode ,
                Spanish ,
                ProductBundle ,
                VIP_UtilityID ,
                VIP_AccountClassID ,
                VIP_MarketerID ,
                VIP_ProductBundleID ,
				VIP_AccountInteractionID ,
                VIP_AccountInteractionGUID ,
                WelcomeLetter1 ,
                WelcomeLetter2 ,
                WelcomeLetter3 ,
                WelcomeLetter4 ,
                FixedPrice ,
                FixedBill_Amount ,
                UnitOfMeasure ,
                TermLengthInMonths ,
                CustomerEmailAddress ,
                StartDate ,
                salesDateplus6months ,
                salesDateplus18months ,
                ProductBundleName,
				Commodity ,
				Product_Expiration_Date,
				DocumentTemplate_KeyName
        FROM    tblAllInfo_WithRowRank
        WHERE   ( 1 = 1 )


GO
