
create procedure dbo.GetSystemMessage

@PortalID     int,
@MessageName  nvarchar(50)

as

select MessageValue
from   dbo.SystemMessages
where  ((PortalID = @PortalID) or (PortalID is null and @PortalID is null)) 
and    MessageName = @MessageName


GO
