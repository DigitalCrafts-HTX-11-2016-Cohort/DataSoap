
CREATE PROCEDURE dbo.[GetModulePermissionsByTabID]
	
	@TabID int

AS
SELECT *
FROM dbo.vw_ModulePermissions MP
	INNER JOIN dbo.TabModules TM on MP.ModuleID = TM.ModuleID
WHERE  TM.TabID = @TabID

GO
