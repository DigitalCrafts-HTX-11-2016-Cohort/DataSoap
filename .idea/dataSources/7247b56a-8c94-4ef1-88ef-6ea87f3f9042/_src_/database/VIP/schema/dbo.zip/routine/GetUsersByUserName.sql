
CREATE PROCEDURE dbo.[GetUsersByUserName]
    @PortalID			int,
    @UserNameToMatch	nvarchar(256),
    @PageIndex			int,
    @PageSize			int
AS
BEGIN
    -- Set the page bounds
    DECLARE @PageLowerBound INT
    DECLARE @PageUpperBound INT
    SET @PageLowerBound = @PageSize * @PageIndex
    SET @PageUpperBound = @PageSize - 1 + @PageLowerBound

    -- Create a temp table TO store the select results
    CREATE TABLE #PageIndexForUsers
    (
        IndexId int IDENTITY (0, 1) NOT NULL,
        UserId int
    )

    -- Insert into our temp table
    INSERT INTO #PageIndexForUsers (UserId)
        SELECT UserId FROM	dbo.vw_Users 
        WHERE  Username LIKE @UserNameToMatch
			AND ( PortalId = @PortalID OR (PortalId Is Null AND @PortalID is null ))
	    ORDER BY UserName

    SELECT  *
    FROM	dbo.vw_Users u, 
			#PageIndexForUsers p
    WHERE  u.UserId = p.UserId
			AND ( PortalId = @PortalID OR (PortalId Is Null AND @PortalID is null ))
			AND p.IndexId >= @PageLowerBound AND p.IndexId <= @PageUpperBound
    ORDER BY u.UserName

    SELECT  TotalRecords = COUNT(*)
    FROM    #PageIndexForUsers
END


GO
