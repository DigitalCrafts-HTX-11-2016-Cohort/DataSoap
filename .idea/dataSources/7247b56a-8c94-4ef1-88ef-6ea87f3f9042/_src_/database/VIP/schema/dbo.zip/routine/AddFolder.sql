
CREATE PROCEDURE dbo.AddFolder

	@PortalID int,
	@FolderPath varchar(300),
	@StorageLocation int,
	@IsProtected bit,
	@IsCached bit,
	@LastUpdated datetime

AS

INSERT INTO dbo.Folders (
  PortalID, 
  FolderPath, 
  StorageLocation, 
  IsProtected, 
  IsCached, 
  LastUpdated
)
VALUES (
  @PortalID, 
  @FolderPath, 
  @StorageLocation, 
  @IsProtected, 
  @IsCached, 
  @LastUpdated
)

SELECT SCOPE_IDENTITY()


GO
