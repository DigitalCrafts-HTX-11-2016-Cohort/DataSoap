
CREATE procedure dbo.UpdatePortalAliasOnInstall

@PortalAlias nvarchar(200)

as

update dbo.PortalAlias 
set    HTTPAlias = @PortalAlias
where  HTTPAlias = '_default'


GO
