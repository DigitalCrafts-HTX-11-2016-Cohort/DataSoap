
-- =============================================
-- Author:		Bryan Panjavan
-- Create date: Sometime before 2012-06-01
-- Description:	Cleans up unprocessed invoices, even ones that JUST got created...
--	2013-09-27 - Added the logic with @invoiceID_DeleteThisAndPrior so we don't delete invoices that JUST got created...
-- =============================================
CREATE PROCEDURE [dbo].[usp_VIP_Cleanup_UnprocessedInvoices]
	
AS

DECLARE @invoiceID_DeleteThisAndPrior INT
SET @invoiceID_DeleteThisAndPrior = (SELECT TOP 1 VIP_InvoiceID FROM VIP_Invoices) - 100

--CLEAR THE INVOICE ITEMS
DELETE VIP_InvoiceItems where VIP_invoiceid in
(
	Select vip_invoiceid from VIP_Invoices where Status = 'Calculating' AND VIP_InvoiceID <= @invoiceID_DeleteThisAndPrior
)

--CLEAR THE INVOICE BREAKDOWNS
DELETE VIP_InvoiceBreakdowns where VIP_InvoiceID in
(
	Select vip_invoiceid from VIP_Invoices where Status = 'Calculating' AND VIP_InvoiceID <= @invoiceID_DeleteThisAndPrior
)

--CLEAR THE INVOICE
DELETE VIP_Invoices where Status = 'Calculating' AND VIP_InvoiceID <= @invoiceID_DeleteThisAndPrior

--RESET THE RECORD IN STAGING
UPDATE VIPMARKET_PGE_Billing SET Status = 'Pending' where STATUS = 'Processing'
GO
