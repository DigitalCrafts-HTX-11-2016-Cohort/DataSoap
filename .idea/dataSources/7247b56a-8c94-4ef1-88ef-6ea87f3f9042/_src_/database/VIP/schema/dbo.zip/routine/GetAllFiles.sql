
CREATE procedure dbo.[GetAllFiles]

AS

SELECT
	FileId,
             FO.PortalId,
             FileName,
             Extension,
             Size,
             Width,
             Height,
             ContentType,
             F.FolderID,
             'Folder' = FolderPath,
	     StorageLocation,
             IsCached
FROM 
	dbo.Files F

INNER JOIN 
	dbo.Folders FO on F.FolderID = FO.FolderID

GO
