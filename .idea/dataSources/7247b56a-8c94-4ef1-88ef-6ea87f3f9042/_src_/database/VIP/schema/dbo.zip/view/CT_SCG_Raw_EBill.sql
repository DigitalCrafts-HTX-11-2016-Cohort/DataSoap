CREATE VIEW CT_SCG_Raw_EBill as select * from VIPMARKET_SCG_EBill (nolock)
GO
