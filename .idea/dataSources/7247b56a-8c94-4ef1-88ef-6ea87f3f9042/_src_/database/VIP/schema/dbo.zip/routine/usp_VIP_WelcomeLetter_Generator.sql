-- =============================================
-- Author:		Bryan Panjavan
-- Create date: 2013-08-19
-- Description:	Authoring script from existing WL proc

--	2013-08-19 - Added search by product without marketer, incorporated into code
-- 2014-02-04 - BPanjavan - re-wrote the join logic.  Look at the previous version and you'll understand.
				-- Oh and also added fields for HTML template

-- 2014-03-14 - BPanjavan - Added StartDate
-- 2014-05-30 - BPanjavan - Added Fixed Bill
-- 2014-05-18 - BPanjavan - Filter OUT Welcome Letter type: EMAIL_ENROLLMENT_CONFIRMATION
-- 2015-07-22 - BPanjavan - Changes for Date Sold plus 6 months and 18 months
-- 2017-01-23 - BPanjavan - For the incomplete AEP Accounts, I added this line to make sure we don't import unless the Billing Address is complete:
		--INNER JOIN AccountServicePoint.VIP_Account_AddressView addressView ON addressView.VIP_AccountID = b.VIP_AccountID -- 2017-01-23 - BPanjavan - Make sure they HAVE a copmlete address
		--																	AND addressView.IsBillingAddressComplete = 1
-- =============================================

CREATE PROCEDURE usp_VIP_WelcomeLetter_Generator
AS ;
    WITH    tblVIP_WelcomeLetterManager_FilteredForWelcomeLetters
              AS ( SELECT   *
                   FROM     dbo.VIP_WelcomeLetterManager
                   WHERE    ISNULL(TemplateType, '') <> 'EMAIL_ENROLLMENT_CONFIRMATION'
                 ),
            tblFirstAccountProductForAccount
              AS ( SELECT   ap.*
                   FROM     dbo.VIP_AccountProducts ap
                            INNER JOIN ( SELECT StartDate_MIN = MIN(ap.StartDate) ,
                                                ap.VIP_AccountID
                                         FROM   dbo.VIP_AccountProducts ap
                                         GROUP BY ap.VIP_AccountID
                                       ) apMinDate ON ap.VIP_AccountID = apMinDate.VIP_AccountID
                                                      AND ap.StartDate = apMinDate.StartDate_MIN
                 )--Select TOP 10000
--	*,
--ISNULL(
--(
--	Select WelcomeLetterFileName from VIP_WelcomeLetterManager
--	where CONVERT(varchar(10), VIP_UtilityID) + '|' +
--	CONVERT(varchar(10), VIP_AccountClassID) + '|' +
--	CONVERT(varchar(10), VIP_MarketerCodeID) + '|' +
--	CONVERT(varchar(10), Spanish) + '|' + 
--	CONVERT(varchar(10), vip_ProductBundleID)
--	= a.WelcomeLetter1
--),'') UtilityAccountClassMarketerCodeProductBundle,
--ISNULL(
--(	
--	Select WelcomeLetterFileName from VIP_WelcomeLetterManager
--	where CONVERT(varchar(10), VIP_UtilityID) + '|' +
--	CONVERT(varchar(10), VIP_AccountClassID) + '|' +
--	CONVERT(varchar(10), VIP_MarketerCodeID) + '|' +
--	CONVERT(varchar(10), Spanish) + '|' +
--	CONVERT(varchar(10), VIP_ProductBundleID)
--	= a.WelcomeLetter2
--),'') UtilityAccountClassMarketerCode,
--ISNULL(
--(	
--	Select TOP 1 WelcomeLetterFileName from VIP_WelcomeLetterManager
--	where CONVERT(varchar(10), VIP_UtilityID) + '|' +
--	CONVERT(varchar(10), VIP_AccountClassID) + '|' +
--	CONVERT(varchar(10), VIP_MarketerCodeID) + '|' +
--	CONVERT(varchar(10), Spanish)	
--	= a.WelcomeLetter3
--),'') DefaultFile,
--ISNULL(
--(	
--	Select WelcomeLetterFileName from VIP_WelcomeLetterManager
--	where CONVERT(varchar(10), VIP_UtilityID) + '|' +
--	CONVERT(varchar(10), VIP_AccountClassID) + '|' +
--	CONVERT(varchar(10), VIP_MarketerCodeID) + '|' +
--	CONVERT(varchar(10), Spanish) + '|' +
--	CONVERT(varchar(10), VIP_ProductBundleID)
--	= a.WelcomeLetter4
--),'') UtilityAccountClassProductBundle
--from 
--(

,           tblAllInfo_WithRowRank
              AS ( SELECT   a.VIP_AccountID ,
                            b.UtilityServiceAccountID ,
                            b.UtilityAccountNumber ,
                            b.BillingFirstName ,
                            b.BillingLastName ,
                            b.BillingAddress1 ,
                            CASE WHEN BillingAddress2 LIKE '%Apt%'
                                      AND b.VIP_AccountClassID = 1
                                 THEN BillingAddress2
                                 WHEN b.VIP_AccountClassID = 1
                                      AND BillingAddress2 <> ''
                                 THEN 'Apt ' + BillingAddress2
                                 ELSE BillingAddress2
                            END AS BillingAddress2 ,
                            RTRIM(b.BillingCity) BillingCity ,
                            RTRIM(b.BillingState) BillingState ,
                            LEFT(b.BillingZipCode, 5) BillingZipCode ,
                            b.CompanyName ,
                            CONVERT(VARCHAR(12), GETDATE(), 107) DocumentDate ,
                            c.Code Utility ,
                            d.Code AccountClass ,
                            e.Code MarketerCode ,
                            b.Spanish ,
                            f.Code ProductBundle ,
                            CASE 
								WHEN f.VIP_ProductBundleID = 715 
								THEN 'NICOR_RESIDENTIAL_WELCOME_LETTER_6PGS' 
								ELSE c.Code + '_' + d.Code + '_WELCOME_LETTER' 
							END AS docType ,
                            c.VIP_UtilityID ,
                            d.VIP_AccountClassID ,
                            e.VIP_MarketerID ,
                            b.VIP_ProductBundleID ,
                            a.VIP_AccountInteractionGUID

	--CONVERT(varchar(10), c.VIP_UtilityID) + '|' +
	--CONVERT(varchar(10), d.VIP_AccountClassID) + '|' +
	--CONVERT(varchar(10), e.VIP_MarketerID) + '|' +
	--CONVERT(varchar(10), b.Spanish) + '|' +
	--CONVERT(varchar(10), b.VIP_ProductBundleID) WelcomeLetter1,
			
	--CONVERT(varchar(10), c.VIP_UtilityID) + '|' +
	--CONVERT(varchar(10), d.VIP_AccountClassID) + '|' +
	--CONVERT(varchar(10), e.VIP_MarketerID) + '|' +
	--CONVERT(varchar(10), b.Spanish) + '|' + '0' WelcomeLetter2, --have marketer, any product buncld id
	
	--CONVERT(varchar(10), c.VIP_UtilityID) + '|' +
	--CONVERT(varchar(10), d.VIP_AccountClassID) + '|' +	
	--'0|' + --marketer code defualt to 0
	--CONVERT(varchar(10), b.Spanish) WelcomeLetter3, --default -> any product bundle id, any marketer

	--CONVERT(varchar(10), c.VIP_UtilityID) + '|' +
	--CONVERT(varchar(10), d.VIP_AccountClassID) + '|' +
	--'0' + '|' + -- any marketer
	--CONVERT(varchar(10), b.Spanish) + '|'  +
	--CONVERT(varchar(10), b.VIP_ProductBundleID) WelcomeLetter4 --any marketer, but specific product bundle id


	--------------------------------
                            ,
                            CONVERT(VARCHAR(10), c.VIP_UtilityID) + '|'
                            + CONVERT(VARCHAR(10), d.VIP_AccountClassID) + '|'
                            + CONVERT(VARCHAR(10), e.VIP_MarketerID) + '|'
                            + CONVERT(VARCHAR(10), b.Spanish) + '|'
                            + CONVERT(VARCHAR(10), b.VIP_ProductBundleID) WelcomeLetter1 ,
                            CONVERT(VARCHAR(10), c.VIP_UtilityID) + '|'
                            + CONVERT(VARCHAR(10), d.VIP_AccountClassID) + '|'
                            + CONVERT(VARCHAR(10), e.VIP_MarketerID) + '|'
                            + CONVERT(VARCHAR(10), b.Spanish) + '|' + '0' WelcomeLetter2 , --have marketer, any product buncld id
                            CONVERT(VARCHAR(10), c.VIP_UtilityID) + '|'
                            + CONVERT(VARCHAR(10), d.VIP_AccountClassID) + '|'
                            + '0|' + --marketer code defualt to 0
	CONVERT(VARCHAR(10), b.Spanish) WelcomeLetter3 , --default -> any product bundle id, any marketer
                            CONVERT(VARCHAR(10), c.VIP_UtilityID) + '|'
                            + CONVERT(VARCHAR(10), d.VIP_AccountClassID) + '|'
                            + '0' + '|' + -- any marketer
	CONVERT(VARCHAR(10), b.Spanish) + '|'
                            + CONVERT(VARCHAR(10), b.VIP_ProductBundleID) WelcomeLetter4 --any marketer, but specific product bundle id

	---------------------------------
                            ,
                            FixedPrice = '$'
                            + CONVERT(VARCHAR, CONVERT(FLOAT, apFirst.FixedPrice)) ,
                            FixedBill_Amount = '$'
                            + CONVERT(VARCHAR, CONVERT(DECIMAL(18, 2), apFirst.FixedBill_Amount)) ,
                            UnitOfMeasure = uom.Name ,
                            TermLengthInMonths = DATEDIFF(MONTH,
                                                          apFirst.StartDate,
                                                          apFirst.EndDate) ,
                            CustomerEmailAddress = b.BillingEmail ,
                            UtilityAccountClassMarketerCodeProductBundle = ISNULL(wm1.WelcomeLetterFileName,
                                                              '') ,
                            UtilityAccountClassMarketerCode = ISNULL(wm2.WelcomeLetterFileName,
                                                              '') ,
                            DefaultFile = ISNULL(wm3.WelcomeLetterFileName, '') ,
                            UtilityAccountClassProductBundle = ISNULL(wm4.WelcomeLetterFileName,
                                                              '') ,
                            Row_Number_WelcomeManagerID = ROW_NUMBER() OVER ( PARTITION BY b.VIP_AccountID ORDER BY wm1.VIP_WelcomeLetterManagerID, wm2.VIP_WelcomeLetterManagerID, wm3.VIP_WelcomeLetterManagerID, wm4.VIP_WelcomeLetterManagerID ) ,
                            VIP_WelcomeLetterManagerID = 
		-- Mimic the priority order that's in the code
                            COALESCE(wm1.VIP_WelcomeLetterManagerID,
                                     wm2.VIP_WelcomeLetterManagerID,
                                     wm4.VIP_WelcomeLetterManagerID,
                                     wm3.VIP_WelcomeLetterManagerID) ,
                            StartDate = CONVERT(VARCHAR(50), apFirst.StartDate, 1) ,
                            salesDateplus6months = CONVERT(VARCHAR(12), DATEADD(MONTH,
                                                              6, b.DateSold), 107) ,
                            salesDateplus18months = CONVERT(VARCHAR(12), DATEADD(MONTH,
                                                              18, b.DateSold), 107) ,
                            f.Name AS ProductBundleName
                   FROM     VIP_AccountInteractions a
                            INNER JOIN VIP_Accounts b ON b.VIP_AccountID = a.VIP_AccountID
                            INNER JOIN AccountServicePoint.VIP_Account_AddressView addressView ON addressView.VIP_AccountID = b.VIP_AccountID -- 2017-01-23 - BPanjavan - Make sure they HAVE a copmlete address
                                                              AND addressView.IsBillingAddressComplete = 1
                            INNER JOIN VIP_Utilities c ON c.VIP_UtilityID = b.VIP_UtilityID
                            INNER JOIN VIP_AccountClasses d ON d.VIP_AccountClassID = b.VIP_AccountClassID
                            INNER JOIN VIP_Marketers e ON e.VIP_MarketerID = b.VIP_MarketerID
                            INNER JOIN VIP_ProductBundles f ON b.VIP_ProductBundleID = f.VIP_ProductBundleID
                            INNER JOIN tblFirstAccountProductForAccount apFirst ON apFirst.VIP_AccountID = a.VIP_AccountID
                            INNER JOIN VIP_Products prod ON apFirst.VIP_ProductID = prod.VIP_ProductID
                            INNER JOIN VIP_UnitsOfMeasure uom ON prod.VIP_UnitOfMeasureID = uom.VIP_UnitOfMeasureID
                            LEFT JOIN tblVIP_WelcomeLetterManager_FilteredForWelcomeLetters wm1 ON wm1.VIP_UtilityID = c.VIP_UtilityID
                                                              AND wm1.VIP_AccountClassID = b.VIP_AccountClassID
                                                              AND wm1.VIP_MarketerCodeID = e.VIP_MarketerID
                                                              AND wm1.Spanish = b.Spanish
                                                              AND wm1.VIP_ProductBundleID = b.VIP_ProductBundleID
                            LEFT JOIN tblVIP_WelcomeLetterManager_FilteredForWelcomeLetters wm2 ON wm2.VIP_UtilityID = c.VIP_UtilityID
                                                              AND wm2.VIP_AccountClassID = b.VIP_AccountClassID
                                                              AND wm2.VIP_MarketerCodeID = e.VIP_MarketerID
                                                              AND wm2.Spanish = b.Spanish
                                                              AND wm2.VIP_ProductBundleID = 0
                            LEFT JOIN tblVIP_WelcomeLetterManager_FilteredForWelcomeLetters wm3 ON wm3.VIP_UtilityID = c.VIP_UtilityID
                                                              AND wm3.VIP_AccountClassID = b.VIP_AccountClassID
                                                              AND wm3.Spanish = b.Spanish
                                                              AND wm3.VIP_MarketerCodeID = 0
                                                              AND wm3.VIP_ProductBundleID = 0
                            LEFT JOIN tblVIP_WelcomeLetterManager_FilteredForWelcomeLetters wm4 ON wm4.VIP_UtilityID = c.VIP_UtilityID
                                                              AND wm4.VIP_AccountClassID = b.VIP_AccountClassID
                                                              AND wm4.Spanish = b.Spanish
                                                              AND wm4.VIP_MarketerCodeID = 0
                                                              AND wm4.VIP_ProductBundleID = b.VIP_ProductBundleID
                   WHERE    VIP_AccountInteractionTypeID IN (
                            SELECT  VIP_AccountInteractionTypeID
                            FROM    VIP_AccountInteractionTypes
                            WHERE   Code = 'GENERATE_WELCOME_LETTER' )
                            AND Status = 'Pending'

--	AND c.Code = 'NICOR' AND b.UtilityAccountNumber = '5932908965'

--) a
                 )
        SELECT TOP 10000
                VIP_AccountID ,
                UtilityServiceAccountID ,
                UtilityAccountNumber ,
                BillingFirstName ,
                BillingLastName ,
                BillingAddress1 ,
                BillingAddress2 ,
                BillingCity ,
                BillingState ,
                BillingZipCode ,
                CompanyName ,
                DocumentDate ,
                Utility ,
                AccountClass ,
                MarketerCode ,
                tblAllInfo_WithRowRank.Spanish ,
                ProductBundle ,
                docType ,
                tblAllInfo_WithRowRank.VIP_UtilityID ,
                tblAllInfo_WithRowRank.VIP_AccountClassID ,
                VIP_MarketerID ,
                tblAllInfo_WithRowRank.VIP_ProductBundleID ,
                VIP_AccountInteractionGUID ,
                WelcomeLetter1 ,
                WelcomeLetter2 ,
                WelcomeLetter3 ,
                WelcomeLetter4 ,
                FixedPrice ,
                FixedBill_Amount ,
                UnitOfMeasure ,
                TermLengthInMonths ,
                CustomerEmailAddress ,
                UtilityAccountClassMarketerCodeProductBundle ,
                UtilityAccountClassMarketerCode ,
                DefaultFile ,
                UtilityAccountClassProductBundle ,
                wmFinal.TemplateType ,
                wmFinal.EmailAttachmentFile_1 ,
                wmFinal.EmailAttachmentFile_2 ,
                wmFinal.EmailAttachmentFile_3 ,
                wmFinal.EmailAttachmentFile_4 ,
                wmFinal.EmailAttachmentFile_5 ,
                StartDate ,
                salesDateplus6months ,
                salesDateplus18months ,
                ProductBundleName
        FROM    tblAllInfo_WithRowRank
                LEFT JOIN dbo.VIP_WelcomeLetterManager wmFinal ON tblAllInfo_WithRowRank.VIP_WelcomeLetterManagerID = wmFinal.VIP_WelcomeLetterManagerID
        WHERE   ( 1 = 1 )
                AND ISNULL(Row_Number_WelcomeManagerID, 1) = 1


--ORDER BY VIP_AccountID DESC


GO
