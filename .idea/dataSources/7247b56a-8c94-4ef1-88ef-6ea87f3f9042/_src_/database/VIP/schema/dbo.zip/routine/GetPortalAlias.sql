

CREATE procedure dbo.GetPortalAlias

@HTTPAlias nvarchar(200),
@PortalID int

as

select *
from dbo.PortalAlias
where HTTPAlias = @HTTPAlias 
and PortalID = @PortalID


GO
