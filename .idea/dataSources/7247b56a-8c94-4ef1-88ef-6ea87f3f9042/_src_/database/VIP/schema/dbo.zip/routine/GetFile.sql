
CREATE procedure dbo.GetFile

@FileName  nvarchar(100),
@PortalID  int,
@FolderID  int

as

select FileId,
       dbo.Folders.PortalId,
       FileName,
       Extension,
       Size,
       Width,
       Height,
       ContentType,
       dbo.Files.FolderID,
       'Folder' = FolderPath,
       StorageLocation,
       IsCached
from dbo.Files
inner join dbo.Folders on dbo.Files.FolderID = dbo.Folders.FolderID
where  FileName = @FileName 
and    dbo.Files.FolderID = @FolderID
and    ((dbo.Folders.PortalId = @PortalID) or (@PortalID is null and dbo.Folders.PortalId is null))


GO
