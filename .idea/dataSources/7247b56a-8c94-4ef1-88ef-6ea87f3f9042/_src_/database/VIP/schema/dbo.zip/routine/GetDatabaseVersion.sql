
create procedure dbo.GetDatabaseVersion

as

select Major,
       Minor,
       Build
from   Version 
where  VersionId = ( select max(VersionId) from Version )

GO
