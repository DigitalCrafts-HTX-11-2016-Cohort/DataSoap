-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE usp_VIP_MarketerMonthlyUsage
	@MarketerID int
AS

Select case when SUM(NoOfAccounts) is null then 0 else SUM(NoOfAccounts) end NoOfAccounts,
case when SUM(Usage_12) is null then 0 else SUM(Usage_12) end Mnth12, 
case when SUM(Usage_11) is null then 0 else SUM(Usage_11) end Mnth11, 
case when SUM(Usage_10) is null then 0 else SUM(Usage_10) end Mnth10, 
case when SUM(Usage_9) is null then 0 else SUM(Usage_9) end Mnth9, 
case when SUM(Usage_8) is null then 0 else SUM(Usage_8) end Mnth8, 
case when SUM(Usage_7) is null then 0 else SUM(Usage_7) end Mnth7, 
case when SUM(Usage_6) is null then 0 else SUM(Usage_6) end Mnth6, 
case when SUM(Usage_5) is null then 0 else SUM(Usage_5) end Mnth5, 
case when SUM(Usage_4) is null then 0 else SUM(Usage_4) end Mnth4, 
case when SUM(Usage_3) is null then 0 else SUM(Usage_3) end Mnth3, 
case when SUM(Usage_2) is null then 0 else SUM(Usage_2) end Mnth2, 
case when SUM(Usage_1) is null then 0 else SUM(Usage_1) end Mnth1,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -11, GETDATE()), 100), 3) + '+' + CONVERT(varchar(4), YEAR(DATEADD(M, -11, GETDATE())))
) Label12,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -10, GETDATE()), 100), 3) + '+' + CONVERT(varchar(4), YEAR(DATEADD(M, -10, GETDATE())))
) Label11,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -9, GETDATE()), 100), 3) + '+' + CONVERT(varchar(4), YEAR(DATEADD(M, -9, GETDATE())))
) Label10,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -8, GETDATE()), 100), 3) + '+' + CONVERT(varchar(4), YEAR(DATEADD(M, -8, GETDATE())))
) Label9,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -7, GETDATE()), 100), 3) + '+' + CONVERT(varchar(4), YEAR(DATEADD(M, -7, GETDATE())))
) Label8,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -6, GETDATE()), 100), 3) + '+' + CONVERT(varchar(4), YEAR(DATEADD(M, -6, GETDATE())))
) Label7,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -5, GETDATE()), 100), 3) + '+' + CONVERT(varchar(4), YEAR(DATEADD(M, -5, GETDATE())))
) Label6,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -4, GETDATE()), 100), 3) + '+' + CONVERT(varchar(4), YEAR(DATEADD(M, -4, GETDATE())))
) Label5,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -3, GETDATE()), 100), 3) + '+' + CONVERT(varchar(4), YEAR(DATEADD(M, -3, GETDATE())))
) Label4,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -2, GETDATE()), 100), 3) + '+' + CONVERT(varchar(4), YEAR(DATEADD(M, -2, GETDATE())))
) Label3,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -1, GETDATE()), 100), 3) + '+' + CONVERT(varchar(4), YEAR(DATEADD(M, -1, GETDATE())))
) Label2,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, 0, GETDATE()), 100), 3) + '+' + CONVERT(varchar(4), YEAR(DATEADD(M, 0, GETDATE())))
) Label1,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -11, GETDATE()), 100), 3) + ' ' + CONVERT(varchar(4), YEAR(DATEADD(M, -11, GETDATE())))
) Header12,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -10, GETDATE()), 100), 3) + ' ' + CONVERT(varchar(4), YEAR(DATEADD(M, -10, GETDATE())))
) Header11,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -9, GETDATE()), 100), 3) + ' ' + CONVERT(varchar(4), YEAR(DATEADD(M, -9, GETDATE())))
) Header10,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -8, GETDATE()), 100), 3) + ' ' + CONVERT(varchar(4), YEAR(DATEADD(M, -8, GETDATE())))
) Header9,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -7, GETDATE()), 100), 3) + ' ' + CONVERT(varchar(4), YEAR(DATEADD(M, -7, GETDATE())))
) Header8,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -6, GETDATE()), 100), 3) + ' ' + CONVERT(varchar(4), YEAR(DATEADD(M, -6, GETDATE())))
) Header7,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -5, GETDATE()), 100), 3) + ' ' + CONVERT(varchar(4), YEAR(DATEADD(M, -5, GETDATE())))
) Header6,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -4, GETDATE()), 100), 3) + ' ' + CONVERT(varchar(4), YEAR(DATEADD(M, -4, GETDATE())))
) Header5,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -3, GETDATE()), 100), 3) + ' ' + CONVERT(varchar(4), YEAR(DATEADD(M, -3, GETDATE())))
) Header4,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -2, GETDATE()), 100), 3) + ' ' + CONVERT(varchar(4), YEAR(DATEADD(M, -2, GETDATE())))
) Header3,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, -1, GETDATE()), 100), 3) + ' ' + CONVERT(varchar(4), YEAR(DATEADD(M, -1, GETDATE())))
) Header2,
(
	SELECT left(CONVERT(VARCHAR(20), DATEADD(M, 0, GETDATE()), 100), 3) + ' ' + CONVERT(varchar(4), YEAR(DATEADD(M, 0, GETDATE())))
) Header1
from 
(
	Select --VIP_AccountID, UtilityAccountNumber, UtilityServiceAccountID, corecustomer, vip_utilityid, VIP_MarketerID,	
	(
		Select COUNT(*) from VIP_Accounts accts 
		where accts.VIP_MarketerID = Vip_accounts.VIP_MarketerID and AccountStatus = 'Enrolled'
	) NoOfAccounts,	
	CONVERT(decimal(9,2),
	(
		Select SUM(usageamount) from VIP_UsageBreakdownsView where VIP_UsageID in
		(
			Select vip_usageid from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID and VIP_UsageTypeID = 2
		) and CONVERT(VARCHAR(6), usagedate, 112) = CONVERT(VARCHAR(6), DATEADD(m, 0, GETDATE()) , 112)
	) /
	case when (Select TOP 1 UnitOfMeasure from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID) = 'THERMS' then 10 else 1 end	 
	) Usage_1,
	CONVERT(decimal(9,2),
	(
		Select SUM(usageamount) from VIP_UsageBreakdownsView where VIP_UsageID in
		(
			Select vip_usageid from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID and VIP_UsageTypeID = 2
		) and CONVERT(VARCHAR(6), usagedate, 112) = CONVERT(VARCHAR(6), DATEADD(m, -1, GETDATE()) , 112)
	) /
	case when (Select TOP 1 UnitOfMeasure from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID) = 'THERMS' then 10 else 1 end	 
	) Usage_2,	
	CONVERT(decimal(9,2),
	(
		Select SUM(usageamount) from VIP_UsageBreakdownsView where VIP_UsageID in
		(
			Select vip_usageid from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID and VIP_UsageTypeID = 2
		) and CONVERT(VARCHAR(6), usagedate, 112) = CONVERT(VARCHAR(6), DATEADD(m, -2, GETDATE()) , 112)
	) /
	case when (Select TOP 1 UnitOfMeasure from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID) = 'THERMS' then 10 else 1 end	 
	) Usage_3,
	CONVERT(decimal(9,2),
	(
		Select SUM(usageamount) from VIP_UsageBreakdownsView where VIP_UsageID in
		(
			Select vip_usageid from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID and VIP_UsageTypeID = 2
		) and CONVERT(VARCHAR(6), usagedate, 112) = CONVERT(VARCHAR(6), DATEADD(m, -3, GETDATE()) , 112)
	) /
	case when (Select TOP 1 UnitOfMeasure from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID) = 'THERMS' then 10 else 1 end	 
	) Usage_4,	
	CONVERT(decimal(9,2),
	(
		Select SUM(usageamount) from VIP_UsageBreakdownsView where VIP_UsageID in
		(
			Select vip_usageid from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID and VIP_UsageTypeID = 2
		) and CONVERT(VARCHAR(6), usagedate, 112) = CONVERT(VARCHAR(6), DATEADD(m, -4, GETDATE()) , 112)
	) /
	case when (Select TOP 1 UnitOfMeasure from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID) = 'THERMS' then 10 else 1 end	 
	) Usage_5,
	CONVERT(decimal(9,2),
	(
		Select SUM(usageamount) from VIP_UsageBreakdownsView where VIP_UsageID in
		(
			Select vip_usageid from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID and VIP_UsageTypeID = 2
		) and CONVERT(VARCHAR(6), usagedate, 112) = CONVERT(VARCHAR(6), DATEADD(m, -5, GETDATE()) , 112)
	) /
	case when (Select TOP 1 UnitOfMeasure from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID) = 'THERMS' then 10 else 1 end	 
	) Usage_6,	
	CONVERT(decimal(9,2),
	(
		Select SUM(usageamount) from VIP_UsageBreakdownsView where VIP_UsageID in
		(
			Select vip_usageid from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID and VIP_UsageTypeID = 2
		) and CONVERT(VARCHAR(6), usagedate, 112) = CONVERT(VARCHAR(6), DATEADD(m, -6, GETDATE()) , 112)
	) /
	case when (Select TOP 1 UnitOfMeasure from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID) = 'THERMS' then 10 else 1 end	 
	) Usage_7,
	CONVERT(decimal(9,2),
	(
		Select SUM(usageamount) from VIP_UsageBreakdownsView where VIP_UsageID in
		(
			Select vip_usageid from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID and VIP_UsageTypeID = 2
		) and CONVERT(VARCHAR(6), usagedate, 112) = CONVERT(VARCHAR(6), DATEADD(m, -7, GETDATE()) , 112)
	) /
	case when (Select TOP 1 UnitOfMeasure from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID) = 'THERMS' then 10 else 1 end	 
	) Usage_8,	
	CONVERT(decimal(9,2),
	(
		Select SUM(usageamount) from VIP_UsageBreakdownsView where VIP_UsageID in
		(
			Select vip_usageid from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID and VIP_UsageTypeID = 2
		) and CONVERT(VARCHAR(6), usagedate, 112) = CONVERT(VARCHAR(6), DATEADD(m, -8, GETDATE()) , 112)
	) /
	case when (Select TOP 1 UnitOfMeasure from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID) = 'THERMS' then 10 else 1 end	 
	) Usage_9,
	CONVERT(decimal(9,2),
	(
		Select SUM(usageamount) from VIP_UsageBreakdownsView where VIP_UsageID in
		(
			Select vip_usageid from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID and VIP_UsageTypeID = 2
		) and CONVERT(VARCHAR(6), usagedate, 112) = CONVERT(VARCHAR(6), DATEADD(m, -9, GETDATE()) , 112)
	) /
	case when (Select TOP 1 UnitOfMeasure from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID) = 'THERMS' then 10 else 1 end	 
	) Usage_10,	
	CONVERT(decimal(9,2),
	(
		Select SUM(usageamount) from VIP_UsageBreakdownsView where VIP_UsageID in
		(
			Select vip_usageid from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID and VIP_UsageTypeID = 2
		) and CONVERT(VARCHAR(6), usagedate, 112) = CONVERT(VARCHAR(6), DATEADD(m, -10, GETDATE()) , 112)
	) /
	case when (Select TOP 1 UnitOfMeasure from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID) = 'THERMS' then 10 else 1 end	 
	) Usage_11,
	CONVERT(decimal(9,2),
	(
		Select SUM(usageamount) from VIP_UsageBreakdownsView where VIP_UsageID in
		(
			Select vip_usageid from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID and VIP_UsageTypeID = 2
		) and CONVERT(VARCHAR(6), usagedate, 112) = CONVERT(VARCHAR(6), DATEADD(m, -11, GETDATE()) , 112)
	) /
	case when (Select TOP 1 UnitOfMeasure from VIP_Usage where VIP_AccountID = VIP_Accounts.VIP_AccountID) = 'THERMS' then 10 else 1 end	 
	) Usage_12
	 from VIP_Accounts where 
	 AccountStatus = 'Enrolled' --and	 
	-- VIP_MarketerID =
	--(
	--	Select VIP_MarketerID from VIP_Marketers where VIP_MarketerID = 14
	--)
	and VIP_Marketerid = @MarketerID
	--(
	--	Select VIP_MarketerAgentID from VIP_MarketerAgents where VIP_MarketerAgentID = @MarketerID
	--)
	--and VIP_MarketerID in
	--(
	--	Select VIP_MarketerID from dbo.VIP_MarketerCommissionTier
	--)
) a
GO
