
CREATE PROCEDURE dbo.[UpdateUser]

	@UserID         int,
	@PortalID		int,
	@FirstName		nvarchar(50),
	@LastName		nvarchar(50),
	@Email          nvarchar(256),
	@DisplayName    nvarchar(100),
	@UpdatePassword	bit,
	@Authorised		bit

AS
UPDATE dbo.Users
SET
	FirstName = @FirstName,
    LastName = @LastName,
    Email = @Email,
	DisplayName = @DisplayName,
	UpdatePassword = @UpdatePassword
WHERE  UserId = @UserID

UPDATE dbo.UserPortals
SET
	Authorised = @Authorised
WHERE  UserId = @UserID
	AND PortalId = @PortalID


GO
