
CREATE PROCEDURE dbo.[GetUsersByRolename]

	@PortalID	int,
	@Rolename	nvarchar(50)

AS

SELECT     
		U.UserID, 
		UP.PortalId, 
		U.Username, 
		U.FirstName, 
		U.LastName, 
		U.DisplayName, 
		U.IsSuperUser, 
		U.Email, 
		U.AffiliateId, 
		U.UpdatePassword
	FROM dbo.UserPortals AS UP 
			RIGHT OUTER JOIN dbo.UserRoles  UR 
			INNER JOIN dbo.Roles R ON UR.RoleID = R.RoleID 
			RIGHT OUTER JOIN dbo.Users AS U ON UR.UserID = U.UserID 
		ON UP.UserId = U.UserID	
	WHERE ( UP.PortalId = @PortalID OR @PortalID IS Null )
		AND (R.RoleName = @Rolename)
		AND (R.PortalId = @PortalID OR @PortalID IS Null )
	ORDER BY U.FirstName + ' ' + U.LastName


GO
