
CREATE VIEW dbo.[vw_Users]
AS
SELECT 
	U.UserId,
    UP.PortalId,
    U.Username,
    U.FirstName,
    U.LastName,
    U.DisplayName,
	U.IsSuperUser,
	U.Email,
    U.AffiliateId,
    U.UpdatePassword,
    UP.Authorised
FROM dbo.Users U
	LEFT OUTER JOIN dbo.UserPortals UP On U.UserId = UP.UserId

GO
