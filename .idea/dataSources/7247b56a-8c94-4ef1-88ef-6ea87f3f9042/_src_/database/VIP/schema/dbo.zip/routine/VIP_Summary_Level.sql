-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE VIP_Summary_Level
@Year int
AS
Select a.Mnth, a.Yr, a.yrmnth, ac.code, ac.vip_accountclassid,
(
	--pending enrollment
	Select COUNT(*) from VIP_Accounts where 
	AccountStatus = 'Pending Enrollment' and YEAR(datesold) = a.yr and MONTH(datesold) = a.Mnth
	and CoreCustomer = 1 and VIP_UtilityID = 1 and VIP_AccountClassID = ac.VIP_AccountClassID
	and VIP_MarketerID in(2,5)
) Pending_Enrollment,
(
	--enrolling
	Select count(*) from VIP_Accounts where AccountStatus = 'Enrolling' and UtilityServiceAccountID
	in(
		Select ReceiverCustomerID from VIPMARKET_PGE_DASR 
		 where OperationType = 'SP-REQ'
		 and TimeStamp like a.yrmnth + '%'
	  )
	 and VIP_AccountClassID = ac.VIP_AccountClassID
	 and VIP_MarketerID in(2,5) and CoreCustomer = 1
) Enrolling,
(
	--enrolled
	Select COUNT(*) from VIP_Accounts where --AccountStatus = 'Enrolled' and
	UtilityServiceAccountID in
	(
		Select SenderCustomerID from VIPMARKET_PGE_DASR 
		 where OperationType = 'SP-ACK-CONNECT'
		 and TimeStamp like a.yrmnth + '%'
	)
	and VIP_AccountClassID = ac.VIP_AccountClassID
	and VIP_MarketerID in(2,5) and CoreCustomer = 1
) Enrolled,

(
	Select COUNT(*) from VIP_Accounts 
	where AccountStatus = 'Enrollment Rejected' and VIP_AccountClassID = ac.VIP_AccountClassID
	and VIP_MarketerID in(2,5) and CoreCustomer = 1
	and VIP_AccountID in
	(
		Select VIP_AccountID from VIP_AccountInteractions where VIP_AccountInteractionTypeID in
		(
			Select VIP_AccountInteractionTypeID from VIP_AccountInteractionTypes where Code = 'ENROLLMENT_CORE'
		) and MONTH(EndDateTime) = a.Mnth and YEAR(EndDateTime) = a.Yr
	)
) EnrollmentRecjected,
(
	--retailer terminated
	Select COUNT(*) from VIP_Accounts subac where AccountStatus = 'Terminated' 
	and VIP_MarketerID in(2,5) and CoreCustomer = 1
	and UtilityServiceAccountID in
	(
		Select SenderCustomerID from VIPMARKET_PGE_DASR 
		 where OperationType = 'SP-ACK-DISCONNECT'
		 and TimeStamp like a.yrmnth + '%'
		 and TimeStamp in
		 (
			Select min(TimeStamp) from VIPMARKET_PGE_DASR 
			where OperationType in('SP-ACK-DISCONNECT')	
			and SenderCustomerID = subac.UtilityServiceAccountID
		 )
	)
	and VIP_AccountClassID = ac.VIP_AccountClassID
) Retailer_Terminated,
(
	--utility terminated
	Select COUNT(*) from VIP_Accounts subac where AccountStatus = 'Terminated' 
	and VIP_MarketerID in(2,5) and CoreCustomer = 1
	and UtilityServiceAccountID in
	(
		Select SenderCustomerID from VIPMARKET_PGE_DASR 
		 where OperationType = 'SVC/DISCONNECT'
		 and TimeStamp like a.yrmnth + '%'
		 and TimeStamp in
		 (
			Select min(TimeStamp) from VIPMARKET_PGE_DASR 
			where OperationType in('SVC/DISCONNECT')	
			and SenderCustomerID = subac.UtilityServiceAccountID
		 )
	)
	and VIP_AccountClassID = ac.VIP_AccountClassID
) Utility_Terminated,
(
	Select SUM(usageamount) from VIP_UsageBreakdowns where VIP_UsageID in
	(
		Select VIP_UsageID from VIP_Usage where VIP_UsageTypeID in (2,3)
		and VIP_AccountID in
		(
			Select vip_accountid from VIP_Accounts where AccountStatus = 'Enrolled'
			and VIP_AccountClassID = ac.VIP_AccountClassID and VIP_MarketerID in(2,5)
			and CoreCustomer = 1
		)
	) and YEAR(usagedate) = a.Yr and MONTH(usagedate) = a.Mnth
) Actual_Usage_of_Enrolled_Customers,
(
	Select count(*) --vip_accountid, UtilityServiceAccountID 
	from VIP_Accounts where AccountStatus = 'Terminated'
	and VIP_AccountClassID in(ac.VIP_AccountClassID) and VIP_MarketerID in(2,5) and CoreCustomer = 1
	and VIP_AccountID in
	(
		Select VIP_AccountID from 
		(
			Select vip_accountid, VIP_AccountInteractionTypeID, 
			max(EndDateTime) EndDate from VIP_AccountInteractions where
			VIP_AccountInteractionTypeID in
			(
				Select VIP_AccountInteractionTypeID from VIP_AccountInteractionTypes where Code 
				in('RETAILER_DROP','UTILITY_DROP')
			) and Status = 'Complete' 				
			group by vip_accountid, VIP_AccountInteractionTypeID		
		) b
		where month(b.EndDate) = a.Mnth and year(b.EndDate) = a.Yr
	) 
	and VIP_AccountID not in
	(
		Select VIP_AccountID from VIP_AccountInteractions 
		where VIP_AccountInteractionTypeID in(9)
	)
) Terminated_Without_Actual_Usage,

(
	Select SUM(usageamount) from VIP_UsageBreakdowns where VIP_UsageID in
	(
		Select VIP_UsageID from VIP_Usage where VIP_UsageTypeID in (2,3)
		and VIP_AccountID in
		(
			Select vip_accountid from VIP_Accounts where AccountStatus = 'Terminated'
			and VIP_AccountClassID = ac.VIP_AccountClassID and VIP_MarketerID in(2,5)
			and CoreCustomer = 1
		)
	) and YEAR(usagedate) = a.Yr and MONTH(usagedate) = a.Mnth
) Historic_Actual_Usage_of_Status_Terminated,
(
	Select sum(InvoiceAmount) from VIP_Invoices where VIP_BillingPointID in
	(
		Select vip_billingpointid from vip_billingpointaccounts where vip_accountid in
		(
			Select vip_accountid from VIP_Accounts where AccountStatus = 'Terminated'
			and VIP_AccountClassID = ac.VIP_AccountClassID and VIP_MarketerID in(2,5)
			and CoreCustomer = 1
		)
	) and YEAR(InvoiceDate) = a.Yr and MONTH(InvoiceDate) = a.Mnth and Status in('Exported')
)
Sum_Invoices_Status_Terminated,
(
	Select SUM(paymentamount) from vip_payments where VIP_BillingPointID in
	(
		Select vip_billingpointid from vip_billingpointaccounts where vip_accountid in
		(
			Select vip_accountid from VIP_Accounts where AccountStatus = 'Terminated'
			and VIP_AccountClassID = ac.VIP_AccountClassID and VIP_MarketerID in(2,5)
			and CoreCustomer = 1
		)
	) and YEAR(paymentdate) = a.Yr and MONTH(PaymentDate) = a.Mnth
)
Sum_Terminated_Residential_Payments,
(
	Select SUM(invoiceamount) from VIP_Invoices 
	where MONTH(invoicedate) = a.Mnth and YEAR(InvoiceDate) = a.Yr
	and Status in('Exported','Ready For Export','Processed')
	and InvoiceTypeCode in('Utility','Retailer')
	and VIP_BillingPointID in
	(
		Select vip_billingpointid from VIP_BillingPointAccounts where VIP_AccountID in
		(
			Select VIP_AccountID from VIP_Accounts where AccountStatus = 'Enrolled'
			and VIP_AccountClassID = ac.VIP_AccountClassID and VIP_MarketerID in(2,5) and CoreCustomer = 1
		)
	)
) Total_Sum_Of_Invoices,
(
	Select SUM(paymentamount) from VIP_Payments where 
	Status in('Exported','Ready For Export','Export Error') and
	MONTH(paymentdate) = a.Mnth and YEAR(paymentdate) = a.Yr and
	VIP_BillingPointID in
	(
		Select vip_billingpointid from VIP_BillingPointAccounts where VIP_AccountID in
		(
			Select VIP_AccountID from VIP_Accounts where AccountStatus = 'Enrolled'
			and VIP_AccountClassID = ac.VIP_AccountClassID and VIP_MarketerID in(2,5) and CoreCustomer = 1
		)
	)
) Total_Sum_Of_Payments,
(
	Select AVG(d.days) from 
	(
		Select 		
			datediff(d,
			(select DateSold from VIP_Accounts where VIP_AccountID = VIP_AccountInteractions.VIP_AccountID),
			max(EndDateTime)
			) days
		from VIP_AccountInteractions where VIP_AccountID in
		(
			Select vip_accountid from VIP_Accounts 
			where AccountStatus = 'Terminated' and VIP_AccountClassID = ac.VIP_AccountClassID 
			and VIP_MarketerID in(2,5) and CoreCustomer = 1
			and UtilityServiceAccountID in
			(
				Select SenderCustomerID from VIPMARKET_PGE_DASR 
				where OperationType in('SP-ACK-DISCONNECT','SVC/DISCONNECT') and 
				TimeStamp like a.yrmnth + '%'
			)
		) and VIP_AccountInteractionTypeID
		in
		(
			Select VIP_AccountInteractionTypeID from VIP_AccountInteractionTypes where Code in
			('RETAILER_DROP','UTILITY_DROP')
		)
		and MONTH(EndDateTime) = a.Mnth and YEAR(EndDateTime) = a.Yr
		group by vip_accountid
	) d
) AverageDaysFromDateSoldToTerminated,
(
	Select count(d.days) from 
	(
		Select 		
			datediff(d,
			(select DateSold from VIP_Accounts where VIP_AccountID = VIP_AccountInteractions.VIP_AccountID),
			max(EndDateTime)
			) days
		from VIP_AccountInteractions where VIP_AccountID in
		(
			Select vip_accountid from VIP_Accounts 
			where AccountStatus = 'Terminated' and VIP_AccountClassID = ac.VIP_AccountClassID 
			and VIP_MarketerID in(2,5)
			and CoreCustomer = 1
			and UtilityServiceAccountID in
			(
				Select SenderCustomerID from VIPMARKET_PGE_DASR 
				where OperationType in('SP-ACK-DISCONNECT','SVC/DISCONNECT') and 
				TimeStamp like a.yrmnth + '%'				
			)
		) and VIP_AccountInteractionTypeID
		in
		(
			Select VIP_AccountInteractionTypeID from VIP_AccountInteractionTypes where Code in
			('RETAILER_DROP','UTILITY_DROP')
		)
		and MONTH(EndDateTime) = a.Mnth and YEAR(EndDateTime) = a.Yr
		group by vip_accountid
	) d where d.days <= 10
) No_Of_SA_LessThan10DaysEnrolled

from 
(
	Select distinct month(seeddate) Mnth, YEAR(seeddate) Yr,
	case 
	   when month(seeddate) < 10 then CONVERT(varchar(4), year(seeddate)) + '0' + CONVERT(varchar(2), MONTH(seeddate))
	   else CONVERT(varchar(4), year(seeddate)) + CONVERT(varchar(2), MONTH(seeddate))
	end yrmnth	
	 from dbo.VIP_SeedDates 
	where YEAR(seeddate) = @Year
) a
cross join VIP_AccountClasses ac
order by a.Mnth
GO
