

/*******************************************************************************************************************
 *	2017-07-21 - BRudd - Removed the Union from this view because we don't use VIP_Archive anymore.
 *
 *
 *
 *******************************************************************************************************************/
CREATE VIEW [dbo].[VIP_AccountInvoiceView]
AS
SELECT     i.VIP_InvoiceID, bpa.VIP_AccountID, i.VIP_BillingPointID, bp.BillingPointName, i.InvoiceDate, i.DateDue, i.InvoiceAmount, i.Status,
ReleaseDate, ReleasedBy,
                          ISNULL(
								(SELECT     MIN(UsageDate) AS Expr1
								FROM          dbo.VIP_InvoiceBreakdowns
								WHERE      (VIP_AccountID = bpa.VIP_AccountID) AND (VIP_InvoiceID = i.VIP_InvoiceID)) 
								,
								(
									(SELECT     MIN(PeriodStartDate) AS Expr1
									FROM          dbo.VIP_InvoiceItems
									WHERE      (VIP_AccountID = bpa.VIP_AccountID) AND (VIP_InvoiceID = i.VIP_InvoiceID))
								)
							)
							
							AS StartDate,

							ISNULL(
								  (SELECT     MAX(UsageDate) AS Expr1
									FROM          dbo.VIP_InvoiceBreakdowns AS VIP_InvoiceBreakdowns_1
									WHERE      (VIP_AccountID = bpa.VIP_AccountID) AND (VIP_InvoiceID = i.VIP_InvoiceID)) 
								,
								(
									(SELECT     MIN(PeriodEndDate) AS Expr1
									FROM          dbo.VIP_InvoiceItems
									WHERE      (VIP_AccountID = bpa.VIP_AccountID) AND (VIP_InvoiceID = i.VIP_InvoiceID))
								)
								)		
							AS EndDate,
							
							
							 '' AS Archived_Data
FROM         dbo.VIP_Invoices AS i INNER JOIN
                      dbo.VIP_BillingPoints AS bp ON i.VIP_BillingPointID = bp.VIP_BillingPointID INNER JOIN
                      dbo.VIP_BillingPointAccounts AS bpa ON bpa.VIP_BillingPointID = i.VIP_BillingPointID
--UNION
--SELECT     i.VIP_InvoiceID, bpa.VIP_AccountID, i.VIP_BillingPointID, bp.BillingPointName, i.InvoiceDate, i.DateDue, i.InvoiceAmount, i.Status,
--ReleaseDate, ReleasedBy,
--                          (SELECT     MIN(UsageDate) AS Expr1
--                            FROM          VIP_Archive..VIP_InvoiceBreakdowns
--                            WHERE      (VIP_AccountID = bpa.VIP_AccountID) AND (VIP_InvoiceID = i.VIP_InvoiceID)) AS StartDate,
--                          (SELECT     MAX(UsageDate) AS Expr1
--                            FROM          VIP_Archive..VIP_InvoiceBreakdowns AS VIP_InvoiceBreakdowns_1
--                            WHERE      (VIP_AccountID = bpa.VIP_AccountID) AND (VIP_InvoiceID = i.VIP_InvoiceID)) AS EndDate, 'Archived' Archived_Data
--FROM         VIP_Archive..VIP_Invoices AS i INNER JOIN
--                      dbo.VIP_BillingPoints AS bp ON i.VIP_BillingPointID = bp.VIP_BillingPointID INNER JOIN
--                      dbo.VIP_BillingPointAccounts AS bpa ON bpa.VIP_BillingPointID = i.VIP_BillingPointID


GO
