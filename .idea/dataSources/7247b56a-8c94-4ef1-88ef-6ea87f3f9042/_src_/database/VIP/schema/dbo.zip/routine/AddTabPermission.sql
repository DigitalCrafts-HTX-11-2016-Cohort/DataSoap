
CREATE PROCEDURE dbo.AddTabPermission
	@TabID int,
	@PermissionID int,
	@RoleID int,
	@AllowAccess bit,
    @UserID int
AS

	INSERT INTO dbo.TabPermission (
		[TabID],
		[PermissionID],
		[RoleID],
		[AllowAccess],
		[UserID]
	) VALUES (
		@TabID,
		@PermissionID,
		@RoleID,
		@AllowAccess,
		@UserID
	)

	select SCOPE_IDENTITY()

GO
