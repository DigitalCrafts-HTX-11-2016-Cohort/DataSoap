
CREATE PROCEDURE [dbo].[VIP_PGEUpdateAccountStatusForReconciledAccounts]	
AS

Update vip_accounts set AccountStatus = 'Terminated' where VIP_AccountID in
(
	Select vip_accountid from vip_accounts 
	where AccountStatus = 'Terminated' and previous_vip_accountid <> -1
	and UtilityServiceAccountID in
	(
		Select SenderCustomerID from VIPMARKET_PGE_DASR
		where OperationType IN('SP-ACK-DISCONNECT', 'SVC/DISCONNECT')
	)
) and AccountStatus = 'Enrolled'
GO
