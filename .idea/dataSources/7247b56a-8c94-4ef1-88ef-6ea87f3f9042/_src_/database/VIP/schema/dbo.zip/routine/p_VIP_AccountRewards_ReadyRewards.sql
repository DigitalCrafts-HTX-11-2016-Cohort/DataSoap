

CREATE PROC dbo.p_VIP_AccountRewards_ReadyRewards
    (
      @userName VARCHAR(100) = ''
    )
AS
    BEGIN


        SELECT  *
        FROM    dbo.VIP_AccountRewards
        WHERE   ( 1 = 1 )
                AND GoodStanding_Flag = 1
                --AND RequestSubmitted_Flag = 1
                AND DeletedOn IS NULL
                AND ExportedOn IS NULL
                AND RejectedOn IS NULL

		UPDATE dbo.VIP_AccountRewards
		SET		ExportedOn = GETDATE()
		WHERE   ( 1 = 1 )
                AND GoodStanding_Flag = 1
                AND DeletedOn IS NULL
                AND ExportedOn IS NULL
                AND RejectedOn IS NULL
			
    END

GO
