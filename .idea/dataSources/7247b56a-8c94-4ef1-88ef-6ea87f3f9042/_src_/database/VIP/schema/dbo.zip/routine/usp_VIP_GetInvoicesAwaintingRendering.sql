


/*
 - 2014-03-26 - BPanjavan - Added columns for changing the presentation, flags for sending Email to the customer
*/
CREATE PROCEDURE [dbo].[usp_VIP_GetInvoicesAwaintingRendering]
AS

---- Send in SSRS report based on the product that the period start date falls under
;
WITH 
tblProducts_Vs_SSRSReport AS
(
	SELECT RetailerProductCode = 'SOCAL Fixed Commodity', Template_SSRSReport = 'Standard'
	UNION ALL SELECT RetailerProductCode = 'SDGE Fixed Commodity', Template_SSRSReport = 'Standard'
)
,tblProducts_Vs_SendEmailToCustomer AS
(
	SELECT RetailerProductCode = 'SOCAL Fixed Commodity', SendEmailToCustomer = 1
	UNION ALL SELECT RetailerProductCode = 'SDGE Fixed Commodity', SendEmailToCustomer = 1
)
,tblInvoice_MinPeriodStartDate AS
(
	SELECT
		inv.VIP_InvoiceID
		,PeriodStartDate_Min = MIN(ii.PeriodStartDate)
		,VIP_AccountID = MIN(ii.VIP_AccountID)
	FROM
		VIP_Invoices inv
		INNER JOIN VIP_InvoiceItems ii ON ii.VIP_InvoiceID = inv.VIP_InvoiceID
	WHERE (1 = 1)
	GROUP BY inv.VIP_InvoiceID
)
,tblInvoice_ActiveProduct AS
(
	SELECT 
		tblInvoice_MinPeriodStartDate.VIP_InvoiceID
		,prod.RetailerProductCode
		--Added 9/9/2014 by JBecker
		,prod.VIP_ProductID
	FROM 
		tblInvoice_MinPeriodStartDate
		INNER JOIN VIP_AccountProducts ap 
			ON tblInvoice_MinPeriodStartDate.VIP_AccountID = ap.VIP_AccountID
			AND ap.StartDate <= 	tblInvoice_MinPeriodStartDate.PeriodStartDate_Min
			AND ap.EndDate > tblInvoice_MinPeriodStartDate.PeriodStartDate_Min		
		INNER JOIN VIP_Products prod ON ap.VIP_ProductID = prod.VIP_ProductID
)
--Added 9/9/2014 by JBecker
, tblProduct_fixedBillB AS
(
SELECT * FROM dbo.VIP_Products 
)
SELECT 
	inv.VIP_InvoiceID ,
    inv.VIP_BillingPointID ,
    inv.InvoiceTypeCode,
	--Added 9/9/2014 by JBecker
	CASE WHEN fbb.VIP_ProductID IS NOT NULL AND fbb.VIP_ProductPricingTypeID =4
		THEN 'FixedBillB_InvoiceTemplate'
		WHEN fbb.VIP_ProductID IS NOT NULL AND fbb.VIP_ProductPricingTypeID NOT IN(4) AND fbb.VIP_UtilityID =2
		THEN 'Standard_Socal'
		ELSE 'Standard'
		END AS Template_SSRSReport
	--Template_SSRSReport = ISNULL(tblProducts_Vs_SSRSReport.Template_SSRSReport, 'Standard')
	,SendEmailToCustomer = ISNULL(tblProducts_Vs_SendEmailToCustomer.SendEmailToCustomer, 0)

--	,tblInvoice_ActiveProduct.RetailerProductCode
FROM    
	VIP_Invoices inv
	LEFT JOIN tblInvoice_ActiveProduct ON inv.VIP_InvoiceID = tblInvoice_ActiveProduct.VIP_InvoiceID
	LEFT JOIN tblProducts_Vs_SSRSReport ON tblInvoice_ActiveProduct.RetailerProductCode = tblProducts_Vs_SSRSReport.RetailerProductCode
	LEFT JOIN tblProducts_Vs_SendEmailToCustomer ON tblInvoice_ActiveProduct.RetailerProductCode = tblProducts_Vs_SendEmailToCustomer.RetailerProductCode
		--Added 9/9/2014 by JBecker
	LEFT JOIN tblProduct_fixedBillB fbb ON fbb.VIP_ProductID = tblInvoice_ActiveProduct.VIP_ProductID
WHERE (1 = 1)
	AND inv.Status = 'Awaiting Rendering'
	























--GO


GO
