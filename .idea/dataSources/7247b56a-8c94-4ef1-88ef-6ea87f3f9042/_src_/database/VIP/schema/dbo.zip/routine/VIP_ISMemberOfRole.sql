-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[VIP_ISMemberOfRole]
(@UserID int, @RoleName varchar(500))
RETURNS int
AS
BEGIN
declare @Authrorized int

set @Authrorized =
(
	Select COUNT(*) from Users where UserID in
	(
		Select UserID from UserRoles where RoleID in
		(
			Select RoleID from Roles where RoleName in(@RoleName)
		) 
	) 
	and UserID = @UserID
)

if @Authrorized = 0
begin
	set @Authrorized = 
	( 
		Select COUNT(*) from Users where UserID = @UserID and IsSuperUser = 1		
	)				
end

RETURN @Authrorized

END
GO
