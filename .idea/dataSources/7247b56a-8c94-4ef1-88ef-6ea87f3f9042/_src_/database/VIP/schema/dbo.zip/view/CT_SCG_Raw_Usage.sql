CREATE VIEW CT_SCG_Raw_Usage as select * from VIPMARKET_SCG_USage (nolock)
GO
