
create procedure dbo.GetSiteLog12

@PortalID int,
@PortalAlias nvarchar(50),
@StartDate datetime,
@EndDate datetime

as

select AffiliateId,
 'Requests' = count(*),
 'LastReferral' = max(DateTime)
from dbo.SiteLog
where dbo.SiteLog.PortalId = @PortalID
and dbo.SiteLog.DateTime between @StartDate and @EndDate
and AffiliateId is not null
group by AffiliateId
order by Requests desc


GO
