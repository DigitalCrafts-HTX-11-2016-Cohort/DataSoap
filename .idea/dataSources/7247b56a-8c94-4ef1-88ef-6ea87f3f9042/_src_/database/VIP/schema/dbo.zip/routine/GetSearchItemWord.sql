
CREATE PROCEDURE dbo.GetSearchItemWord
	@SearchItemWordID int
	
AS

SELECT
	[SearchItemWordID],
	[SearchItemID],
	[SearchWordsID],
	[Occurrences]
FROM
	dbo.SearchItemWord
WHERE
	[SearchItemWordID] = @SearchItemWordID


GO
