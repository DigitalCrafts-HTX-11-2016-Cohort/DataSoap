
--SELECT * FROM dbo.v_ScheduledRewards

CREATE VIEW dbo.v_ScheduledRewards
AS 

WITH    EligibleRewardsCustomers
          AS ( SELECT   accuView.UtilityCode ,
                        accuView.AccountStatus ,
                        DATE_THAT_WE_WILL_HAVE_TO_SEND_GIFT_CARD = DATEADD(MONTH,
                                                              3,
                                                              apView.FirstAccountProduct_StartDate) ,
                        apView.*
               FROM     Products.mv_VIP_CumulativeAccountProductsView apView
                        INNER JOIN AccountServicePoint.mv_VIP_AccountCumulativeView_v2 accuView ON accuView.VIP_AccountID = apView.VIP_AccountID
                        LEFT JOIN Accounting.mv_Aging_v2_FromMVToday_COLLECTIONS collectionsAging ON collectionsAging.VIP_AccountID = accuView.VIP_AccountID
               WHERE    ( 1 = 1 )
                        AND apView.FirstAccountProduct_ProductName LIKE '%reward%'
--ORDER BY apView.FirstAccountProduct_EndDate ASC
             ),
        HorizontalPivot
          AS ( SELECT   VIP_AccountID ,
                        AccountStatus ,
                        UtilityCode ,
                        DATEPART(YEAR,
                                 EligibleRewardsCustomers.DATE_THAT_WE_WILL_HAVE_TO_SEND_GIFT_CARD) AS Year ,
                        CASE DATEPART(MONTH,
                                      DATE_THAT_WE_WILL_HAVE_TO_SEND_GIFT_CARD)
                          WHEN 1 THEN 1
                          ELSE 0
                        END AS January ,
                        CASE DATEPART(MONTH,
                                      DATE_THAT_WE_WILL_HAVE_TO_SEND_GIFT_CARD)
                          WHEN 2 THEN 1
                          ELSE 0
                        END AS February ,
                        CASE DATEPART(MONTH,
                                      DATE_THAT_WE_WILL_HAVE_TO_SEND_GIFT_CARD)
                          WHEN 3 THEN 1
                          ELSE 0
                        END AS March ,
                        CASE DATEPART(MONTH,
                                      DATE_THAT_WE_WILL_HAVE_TO_SEND_GIFT_CARD)
                          WHEN 4 THEN 1
                          ELSE 0
                        END AS April ,
                        CASE DATEPART(MONTH,
                                      DATE_THAT_WE_WILL_HAVE_TO_SEND_GIFT_CARD)
                          WHEN 5 THEN 1
                          ELSE 0
                        END AS May ,
                        CASE DATEPART(MONTH,
                                      DATE_THAT_WE_WILL_HAVE_TO_SEND_GIFT_CARD)
                          WHEN 6 THEN 1
                          ELSE 0
                        END AS June ,
                        CASE DATEPART(MONTH,
                                      DATE_THAT_WE_WILL_HAVE_TO_SEND_GIFT_CARD)
                          WHEN 7 THEN 1
                          ELSE 0
                        END AS July ,
                        CASE DATEPART(MONTH,
                                      DATE_THAT_WE_WILL_HAVE_TO_SEND_GIFT_CARD)
                          WHEN 8 THEN 1
                          ELSE 0
                        END AS August ,
                        CASE DATEPART(MONTH,
                                      DATE_THAT_WE_WILL_HAVE_TO_SEND_GIFT_CARD)
                          WHEN 9 THEN 1
                          ELSE 0
                        END AS September ,
                        CASE DATEPART(MONTH,
                                      DATE_THAT_WE_WILL_HAVE_TO_SEND_GIFT_CARD)
                          WHEN 10 THEN 1
                          ELSE 0
                        END AS October ,
                        CASE DATEPART(MONTH,
                                      DATE_THAT_WE_WILL_HAVE_TO_SEND_GIFT_CARD)
                          WHEN 11 THEN 1
                          ELSE 0
                        END AS November ,
                        CASE DATEPART(MONTH,
                                      DATE_THAT_WE_WILL_HAVE_TO_SEND_GIFT_CARD)
                          WHEN 12 THEN 1
                          ELSE 0
                        END AS December
               FROM     EligibleRewardsCustomers
             )
    SELECT  UtilityCode ,
            AccountStatus ,
			Year ,
            SUM(January) AS January ,
			SUM(February) AS February ,
			SUM(March) AS March ,
			SUM(April) AS April ,
			SUM(May) AS May ,
			SUM(June) AS June ,
			SUM(July) AS July ,
			SUM(August) AS August ,
			SUM(September) AS September ,
			SUM(October) AS October ,
			SUM(November) AS November ,
			SUM(December) AS December 
    FROM    HorizontalPivot
    GROUP BY UtilityCode ,
            AccountStatus ,
			YEAR


GO
