
create procedure dbo.GetSiteLog7

@PortalID int,
@PortalAlias nvarchar(50),
@StartDate datetime,
@EndDate datetime

as

select 'WeekDay' = datepart(weekday,DateTime),
 'Views' = count(*),
 'Visitors' = count(distinct dbo.SiteLog.UserHostAddress),
 'Users' = count(distinct dbo.SiteLog.UserId)
from dbo.SiteLog
where PortalId = @PortalID
and dbo.SiteLog.DateTime between @StartDate and @EndDate
group by datepart(weekday,DateTime)
order by WeekDay


GO
