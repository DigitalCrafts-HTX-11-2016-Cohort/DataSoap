
create procedure dbo.DeleteUser

@UserID   int

as

delete
from dbo.Users
where  UserId = @UserID


GO
