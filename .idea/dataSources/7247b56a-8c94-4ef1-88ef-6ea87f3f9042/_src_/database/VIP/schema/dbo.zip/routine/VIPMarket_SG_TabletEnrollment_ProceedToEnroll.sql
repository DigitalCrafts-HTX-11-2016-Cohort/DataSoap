



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[VIPMarket_SG_TabletEnrollment_ProceedToEnroll]
(
	@userName VARCHAR(50),
	@VIPMarket_SG_TabletEnrollmentID INT
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRY
		PRINT('Executing.  Begin Transaction')
		BEGIN TRAN
	
		DECLARE @userID INT
		IF NOT EXISTS((Select userid from users where username = '41MG'))
		BEGIN
			RAISERROR('Cannot find UserID for 41MG',15,1000)
		END      
        
		SET @userID = (Select userid from users where username = '41MG')      

		/*
			//      SET Email override if we have
			//      SET Product and price record row
			//      Set status to: Sale Accepted
		*/
		UPDATE pr
			SET
				pr.Email = CASE
								WHEN ISNULL(te.EmailAddress,'') = '' THEN pr.Email
								ELSE te.EmailAddress
							END
				,pr.PriceOption = te.PriceRateCode
				,pr.SelectedRow = te.VIPMarket_SG_PriceRateCode_ID
				,pr.UserId = @userID
				,pr.Enrollment_Date = te.DateReceived
				,pr.Confirmation_ID = SUBSTRING(CONVERT(VARCHAR(50), te.EnrollmentSubmissionID), 1, 8)
				,pr.Control_Number = te.ControlNumber
				,pr.ConfDatetime = GETDATE()
				,pr.Status = 'Sale Accepted'
		FROM
			dbo.VIPMarket_SG_TabletEnrollment te
			INNER JOIN dbo.VIPMARKET_SG_ELG_PREMISE pr ON te.VIPMARKET_SG_ELG_PREMISE_ID = pr.VIPMARKET_SG_ELG_PREMISE_ID      
		WHERE
			te.VIPMarket_SG_TabletEnrollmentID = @VIPMarket_SG_TabletEnrollmentID

		UPDATE te
			SET
				te.ModifiedBy = @userName
				,te.ModifiedOn = GETDATE()
				,te.[Status] = 'Submitted'
				,te.StatusReason = 'Submitted with control #'
		FROM
			dbo.VIPMarket_SG_TabletEnrollment te
		WHERE
			te.VIPMarket_SG_TabletEnrollmentID = @VIPMarket_SG_TabletEnrollmentID  
		
	

		PRINT('Execution Complete.  Committing Transaction')
		COMMIT
	END TRY
	BEGIN CATCH
		PRINT('Execution Error.  Rolling back transaction')
		ROLLBACK
	
		DECLARE @errorMessage VARCHAR(400)
		SET @errorMessage = CONVERT(varchar(100), ERROR_MESSAGE())

		PRINT('ERROR_NUMBER: ' + CONVERT(varchar(100), ERROR_NUMBER()) )
		PRINT('ERROR_SEVERITY: ' + CONVERT(varchar(100), ERROR_SEVERITY()) )
		PRINT('ERROR_STATE: ' + CONVERT(varchar(100), ERROR_STATE()) )
		PRINT('ERROR_PROCEDURE: ' + CONVERT(varchar(100), ERROR_PROCEDURE()) )
		PRINT('ERROR_LINE: ' + CONVERT(varchar(100), ERROR_LINE()) )
		PRINT('ERROR_MESSAGE: ' + @errorMessage )

		-- Bubble up
		RAISERROR(@errorMessage,15,1001)
	END CATCH


END


GO
