
CREATE procedure dbo.GetHostSettings

as

if not exists ( select 1 from dbo.HostSettings where SettingName = 'GUID' )
  insert into dbo.HostSettings ( SettingName, SettingValue, SettingIsSecure ) values ( 'GUID', newid(), 0 )

select SettingName,
       SettingValue,
       SettingIsSecure
from   dbo.HostSettings

GO
