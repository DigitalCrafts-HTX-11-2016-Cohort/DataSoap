-- =============================================
-- Author:		Bryan Panjavan
-- Create date: 2013-10-11
-- Description:	Insert record into external transaction table for usage

	-- 2013-10-11 - Initial Creation

-- =============================================
CREATE PROCEDURE VIP_InvoiceToExternalSource_Insert
(
	@VIP_InvoiceID int = Null
	,@MarketCode varchar(50)
	,@ExternalReferenceNumber varchar(400)
	,@Status varchar(100)
	,@StatusDescription varchar(800)
	,@userID varchar(50)
)
AS
INSERT INTO VIP_InvoiceToExternalSourceTable
           ([InvoiceID]
           ,[MarketCode]
           ,[ExternalReferenceNumber]
           ,[Status]
           ,[StatusDescription]
           ,[CreatedBy]
           ,[CreatedOn]
           ,[ModifiedBy]
           ,[ModifiedOn])
     VALUES
           (
		   @VIP_InvoiceID
           ,@MarketCode
           ,@ExternalReferenceNumber
           ,@Status
           ,@StatusDescription
           ,@userID
           ,GETDATE()
           ,@userID
           ,GETDATE()
		   )

GO
