CREATE VIEW dbo.VIP_InvoicesView_Recent AS
SELECT * FROM dbo.VIP_InvoicesView
WHERE DATEADD(DAY, -30, GETDATE()) <= InvoiceDate
GO
