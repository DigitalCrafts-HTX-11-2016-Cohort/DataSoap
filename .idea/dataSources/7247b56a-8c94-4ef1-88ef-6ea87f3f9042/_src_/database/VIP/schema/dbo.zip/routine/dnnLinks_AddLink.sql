
/** Create renamed Stored Procedures **/

CREATE PROCEDURE dbo.dnnLinks_AddLink

	@ModuleId    int,
	@UserId      int,
	@CreatedDate datetime,
	@Title       nvarchar(100),
	@Url         nvarchar(250),
	@ViewOrder   int,
	@Description nvarchar(2000)

AS

INSERT INTO dbo.Links (
	ModuleId,
	CreatedByUser,
	CreatedDate,
	Title,
	Url,
	ViewOrder,
	Description
)
VALUES (
	@ModuleId,
	@UserId,
	@CreatedDate,
	@Title,
	@Url,
	@ViewOrder,
	@Description
)

SELECT SCOPE_IDENTITY()

GO
