

CREATE PROC dbo.PendingRateChange_Clear
(
	@accountID INT 
)
AS
BEGIN
BEGIN TRAN

UPDATE dbo.VIP_AccountProductsRateScheduleChange
SET		Status = 'Cleared'
WHERE VIP_AccountID = @accountID AND Status = 'Pending'

COMMIT
END
GO
