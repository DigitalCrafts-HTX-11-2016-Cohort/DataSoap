-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[VIP_ISApproval_Authority]
(@UserID int)
RETURNS int
AS
BEGIN
declare @Authrorized int

set @Authrorized =
(
	Select COUNT(*) from Users where UserID in
	(
		Select UserID from UserRoles where RoleID in
		(
			Select RoleID from Roles where RoleName in('SA_Approval_Auth','Administrators')
		) 
	) 
	and UserID = @UserID
)

if @Authrorized = 0
begin
	set @Authrorized = 
	( 
		Select COUNT(*) from Users where UserID = @UserID and IsSuperUser = 1		
	)				
end

RETURN @Authrorized

END
GO
