
create procedure dbo.GetAffiliates

@VendorId int

as

select AffiliateId,
       StartDate,
       EndDate,
       CPC,
       Clicks,
       'CPCTotal' = Clicks * CPC,
       CPA,
       Acquisitions,
       'CPATotal' = Acquisitions * CPA
from   dbo.Affiliates
where  VendorId = @VendorId
order  by StartDate desc


GO
