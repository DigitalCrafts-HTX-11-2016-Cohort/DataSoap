-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE usp_VIP_SG_AddPricingForBallottedAccountsNotSubmittedToSourceGas
	-- Add the parameters for the stored procedure here
	@AcctNumber varchar(15), @PriceCode varchar(5)
AS
BEGIN TRANSACTION

BEGIN TRY
	declare @SelectedRow int
	declare @PriceOption varchar(20)

	set @PriceOption = 
		(
			Select case when Category = 'FP1' then 'Fixed'
						when Category = 'FP2' then 'Fixed2'
						when Category = 'IND1' then 'Index'
						when Category = 'IND2' then 'Index2'
			end PriceOption
			from dbo.VIPMARKET_SG_PriceRateCodes 
			where rate_code = @PriceCode
		)
	
	if @PriceOption is not null
	begin				
		insert into dbo.VIPMARKET_SG_Pricing
		(
			Account_Number, 
			Marketer, 
			FixedPriceRate, 
			FixedpriceCode, 
			FixedPriceRate2, 
			FixedPriceCode2, 
			IndexRate, 
			IndexCode, 
			IndexRate2, 
			IndexCode2, 
			BlendCode, 
			BlendCode2, 
			Weighted_Fixed_Average, 
			Weighted_Fixed_Code, 
			NymexRate1, 
			NymexCode1, 
			NymexRate2, 
			NymexCode2, 
			FixedBillUnlimitedCode1, 
			FixedBillUnlimitedRate1, 
			FixedBillUnlimitedCode2, 
			FixedBillUnlimitedRate2, 
			BrokerDiscount, 
			VistaMatchDiscount, 
			ImportDate, 
			ImportFileName
		)
		Select 
		@AcctNumber Account_Number, 
		'WEB' Marketer, 
		case when Category = 'FP1' then Price else '0' end FixedPriceRate, 
		case when Category = 'FP1' then Rate_Code else '00000' end FixedpriceCode, 
		case when Category = 'FP2' then Price else '0' end FixedPriceRate2, 
		case when Category = 'FP2' then Rate_Code else '00000' end FixedPriceCode2, 
		case when Category = 'IND1' then Price else '0' end IndexRate, 
		case when Category = 'IND1' then Rate_Code else '00000' end IndexCode, 
		case when Category = 'IND2' then Price else '0' end IndexRate2, 
		case when Category = 'IND2' then Rate_Code else '00000' end IndexCode2, 
		'00000' BlendCode, 
		'00000' BlendCode2, 
		'0' Weighted_Fixed_Average, 
		'00000' Weighted_Fixed_Code, 
		'0' NymexRate1, 
		'00000' NymexCode1, 
		'0' NymexRate2, 
		'00000' NymexCode2, 
		'00000' FixedBillUnlimitedCode1, 
		'0' FixedBillUnlimitedRate1, 
		'00000' FixedBillUnlimitedCode2, 
		'0' FixedBillUnlimitedRate2, 
		0.00 BrokerDiscount, 
		0.00 VistaMatchDiscount, 
		getdate() ImportDate, 
		'' ImportFileName
		from dbo.VIPMARKET_SG_PriceRateCodes
		where rate_code = @priceCode and Category not in('FB1','FB2')

		set @SelectedRow = @@Identity
				
		if @SelectedRow is not null
		begin
			update VIPMARKET_SG_ELG_PREMISE
			set 
			PriceOption = @PriceOption, 
			Selectedrow = @SelectedRow,
			userid = (Select userid from users where username = 'SG_CUSTOMER'),
			Enrollment_Date = getdate(),
			Confirmation_ID = left(newid(),8),
			Status = 'Enrolled'
			where account_number = @AcctNumber
			
			COMMIT TRANSACTION
									
			Select *, 'Success' Results from VIPMARKET_SG_ELG_PREMISE where account_number = @AcctNumber
		end
		else
		begin			
			Select *, 'No Price Rate Code Found' Results from VIPMARKET_SG_ELG_PREMISE where account_number = @AcctNumber
		end	
	end
	else
	begin		
		Select *, 'No Price Code' Results from VIPMARKET_SG_ELG_PREMISE where account_number = @AcctNumber
	end

END TRY
BEGIN CATCH
	ROLLBACK TRANSACTION	
	Select *, 'Error:  No Price Code' Results from VIPMARKET_SG_ELG_PREMISE where account_number = @AcctNumber
END CATCH
		
----------------------------------------------------------------
--Select * from VIPMARKET_SG_ELG_PREMISE where account_number = @AcctNumber

--determine if this price code has been loaded per the account number

--update VIPMARKET_SG_ELG_PREMISE
--set 
--PriceOption= a.PriceOption, 
--Selectedrow = a.vipmarket_sg_pricing_id,
--userid = 90
--Enrollment_Date = (Select userid from users where username = 'SG_CUSTOMER')
--Confirmation_ID = a.ConfId
--from 
--(
--	Select top 1 *, left(newid(),8) ConfId from 
--	(
--		Select vipmarket_sg_pricing_id, marketer, fixedpricecode, 'Fixed' PriceOption from VIPMARKET_SG_Pricing 
--		where account_number= @AcctNumber and fixedpricecode = @priceCode and marketer = 'WEB'
--		union
--		Select vipmarket_sg_pricing_id, marketer, fixedpricecode2, 'Fixed2' PriceOption from VIPMARKET_SG_Pricing 
--		where account_number= @AcctNumber and fixedpricecode2 = @priceCode and marketer = 'WEB'
--		union
--		Select vipmarket_sg_pricing_id, marketer, indexcode, 'Index' PriceOption from VIPMARKET_SG_Pricing 
--		where account_number= @AcctNumber and indexcode = @priceCode and marketer = 'WEB'
--		union
--		Select vipmarket_sg_pricing_id, marketer, indexcode2, 'Index2' PriceOption from VIPMARKET_SG_Pricing 
--		where account_number= @AcctNumber and indexcode2 = @priceCode and marketer = 'WEB'
--		union
--		Select vipmarket_sg_pricing_id, marketer, FixedBillUnlimitedCode1, 'FBILLUNL1' PriceOption from VIPMARKET_SG_Pricing 
--		where account_number= @AcctNumber and FixedBillUnlimitedCode1 = @priceCode and marketer = 'WEB'
--		union
--		Select vipmarket_sg_pricing_id, marketer, FixedBillUnlimitedCode2, 'FBILLUNL1' PriceOption from VIPMARKET_SG_Pricing 
--		where account_number= @AcctNumber and FixedBillUnlimitedCode2 = @priceCode and marketer = 'WEB'
--	) a
--)


-------------------------------------------------------------------------
--Select * from VIPMARKET_SG_ELG_PREMISE where 
--priceoption = '' and balloted_status = 'Enrolled' and account_number = '211014621381'




/*
49465

category in('FB1','FB2')
*/
--order by rate_code
--@priceCode
GO
