
CREATE PROCEDURE dbo.[GetAllTabs]

AS
SELECT *
FROM   dbo.vw_Tabs
ORDER BY TabOrder, TabName

GO
