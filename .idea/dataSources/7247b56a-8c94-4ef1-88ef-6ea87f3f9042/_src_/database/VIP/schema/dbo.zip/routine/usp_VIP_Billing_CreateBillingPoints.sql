-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_VIP_Billing_CreateBillingPoints]
AS

declare @Vip_Accountid int
declare @RecID int
DECLARE db_cursor CURSOR FOR  


Select vip_accountid from vip_accounts where
VIP_AccountID  not in
(
	Select vip_accountid from VIP_BillingPointAccounts 
) 
and AccountStatus = 'Enrolled'


OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @Vip_Accountid   

WHILE @@FETCH_STATUS = 0   
BEGIN   
       
insert into VIP_BillingPoints
(BillingPointName,BillingPointCode,BillingTrigger,BillingAttentionTo,Address1,Address2,city, State,ZipCode,Phone, Email)
Select GUIDID, GUIDID, BillingTrigger, AttentionTo, BillingAddress1, BillingAddress2, BillingCity, BillingState, BillingZipCode, BillingPhone, BillingEmail from 
(
	Select 
	NEWID() GUIDID, 
	'Usage' BillingTrigger, 
	case CompanyName
		 when '' then billingFirstName + ' ' + billingLastName 
		 else CompanyName
	end AttentionTo,
	BillingAddress1, 
	BillingAddress2,
	BillingCity,
	BillingState,
	BillingZipCode,
	BillingPhone,
	BillingEmail
	 from VIP_Accounts where VIP_AccountID = @Vip_Accountid
) a

Select @RecID = (select @@IDENTITY)

insert into VIP_BillingPointAccounts
(VIP_BillingPointID, VIP_AccountID, DateCreated)
values
(
	@RecID, @Vip_Accountid, GETDATE()
)

FETCH NEXT FROM db_cursor INTO @Vip_Accountid   
END   

CLOSE db_cursor   
DEALLOCATE db_cursor
GO
