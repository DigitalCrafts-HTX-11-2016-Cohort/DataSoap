
create procedure dbo.GetUrlLog

@URLTrackingID int,
@StartDate     datetime,
@EndDate       datetime

as

select dbo.UrlLog.*,
       'FullName' = dbo.Users.FirstName + ' ' + dbo.Users.LastName
from   dbo.UrlLog
inner join dbo.UrlTracking on dbo.UrlLog.UrlTrackingId = dbo.UrlTracking.UrlTrackingId
left outer join dbo.Users on dbo.UrlLog.UserId = dbo.Users.UserId
where  dbo.UrlLog.UrlTrackingID = @UrlTrackingID
and    ((ClickDate >= @StartDate) or @StartDate is null)
and    ((ClickDate <= @EndDate) or @EndDate is null)
order by ClickDate


GO
