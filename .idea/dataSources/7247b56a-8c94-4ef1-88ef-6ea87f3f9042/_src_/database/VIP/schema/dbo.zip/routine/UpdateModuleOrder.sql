
create procedure dbo.UpdateModuleOrder

@TabId              int,
@ModuleId           int,
@ModuleOrder        int,
@PaneName           nvarchar(50)

as

update dbo.TabModules
set    ModuleOrder = @ModuleOrder,
       PaneName = @PaneName
where  TabId = @TabId
and    ModuleId = @ModuleId


GO
