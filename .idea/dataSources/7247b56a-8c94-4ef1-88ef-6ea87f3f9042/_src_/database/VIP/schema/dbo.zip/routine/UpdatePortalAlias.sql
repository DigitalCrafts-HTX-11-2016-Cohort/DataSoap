
CREATE procedure dbo.UpdatePortalAlias
@PortalAliasID int,
@PortalID int,
@HTTPAlias nvarchar(200)

as

UPDATE dbo.PortalAlias 
SET HTTPAlias = @HTTPAlias
WHERE PortalID = @PortalID
AND	  PortalAliasID = @PortalAliasID


GO
