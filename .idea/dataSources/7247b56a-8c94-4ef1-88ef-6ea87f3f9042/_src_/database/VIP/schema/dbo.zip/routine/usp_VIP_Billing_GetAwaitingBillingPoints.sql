

/*
 - 2013-10-22 - BPanjavan - Removed the section where it was getting invoices in pre-correction: 'Reinvoice' status.  This was causing it to pickup invoices people were re-calculating in the UI
 - 2014-08-13 - BPanjavan - Exclude 'Loaded-Assoc' because those need to have their breakdowns created
*/

CREATE procedure [dbo].[usp_VIP_Billing_GetAwaitingBillingPoints]
	@Type as varchar(150)
AS
	SET TRANSACTION ISOLATION LEVEL SNAPSHOT

-- BGE - Exclude SCG from processing

--DECLARE	@Type as varchar(150)
--SET @Type = 'DUAL'

;
WITH    tblInvoiceItemInvoice
          AS ( SELECT   ii.* ,
                        inv.[Status]
               FROM     VIP_InvoiceItems ii
                        INNER JOIN VIP_Invoices inv ON ii.VIP_InvoiceID = inv.VIP_InvoiceID
             )
    SELECT  bpa.VIP_BillingPointID ,
            u.VIP_UsageID
    FROM    VIP_Usage u
            INNER JOIN VIP_UsageTypes ut ON u.VIP_UsageTypeID = ut.VIP_UsageTypeID
            INNER JOIN VIP_BillingPointAccounts bpa ON u.VIP_AccountID = bpa.VIP_AccountID
            INNER JOIN VIP_AccountProducts ap ON bpa.VIP_AccountID = ap.VIP_AccountID
            INNER JOIN VIP_Products p ON ap.VIP_ProductID = p.VIP_ProductID
            INNER JOIN VIP_ProductBillingTypes pbt ON p.VIP_ProductBillingTypeID = pbt.VIP_ProductBillingTypeID
            INNER JOIN VIP_Accounts a ON a.VIP_AccountID = ap.VIP_AccountID
                                         AND a.VIP_UtilityID NOT IN ( 18, 19,
                                                              13 ) -- BGE
            LEFT JOIN tblInvoiceItemInvoice invI ON invI.VIP_UsageID = u.VIP_UsageID
                                                    AND invI.[Status] NOT IN (
                                                    'Voided' )

		-- Join against the product terms for utilities that can have multiple pricing types across the lifetime of the account
		LEFT JOIN VIP_AccountProducts apUsage
			ON  u.VIP_AccountID = apUsage.VIP_AccountID
				AND u.EndDate >= apUsage.StartDate AND u.EndDate <= apUsage.EndDate
		LEFT JOIN VIP_Products prod ON apUsage.VIP_ProductID = prod.VIP_ProductID
		LEFT JOIN dbo.VIP_ProductPricingTypes prodPT ON prodPT.VIP_ProductPricingTypeID = prod.VIP_ProductPricingTypeID

    WHERE   ut.Code IN ( 'ACTUAL', 'ESTIMATED', 'CANCELLED' )
            AND invI.VIP_UsageID IS NULL	-- Does NOT have a non-voided invoice on it
            AND u.StartDate >= '2013-01-01' -- had to put this in place when we implemented the new logic
--    AND u.VIP_UsageID NOT IN (SELECT VIP_UsageID FROM VIP_InvoiceItemsView WHERE VIP_UsageID IS NOT NULL)
            AND pbt.Code = @Type--'DUAL'
            AND ( u.Status NOT IN ( 'Review', 'ReInvoice', 'Loaded-Assoc', 'Hold' )
                  OR u.status IS NULL
                )

			-- Exclude Fixed Bill Type-B
			AND ISNULL(prodPT.Code,'') <> 'FIXEDBILL_B' 

    GROUP BY bpa.VIP_BillingPointID ,
            u.VIP_UsageID


--UNION

--SELECT DISTINCT -- DISTINCT to get only one record for this invoice
--	inv.VIP_BillingPointID
--	,usg.VIP_UsageID 
--FROM 
--	dbo.VIP_Invoices inv
--	INNER JOIN VIP_BillingPointAccounts bpa ON inv	.VIP_BillingPointID = bpa.VIP_BillingPointID
--	INNER JOIN VIP_AccountProducts ap ON bpa.VIP_AccountID = ap.VIP_AccountID
--	INNER JOIN VIP_Products p ON ap.VIP_ProductID = p.VIP_ProductID
--	INNER JOIN VIP_ProductBillingTypes pbt ON p.VIP_ProductBillingTypeID = pbt.VIP_ProductBillingTypeID
--	INNER JOIN VIP_InvoiceItems ii ON inv.VIP_InvoiceID = ii.VIP_InvoiceID
--	INNER JOIN dbo.VIP_Usage usg ON ii.VIP_UsageID = usg.VIP_UsageID
--	INNER JOIN VIP_Accounts a on a.VIP_AccountID = ap.VIP_AccountID
--       and a.VIP_UtilityID not in (18,19,13) -- BGE
--WHERE (1 = 1)
--	AND inv.PrecorrectionStatus = 'Reinvoice'
--	AND pbt.Code = @Type

UNION

SELECT bpa.VIP_BillingPointID, u.VIP_UsageID
FROM VIP_Usage u
	INNER JOIN VIP_UsageTypes ut ON u.VIP_UsageTypeID = ut.VIP_UsageTypeID
	INNER JOIN VIP_BillingPointAccounts bpa ON u.VIP_AccountID = bpa.VIP_AccountID
	INNER JOIN VIP_AccountProducts ap ON bpa.VIP_AccountID = ap.VIP_AccountID
	INNER JOIN VIP_Products p ON ap.VIP_ProductID = p.VIP_ProductID
	INNER JOIN VIP_ProductBillingTypes pbt ON p.VIP_ProductBillingTypeID = pbt.VIP_ProductBillingTypeID
	INNER JOIN VIP_Accounts a on a.VIP_AccountID = ap.VIP_AccountID
       and a.VIP_UtilityID not in (18,19,13) -- BGE
WHERE ut.Code IN ('ACTUAL', 'ESTIMATED', 'CANCELLED')
    AND u.VIP_UsageID NOT IN (SELECT VIP_UsageID FROM VIP_InvoiceItemsView WHERE VIP_UsageID IS NOT NULL)
	AND pbt.Code = 'RATE_READY'
	AND (u.Status not in('Review') or status is null)
	AND a.CoreCustomer = 0
GROUP BY bpa.VIP_BillingPointID, u.VIP_UsageID


GO
