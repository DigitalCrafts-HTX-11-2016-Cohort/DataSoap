
-- select * from dbo.v_ScheduledRewards_v2

CREATE VIEW dbo.v_ScheduledRewards_v2
AS 

WITH    RewardsAccounts
          AS ( SELECT   accp.VIP_AccountID ,
                        --reward.VIP_RewardID ,
                        reward.RewardGroup ,
                        --reward.VIP_ProductID ,
                        reward.RewardAmount ,
                        reward.Limit ,
                        reward.AmountRequired ,
                        reward.AmountRequired_UnitOfMeasure
               FROM     dbo.VIP_Rewards reward
                        INNER JOIN dbo.VIP_AccountProducts accp ON accp.VIP_ProductID = reward.VIP_ProductID
               GROUP BY accp.VIP_AccountID ,
                        --reward.VIP_RewardID ,
                        reward.RewardGroup ,
                        --reward.VIP_ProductID ,
                        reward.RewardAmount ,
                        reward.Limit ,
                        reward.AmountRequired ,
                        reward.AmountRequired_UnitOfMeasure
             ),
        MonthlyCalendarization
          AS ( SELECT   *
               FROM     Accounting.CalendarDateAllRange
               WHERE    CalendarDate BETWEEN '2017-01-01'
                                     AND     '2024-12-31'
                        AND DATEPART(DAY, CalendarDate) = 1
             ),
        GiftCardDateRange
          AS ( SELECT   ra.* ,
                        capv.FirstAccountProduct_StartDate ,
                        DATEADD(MONTH,
                                ra.Limit / ra.RewardAmount * ra.AmountRequired,
                                capv.FirstAccountProduct_StartDate) AS FinalGiftCardDate
               FROM     RewardsAccounts ra
                        INNER JOIN Products.mv_VIP_CumulativeAccountProductsView capv ON capv.VIP_AccountID = ra.VIP_AccountID
             ),
        RowNumberPartition
          AS ( SELECT   * , 
						--DATEADD(DAY,
      --                                                        1 - DATEPART(DAY,
      --                                                        gcdr.FirstAccountProduct_StartDate),
      --                                                        gcdr.FirstAccountProduct_StartDate) AS StartingDay,
						--DATEADD(DAY,
      --                                                        1 - DATEPART(DAY,
      --                                                        gcdr.FinalGiftCardDate),
      --                                                        gcdr.FinalGiftCardDate) AS FinalDay,
                        ROW_NUMBER() OVER ( PARTITION BY gcdr.VIP_AccountID ORDER BY mc.CalendarDate ) AS RowNumber
               FROM     GiftCardDateRange gcdr
                        INNER JOIN MonthlyCalendarization mc ON mc.CalendarDate BETWEEN DATEADD(DAY,
                                                              1 - DATEPART(DAY,
                                                              gcdr.FirstAccountProduct_StartDate),
                                                              gcdr.FirstAccountProduct_StartDate)
                                                              AND
                                                              DATEADD(DAY,
                                                              1 - DATEPART(DAY,
                                                              gcdr.FinalGiftCardDate),
                                                              gcdr.FinalGiftCardDate)
             ),
        GetRewardMonths
          AS ( SELECT   * ,
                        DATEPART(MONTH, CalendarDate) AS Month ,
                        DATEPART(YEAR, CalendarDate) AS Year
               FROM     RowNumberPartition
               WHERE    ( RowNumber - 1 ) % AmountRequired = 0
                        AND RowNumber <> 1
    --ORDER BY VIP_AccountID ,
    --        CalendarDate
             )--   SELECT  acv.UtilityCode ,
	--		acv.AccountStatus ,
 --           CalendarDate ,
 --           SUM(RewardAmount) AS RewardAmount
 --   FROM    GetRewardMonths
 --           INNER JOIN AccountServicePoint.mv_VIP_AccountCumulativeView_v2 acv ON acv.VIP_AccountID = GetRewardMonths.VIP_AccountID
 --   GROUP BY acv.UtilityCode ,
 --           CalendarDate ,
	--		acv.AccountStatus
	--ORDER BY acv.AccountStatus, CalendarDate, acv.UtilityCode
		,
        HorizontalPivot
          AS ( SELECT   acv.VIP_AccountID ,
						acv.UtilityCode ,
                        AccountStatus ,
                        Year ,
                        CASE WHEN Month = 1 THEN RewardAmount
                             ELSE 0.00
                        END AS January ,
                        CASE WHEN Month = 2 THEN RewardAmount
                             ELSE 0.00
                        END AS February ,
                        CASE WHEN Month = 3 THEN RewardAmount
                             ELSE 0.00
                        END AS March ,
                        CASE WHEN Month = 4 THEN RewardAmount
                             ELSE 0.00
                        END AS April ,
                        CASE WHEN Month = 5 THEN RewardAmount
                             ELSE 0.00
                        END AS May ,
                        CASE WHEN Month = 6 THEN RewardAmount
                             ELSE 0.00
                        END AS June ,
                        CASE WHEN Month = 7 THEN RewardAmount
                             ELSE 0.00
                        END AS July ,
                        CASE WHEN Month = 8 THEN RewardAmount
                             ELSE 0.00
                        END AS August ,
                        CASE WHEN Month = 9 THEN RewardAmount
                             ELSE 0.00
                        END AS September ,
                        CASE WHEN Month = 10 THEN RewardAmount
                             ELSE 0.00
                        END AS October ,
                        CASE WHEN Month = 11 THEN RewardAmount
                             ELSE 0.00
                        END AS November ,
                        CASE WHEN Month = 12 THEN RewardAmount
                             ELSE 0.00
                        END AS December
               FROM     GetRewardMonths
                        INNER JOIN AccountServicePoint.mv_VIP_AccountCumulativeView_v2 acv ON acv.VIP_AccountID = GetRewardMonths.VIP_AccountID
             )
    SELECT  VIP_AccountID ,
			UtilityCode ,
            AccountStatus ,
            Year ,
            SUM(January) AS January ,
            SUM(February) AS February ,
            SUM(March) AS March ,
            SUM(April) AS April ,
            SUM(May) AS May ,
            SUM(June) AS June ,
            SUM(July) AS July ,
            SUM(August) AS August ,
            SUM(September) AS September ,
            SUM(October) AS October ,
            SUM(November) AS November ,
            SUM(December) AS December
    FROM    HorizontalPivot
    GROUP BY
			VIP_AccountID , 
			UtilityCode ,
            AccountStatus ,
            YEAR


GO
