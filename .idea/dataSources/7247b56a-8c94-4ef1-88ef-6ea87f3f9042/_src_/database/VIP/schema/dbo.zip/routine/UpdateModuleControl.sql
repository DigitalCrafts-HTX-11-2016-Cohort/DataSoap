
CREATE PROCEDURE dbo.UpdateModuleControl
	
	@ModuleControlId				int,
	@ModuleDefID					int,
	@ControlKey						nvarchar(50),
	@ControlTitle					nvarchar(50),
	@ControlSrc						nvarchar(256),
	@IconFile						nvarchar(100),
	@ControlType					int,
	@ViewOrder						int,
	@HelpUrl						nvarchar(200),
	@SupportsPartialRendering		bit

AS
	UPDATE dbo.ModuleControls
	SET    
		ModuleDefId = @ModuleDefId,
		ControlKey = @ControlKey,
		ControlTitle = @ControlTitle,
		ControlSrc = @ControlSrc,
		IconFile = @IconFile,
		ControlType = @ControlType,
		ViewOrder = ViewOrder,
		HelpUrl = @HelpUrl,
		SupportsPartialRendering = @SupportsPartialRendering
	WHERE  ModuleControlId = @ModuleControlId
GO
