
CREATE PROCEDURE dbo.dnnLinks_UpdateLink

	@ItemId      int,
	@UserId      int,
	@CreatedDate DateTime,
	@Title       nvarchar(100),
	@Url         nvarchar(250),
	@ViewOrder   int,
	@Description nvarchar(2000)

AS

UPDATE Links
SET    CreatedByUser = @UserId,
       CreatedDate   = @CreatedDate,
       Title         = @Title,
       Url           = @Url,
       ViewOrder     = @ViewOrder,
       Description   = @Description
WHERE  ItemId = @ItemId

GO
