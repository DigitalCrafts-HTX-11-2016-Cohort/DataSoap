
CREATE PROCEDURE usp_VIP_UpdateAccountClass_Per_SPRATE
AS

--set to commercial
update VIP_Accounts set VIP_AccountClassID = 2
where SPRateName not in('G1','GM','GT','HG1') and SPRateName <> ''
and VIP_AccountClassID = 1 and CoreCustomer = 1 and 
VIP_MarketerID in(Select VIP_MarketerID from VIP_Marketers where Code in('CSS2'))

--set to residential
update VIP_Accounts set VIP_AccountClassID = 1
where SPRateName in('G1','GM','GT','HG1','HGM')
and VIP_AccountClassID = 2 and CoreCustomer = 1 AND 
VIP_MarketerID in(Select VIP_MarketerID from VIP_Marketers where Code in('CSS2'))
GO
