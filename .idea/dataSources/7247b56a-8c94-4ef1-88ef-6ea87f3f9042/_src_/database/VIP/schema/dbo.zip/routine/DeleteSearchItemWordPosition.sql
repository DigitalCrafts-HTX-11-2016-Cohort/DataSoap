
CREATE PROCEDURE dbo.DeleteSearchItemWordPosition
	@SearchItemWordPositionID int
AS

DELETE FROM dbo.SearchItemWordPosition
WHERE
	[SearchItemWordPositionID] = @SearchItemWordPositionID


GO
