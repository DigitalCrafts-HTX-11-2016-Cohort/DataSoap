

-- =============================================
-- Author:		Not Bryan Panjavan
-- Create date: Not on 2014-11-17
-- Description:	2014-11-17 - BPanjavan - This has been broken for a while.  I put in a fix to the insert statement so that it would succeed
-- =============================================
CREATE PROCEDURE [dbo].[usp_VIP_PGE_DropServiceAccountsPerSwitchDate_OLD]
AS

Begin Transaction
insert into VIP_AccountInteractions
SELECT
(select VIP_AccountInteractionTypeID from VIP_AccountInteractionTypes where Code = 'SWITCHED_PROVIDER'),
VIP_AccountID, 
NEWID(),
0,
'Complete',
GETDATE(),
GETDATE(),
NULL
--UtilityServiceAccountID, AccountStatus, SCH_EnrollSwitchDate, SwitchToRetailer 
from VIP_Accounts 
where SCH_EnrollSwitchDate <= GETDATE()
and YEAR(sch_enrollswitchdate) <> 1900
and SwitchToRetailer not in('VISTA','')
and AccountStatus = 'Enrolled'
and VIP_UtilityID = (Select VIP_UtilityID from VIP_Utilities where Code = 'PGE')
and CoreCustomer = 1

UPDATE VIP_Accounts set AccountStatus = 'Terminated' 
where VIP_AccountID in
(
	Select 
	VIP_AccountID
	from VIP_Accounts 
	where SCH_EnrollSwitchDate <= GETDATE()
	and YEAR(sch_enrollswitchdate) <> 1900
	and SwitchToRetailer not in('VISTA','')
	and AccountStatus = 'Enrolled'
	and VIP_UtilityID = (Select VIP_UtilityID from VIP_Utilities where Code = 'PGE')
	and CoreCustomer = 1
)

COMMIT


GO
