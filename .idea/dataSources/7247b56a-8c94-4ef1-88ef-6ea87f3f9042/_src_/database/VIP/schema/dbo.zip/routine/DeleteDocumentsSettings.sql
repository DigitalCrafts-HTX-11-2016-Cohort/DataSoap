
CREATE  PROCEDURE dbo.DeleteDocumentsSettings
@ModuleId INT
AS
DELETE
FROM DocumentsSettings
WHERE  ModuleId = @ModuleId
GO
