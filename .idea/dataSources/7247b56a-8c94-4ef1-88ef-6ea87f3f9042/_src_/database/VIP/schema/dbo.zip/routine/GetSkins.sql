
CREATE procedure dbo.[GetSkins]

    @PortalID		int

AS
    SELECT *
    FROM	dbo.Skins
    WHERE   ( PortalID is null or PortalID = @PortalID )
    ORDER BY PortalID desc
GO
