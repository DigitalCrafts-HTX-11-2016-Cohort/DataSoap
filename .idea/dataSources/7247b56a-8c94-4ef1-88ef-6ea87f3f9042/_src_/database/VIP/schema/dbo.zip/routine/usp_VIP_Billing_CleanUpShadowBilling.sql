-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE usp_VIP_Billing_CleanUpShadowBilling
	@VIP_InvoiceID int
AS

delete VIP_InvoiceBreakdowns where VIP_InvoiceID in
(
	Select VIP_InvoiceID from VIP_Invoices where VIP_InvoiceID = @VIP_InvoiceID
)

delete from VIP_InvoiceItems where VIP_InvoiceID in
(
	Select VIP_InvoiceID from VIP_Invoices where VIP_InvoiceID = @VIP_InvoiceID
)

delete from VIP_Invoices where VIP_InvoiceID = @VIP_InvoiceID
GO
