
CREATE PROCEDURE dbo.[GetUsersByEmail]
    @PortalID		int,
    @EmailToMatch   nvarchar(256),
    @PageIndex      int,
    @PageSize       int
AS
BEGIN
    -- Set the page bounds
    DECLARE @PageLowerBound INT
    DECLARE @PageUpperBound INT
    SET @PageLowerBound = @PageSize * @PageIndex
    SET @PageUpperBound = @PageSize - 1 + @PageLowerBound

    -- Create a temp table TO store the select results
    CREATE TABLE #PageIndexForUsers
    (
        IndexId int IDENTITY (0, 1) NOT NULL,
        UserId int
    )

    -- Insert into our temp table
    IF( @EmailToMatch IS NULL )
        INSERT INTO #PageIndexForUsers (UserId)
            SELECT UserId FROM	dbo.vw_Users 
            WHERE  Email IS NULL
				AND ( PortalId = @PortalID OR (PortalId Is Null AND @PortalID is null ))
            ORDER BY Email
    ELSE
        INSERT INTO #PageIndexForUsers (UserId)
            SELECT UserId FROM	dbo.vw_Users 
            WHERE  LOWER(Email) LIKE LOWER(@EmailToMatch)
				AND ( PortalId = @PortalID OR (PortalId Is Null AND @PortalID is null ))
            ORDER BY Email

    SELECT  *
    FROM	dbo.vw_Users u, 
			#PageIndexForUsers p
    WHERE  u.UserId = p.UserId
			AND ( PortalId = @PortalID OR (PortalId Is Null AND @PortalID is null ))
			AND p.IndexId >= @PageLowerBound AND p.IndexId <= @PageUpperBound
    ORDER BY LOWER(u.Email)

    SELECT  TotalRecords = COUNT(*)
    FROM    #PageIndexForUsers

END


GO
