
-- =============================================
-- Author:		Not Bryan Panjavan
-- Create date: Not on 2014-11-17
-- Description:	2014-11-17 - BPanjavan - This has been broken for a while.  I put in a fix to the insert statement so that it would succeed
-- =============================================
CREATE PROCEDURE [dbo].[usp_VIP_PGE_DropServiceAccountsPerSwitchDate]
AS
	DECLARE @UtilityDropAccountInteractionTypeId INT;
	DECLARE @SwitchProviderAccountInteractionTypeId INT;
	DECLARE @NewAccountInteractionId INT;
	DECLARE @VipAccountId INT;

	SELECT @SwitchProviderAccountInteractionTypeId = VIP_AccountInteractionTypeID 
	FROM VIP_AccountInteractionTypes WHERE Code = 'SWITCHED_PROVIDER';

	SELECT @UtilityDropAccountInteractionTypeId = VIP_AccountInteractionTypeID 
	FROM VIP_AccountInteractionTypes WHERE Code = 'UTILITY_DROP';

	DECLARE SwitchProviderCursor CURSOR FOR
	SELECT
		VIP_AccountID
	FROM VIP_Accounts 
	WHERE SCH_EnrollSwitchDate <= GETDATE()
		AND YEAR(sch_enrollswitchdate) <> 1900
		AND SwitchToRetailer not in('VISTA','')
		AND AccountStatus = 'Enrolled'
		AND VIP_UtilityID = (Select VIP_UtilityID from VIP_Utilities where Code = 'PGE')
		AND CoreCustomer = 1

	BEGIN TRANSACTION
		--Create Account Interactions for SWITCHED PROVIDER
		INSERT INTO VIP_AccountInteractions
		SELECT
		      @SwitchProviderAccountInteractionTypeId
			, VIP_AccountID
			, NEWID()
			, 0
			, 'Complete'
			, GETDATE()
			, GETDATE()
			, NULL
			--, UtilityServiceAccountID, AccountStatus, SCH_EnrollSwitchDate, SwitchToRetailer 
		FROM VIP_Accounts 
		WHERE SCH_EnrollSwitchDate <= GETDATE()
			AND YEAR(sch_enrollswitchdate) <> 1900
			AND SwitchToRetailer not in('VISTA','')
			AND AccountStatus = 'Enrolled'
			AND VIP_UtilityID = (Select VIP_UtilityID from VIP_Utilities where Code = 'PGE')
			AND CoreCustomer = 1

		--Create Account Interaction for UTILITY DROPS
		OPEN SwitchProviderCursor
			FETCH NEXT FROM SwitchProviderCursor
			INTO @VipAccountId

			WHILE @@FETCH_STATUS = 0
			BEGIN
				--Insert Utility Drop Account Interaction
				INSERT INTO VIP_AccountInteractions
				VALUES(@UtilityDropAccountInteractionTypeId, @VipAccountId, NEWID(), 0, 'Complete', GETDATE(), GETDATE(), NULL)

				--Retrieve New Account Interaction Id
				SELECT @NewAccountInteractionId = SCOPE_IDENTITY();

				--Insert Utility Drop Account Interaction Audit
				INSERT INTO VIP_AccountInteractionAudit
				VALUES(@NewAccountInteractionId, 'Information', 'Medium', GETDATE(), 'Termination Accepted')

				FETCH NEXT FROM SwitchProviderCursor
				INTO @VipAccountId
			END

		CLOSE SwitchProviderCursor;
		DEALLOCATE SwitchProviderCursor;

		--Update Account to Terminated
		UPDATE VIP_Accounts SET AccountStatus = 'Terminated' 
		WHERE VIP_AccountID IN
		(
			SELECT 
				VIP_AccountID
			FROM VIP_Accounts 
			WHERE SCH_EnrollSwitchDate <= GETDATE()
				AND YEAR(sch_enrollswitchdate) <> 1900
				AND SwitchToRetailer not in('VISTA','')
				AND AccountStatus = 'Enrolled'
				AND VIP_UtilityID = (Select VIP_UtilityID from VIP_Utilities where Code = 'PGE')
				AND CoreCustomer = 1
		)

	COMMIT

GO
