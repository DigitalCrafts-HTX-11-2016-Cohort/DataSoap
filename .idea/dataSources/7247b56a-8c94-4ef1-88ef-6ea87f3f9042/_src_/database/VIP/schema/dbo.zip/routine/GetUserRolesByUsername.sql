
CREATE PROCEDURE dbo.GetUserRolesByUsername

@PortalID int, 
@Username nvarchar(100), 
@Rolename nvarchar(50)

AS

IF @UserName Is Null
	BEGIN
		SELECT	R.*,        
				U.DisplayName As FullName,
				UR.UserRoleID,
				UR.UserID,
				UR.EffectiveDate,
				UR.ExpiryDate,
				UR.IsTrialUsed
			FROM	dbo.UserRoles UR
				INNER JOIN dbo.Users U ON UR.UserID = U.UserID
				INNER JOIN dbo.Roles R ON R.RoleID = UR.RoleID
			WHERE  R.PortalId = @PortalID
				AND    (R.Rolename = @Rolename or @RoleName is NULL)
	END
ELSE
	BEGIN
		IF @RoleName Is NULL
			BEGIN
				SELECT	R.*,        
						U.DisplayName As FullName,
						UR.UserRoleID,
						UR.UserID,
						UR.EffectiveDate,
						UR.ExpiryDate,
						UR.IsTrialUsed
					FROM	dbo.UserRoles UR
						INNER JOIN dbo.Users U ON UR.UserID = U.UserID
						INNER JOIN dbo.Roles R ON R.RoleID = UR.RoleID
					WHERE  R.PortalId = @PortalID
						AND    (U.Username = @Username or @Username is NULL)
			END
		ELSE
			BEGIN
				SELECT	R.*,        
						U.DisplayName As FullName,
						UR.UserRoleID,
						UR.UserID,
						UR.EffectiveDate,
						UR.ExpiryDate,
						UR.IsTrialUsed
					FROM	dbo.UserRoles UR
						INNER JOIN dbo.Users U ON UR.UserID = U.UserID
						INNER JOIN dbo.Roles R ON R.RoleID = UR.RoleID
					WHERE  R.PortalId = @PortalID
						AND    (R.Rolename = @Rolename or @RoleName is NULL)
						AND    (U.Username = @Username or @Username is NULL)
			END
	END

GO
