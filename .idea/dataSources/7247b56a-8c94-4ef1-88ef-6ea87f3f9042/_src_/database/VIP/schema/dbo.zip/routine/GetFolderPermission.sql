
CREATE PROCEDURE dbo.[GetFolderPermission]
	
	@FolderPermissionID int

AS
SELECT *
FROM dbo.vw_FolderPermissions
WHERE FolderPermissionID = @FolderPermissionID

GO
