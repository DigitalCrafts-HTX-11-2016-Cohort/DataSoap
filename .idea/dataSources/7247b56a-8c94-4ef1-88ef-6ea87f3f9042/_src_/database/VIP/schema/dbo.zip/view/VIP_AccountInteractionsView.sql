
CREATE VIEW [dbo].[VIP_AccountInteractionsView]
AS
Select *, '' Archived from VIP_AccountInteractions
union
Select *, 'Archived' Archived from VIP_Archive..VIP_AccountInteractions

GO
