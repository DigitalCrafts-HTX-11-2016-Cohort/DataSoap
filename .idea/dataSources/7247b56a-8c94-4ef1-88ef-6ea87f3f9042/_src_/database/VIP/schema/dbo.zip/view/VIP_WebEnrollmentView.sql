CREATE VIEW dbo.VIP_WebEnrollmentView
AS
SELECT     vbe.VIP_BatchEnrollEntryID, vbe.BatchEnrollmentStatus, dbo.VIP_ProductBundles.Code AS ProductBundle, dbo.VIP_Retailers.Code AS Retailer, 
                      dbo.VIP_Utilities.Code AS Utility, dbo.VIP_AccountClasses.Code AS AccountClass, dbo.VIP_Marketers.Code AS Marketer, vbe.UtilityServiceAccountID, 
                      vbe.ServiceEmail, vbe.CompanyName, vbe.ServiceFirstName, vbe.ServiceLastName, vbe.ServiceLastName + ', ' + vbe.ServiceFirstName AS ServiceAccountName, 
                      vbe.ServiceAddress1, vbe.ServiceAddress2, vbe.ServiceCity, vbe.ServiceStateCode, vbe.ServiceZipCode, vbe.ServicePhone, 
                      vbe.ServiceAddress1 + ' ' + ISNULL(vbe.ServiceAddress2, '') AS ServiceAddressData, vbe.ServiceCity + ', ' + vbe.ServiceStateCode AS ServiceCityStateZip, 
                      LEFT(vbe.ServicePhone, 3) + '-' + SUBSTRING(vbe.ServicePhone, 3, 3) + '-' + RIGHT(vbe.ServicePhone, 4) AS ServPhone, vbe.BillingFirstName, vbe.BillingLastName, 
                      vbe.BillingAddress1, vbe.BillingAddress2, vbe.BillingCity, vbe.BillingStateCode, vbe.BillingZipCode, vbe.BillingPhone, 
                      vbe.BillingAddress1 + ' ' + ISNULL(vbe.BillingAddress2, '') AS BillingAddressData, vbe.BillingCity + ', ' + vbe.BillingStateCode AS BillingCityStateZip, 
                      vbe.ContractMonths, vbe.MasterAccountID, vbe.BatchEnrollmentFile, vbe.PromotionCode, vbe.ReferralAccount,
                          (SELECT     TOP (1) CONVERT(varchar(5000), AuditMessage) AS Expr1
                            FROM          dbo.VIP_AccountInteractionAudit
                            WHERE      (VIP_AccountInteractionID IN
                                                       (SELECT     TOP (1) VIP_AccountInteractionID
                                                         FROM          dbo.VIP_AccountInteractions
                                                         WHERE      (VIP_AccountID IN
                                                                                    (SELECT     VIP_AccountID
                                                                                      FROM          dbo.VIP_Accounts
                                                                                      WHERE      (VIP_AccountGUID = vbe.MasterAccountID))) AND (VIP_AccountInteractionTypeID IN (49))
                                                         ORDER BY StartDateTime DESC))
                            ORDER BY AuditDateTime) AS AuditMessage,
                          (SELECT     CASE WHEN COUNT(*) > 0 THEN 'Service account was previously enrolled in VIP' ELSE '' END AS Message
                            FROM          dbo.VIP_AccountInteractionsView
                            WHERE      (VIP_AccountID IN
                                                       (SELECT     VIP_AccountID
                                                         FROM          dbo.VIP_Accounts AS VIP_Accounts_1
                                                         WHERE      (UtilityServiceAccountID = vbe.UtilityServiceAccountID))) AND (VIP_AccountInteractionTypeID IN
                                                       (SELECT     VIP_AccountInteractionTypeID
                                                         FROM          dbo.VIP_AccountInteractionTypes
                                                         WHERE      (Code = 'MONTHLY_USAGE'))) AND (StartDateTime < GETDATE())) AS PrevEnrolledMessage
FROM         dbo.VIP_BatchEnrollmentEntries AS vbe INNER JOIN
                      dbo.VIP_Retailers ON dbo.VIP_Retailers.VIP_RetailerID = vbe.VIP_RetailerID INNER JOIN
                      dbo.VIP_Utilities ON dbo.VIP_Utilities.VIP_UtilityID = vbe.VIP_UtilityID INNER JOIN
                      dbo.VIP_AccountClasses ON dbo.VIP_AccountClasses.VIP_AccountClassID = vbe.VIP_AccountClassID INNER JOIN
                      dbo.VIP_Marketers ON dbo.VIP_Marketers.VIP_MarketerID = vbe.VIP_MarketerID INNER JOIN
                      dbo.VIP_ProductBundles ON dbo.VIP_ProductBundles.VIP_ProductBundleID = vbe.VIP_ProductBundleID
GO
