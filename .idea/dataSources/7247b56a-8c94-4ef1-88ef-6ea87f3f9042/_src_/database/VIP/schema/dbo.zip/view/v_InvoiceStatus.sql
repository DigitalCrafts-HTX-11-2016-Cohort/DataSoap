
CREATE VIEW dbo.v_InvoiceStatus
AS

	WITH PGE AS
	(
		SELECT
			  'PGE' AS UtilityCode
			, I.VIP_InvoiceID
			, I.InvoiceDate AS InvoiceDate
			, H.Invoice_type AS InvoiceType
			, TFO.FileName AS InvoiceFile
			, I.DateDue AS DueDate
			, I.Status AS InvoiceStatus
			, I.InvoiceAmount
			, H.Transaction_Date AS TransactionDate
			, H.LDC_Act_No AS UtilityAccountNumber
			, H.Meter_Number AS MeterNumber
			, H.End_Customer AS CustomerName
			, H.CustomerReferanceNumber AS ReferenceNumber
			, H.Invoice_Period_Start AS InvoicePeriodStart
			, H.Invoice_Period_End AS InvoicePeriodEnd
			, CASE
				WHEN AAD.Transaction_Status = 'ACCEPTANCE' THEN 'ACCEPT'
				WHEN AAD.Transaction_Status = 'REJECTION' THEN 'REJECT'
			  END AS ActionCode
			, AAD.Transaction_Status AS TransactionStatus
			, AAD.Error_Desc AS ErrorCode
			, AAD.Comments AS ErrorReason
			, AAD.Comments AS ErrorDescription
			, TI.[FileName] AS StatusFile
		FROM VIP_Invoices I
		INNER JOIN B2B.PGE_Out810InvoiceHeader H
			ON I.VIP_InvoiceID = H.Invoice_No
		INNER JOIN B2B.PGE_Out810Invoice O
			ON H.PGE_Out810Invoice_ID = O.PGE_Out810Invoice_ID
		INNER JOIN B2B.PGE_Out810Invoice_BillDetail DB
			ON H.PGE_Out810InvoiceHeader_ID = DB.PGE_Out810InvoiceHeader_ID
			AND DB.Charges_Desc_Code = 'NET'
		LEFT JOIN B2B.PGE_In824ApplicationAdvice_Detail AAD
			ON AAD.Reference_No = H.Invoice_No
		LEFT JOIN B2B.TransactionFile_Outbound TFO
			ON O.PGE_Out810Invoice_ID = TFO.SourceTransactionID
			AND TFO.SourceTableName = 'PGE_Out810Invoice'
		LEFT JOIN B2B.TransactionFile_Inbound TI
			ON AAD.PGE_In824ApplicationAdvice_ID = TI.DestinationTransactionID
			AND TI.DestinationTableName = 'PGE_In824ApplicationAdvice'
		WHERE 1=1
			AND I.Status = 'Exported'
	)
	, PSEG AS
	(
		SELECT
			 'PSEG' AS UtilityCode
			, I.VIP_InvoiceID
			, I.InvoiceDate AS InvoiceDate
			, ID.Charge_Code_Line_Item_Charge AS InvoiceType
			, TFO.FileName AS InvoiceFile
			, I.DateDue AS DueDate
			, I.Status AS InvoiceStatus
			, ID.Charge_Amount_Line_Item_Charge AS InvoiceAmount
			, ID.Transaction_Date AS TransactionDate
			, ID.Utility_Account_Number AS UtilityAccountNumber
			, NULL AS MeterNumber
			, ID.Customer_Name AS CustomerName
			, ID.Original_Document_ID AS ReferenceNumber
			, ID.Service_Period_Start_Date AS InvoicePeriodStart
			, ID.Service_Period_End_Date AS InvoicePeriodEnd
			, CASE 
				WHEN (ISNULL(P.Action, 'NA') = 'PAYMENT') THEN 'ACCEPT'
				WHEN (ISNULL(AAD.Action, 'NA') = 'REJECT') THEN 'REJECT'
				ELSE NULL
			  END AS ActionCode
			, CASE 
				WHEN (ISNULL(P.Action, 'NA') = 'PAYMENT') THEN 'ACCEPTANCE'
				WHEN (ISNULL(AAD.Action, 'NA') = 'REJECT') THEN 'REJECTION'
				ELSE NULL 
			  END AS TransactionStatus
			, AAD.Error_Code AS ErrorCode
			, AAD.Error_Reason AS ErrorReason
			, AAD.Error_Description AS ErrorDescription
			, ISNULL(TI.[FileName], P.FileName) AS StatusFile
		FROM VIP_Invoices I
		INNER JOIN B2B.PSEG_Out810Invoice_Detail ID
			ON I.VIP_InvoiceID = ID.Document_Tracking_Number
		INNER JOIN B2B.PSEG_Out810Invoice IH
			ON ID.PSEG_Out810Invoice_ID = IH.PSEG_Out810Invoice_ID
		LEFT JOIN B2B.PSEG_In824ApplicationAdvice_Detail AAD
			ON AAD.Utility_Account_Number = ID.Utility_Account_Number
			AND ID.Document_Tracking_Number = AAD.Original_Tracking_Number
			AND ID.Original_Document_ID = AAD.Original_Document_ID
		LEFT JOIN B2B.TransactionFile_Outbound TFO
			ON IH.PSEG_Out810Invoice_ID = TFO.SourceTransactionID
			AND TFO.SourceTableName = 'PSEG_Out810Invoice'
		LEFT JOIN B2B.TransactionFile_Inbound TI
			ON AAD.PSEG_In824ApplicationAdvice_ID = TI.DestinationTransactionID
			AND TI.DestinationTableName = 'PGE_In824ApplicationAdvice'
		LEFT JOIN B2B.v_PSEG_Payments P
			ON ID.Utility_Account_Number = P.UtilityAccountNumber
			AND ID.Original_Document_ID = P.OriginalReferenceNumber
		WHERE 1=1
			AND I.Status = 'Exported'
	)
	, INV_STAT AS
	(
		SELECT *  FROM PGE

		UNION ALL

		SELECT * FROM PSEG

	)

	SELECT *
	FROM INV_STAT
	WHERE 1=1

GO
