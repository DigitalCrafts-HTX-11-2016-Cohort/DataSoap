
create procedure dbo.DeleteModuleSettings
@ModuleId      int
as

DELETE FROM dbo.ModuleSettings 
WHERE ModuleId = @ModuleId


GO
