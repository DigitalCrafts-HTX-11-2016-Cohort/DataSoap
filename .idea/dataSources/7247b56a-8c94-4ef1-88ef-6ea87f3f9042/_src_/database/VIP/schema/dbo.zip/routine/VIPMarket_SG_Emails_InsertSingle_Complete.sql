
-- =============================================
-- Author:		BPanjavan
-- Description:	Used in Single Sendign Delegation Form, inserts a record of the completed Email that got sent
-- =============================================
CREATE PROCEDURE [dbo].VIPMarket_SG_Emails_InsertSingle_Complete
(
	@userID VARCHAR(50)
	,@accountNumber VARCHAR(50)
	,@emailAddress VARCHAR(50)
	,@DateSent DATETIME
	,@Status VARCHAR(50)
	,@StatusReason VARCHAR(100)
	,@EmailText TEXT
	,@EmailAttachments VARCHAR(400) = null
)
AS
BEGIN

INSERT INTO dbo.VIPMarket_SG_Email
        ( CreatedBy ,
          CreatedOn ,
          ModifiedBy ,
          ModifiedOn ,
          Account_Number ,
          SelectedRow ,
          EmailSent_DateTime ,
          Status ,
          StatusReason ,
          EmailAddress ,
          EmailText ,
          EmailAttachments
        )
SELECT TOP 1
	@userID
	,GETDATE()
	,@userID
	,GETDATE()
	,pr.Account_Number
	,pricing.VIPMARKET_SG_Pricing_ID 
	,@DateSent
	,@Status
	,@StatusReason
	,@emailAddress
	,@EmailText
	,@EmailAttachments
FROM dbo.VIPMARKET_SG_ELG_PREMISE pr INNER JOIN dbo.VIPMARKET_SG_Pricing pricing ON pricing.Account_Number = pr.Account_Number
WHERE pr.Account_Number = @accountNumber
ORDER BY pricing.ImportDate DESC

----VALUES  ( @userID , -- CreatedBy - varchar(100)
----          GETDATE() , -- CreatedOn - datetime
----          @userID , -- ModifiedBy - varchar(100)
----          GETDATE() , -- ModifiedOn - datetime
----          @accountNumber , -- Account_Number - varchar(50)
----          0 , -- SelectedRow - int
----          '2015-03-31 03:55:45' , -- EmailSent_DateTime - datetime
----          '' , -- Status - varchar(50)
----          '' , -- StatusReason - varchar(500)
----          '' , -- EmailAddress - varchar(100)
----          '' , -- EmailText - text
----          ''  -- EmailAttachments - varchar(800)
----        )

----UPDATE dbo.[VIPMarket_SG_Email]
----SET EmailSent_DateTime = @DateSent
----	,[Status] = @Status
----	,[StatusReason] = @StatusReason
----	,[EmailText] = @EmailText
----	,EmailAttachments = @EmailAttachments
----WHERE
----	VIPMarket_SG_Email_ID = @VIPMarket_SG_Email_ID

END


GO
