
CREATE VIEW dbo.[vw_Modules]
AS
	SELECT	
		M.PortalID,
		TM.TabId,
        TM.TabModuleId,
		M.ModuleID,
		M.ModuleDefID,
        TM.ModuleOrder,
        TM.PaneName,
        M.ModuleTitle,
        TM.CacheTime,
        TM.Alignment,
        TM.Color,
        TM.Border,
		CASE WHEN LEFT(LOWER(TM.IconFile), 6) = 'fileid' 
			THEN
				(SELECT Folder + FileName  
					FROM dbo.Files 
					WHERE 'fileid=' + convert(varchar,dbo.Files.FileID) = TM.IconFile
				) 
			ELSE 
				TM.IconFile  
			END 
		AS IconFile,
		M.AllTabs,
		TM.Visibility,
		M.IsDeleted,
		M.Header,
		M.Footer,
		M.StartDate,
		M.EndDate,
		TM.ContainerSrc,
		TM.DisplayTitle,
		TM.DisplayPrint,
		TM.DisplaySyndicate,
		M.InheritViewPermissions,
		DM.DesktopModuleID, 
		DM.FriendlyName, 
		DM.Description, 
		DM.Version, 
		DM.IsPremium, 
		DM.IsAdmin, 
		DM.BusinessControllerClass, 
		DM.FolderName, 
        DM.ModuleName, 
        DM.SupportedFeatures, 
        DM.CompatibleVersions, 
        DM.Dependencies, 
        DM.Permissions,
		MD.DefaultCacheTime,
		MC.ModuleControlId,
		MC.ControlSrc,
		MC.ControlType,
		MC.ControlTitle,
		MC.HelpURL, 
		MC.SupportsPartialRendering
	FROM   dbo.ModuleDefinitions AS MD 
	INNER JOIN dbo.Modules AS M ON MD.ModuleDefID = M.ModuleDefID 
	INNER JOIN dbo.DesktopModules AS DM ON MD.DesktopModuleID = DM.DesktopModuleID 
	INNER JOIN dbo.ModuleControls AS MC ON MD.ModuleDefID = MC.ModuleDefID 
	LEFT OUTER JOIN dbo.Tabs AS T 
	  INNER JOIN dbo.TabModules AS TM ON T.TabID = TM.TabID 
		ON M.ModuleID = TM.ModuleID
	WHERE (MC.ControlKey IS NULL)

GO
