
CREATE VIEW [dbo].[VIPMARKET_CGK_DAT_FILE_View]
AS

	WITH tblCGK_DAT_RECORD_EXPORT_CountPerFile AS
	(
		SELECT 
			datExp.VIPMarket_CGK_DAT_FILEID	
			,NumberOfRecords = COUNT(1)
		FROM 
			dbo.VIPMarket_CGK_DAT_RECORD_EXPORT datExp
		WHERE (1 = 1)
		GROUP BY
			datExp.VIPMarket_CGK_DAT_FILEID	
	)
	SELECT
		fl.VIPMARKET_CGK_DAT_FILEID,
		fl.VIPMARKET_CGK_DAT_FILE_KEYNAME,
		fl.CreatedBy,
		fl.CreatedOn,
		fl.ModifiedBy,
		fl.ModifiedOn,
		fl.FileName,
		fl.ExportDate,
		NumberOfRecords = ISNULL(cpf.NumberOfRecords,0)
		,CreatedByUserName = ISNULL(userCreatedBy.DisplayName, 'N/A')
		,ModifiedByUserName = ISNULL(userModifiedBy.DisplayName, 'N/A')
	FROM
		dbo.VIPMARKET_CGK_DAT_FILE fl
		LEFT JOIN tblCGK_DAT_RECORD_EXPORT_CountPerFile cpf ON fl.VIPMarket_CGK_DAT_FILEID = cpf.VIPMarket_CGK_DAT_FILEID
		LEFT JOIN Users userCreatedBy ON fl.CreatedBy = userCreatedBy.UserID
		LEFT JOIN Users userModifiedBy ON fl.CreatedBy = userModifiedBy.UserID


GO
