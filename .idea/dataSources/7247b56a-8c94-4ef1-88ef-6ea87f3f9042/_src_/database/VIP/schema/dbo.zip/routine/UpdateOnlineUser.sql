
create procedure dbo.UpdateOnlineUser

@UserID 	int,
@PortalID 	int,
@TabID 		int,
@LastActiveDate datetime 

as
BEGIN
	IF EXISTS (SELECT UserID FROM dbo.UsersOnline WHERE UserID = @UserID and PortalID = @PortalID)
		UPDATE 
			dbo.UsersOnline
		SET 
			TabID = @TabID,
			LastActiveDate = @LastActiveDate
		WHERE
			UserID = @UserID
			and 
			PortalID = @PortalID
	ELSE
		INSERT INTO
			dbo.UsersOnline
			(UserID, PortalID, TabID, CreationDate, LastActiveDate) 
		VALUES
			(@UserID, @PortalID, @TabID, GetDate(), @LastActiveDate)

END


GO
