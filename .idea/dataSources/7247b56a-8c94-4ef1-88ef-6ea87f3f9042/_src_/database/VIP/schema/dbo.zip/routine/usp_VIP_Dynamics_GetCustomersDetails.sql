CREATE PROCEDURE [dbo].[usp_VIP_Dynamics_GetCustomersDetails]
	@VIP_AccountID int
AS
SELECT bp.VIP_BillingPointID, bp.DynamicsCustomerID, bp.BillingAttentionTo, bp.Address1, bp.Address2, bp.City, bp.ZipCode, bp.State, bp.Phone,
	a.CompanyName CustomerName, CoreCustomer, ServiceLastName,
	(SELECT Name FROM VIP_Utilities where VIP_UtilityID = a.VIP_UtilityID) Utility,
	(SELECT Name FROM VIP_AccountClasses where VIP_AccountClassID =	a.VIP_AccountClassID) AccountClass,
	a.UtilityServiceAccountID ServiceAccountID,
	a.UtilityAccountNumber
FROM VIP_Accounts a
	INNER JOIN VIP_BillingPointAccounts bpa ON a.VIP_AccountID = bpa.VIP_AccountID
	INNER JOIN VIP_BillingPoints bp ON bpa.VIP_BillingPointID = bp.VIP_BillingPointID
WHERE a.VIP_AccountID = @VIP_AccountID
GO
