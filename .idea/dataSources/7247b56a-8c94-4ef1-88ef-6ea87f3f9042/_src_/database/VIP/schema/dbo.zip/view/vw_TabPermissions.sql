
CREATE VIEW dbo.vw_TabPermissions

AS

	SELECT  TP.TabPermissionID, 
		TP.TabID, 
		P.PermissionID, 
		TP.RoleID, 
		CASE TP.RoleID
			when -1 then 'All Users'
			when -2 then 'Superuser'
			when -3 then 'Unauthenticated Users'
			else 	R.RoleName
		END AS 'RoleName',
		TP.AllowAccess, 
		TP.UserID,
		U.Username,
		U.DisplayName, 
		P.PermissionCode, 
		P.ModuleDefID, 
		P.PermissionKey, 
		P.PermissionName,
		T.PortalId
	FROM dbo.TabPermission AS TP 
		INNER JOIN dbo.Tabs AS T ON TP.TabID = T.TabID	
		LEFT OUTER JOIN dbo.Permission AS P ON TP.PermissionID = P.PermissionID 
		LEFT OUTER JOIN dbo.Roles AS R ON TP.RoleID = R.RoleID
		LEFT OUTER JOIN dbo.Users AS U ON TP.UserID = U.UserID

GO
