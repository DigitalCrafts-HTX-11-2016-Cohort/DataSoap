
CREATE procedure dbo.[GetUserRole]

	@PortalID int, 
	@UserID int, 
	@RoleId int

AS
SELECT	r.*, 
        ur.UserRoleID, 
        ur.UserID, 
        ur.EffectiveDate, 
        ur.ExpiryDate, 
        ur.IsTrialUsed
	FROM	dbo.UserRoles ur
		INNER JOIN dbo.UserPortals up on ur.UserId = up.UserId
		INNER JOIN dbo.Roles r on r.RoleID = ur.RoleID
	WHERE   up.UserId = @UserID
		AND     up.PortalId = @PortalID
		AND     ur.RoleId = @RoleId

GO
