
--/* ========================================================
---- Author:		
---- Modified:    27Aug2013, Debra Johnson
---- Created:
---- Database:    IEX-SQL-01
---- Department:  Operations
---- Description: Add SenderID to filter criteria for Inbound records
---- Updated: JBecker updated to accept a change in pge logic for disconnect.
-- ========================================================*/

CREATE PROCEDURE [dbo].[usp_VIP_GetPGEDropResponse_Exclude_Com_Disconnect]
    @Reason VARCHAR(30) = NULL ,
	---added 07/21/2014
    @OperationType VARCHAR(30) = NULL
AS --DECLARE @Reason varchar(30)
 --DECLARE @OperationType varchar(30)
 --SET @Reason = 'SVC/DISCONNECT'
 --SET @OperationType = 'ADV-DISCONNECT'
    SELECT  [RecordType] ,
            [RecordVersion] ,
            [SenderID] ,
            [SenderCustomerID] ,
            [ReceiverID] ,
            [ReceiverCustomerID] ,
            [TimeStamp] ,
            [VIPMARKET_PGE_DASRID] AS RecordID ,
            [OperationType] ,
            [ServiceRelationshipCount] ,
            [TypeOfServiceRelationship] ,
            [Reason] ,
            [Comment] ,
            [UDCID] ,
            [UDCAccountID] ,
            [EffStartDate] ,
            [EffEndDate] ,
            [AccountStatus] ,
            [PendingStatus] ,
            [PendingSPIdentifier] ,
            [ReadingEstMethod] ,
            [Commodity] ,
            [CustomerName] ,
            [ContactLastName] ,
            [ContactFirstName] ,
            [ContactMiddleName] ,
            [HouseNumber] ,
            [HouseFractionNumber] ,
            [StreetPrefix] ,
            [StreetName] ,
            [StreetSuffix] ,
            [UnitNumber] ,
            [City] ,
            [State] ,
            [Country] ,
            [Zip] ,
            [ZipExtension4] ,
            [USPSRt] ,
            [StandardTimeZone] ,
            [DaylightTimeZone] ,
            [ServiceCategory] ,
            [MeterCongestionZone] ,
            [UsageProfile] ,
            [BillingOption] ,
            [UDCRateName] ,
            [SPRateName] ,
            [PhoneInternationalAccess] ,
            [PhoneAreaCode] ,
            [PhoneNumber] ,
            [PhoneExtNumber] ,
            [FAXNumber] ,
            [RenewableEnergyProvider] ,
            [MeterCount] ,
            [Meter] ,
            [ChangeReason] ,
            [GUID]
    FROM    [VIPMARKET_PGE_DASR]
    WHERE   SenderID = '006912877' -- Inbound
            AND VIPMARKET_PGE_DASR.STATUS = 'Loaded'
			AND OperationType NOT LIKE 'COM-DISCONNECT'
	---added 07/21/2014
            AND ( @Reason IS NULL
                  OR ( @Reason IS NOT NULL
                       AND VIPMARKET_PGE_DASR.Reason = @Reason
                     )
                )
            AND ( @OperationType IS NULL
                  OR ( @OperationType IS NOT NULL
                       AND VIPMARKET_PGE_DASR.OperationType = @OperationType
                     )
                )

GO
