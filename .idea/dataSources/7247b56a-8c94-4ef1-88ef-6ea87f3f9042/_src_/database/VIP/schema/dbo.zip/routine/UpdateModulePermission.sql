
CREATE PROCEDURE dbo.UpdateModulePermission
	@ModulePermissionID int, 
	@ModuleID int, 
	@PermissionID int, 
	@RoleID int ,
	@AllowAccess bit,
	@UserID int
AS

UPDATE dbo.ModulePermission SET
	[ModuleID] = @ModuleID,
	[PermissionID] = @PermissionID,
	[RoleID] = @RoleID,
	[AllowAccess] = @AllowAccess,
	[UserID] = @UserID
WHERE
	[ModulePermissionID] = @ModulePermissionID

GO
