
CREATE PROCEDURE dbo.GetModuleControl
	
	@ModuleControlId int

AS
	SELECT *     
	FROM dbo.ModuleControls
	WHERE  ModuleControlId = @ModuleControlId
GO
