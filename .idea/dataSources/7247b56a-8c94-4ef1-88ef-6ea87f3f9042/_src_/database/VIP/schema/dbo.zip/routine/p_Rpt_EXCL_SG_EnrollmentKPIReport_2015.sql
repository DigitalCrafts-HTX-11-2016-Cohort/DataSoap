
CREATE PROCEDURE [dbo].[p_Rpt_EXCL_SG_EnrollmentKPIReport_2015]
AS

;
WITH tblPremiseNotesMax AS
(
	SELECT 
		pn.* 
	FROM 
		dbo.VIPMARKET_SG_ELG_PREMISE_NOTES pn WITH (NOLOCK)
		INNER JOIN 
		(
			SELECT
				VIPMARKET_SG_ELG_PREMISE_ID
				,PostedDate_MAX = MAX(PostedDate)
			FROM
				VIPMARKET_SG_ELG_PREMISE_NOTES WITH (NOLOCK)
			GROUP BY VIPMARKET_SG_ELG_PREMISE_ID
		) postedDateMAX
		ON pn.VIPMARKET_SG_ELG_PREMISE_ID = postedDateMAX.VIPMARKET_SG_ELG_PREMISE_ID
			AND pn.PostedDate = postedDateMAX.PostedDate_MAX
)
,tblDelegationFormMaxPerCustomer AS
(
	SELECT 
		dfd.* 
	FROM 
		Enrollment.SG_DelegationFormDocument dfd  WITH (NOLOCK)
		INNER JOIN
		(
		SELECT 
			CreatedOn_MAX = MAX(dfd.CreatedOn)
			,dfd.Account_Number
		FROM 
			Enrollment.SG_DelegationFormDocument dfd  WITH (NOLOCK)
		GROUP BY
			Account_Number
		) dfdMax
			ON dfd.Account_Number = dfdMax.Account_Number
				AND dfd.CreatedOn = dfdMax.CreatedOn_MAX
)
,tblDelegationFormMaxPerCustomer_Completed AS
(
	SELECT 
		dfd.*
	FROM 
		Enrollment.SG_DelegationFormDocument dfd  WITH (NOLOCK)
		INNER JOIN
		(
		SELECT 
			CreatedOn_MAX = MAX(dfd.CreatedOn)
			,dfd.Account_Number
		FROM 
			Enrollment.SG_DelegationFormDocument dfd  WITH (NOLOCK)
		WHERE dfd.DocumentFormData <> ''
		GROUP BY
			Account_Number
		) dfdMax
			ON dfd.Account_Number = dfdMax.Account_Number
				AND dfd.CreatedOn = dfdMax.CreatedOn_MAX
	WHERE
		dfd.DocumentFormData <> ''
)
,tblOne AS
(
SELECT --TOP 100
	KPIStatus = 
		CASE 
			WHEN pr.Balloted_Status = 'Enrolled' THEN 'Enrolled' -- Balloted status trumps all
			WHEN pr.[Status] = 'Sale Accepted' THEN 'Pending Submission'	
			WHEN pr.[Status] = 'Error' THEN 'Enrollment Rejected'	
			WHEN pr.[Status] = 'Pending Delegation Form' AND dfMax_Complete.Account_Number IS NULL THEN 'Pending Form (Customer)'
			WHEN pr.[Status] = 'Pending Delegation Form' AND dfMax_Complete.Account_Number IS NOT NULL THEN 'Pending Form (Utility)'
			WHEN dfr.[Status] IS NOT NULL AND dfr.[Status] <> 'Processed' THEN 'Form Not Accepted - ' + dfr.[Status]
			ELSE pr.[Status] 
		END
	,LastNotation_RejectReason = tblPremiseNotesMax.[Notes]

	,KPI_RejectReason = CASE
					WHEN SUBSTRING(tblPremiseNotesMax.[Notes], 1, 36) = 'Enrollment failed due to A selection' THEN 'SELECTION ALREADY MADE'
					WHEN SUBSTRING(tblPremiseNotesMax.[Notes], 1, 36) = 'Enrollment failed due to The control' THEN 'INVALID CONTROL #'
					WHEN SUBSTRING(tblPremiseNotesMax.[Notes], 1, 36) = 'Enrollment failed due to The confirm' THEN 'INVALID CONFIRMATION CODE'
					ELSE SUBSTRING(tblPremiseNotesMax.[Notes], 1, 60) + '...'
					END
	,pr.Account_Number
	,pr.Service_Address
	,pr.Service_City
	,pr.Service_State
	,pr.Service_Zip
	,pr.DivisionRegion
	,FullName =  pr.First_Name + ISNULL(' ' + pr.Last_Name,'')
	,pr.PriceOption
	,pr.Confirmation_Code
	,Price = 
		CASE 
			WHEN PriceOption = 'Fixed' THEN price.FixedPriceRate
			WHEN PriceOption = 'Fixed2' THEN price.FixedPriceRate2

			WHEN PriceOption = 'Index' THEN price.IndexRate
			WHEN PriceOption = 'Index2' THEN price.IndexRate2

			WHEN PriceOption = 'Blended' THEN price.FixedPriceRate
			WHEN PriceOption = 'Blended2' THEN price.FixedPriceRate2

			WHEN PriceOption = 'FBILLUNL1' THEN price.FixedBillUnlimitedRate1
			WHEN PriceOption = 'FBILLUNL2' THEN price.FixedBillUnlimitedRate2
			ELSE -1 END
	,Price2 = 
		CASE 
			WHEN PriceOption = 'Blended' THEN price.IndexRate
			WHEN PriceOption = 'Blended2' THEN price.IndexRate2
			ELSE 0
		END
	,Email
	,EnrollmentDelegation_Date = pr.ConfDatetime
	,EnrollmentDelegation_DateOnly = CONVERT(DATEtime, CONVERT(VARCHAR(50), pr.ConfDatetime,112) )
	,EnrollmentDelegation_HourOfDay = DATEPART(HOUR, pr.ConfDatetime)

	,EnrollmentConfirmed_Date = pr.Sign_Up_Date
	,pr.[Status]
	,pr.Balloted_Status

	,DelegationFormURL_CanSendToCustomer = ISNULL(dfMax.WidgetURL,dfMax_Complete.WidgetURL)
	,DelegationForm_Submitted = dfs.SubmissionDate
	,DelegationForm_ResponseStatus = dfr.[Status]
FROM    
	dbo.VIPMARKET_SG_ELG_PREMISE pr  WITH (NOLOCK)
	INNER JOIN Enrollment.v_VIPMARKET_SG_ELG_PREMISE_CAMPAIGN prCampaign ON prCampaign.VIPMARKET_SG_ELG_PREMISE_ID = pr.VIPMARKET_SG_ELG_PREMISE_ID
	LEFT JOIN dbo.VIPMARKET_SG_Pricing price  WITH (NOLOCK)
		ON price.Account_Number = pr.Account_Number AND pr.SelectedRow = price.VIPMARKET_SG_Pricing_ID
	LEFT JOIN tblPremiseNotesMax  WITH (NOLOCK)
		ON tblPremiseNotesMax.VIPMARKET_SG_ELG_PREMISE_ID = pr.VIPMARKET_SG_ELG_PREMISE_ID
	LEFT JOIN tblDelegationFormMaxPerCustomer dfMax  WITH (NOLOCK)
		ON dfMax.Account_Number = pr.Account_Number AND dfMax.CreatedOn >= pr.ConfDatetime
	LEFT JOIN tblDelegationFormMaxPerCustomer_Completed dfMax_Complete  WITH (NOLOCK)
		ON dfMax_Complete.Account_Number = pr.Account_Number AND dfMax_Complete.CreatedOn >= pr.ConfDatetime
	LEFT JOIN Enrollment.SG_DelegationFormSubmissionToSG dfs  WITH (NOLOCK)
		ON dfs.SG_DelegationFormDocumentID = dfMax_Complete.SG_DelegationFormDocumentID
	LEFT JOIN dbo.VIPMARKET_SG_FILE_DELEGATIONFORMRESPONSE dfr  WITH (NOLOCK)
		ON dfMax_Complete.Account_Number = dfr.[Account Number]
			AND dfr.DateReceived >= dfs.SubmissionDate
		
WHERE (1 = 1)
	AND 
		(
			pr.[Status] <> ''
			OR
			( -- Ballotted Confirmed
					pr.[Status] <> 'Enrolled'
					AND pr.Balloted_Status = 'Enrolled'
					AND pr.[Status] <> 'Cancelled'
			)          
--			OR dfMax_Complete.DocumentFormData IS NOT NULL -- meaning they have signed form
		)
		AND prCampaign.Campaign_Key = 'CHOICE_GAS_2017'


)
SELECT 
	*
FROM 
	tblOne
WHERE (1=1)
--	AND KPIStatus = 'Enrollment Rejected'


RETURN 0

GO
