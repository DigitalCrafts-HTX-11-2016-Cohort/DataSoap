
CREATE VIEW [dbo].[VIP_ReEnrollmentQueue]
AS
SELECT     
'BatchEnrollTable' Location,
VIP_BatchEnrollEntryID, BatchEnrollmentStatus, VIP_ProductBundles.Code ProductBundle, VIP_Retailers.Code Retailer, VIP_Utilities.Code Utility, 
                      VIP_AccountClasses.Code AccountClass, VIP_Marketers.Code Marketer, UtilityServiceAccountID, ServiceEmail, CompanyName, ServiceFirstName, ServiceLastName, 
                      ServiceLastName + ', ' + ServiceFirstName ServiceAccountName, ServiceAddress1, ServiceAddress2, ServiceCity, ServiceStateCode, ServiceZipCode, ServicePhone, 
                      ServiceAddress1 + ' ' + isnull(ServiceAddress2, '') ServiceAddressData, ServiceCity + ', ' + ServiceStateCode ServiceCityStateZip, LEFT(ServicePhone, 3) 
                      + '-' + SUBSTRING(servicephone, 3, 3) + '-' + RIGHT(servicephone, 4) ServPhone, BillingFirstName, BillingLastName, BillingAddress1, BillingAddress2, BillingCity, 
                      BillingStateCode, BillingZipCode, BillingPhone, BillingAddress1 + ' ' + isnull(BillingAddress2, '') BillingAddressData, 
                      BillingCity + ', ' + BillingStateCode BillingCityStateZip, ContractMonths, MasterAccountID,
                          (SELECT     TOP 1 CONVERT(varchar(5000), AuditMessage)
                            FROM          VIP_AccountInteractionAudit
                            WHERE      VIP_AccountInteractionID IN
                                                       (SELECT     TOP 1 VIP_AccountInteractionID
                                                         FROM          VIP_AccountInteractions
                                                         WHERE      VIP_AccountID IN
                                                                                    (SELECT     VIP_AccountID
                                                                                      FROM          VIP_Accounts
                                                                                      WHERE      VIP_AccountGUID = MasterAccountID) AND VIP_AccountInteractionTypeID IN (49)
                                                         ORDER BY StartDateTime DESC)
                            ORDER BY AuditDateTime) AuditMessage,
                          (SELECT     CASE WHEN COUNT(*) > 0 THEN 'Service account was previously enrolled in VIP' ELSE '' END AS Message
                            FROM          VIP_AccountInteractionsview
                            WHERE      VIP_AccountID IN
                                                       (SELECT     vip_accountid
                                                         FROM          VIP_Accounts
                                                         WHERE      UtilityServiceAccountID = vbe.UtilityServiceAccountID) AND VIP_AccountInteractionTypeID IN
                                                       (SELECT     VIP_AccountInteractionTypeID
                                                         FROM          VIP_AccountInteractionTypes
                                                         WHERE      code = 'MONTHLY_USAGE') AND StartDateTime < GETDATE()) PrevEnrolledMessage
FROM         VIP_BatchEnrollmentEntries vbe INNER JOIN
                      VIP_Retailers ON VIP_Retailers.VIP_RetailerID = vbe.VIP_RetailerID INNER JOIN
                      VIP_Utilities ON VIP_Utilities.VIP_UtilityID = vbe.VIP_UtilityID INNER JOIN
                      VIP_AccountClasses ON VIP_AccountClasses.VIP_AccountClassID = vbe.VIP_AccountClassID INNER JOIN
                      VIP_Marketers ON VIP_Marketers.VIP_MarketerID = vbe.VIP_MarketerID INNER JOIN
                      VIP_ProductBundles ON VIP_ProductBundles.VIP_ProductBundleID = vbe.VIP_ProductBundleID
UNION
SELECT     
'CorrectionFile' Location,
VIP_MarketerCSS_CorrectionFileID, BatchUpdateStatus BatchEnrollmentStatus, VIP_ProductBundles.Code ProductBundle, VIP_Retailers.Code Retailer, 
                      VIP_Utilities.Code Utility, VIP_AccountClasses.Code AccountClass, VIP_Marketers.Code Marketer, UtilityServiceAccountID, ServiceEmail, CompanyName, 
                      ServiceFirstName, ServiceLastName, ServiceLastName + ', ' + ServiceFirstName ServiceAccountName, ServiceAddress1, ServiceAddress2, ServiceCity, 
                      ServiceStateCode, ServiceZipCode, ServicePhone, ServiceAddress1 + ' ' + isnull(ServiceAddress2, '') ServiceAddressData, 
                      ServiceCity + ', ' + ServiceStateCode ServiceCityStateZip, LEFT(ServicePhone, 3) + '-' + SUBSTRING(servicephone, 3, 3) + '-' + RIGHT(servicephone, 4) ServPhone, 
                      BillingFirstName, BillingLastName, BillingAddress1, BillingAddress2, BillingCity, BillingStateCode, BillingZipCode, BillingPhone, 
                      BillingAddress1 + ' ' + isnull(BillingAddress2, '') BillingAddressData, BillingCity + ', ' + BillingStateCode BillingCityStateZip, ContractMonths, MasterAccountID,
                          (SELECT     TOP 1 CONVERT(varchar(5000), AuditMessage)
                            FROM          VIP_AccountInteractionAudit
                            WHERE      VIP_AccountInteractionID IN
                                                       (SELECT     TOP 1 VIP_AccountInteractionID
                                                         FROM          VIP_AccountInteractions
                                                         WHERE      VIP_AccountID IN
                                                                                    (SELECT     VIP_AccountID
                                                                                      FROM          VIP_Accounts
                                                                                      WHERE      VIP_AccountGUID = MasterAccountID) AND VIP_AccountInteractionTypeID IN (49)
                                                         ORDER BY StartDateTime DESC)
                            ORDER BY AuditDateTime) AuditMessage,
                          (SELECT     CASE WHEN COUNT(*) > 0 THEN 'Service account was previously enrolled in VIP' ELSE '' END AS Message
                            FROM          VIP_AccountInteractionsview
                            WHERE      VIP_AccountID IN
                                                       (SELECT     vip_accountid
                                                         FROM          VIP_Accounts
                                                         WHERE      UtilityServiceAccountID = vbe.UtilityServiceAccountID) AND VIP_AccountInteractionTypeID IN
                                                       (SELECT     VIP_AccountInteractionTypeID
                                                         FROM          VIP_AccountInteractionTypes
                                                         WHERE      code = 'MONTHLY_USAGE') AND StartDateTime < GETDATE()) PrevEnrolledMessage
FROM         VIP_MarketerCSS_CorrectionFile vbe INNER JOIN
                      VIP_Retailers ON VIP_Retailers.VIP_RetailerID = vbe.VIP_RetailerID INNER JOIN
                      VIP_Utilities ON VIP_Utilities.VIP_UtilityID = vbe.VIP_UtilityID INNER JOIN
                      VIP_AccountClasses ON VIP_AccountClasses.VIP_AccountClassID = vbe.VIP_AccountClassID INNER JOIN
                      VIP_Marketers ON VIP_Marketers.VIP_MarketerID = vbe.VIP_MarketerID INNER JOIN
                      VIP_ProductBundles ON VIP_ProductBundles.VIP_ProductBundleID = vbe.VIP_ProductBundleID

GO
