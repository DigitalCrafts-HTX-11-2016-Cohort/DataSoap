
CREATE PROCEDURE dbo.UpdateTab 
	@TabId              int,
	@TabName            nvarchar(50),
	@IsVisible          bit,
	@DisableLink        bit,
	@ParentId           int,
	@IconFile           nvarchar(100),
	@Title              nvarchar(200),
	@Description        nvarchar(500),
	@KeyWords           nvarchar(500),
	@IsDeleted          bit,
	@Url                nvarchar(255),
	@SkinSrc            nvarchar(200),
	@ContainerSrc       nvarchar(200),
	@TabPath            nvarchar(255),
	@StartDate          datetime,
	@EndDate            datetime,
	@RefreshInterval    int,
	@PageHeadText	    nvarchar(500),
	@IsSecure           bit,
	@PermanentRedirect	bit
AS
	UPDATE dbo.Tabs
		SET
		    TabName            = @TabName,
			IsVisible          = @IsVisible,
			DisableLink        = @DisableLink,
			ParentId           = @ParentId,
			IconFile           = @IconFile,
			Title              = @Title,
			Description        = @Description,
			KeyWords           = @KeyWords,
			IsDeleted          = @IsDeleted,
			Url                = @Url,
			SkinSrc            = @SkinSrc,
			ContainerSrc       = @ContainerSrc,
			TabPath            = @TabPath,
			StartDate          = @StartDate,
			EndDate            = @EndDate,
			RefreshInterval	   = @RefreshInterval,
			PageHeadText       = @PageHeadText,
			IsSecure           = @IsSecure,
			PermanentRedirect = @PermanentRedirect
	WHERE  TabId = @TabId
GO
