
--EXEC dbo.KPI_Account_TaxableAccountsWithNoCounty

CREATE PROC dbo.KPI_Account_TaxableAccountsWithNoCounty
AS
BEGIN

SELECT  TOP 100
		acc.VIP_AccountID, acc.ServiceAddress1, acc.ServiceCity, acc.ServiceState, acc.ServiceCounty
		--, *
FROM    dbo.VIP_Accounts acc
        INNER JOIN dbo.VIP_Utilities uti ON uti.VIP_UtilityID = acc.VIP_UtilityID
WHERE   uti.Code IN ( 'PPL', 'PecoEL', 'PJM', 'PecoGas' )
        AND acc.AccountStatus = 'Enrolled'
        AND acc.ServiceCounty = ''
		AND acc.ServiceAddress1 <> ''
		AND acc.ServiceCity <> ''

END


GO
