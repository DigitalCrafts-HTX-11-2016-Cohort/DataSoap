
create procedure dbo.GetTabModuleOrder

@TabId    int, 
@PaneName nvarchar(50)

as

select *
from   dbo.TabModules 
where  TabId = @TabId 
and    PaneName = @PaneName
order by ModuleOrder


GO
