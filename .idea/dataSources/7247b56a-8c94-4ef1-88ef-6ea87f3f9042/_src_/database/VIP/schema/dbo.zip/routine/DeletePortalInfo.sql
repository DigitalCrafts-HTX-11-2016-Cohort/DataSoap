
CREATE PROCEDURE dbo.[DeletePortalInfo]
	@PortalID int

AS

/* Delete all the Portal Modules */
DELETE
FROM dbo.Modules
WHERE PortalId = @PortalID

/* Delete all the Portal Search Items */
DELETE dbo.Modules
FROM  dbo.Modules 
	INNER JOIN dbo.SearchItem ON dbo.Modules.ModuleID = dbo.SearchItem.ModuleId
WHERE	PortalId = @PortalID

/* Delete Portal */
DELETE
FROM dbo.Portals
WHERE  PortalId = @PortalID


GO
