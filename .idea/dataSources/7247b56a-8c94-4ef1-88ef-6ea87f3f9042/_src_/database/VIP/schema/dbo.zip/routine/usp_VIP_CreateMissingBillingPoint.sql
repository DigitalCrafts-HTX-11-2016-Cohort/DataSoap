CREATE PROCEDURE [dbo].[usp_VIP_CreateMissingBillingPoint]
	@VIP_AccountID int
AS

INSERT INTO VIP_BillingPoints
SELECT NEWID(), NEWID(), 'Usage', BillingFirstName + ' ' + BillingLastName, BillingAddress1, BillingAddress2, BillingCity, BillingState, BillingZipCode, BillingCounty, BillingPhone, BillingEmail, null
FROM VIP_Accounts
WHERE VIP_AccountID = @VIP_AccountID

DECLARE @ID int = @@IDENTITY

INSERT INTO VIP_BillingPointAccounts
VALUES (@ID, @VIP_AccountID, GETDATE())

INSERT INTO VIP_AccountInteractions
VALUES (25, @VIP_AccountID, NEWID(), 0, 'Pending', GETDATE(), null)
GO
