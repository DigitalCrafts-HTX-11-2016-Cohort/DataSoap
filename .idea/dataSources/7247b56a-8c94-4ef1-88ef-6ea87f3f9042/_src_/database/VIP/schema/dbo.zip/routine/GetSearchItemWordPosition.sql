
CREATE PROCEDURE dbo.GetSearchItemWordPosition
	@SearchItemWordPositionID int
	
AS

SELECT
	[SearchItemWordPositionID],
	[SearchItemWordID],
	[ContentPosition]
FROM
	dbo.SearchItemWordPosition
WHERE
	[SearchItemWordPositionID] = @SearchItemWordPositionID


GO
