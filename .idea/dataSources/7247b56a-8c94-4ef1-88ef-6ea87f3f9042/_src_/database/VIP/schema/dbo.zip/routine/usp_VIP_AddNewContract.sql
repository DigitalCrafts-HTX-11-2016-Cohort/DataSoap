-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_VIP_AddNewContract]
@VIP_Accountid int, @StartDate smalldatetime,@EndDate smalldatetime, @VIPMarketerAgentID int, @VIPProductBundleID int
AS

DECLARE @intErrorCode INT
DECLARE @VIP_ContractID int
DECLARE @OLDVIP_ContractID int
DECLARE @VIP_Marketer int
BEGIN TRAN

Select @OLDVIP_ContractID = VIP_Contractid from vip_accounts where vip_accountid = @VIP_Accountid

-- ARCHIVE OLD CONTRACT
insert into VIP_Archive..vip_contracts
(
VIP_Contractid,
ContractName, 
StartDate, 
EndDate, 
DatesFinalized, 
EarlyTerminationFee, 
VIP_Accountid, 
VIP_MarketerAgentID, 
VIP_ProductBundleID
)

Select 
VIP_Contractid,
ContractName, 
StartDate, 
EndDate, 
DatesFinalized, 
EarlyTerminationFee, 
VIP_Accountid, 
VIP_MarketerAgentID, 
VIP_ProductBundleID
 from vip_contracts where vip_contractid in
(
   Select vip_contractid from vip_accounts where vip_accountid = @VIP_Accountid
)

-- CREATE NEW CONTRACT
insert into vip_contracts
(
ContractName, 
StartDate, 
EndDate, 
DatesFinalized, 
EarlyTerminationFee, 
VIP_Accountid, 
VIP_MarketerAgentID, 
VIP_ProductBundleID
)
Select 
case when companyname is null or companyname = '' then
servicefirstname + ' ' + servicelastname else
companyname end,
@StartDate, 
@EndDate, 
0, 
0.00,
VIP_Accountid,
@VIPMarketerAgentID,
@VIPProductBundleID
 from vip_accounts
where vip_accountid = @VIP_Accountid

SET @VIP_ContractID = (Select max(VIP_ContractID) from vip_contracts)

-- GET THE MARKETER
Select @VIP_Marketer = VIP_MarketerID from vip_marketers where VIP_MarketerID in
(
	Select VIP_MarketerID from vip_marketeragents 
	where VIP_MarketerAgentID = @VIPMarketerAgentID
)

-- UPDATE THE ACCOUNTS TABLE 
Update vip_accounts 
set vip_contractid = @VIP_ContractID,
ServiceAgreementStartDate = @StartDate,
ServiceAgreementEndDate = @EndDate,
VIP_MarketerID = @VIP_Marketer,
VIP_MarketerAgentID = @VIPMarketerAgentID,
VIP_ProductBundleID = @VIPProductBundleID
where vip_accountid = @VIP_Accountid


-- SET THE END DATE TO THE LAST PRODUCTS
--update VIP_AccountProducts set EndDate = DATEADD(D, -1, @StartDate)
--where VIP_AccountProductID in
--(
--	Select VIP_AccountProductID from VIP_AccountProducts 
--	where VIP_AccountID = @VIP_Accountid and EndDate >= @StartDate order by EndDate 
--) 
--and EndDate >= @StartDate


   
--remove old contract
Delete vip_contracts where vip_contractid = @OLDVIP_ContractID

SELECT @intErrorCode = @@ERROR
    IF (@intErrorCode <> 0) GOTO PROBLEM
    
COMMIT TRAN

PROBLEM:
IF (@intErrorCode <> 0) 
BEGIN
    ROLLBACK TRAN
END
GO
