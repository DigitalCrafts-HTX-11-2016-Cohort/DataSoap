
CREATE PROCEDURE dbo.GetAuthenticationServices
AS
	SELECT *
		FROM   dbo.Authentication
GO
