
create procedure dbo.GetModuleDefinition

@ModuleDefId int

as

select *
from dbo.ModuleDefinitions
where  ModuleDefId = @ModuleDefId


GO
