
CREATE PROCEDURE dbo.GetAuthenticationService

	@AuthenticationID int

AS
	SELECT *
		FROM   dbo.Authentication
		WHERE AuthenticationID = @AuthenticationID
GO
