
CREATE PROCEDURE dbo.[GetRole]

	@RoleId   int,
	@PortalID int

AS

SELECT RoleId,
       PortalId,
       RoleGroupId,
       RoleName,
       Description,
       ServiceFee,
       BillingPeriod,
       BillingFrequency,
       TrialFee,
       TrialPeriod,
       TrialFrequency,
       IsPublic,
       AutoAssignment,
       RSVPCode,
       IconFile
FROM   dbo.Roles
WHERE  RoleId = @RoleId
	AND    PortalId = @PortalID


GO
