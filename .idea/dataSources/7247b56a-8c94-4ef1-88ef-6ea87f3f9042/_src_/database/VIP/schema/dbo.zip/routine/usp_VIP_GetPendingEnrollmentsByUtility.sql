
/*
 - -- 2016-10-11 - BPanjavan - SoldDate_v2 = Had to make this v2 to make it backwards compatible, since PSEG is using the "Original Sold Date"
*/
CREATE Procedure [dbo].[usp_VIP_GetPendingEnrollmentsByUtility]

	@UtilityCode varchar(20), @InteractionCode varchar(100), @UtilityServAcctID varchar(10)

As

--DECLARE @UtilityCode varchar(20)
--DECLARE @InteractionCode varchar(100)
--DECLARE @UtilityServAcctID varchar(10)

--SET @UtilityCode = 'PGE'
--SET @InteractionCode = 'ENROLLMENT_CORE'
--SET @UtilityServAcctID = ''
--;

WITH tblAccountInteractionAudit_MaxPerAccountInteraction AS
(
	SELECT 
		aia.*
	FROM 
		dbo.VIP_AccountInteractionAudit aia
		INNER JOIN
		(
			SELECT
				VIP_AccountInteractionID
				,VIP_AccountInteractionAuditID_MAX = MAX(VIP_AccountInteractionAuditID)
			FROM
				dbo.VIP_AccountInteractionAudit
			GROUP BY
				VIP_AccountInteractionID
		)  aiaMax
		ON aia.VIP_AccountInteractionID = aiaMax.VIP_AccountInteractionID
			AND aia.VIP_AccountInteractionAuditID = aiaMax.VIP_AccountInteractionAuditID_MAX
	WHERE (1 = 1)
)
,tblAccountInteractionEnrollmentProcessing_MaxPerAccount AS
(
	SELECT 
		ai.*
	FROM 
		dbo.VIP_AccountInteractions ai
		INNER JOIN dbo.VIP_AccountInteractionTypes ait ON ai.VIP_AccountInteractionTypeID = ait.VIP_AccountInteractionTypeID
			AND ait.Code = 'ENROLLMENT_CORE'
		INNER JOIN
		(
			SELECT
				VIP_AccountID
				,VIP_AccontInteractionID_MAX = MAX(VIP_AccountInteractionID)
			FROM
				dbo.VIP_AccountInteractions aia
				INNER JOIN dbo.VIP_AccountInteractionTypes ait ON aia.VIP_AccountInteractionTypeID = ait.VIP_AccountInteractionTypeID
					AND ait.Code = 'ENROLLMENT_CORE'
			WHERE (1 = 1)
				AND [Status] = 'Processing'
			GROUP BY
				VIP_AccountID
		)  aiMax
		ON ai.VIP_AccountID = aiMax.VIP_AccountID
			AND ai.VIP_AccountInteractionID = aiMax.VIP_AccontInteractionID_MAX
	WHERE (1 = 1)
		AND ai.[Status] = 'Processing'
)
SELECT 
	VIP_Retailers.Code as RetailerCode, VIP_Retailers.DUNSNumber as RetailerDUNS, VIP_Utilities.Code as UtilityCode,
	VIP_Utilities.Code as ReceiverCustomerID, VIP_Retailers.Code as RetailerCode, VIP_Retailers.DUNSNumber as RetailerDUNS, 
	VIP_Accounts.CompanyName, VIP_Accounts.ServiceLastName, VIP_Accounts.ServiceFirstName,
	VIP_Accounts.ServiceAddress1, VIP_Accounts.ServiceCity, VIP_Accounts.ServiceState, 
	VIP_Accounts.ServiceZipCode, VIP_Accounts.ServicePhone, VIP_AccountInteractions.VIP_AccountInteractionGUID,VIP_AccountInteractions.VIP_AccountInteractionID,
	VIP_ProductBillingTypes.Code AS BillingOption
	
	,VIP_ProductID = COALESCE(prodForReEnrollment.VIP_ProductID, prodCurrent.VIP_ProductID, VIP_Products.VIP_ProductID)
	,UtilityProductCode = COALESCE(prodForReEnrollment.UtilityProductCode, prodCurrent.UtilityProductCode, VIP_Products.UtilityProductCode)
	
	,VIP_Accounts.VIP_AccountID, VIP_Accounts.UtilityAccountNumber, VIP_Accounts.RetailerAccountNumber,
	VIP_Accounts.UtilityServiceAccountID, VIP_Accounts.AccountStatus, VIP_AccountInteractions.StartDateTime, VIP_Accounts.EnrollmentAcceptDate, VIP_Accounts.UtilityMeterNumber
	, SoldDate = VIP_AccountInteractions.StartDateTime
	, SoldDate_v2 = VIP_Accounts.DateSold -- 2016-10-11 - BPanjavan - Had to make this v2 to make it backwards compatible, since PSEG is using the "Original Sold Date"
	,VIP_Accounts.UtilityIdentifier_CustomerSequence, VIP_Accounts.UtilityIdentifier_CheckDigit

	,MaxAudit_AuditMessage = tblAccountInteractionAudit_MaxPerAccountInteraction.AuditMessage

	,VIP_AccountInteractionID_Enrolling = tblAccountInteractionEnrollmentProcessing_MaxPerAccount.VIP_AccountInteractionID
	,VAC.Name AS AccountClassCode
	From 
		VIP_AccountInteractions Inner Join VIP_Accounts On VIP_AccountInteractions.VIP_AccountID = VIP_Accounts.VIP_AccountID
		Inner Join VIP_Utilities On VIP_Accounts.VIP_UtilityID = VIP_Utilities.VIP_UtilityID
		Inner Join VIP_AccountInteractionTypes On VIP_AccountInteractions.VIP_AccountInteractionTypeID = VIP_AccountInteractionTypes.VIP_AccountInteractionTypeID
		Inner Join VIP_Retailers ON VIP_Accounts.VIP_RetailerID = VIP_Retailers.VIP_RetailerID 
		Inner Join VIP_ProductBillingTypes on VIP_Accounts.VIP_AccountBillingTypeID = VIP_ProductBillingTypes.VIP_ProductBillingTypeID	

		LEFT Join VIP_ProductBundles on VIP_Accounts.VIP_ProductBundleID = VIP_ProductBundles.VIP_ProductBundleID
		LEFT Join VIP_ProductBundleItems on VIP_ProductBundles.VIP_ProductBundleID = VIP_ProductBundleItems.VIP_ProductBundleID
		LEFT Join VIP_Products on VIP_ProductBundleItems.VIP_ProductID = VIP_Products.VIP_ProductID
		LEFT JOIN dbo.VIP_AccountClasses VAC ON VAC.VIP_AccountClassID = VIP_Accounts.VIP_AccountClassID

		LEFT JOIN tblAccountInteractionAudit_MaxPerAccountInteraction
			ON VIP_AccountInteractions.VIP_AccountInteractionID = tblAccountInteractionAudit_MaxPerAccountInteraction.VIP_AccountInteractionID

		LEFT JOIN tblAccountInteractionEnrollmentProcessing_MaxPerAccount
			ON VIP_Accounts.VIP_AccountID = tblAccountInteractionEnrollmentProcessing_MaxPerAccount.VIP_AccountID

		-- Used in the case of ReEnrollments, the AccountInteraction for the pending enrollment is associated with a particular Account Product
		LEFT JOIN [Enrollment].[VIP_AccountInteraction_AccountProduct_ForEnrollment] aiAP ON VIP_AccountInteractions.VIP_AccountInteractionID = aiAP.VIP_AccountInteractionID
		LEFT JOIN VIP_AccountProducts apForReEnrollment ON aiAP.VIP_AccountProductID = apForReEnrollment.VIP_AccountProductID
		LEFT JOIN VIP_Products prodForReEnrollment ON apForReEnrollment.VIP_ProductID = prodForReEnrollment.VIP_ProductID

		-- In the case of a re-enrollment where it's just re-enrolling on the current account product (There is no entry in the [VIP_AccountInteraction_AccountProduct_ForEnrollment] table
		LEFT JOIN dbo.VIP_AccountProducts apCurrent
			ON apCurrent.VIP_AccountID = VIP_AccountInteractions.VIP_AccountID
				AND apCurrent.StartDate <= GETDATE() AND apCurrent.EndDate >= GETDATE()
		LEFT JOIN dbo.VIP_Products prodCurrent
			ON apCurrent.VIP_ProductID = prodCurrent.VIP_ProductID
Where
	VIP_AccountInteractionTypes.Code = @InteractionCode
		and VIP_AccountInteractions.Status = 'Pending'
		And VIP_Utilities.Code = @UtilityCode

		and ISNULL(VIP_ProductBundleItems.Sequence,1) = 1	-- not all accounts were enrolled using a product bundle

		and ISNULL(VIP_Accounts.HoldProcessDate,'1900-01-01') <= GETDATE() -- For enrollments
		AND (
				VIP_AccountInteractions.StartDateTime IS NULL
				OR VIP_AccountInteractions.StartDateTime <= GETDATE()              
			)

		AND
			(
				ISNULL(@UtilityServAcctID,'') = ''
				OR ( ISNULL(@UtilityServAcctID,'') <> '' AND UtilityServiceAccountID = @UtilityServAcctID )
			)     
ORDER BY 
	HoldProcessDate DESC
--EndOfFile: -- end


GO
