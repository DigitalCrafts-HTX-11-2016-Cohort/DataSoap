
/*
 - 2017-06-12 - LMiranda - Replacing Dynamic SQL, reviewing with Bryan
 - 2017-07-21 - BRudd - Getting rid of nested SQL
*/
CREATE PROC dbo.p_VIP_usp_WebLookUpAccountInformation
(
--parameters go here
	@vipAccountID INT
)
AS
BEGIN

	--DECLARE @vipAccountID INT = 388015

SET TRANSACTION ISOLATION LEVEL SNAPSHOT
----#1
--SELECT a.AccountStatus,
--       a.UtilityAccountNumber,
--       a.UtilityServiceAccountID,
--       a.CompanyName,
--       a.DateSold,
--       a.BillingFirstName + ' ' + a.BillingLastName AS CustomerName,
--       a.BillingPhone,
--       b.MeterNumber,
--       c.StartDate,
--       c.EndDate,
--       a.EnrollmentAcceptDate,
--       a.VIP_MarketerID,
--       a.CoreCustomer,
--       a.HoldProcessDate,
--       (
--           SELECT TOP 1
--               e.UsageAmount
--           FROM VIP_Meters d
--               INNER JOIN VIP_Usage e
--                   ON e.VIP_MeterID = d.VIP_MeterID
--           WHERE d.MeterNumber = b.MeterNumber
--                 AND e.VIP_UsageTypeID = 2
--           ORDER BY e.EndDate DESC
--       ) AS LastUsageAmount,
--       (
--           SELECT TOP 1
--               e.BeginRead
--           FROM VIP_Meters d
--               INNER JOIN VIP_Usage e
--                   ON e.VIP_MeterID = d.VIP_MeterID
--           WHERE d.MeterNumber = b.MeterNumber
--                 AND e.VIP_UsageTypeID = 2
--           ORDER BY e.EndDate DESC
--       ) AS BeginRead,
--       (
--           SELECT TOP 1
--               e.EndRead
--           FROM VIP_Meters d
--               INNER JOIN VIP_Usage e
--                   ON e.VIP_MeterID = d.VIP_MeterID
--           WHERE d.MeterNumber = b.MeterNumber
--                 AND e.VIP_UsageTypeID = 2
--           ORDER BY e.EndDate DESC
--       ) AS EndRead,
--       (
--           SELECT UtilityServiceAccountID
--           FROM VIP_Accounts
--           WHERE VIP_AccountID = a.Previous_VIP_Accountid
--       ) AS PreviousSAID,
--       SPRateName,
--       (
--           SELECT Name
--           FROM VIP_AccountClasses
--           WHERE VIP_AccountClassID = a.VIP_AccountClassID
--       ) AS AccountClass,
--       CASE
--           WHEN Residual = 1 THEN
--               'Yes'
--           ELSE
--               'No'
--       END AS Residual,
--       Spanish,
--       d.Name ProductBundleName,
--       PromotionCode,

--                                          -- Begin PendingTerminationInteraction
--       CASE
--           WHEN AccountStatus = 'Enrolled'
--                AND YEAR(EnrollmentAcceptDate) <> 1900 THEN
--               ISNULL(
--               (
--                   SELECT TOP 1
--                       'Pending termination request scheduled for ' + CONVERT(VARCHAR(10), StartDateTime, 101)
--                   FROM VIP_AccountInteractions
--                   WHERE VIP_AccountInteractionTypeID IN ( 12 )
--                         AND VIP_AccountID = a.VIP_AccountID
--                         AND Status IN ( 'Pending' )
--                   ORDER BY StartDateTime ASC
--               ),
--               ''
--                     )
--           WHEN AccountStatus = 'Enrolled'
--                AND YEAR(EnrollmentAcceptDate) = 1900 THEN
--               ISNULL(
--               (
--                   SELECT TOP 1
--                       'Pending termination request scheduled for ' + CONVERT(VARCHAR(10), StartDateTime, 101)
--                       + '.  Termination request will be submitted after the account has been <b><u>Enrolled</u></b> and the Enrollment Acceptance Date has been set to a date other than 1/1/1900'
--                   FROM VIP_AccountInteractions
--                   WHERE VIP_AccountInteractionTypeID IN ( 12 )
--                         AND VIP_AccountID = a.VIP_AccountID
--                         AND Status IN ( 'Pending' )
--                   ORDER BY StartDateTime ASC
--               ),
--               ''
--                     )
--           WHEN AccountStatus = 'Enrolling' THEN
--               ISNULL(
--               (
--                   SELECT TOP 1
--                       'Pending termination request scheduled for ' + CONVERT(VARCHAR(10), StartDateTime, 101)
--                       + '.  Termination request will be submitted after the account has been <b><u>Enrolled</u></b>'
--                   FROM VIP_AccountInteractions
--                   WHERE VIP_AccountInteractionTypeID IN ( 12 )
--                         AND VIP_AccountID = a.VIP_AccountID
--                         AND Status IN ( 'Pending' )
--                   ORDER BY StartDateTime ASC
--               ),
--               ''
--                     )
--           ELSE
--               ''
--       END PendingTerminationInteraction, -- End PendingTerminationInteraction

--       CASE
--           WHEN AccountStatus = 'Enrolled'
--                AND ACT_EnrollSwitchDate > GETDATE() --Begin GasFlowDate
--       THEN
--               'Gas Flow Start Date set for ' + CONVERT(VARCHAR(10), ACT_EnrollSwitchDate, 101)
--           ELSE
--               ''
--       END GasFlowDate,                   -- End GasFlowDate

--       mprod.CurrentAccountProduct_ProductName AS CurrentProductInfo,
--       'Date:' + CAST(CAST(minvo.LatestInvoiceDate AS DATE) AS VARCHAR(100)) + ', Amount:'
--       + CAST(inv.InvoiceAmount AS VARCHAR(100)) AS LastestInvoiceInfo,
--       'Date:' + CAST(CAST(mpay.LatestPaymentDate AS DATE) AS VARCHAR(100)) + ' , Amount:'
--       + CAST(pay.PaymentAmount AS VARCHAR(100)) AS LastestPaymentInfo
--FROM VIP_Accounts a
--    LEFT OUTER JOIN VIP_Meters b
--        ON a.VIP_AccountID = b.VIP_AccountID
--    LEFT OUTER JOIN VIP_ContractsView c
--        ON a.VIP_ContractID = c.VIP_ContractID
--    LEFT OUTER JOIN VIP_ProductBundles d
--        ON a.VIP_ProductBundleID = d.VIP_ProductBundleID
--    LEFT JOIN Products.mv_VIP_CumulativeAccountProductsView mprod
--        ON mprod.VIP_AccountID = a.VIP_AccountID
--    LEFT JOIN Invoicing.mv_VIP_AccountCumulativeInvoiceView minvo
--        ON minvo.VIP_AccountID = a.VIP_AccountID
--    LEFT JOIN dbo.VIP_Invoices inv
--        ON inv.VIP_InvoiceID = minvo.VIP_InvoiceID_Latest
--    LEFT JOIN Accounting.mv_VIP_AccountCumulativePaymentView mpay
--        ON mpay.VIP_AccountID = a.VIP_AccountID
--    LEFT JOIN dbo.VIP_Payments pay
--        ON pay.VIP_PaymentID = mpay.VIP_PaymentID_Latest
--WHERE a.VIP_AccountID = @vipAccountID;--268253;

;WITH latestUsage AS (
	SELECT TOP 1 * FROM dbo.VIP_Usage WHERE VIP_AccountID = @vipAccountID AND VIP_UsageTypeID = 2 ORDER BY EndDate DESC 
),
latestPendingTerminationInteraction AS (
	SELECT TOP 1 * FROM dbo.VIP_AccountInteractions WHERE VIP_AccountID = @vipAccountID AND VIP_AccountInteractionTypeID = 12 AND Status = 'Pending' ORDER BY StartDateTime DESC 
)
SELECT  --* ,
        acc.AccountStatus ,
        acc.UtilityAccountNumber ,
        acc.UtilityServiceAccountID ,
        acc.CompanyName ,
        acc.DateSold ,
        CASE WHEN acc.ServiceFirstName <> ''
                  AND acc.ServiceFirstName IS NOT NULL THEN acc.ServiceFirstName
             ELSE acc.BillingFirstName
        END + ' '
        + CASE WHEN acc.ServiceLastName <> ''
                    AND acc.ServiceLastName IS NOT NULL THEN acc.ServiceLastName
               ELSE acc.BillingLastName
          END AS CustomerName
		, acc.BillingPhone
		, meter.MeterNumber
		, capv.FirstAccountProduct_StartDate AS StartDate
		, capv.LastAccountProduct_EndDate AS EndDate
		, acc.EnrollmentAcceptDate
		, acc.VIP_MarketerID
		, acc.CoreCustomer
		, acc.HoldProcessDate
		, ISNULL(usage.UsageAmount, 0.00) AS LastUsageAmount
		, ISNULL(usage.BeginRead, 0) AS BeginRead
		, ISNULL(usage.EndRead ,0) AS EndRead
		, prevAccount.UtilityServiceAccountID AS PreviousSAID
		, acc.SPRateName
		, accClass.Code AS AccountClass
		, CASE acc.Residual WHEN 1 THEN 'Yes' ELSE 'No' END AS Residual 
		, acc.Spanish
		, prdBundle.Name AS ProductBundleName
		, acc.PromotionCode
		, CASE 
			WHEN ai.VIP_AccountInteractionID IS NOT NULL THEN
			  CASE 
				WHEN acc.AccountStatus = 'Enrolled' AND DATEPART(YEAR, acc.EnrollmentAcceptDate) <> 1900 THEN  'Pending termination request scheduled for ' + CONVERT(VARCHAR(10), ai.StartDateTime, 111) 
				WHEN acc.AccountStatus = 'Enrolled' AND DATEPART(YEAR, acc.EnrollmentAcceptDate) = 1900 THEN 'Pending termination request scheduled for ' + CONVERT(VARCHAR(10), ai.StartDateTime, 111)
						   + '.  Termination request will be submitted after the account has been <b><u>Enrolled</u></b> and the Enrollment Acceptance Date has been set to a date other than 1/1/1900'
				WHEN acc.AccountStatus = 'Enrolling' THEN 'Pending termination request scheduled for ' + CONVERT(VARCHAR(10), ai.StartDateTime, 111)
						   + '.  Termination request will be submitted after the account has been <b><u>Enrolled</u></b>'
				ELSE ''
			  END  
			ELSE '' 
		  END AS PendingTerminationInteraction --Check with Mario on this one
		, '' AS GasFlowDate
		, capv.CurrentAccountProduct_ProductName AS CurrentProductInfo
		, 'Date: ' + CONVERT(VARCHAR,civ.LatestInvoiceDate, 111) + ', Amount: $' + CONVERT(VARCHAR,inv.InvoiceAmount) AS LastestInvoiceInfo
		, 'Date: ' + CONVERT(VARCHAR,cpv.LatestPaymentDate, 111) + ', Amount: $' + CONVERT(VARCHAR,pmt.PaymentAmount) AS LastestPaymentInfo
FROM    dbo.VIP_Accounts acc
		INNER JOIN dbo.VIP_AccountClasses accClass ON accClass.VIP_AccountClassID = acc.VIP_AccountClassID
		INNER JOIN Products.mv_VIP_CumulativeAccountProductsView capv ON capv.VIP_AccountID = acc.VIP_AccountID
		INNER JOIN Invoicing.mv_VIP_AccountCumulativeInvoiceView civ ON civ.VIP_AccountID = acc.VIP_AccountID
		INNER JOIN Accounting.mv_VIP_AccountCumulativePaymentView cpv ON cpv.VIP_AccountID = acc.VIP_AccountID
		LEFT JOIN dbo.VIP_Meters meter ON meter.VIP_AccountID = acc.VIP_AccountID
		LEFT JOIN dbo.VIP_Payments pmt ON pmt.VIP_PaymentID = cpv.VIP_PaymentID_Latest
		LEFT JOIN dbo.VIP_Invoices inv ON inv.VIP_InvoiceID = civ.VIP_InvoiceID_Latest
		LEFT JOIN dbo.VIP_ProductBundles prdBundle ON prdBundle.VIP_ProductBundleID = acc.VIP_ProductBundleID
		LEFT JOIN latestUsage usage ON usage.VIP_AccountID = acc.VIP_AccountID
		LEFT JOIN dbo.VIP_Accounts prevAccount ON PrevAccount.VIP_AccountID = acc.Previous_VIP_Accountid
		LEFT JOIN latestPendingTerminationInteraction ai ON ai.VIP_AccountID = acc.VIP_AccountID AND ai.VIP_AccountInteractionTypeID = 12
WHERE acc.VIP_AccountID = @vipAccountID
ORDER BY meter.MeterNumber

END

GO
