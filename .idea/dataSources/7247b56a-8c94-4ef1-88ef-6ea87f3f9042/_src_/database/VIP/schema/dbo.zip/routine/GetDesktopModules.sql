
create procedure dbo.GetDesktopModules

as

select *
from   dbo.DesktopModules
where  IsAdmin = 0
order  by FriendlyName


GO
