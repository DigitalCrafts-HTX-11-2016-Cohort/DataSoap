
CREATE PROCEDURE dbo.[GetTab]

@TabId    int

AS
SELECT *
FROM   dbo.vw_Tabs
WHERE  TabId = @TabId

GO
