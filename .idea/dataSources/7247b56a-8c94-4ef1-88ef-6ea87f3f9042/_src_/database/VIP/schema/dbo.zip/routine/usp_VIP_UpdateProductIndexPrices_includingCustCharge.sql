
CREATE		 PROCEDURE dbo.usp_VIP_UpdateProductIndexPrices_includingCustCharge
    @IndexName VARCHAR(70) ,
    @EffectiveStartDate DATETIME ,
	@EffectiveEndDate DATETIME ,
    @customerPrice NUMERIC(15, 5) ,
    @Price NUMERIC(15, 5) ,
    @UserID INT = 0,
    @FileName VARCHAR(50) = 'Nooo.txt'
AS

    
--DETERMINE IF THE INDEX EXIST
    IF EXISTS ( SELECT  *
                FROM    VIP_VariableProductIndexes
                WHERE   Name = @IndexName --and ImportFileName like @FileName + '%'
	)
        BEGIN
            DECLARE @VariableProdIndexID INT
            SELECT  @VariableProdIndexID = ( SELECT VIP_VariableProductIndexID
                                             FROM   VIP_VariableProductIndexes
                                             WHERE  Name = @IndexName
                                           )

	--DETERMINE IF THE INDEX PRICE CURRENTLY EXIST FOR EFFECTIVE DATE
            IF EXISTS ( SELECT  *
                        FROM    VIP_VariableProductIndexes a
                                INNER JOIN VIP_VariableProductIndexPrices b ON b.VIP_VariableProductIndexID = a.VIP_VariableProductIndexID
                        WHERE   a.Name = @IndexName
                                AND EffectiveStartDate = @EffectiveStartDate )
		--UPDATE THE PRICE IF IT EXIST
                BEGIN
                    UPDATE  VIP_VariableProductIndexPrices
                    SET     VariableProductServiceFee = @customerPrice ,
                            VariableProductIndexPrice = @Price ,
                            DateCreated = GETDATE() ,
                            CreatedByUserID = @UserID
                    WHERE   VIP_VariableProductIndexID = @VariableProdIndexID
                            AND EffectiveStartDate = @EffectiveStartDate			
                END
            ELSE
		--INSERT A NEW RECORD IF IT IS A NEW ENTRY
                BEGIN
                    INSERT  VIP_VariableProductIndexPrices
                            ( VIP_VariableProductIndexID ,
                              VariableProductServiceFee ,
                              VariableProductIndexPrice ,
                              EffectiveStartDate ,
                              EffectiveEndDate ,
                              DateCreated ,
                              CreatedByUserID
                            )
                    VALUES  ( @VariableProdIndexID ,
                              @customerPrice ,
                              @Price ,
                              @EffectiveStartDate ,
                              @EffectiveEndDate ,
                              GETDATE() ,
                              @UserID
                            )
                END 
        END
GO
