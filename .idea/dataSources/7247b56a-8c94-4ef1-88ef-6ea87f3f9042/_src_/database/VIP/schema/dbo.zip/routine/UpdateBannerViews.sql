
create procedure dbo.UpdateBannerViews

@BannerId  int, 
@StartDate datetime, 
@EndDate   datetime

as

update dbo.Banners
set    Views = Views + 1,
       StartDate = @StartDate,
       EndDate = @EndDate
where  BannerId = @BannerId


GO
