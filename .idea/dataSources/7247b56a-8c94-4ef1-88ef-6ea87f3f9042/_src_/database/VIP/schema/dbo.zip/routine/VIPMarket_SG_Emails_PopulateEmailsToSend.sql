
/*
 - 2016-03-09 - BPanjavan - Slight Hook to inner join on ONLY the pass-on customers
 - 2017-02-10 - BPanjavan - Reinstated the Row number limit on emali addresses to ensure the same person doesn't get emailed more than once
 - 2017-04-09 - BPanjavan - Excluding all-balloted customers from future Emails
*/
CREATE PROCEDURE VIPMarket_SG_Emails_PopulateEmailsToSend
(
	@strLimitState_LeaveBlankForAll VARCHAR(50) = ''
	,@excludeCustomersInPast36Hours BIT = 1
	,@campaignKey VARCHAR(50)
	,@userName VARCHAR(50)
)
AS
BEGIN
	----DECLARE @strLimitState_LeaveBlankForAll VARCHAR(50) 
	----SET @strLimitState_LeaveBlankForAll = ''
	----DECLARE  @excludeCustomersInPast36Hours BIT
	----SET @excludeCustomersInPast36Hours = 
	----DECLARE @userName VARCHAR(50)
	----SET @userName = '141'
	----DECLARE @campaignKey VARCHAR(50)
	----SET @campaignKey = 'AG_2016'

	DECLARE @36HoursAgo DATETIME
	SET @36HoursAgo = DATEADD(HOUR, -12, GETDATE())
	PRINT(@36HoursAgo)

	-----------------------------------------------
	-- Insert records into outgoing table
	-----------------------------------------------
	IF OBJECT_ID('tempdb..#tblOne') IS NOT NULL
		DROP TABLE #tblOne

	IF OBJECT_ID('tempdb..#dateTheyCannotEnroll') IS NOT NULL
		DROP TABLE #dateTheyCannotEnroll

	SELECT * INTO #dateTheyCannotEnroll FROM Enrollment.v_SG_ExtendedCustomers_DateTheyCannotEnrollAnymore

		-- Populate the verified Emails
	IF OBJECT_ID('tempdb..#tblEmailsVerified') IS NOT NULL
	DROP TABLE #tblEmailsVerified
	;
	WITH tblEmailsThatHaveBeenVerified AS
	(
		SELECT [Email] = [address] FROM Enrollment.SG_EmailAddress_Verification_IsValid emailVerified WHERE emailVerified.valid = 'true'
		UNION ALL SELECT [Email] FROM B2B.Experian_Inbound_EmailClean_Detail WHERE REsult = 'verified' AND Usable = 'Email'
	)
	SELECT DISTINCT [Email] INTO #tblEmailsVerified  FROM tblEmailsThatHaveBeenVerified
	CREATE UNIQUE CLUSTERED INDEX IDX_EmailsVerified ON #tblEmailsVerified([Email])

	-- Verified Attempted
	IF OBJECT_ID('tempdb..#tblEmailsVerifiedAttempted') IS NOT NULL
	DROP TABLE #tblEmailsVerifiedAttempted
	;
	WITH tblEmailsThatHaveBeenVerifiedAttempted AS
	(
		SELECT [Email] = [address] FROM Enrollment.SG_EmailAddress_Verification_IsValid emailVerified 
		UNION ALL SELECT [Email] FROM B2B.Experian_Inbound_EmailClean_Detail 
	)
	SELECT DISTINCT [Email] INTO #tblEmailsVerifiedAttempted  FROM tblEmailsThatHaveBeenVerifiedAttempted

	CREATE UNIQUE CLUSTERED INDEX IDX_EmailsVerifiedAttempted ON #tblEmailsVerifiedAttempted([Email])


	;WITH tblAllBalloted AS -- for excluding accounts on the All-Balloted file
	(
		SELECT  
			abd.[Account Number]
			----txn.ImportDate
			----,txn.FileName
			----,abd.*
		FROM    
			B2B.SG_InboundAllBallotedFile_Detail abd
			INNER JOIN B2B.SG_AllBallotedFile abf ON abf.SG_AllBallotedFile_ID = abd.SG_AllBallotedFile_ID
			INNER JOIN B2B.TransactionFile_Inbound txn
				ON txn.DestinationTableName = 'SG_AllBallotedFile'
					AND txn.DestinationTransactionID = abf.SG_AllBallotedFile_ID
		WHERE (1 = 1)
			AND txn.ImportDate >= '2017-01-01'
	)
	,tblAccountMaxPriceID AS -- Get the max Price Available for account
	(
		SELECT

			Account_Number
			,Max_ID = MAX(VIPMARKET_SG_Pricing_ID)
		FROM
			dbo.VIPMARKET_SG_Pricing WITH (NOLOCK)
		WHERE (1 = 1)
	--		AND Marketer = 'WEB'
		GROUP BY
			Account_Number
	)
	,tblPremise_Email_Zero AS -- combines the Emails we have with the Emails received from the CSR Group, CSR Emails take precedence
	(
		SELECT pr.Account_Number
				, Email = CASE
							WHEN ISNULL(pr.Email,'') <> '' THEN pr.Email -- 2016-04-02 - prioratize our Email addresses first
							WHEN ISNULL(nexxa.EMail, '') <> '' THEN LTRIM(RTRIM(nexxa.Email)) -- 2016-03-28 - BPanjavan - Prioratize Nexxa second
----							WHEN sgEmailsFound.Email_Address IS NOT NULL THEN LTRIM(RTRIM(sgEmailsFound.Email_Address) ) 
							ELSE NULL
						END

				, Service_State 
				,[Status]
				,campaign.Campaign_Key
		FROM 
			dbo.VIPMARKET_SG_ELG_PREMISE pr
			INNER JOIN Enrollment.v_VIPMARKET_SG_ELG_PREMISE_CAMPAIGN campaign ON campaign.VIPMARKET_SG_ELG_PREMISE_ID = pr.VIPMARKET_SG_ELG_PREMISE_ID

			------------------ 2016-03-09 - Slight hook to capture pass-on customers WY ONLY
			----LEFT JOIN B2B.SG_PassOnRate_DTSImport_20160309 passOn ON dbo.VIPMARKET_SG_ELG_PREMISE.Account_Number = passOn.Account_Number_VarChar

			------ 2016-04-29 - BPanjavan - Hook to ONLY get the new Extended customers only
			----INNER JOIN #dateTheyCannotEnroll dateTheyCannotEnroll ON dateTheyCannotEnroll.VIPMARKET_SG_ELG_PREMISE_ID = VIPMARKET_SG_ELG_PREMISE.VIPMARKET_SG_ELG_PREMISE_ID
			----	AND DATEDIFF(DAY, CONVERT(DATE, GETDATE()), dateTheyCannotEnroll.DateTheyCannoEnrollAnymore ) >= 1

			-- 2017-02-03 - New Nexxa Append List
			LEFT JOIN B2B.Nexxa_EmailAppend_Result_Detail nexxa ON nexxa.ID_Nuber = pr.Premise_Number AND nexxa.[Append] = 'I' -- Individual ONLY
				AND nexxa.STD_STATE IN ('WY', 'NE')

			------ 2016-03-28 - Nexxa Email Integration
			----LEFT JOIN B2B.[NEXXA_VEM_Source Gas Email Append_Final_3-28] nexxa ON VIPMARKET_SG_ELG_PREMISE.Premise_Number = nexxa.ID_Number AND nexxa.[Match Level] <> 'A' -- don't match address level

			-- 2017-02-03 - BPanjavan - These really got us in trouble last time, excluding them
			------ 2015-03-27 - Include Emails from CSR Group
			----LEFT JOIN (SELECT DISTINCT Account_Number, Email_Address FROM B2B.SG_Emails_Detail) sgEmailsFound ON VIPMARKET_SG_ELG_PREMISE.Account_Number = sgEmailsFound.Account_Number
		WHERE (1 = 1)
			AND campaign.Campaign_Key = @campaignKey
			AND
			(
				ISNULL(@strLimitState_LeaveBlankForAll,'') = ''
				OR 
					(
						ISNULL(@strLimitState_LeaveBlankForAll,'') <> ''
						AND Service_State = @strLimitState_LeaveBlankForAll
					)
			)

			-- 2017-04-29 - BPanjavan - removed
			------ Special Exception exclude multi-account #'s for now
			----AND pr.Account_Number NOT IN
			----(
			----	SELECT TOP 1000 
			----		premise.Account_Number
			----		----,premise.Email
			----		----,COUNT(1)
			----	--	premise.* 
			----	FROM 
			----		dbo.VIPMARKET_SG_ELG_PREMISE premise
			----	GROUP BY
			----		premise.Account_Number
			----		,premise.Email
			----	HAVING COUNT(1) > 1
			----)

			--AND ImportFileName = 'NE eligible premise file 2016 - Trimmed for 20160404 Load.xlsx'
--			AND ISNULL(nexxa.EMail, '') <> '' AND ISNULL(dbo.VIPMARKET_SG_ELG_PREMISE.Email,'') = '' --2016-03-28 - Special Exception get only Nexxa Emails

	)
	,tblPremise_Email AS ( SELECT * FROM tblPremise_Email_Zero WHERE [Email] IS NOT NULL )
	----,tblLastYearSelection AS
	----(
	----	SELECT --TOP 10
	----			ePremise.Account_Number
	----			,ePremise.PriceOption
	----			,ePremise.SelectedRow
	----			,ePremise.[Status]
	----			,LastYearPrice = 
	----				CASE
	----					WHEN PriceOption = 'FBILLUNL2' THEN ePricing.FixedBillUnlimitedRate2
	----					WHEN PriceOption = 'FBILLUNL1' THEN ePricing.FixedBillUnlimitedRate1
	----					WHEN PriceOption = 'Fixed' THEN ePricing.FixedPriceRate
	----					WHEN PriceOption = 'Fixed2' THEN ePricing.FixedPriceRate2
	----				END
	------			,ePricing.*
	----		FROM    
	----			VIP_Archive.dbo.VIPMARKET_SG_ELG_PREMISE_2014 ePremise
	----			LEFT JOIN VIP_Archive.dbo.VIPMARKET_SG_Pricing_2014 ePricing 
	----				ON ePricing.Account_Number = ePremise.Account_Number
	----					AND ePremise.SelectedRow = ePricing.VIPMARKET_SG_Pricing_ID												
	----		WHERE (1 = 1)   
	----			AND ISNULL(ePremise.SelectedRow, 0) > 0
	----			AND [Status] = 'Enrolled'
	----			AND PriceOption IN ('FBILLUNL2','FBILLUNL1')--,'Fixed','Fixed2')
	----			AND PriceOption IN ('FBILLUNL1') -- ONLY 2014 Enrollments that enrolled on 1 year deal
	----)
	,tblOne AS
	(
	SELECT
		--price.Account_Number
		Email
		,RowNumber = ROW_NUMBER() OVER (PARTITION BY Email ORDER BY pr.Account_Number)
		--[Status]
		,price.* 
		,pr.Service_State
		,pr.Campaign_Key
	FROM
		tblPremise_Email pr WITH (NOLOCK)
		INNER JOIN tblAccountMaxPriceID maxprice ON pr.Account_Number = maxprice.Account_Number
		INNER JOIN dbo.VIPMARKET_SG_Pricing price ON maxprice.Max_ID = price.VIPMARKET_SG_Pricing_ID

		------ Selected something last year
		----LEFT JOIN tblLastYearSelection ON pr.Account_Number = tblLastYearSelection.Account_Number
	WHERE (1 = 1)
		-- 2015-03-27 - Limit no 500's
		AND price.FixedBillUnlimitedRate2 <= 500.00

		AND (
				pr.Campaign_Key = 'AG_2017' -- WIth AG, we don't control these accounts by negative prices
				OR
				(
					pr.Campaign_Key <> 'AG_2017' 
					-- 2017-04-29 - BPanjavan - Removed this rule to include more customers
						-- this is okay since we don't display the price in the email anymore
--					AND price.FixedBillUnlimitedRate2 >= 0.0 -- to exclude the 5000's, which Bryan made into -5000.00
					AND price.FixedPriceRate >= 0 -- exclude anything we set to negative 1
				)
			)

		-- 2015-03-31 - BPanjavan - Per Cris's Email, ONLY send to accounts we've never interacted with
		AND pr.[Status] = '' -- accounts we haven't touched whatsoever

		AND pr.Account_Number NOT IN (SELECT tblAllBalloted.[Account Number] FROM tblAllBalloted ) -- 2015-04-06 - Exclude ANY Balloted Customer

	)
--	SELECT * FROM tblPremise_Email
	SELECT * INTO #tblOne FROM tblOne 

	BEGIN TRAN

	;
	WITH tblTwo AS
	(
		SELECT * FROM #tblOne tblOne
		WHERE (1 = 1) 
			AND RowNumber = 1

		------ New exclusion list
		AND Email NOT IN 
		(
			SELECT ISNULL(ep.Email,'') FROM dbo.VIPMarket_SG_Email_AccountExclude ae INNER JOIN dbo.VIPMARKET_SG_ELG_PREMISE ep ON ep.Account_Number = ae.Account_Number
		)
		AND Email NOT IN (SELECT Email_Address FROM B2B.SG_EmailsExclude_Detail -- new exclusion list
			)
		AND tblOne.Account_Number NOT IN (SELECT Account_Number FROM dbo.VIPMarket_SG_Email_AccountExclude)

	  -- Exclude customers in the past 36 hours
	  AND (
			@excludeCustomersInPast36Hours = 0
			OR
			(
				@excludeCustomersInPast36Hours = 1
				AND [Account_Number] NOT IN 
				(SELECT VIPMarket_SG_Email.Account_Number FROM dbo.VIPMarket_SG_Email WHERE CreatedOn >= @36HoursAgo AND [Status] <> 'CANCELLED')
			)
		)

	-- 2017-03-07
	-- For new customers in 2017 excluding Verified emails for now
	---------- 2016-12-03 - Changed to go off of temp table.  ONLY verified Emails
	----AND (
	----		[Email] IN (SELECT [Email] FROM #tblEmailsVerified )
	----		OR
	----		(
	----			Campaign_Key = 'AG_2017' -- 2017-01-31 - NOT required to be verified
	----		)
	----	)

	)
	INSERT INTO dbo.[VIPMarket_SG_Email] 
	SELECT-- COUNT(1)
		TOP 80000
		@userName
		,GETDATE()
		,@userName
		,GETDATE()
		,Account_Number
		,VIPMARKET_SG_Pricing_ID
		,NULL
		,'PENDING'
		,''
		,Email
		,NULL
		,NULL
	FROM tblTwo --WHERE RowNumber = 1

	COMMIT
--ROLLBACK
	
	SELECT COUNT(1) FROM dbo.[VIPMarket_SG_Email]  WHERE [Status] = 'PENDING'

END


GO
