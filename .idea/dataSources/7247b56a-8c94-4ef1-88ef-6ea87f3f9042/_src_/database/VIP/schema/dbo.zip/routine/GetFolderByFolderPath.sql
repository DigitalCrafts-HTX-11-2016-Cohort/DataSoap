
CREATE PROCEDURE dbo.GetFolderByFolderPath
	@PortalID int,
	@FolderPath nvarchar(300)
AS
SELECT *
	FROM dbo.Folders
	WHERE ((PortalID = @PortalID) or (PortalID is null and @PortalID is null))
		AND (FolderPath = @FolderPath)
	ORDER BY FolderPath

GO
