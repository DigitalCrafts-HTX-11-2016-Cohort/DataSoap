

CREATE PROC dbo.p_VIP_AccountRewards_RequestSubmitted
    (
      @userName VARCHAR(100) = ''
    )
AS
    BEGIN

        BEGIN TRAN

        UPDATE  reward
        SET     reward.ModifiedOn = GETDATE() ,
                reward.ModifiedBy = @userName ,
                reward.RequestSubmitted_Flag = 1
        FROM    dbo.VIP_AccountRewards reward
                INNER JOIN dbo.VIP_AccountProductActivationCodes code ON code.VIP_AccountID = reward.VIP_AccountID
                                                              AND code.[Current] = 1
                                                              AND code.Used = 1
        WHERE   reward.RequestSubmitted_Flag = 0
                AND reward.DeletedOn IS NULL
                AND reward.RejectedOn IS NULL
                AND reward.ExportedOn IS NULL

        COMMIT

    END
GO
