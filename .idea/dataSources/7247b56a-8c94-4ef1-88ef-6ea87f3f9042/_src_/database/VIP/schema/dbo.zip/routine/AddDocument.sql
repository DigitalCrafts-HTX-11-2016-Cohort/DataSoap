
CREATE PROCEDURE dbo.AddDocument
@ModuleId         INT,
@Title            nvarchar(150),
@URL              nvarchar(250),
@UserId           INT,
@OwnedByUserId    INT,
@Category         nvarchar(50),
@SortOrderIndex   INT, 
@Description      nvarchar(255)
AS
INSERT INTO dbo.Documents (
  ModuleId,
  Title,
  URL,
  CreatedByUserID,
  CreatedDate,
  Category,
  OwnedByUserID,
  ModifiedByUserID,
  ModifiedDate,
  SortOrderIndex,
  Description
)
VALUES (
  @ModuleId,
  @Title,
  @URL,
  @UserId,
  getdate(),
  @Category,
  @OwnedByUserId,
  @UserId,
  getdate(),
  @SortOrderIndex,
  @Description
)
SELECT SCOPE_IDENTITY()
GO
