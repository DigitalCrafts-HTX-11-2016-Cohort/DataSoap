

CREATE FUNCTION [dbo].[GetAccountProductPricing]
(	
	@UtilityServiceAccountID varchar(50),
	@AccountDate varchar(10)	
)
RETURNS TABLE
AS
RETURN 
(
	SELECT ap.VIP_AccountProductID, ap.VIP_AccountID, ap.VIP_ProductID, p.UtilityProductCode, ppt.Name ProductPriceType,
		ap.FixedPrice, ap.VariableAdder, p.ServiceFeeAmount,
		CASE WHEN ppt.Name = 'Variable' THEN
			ISNULL((SELECT VariableProductIndexPrice FROM VIP_VariableProductIndexPrices WHERE VIP_VariableProductIndexID = p.CommoidtyVariableProductIndexID AND @AccountDate BETWEEN EffectiveStartDate and EffectiveEndDate) + ap.VariableAdder, 0)
		ELSE
			ISNULL(ap.FixedPrice, 0)
		END AS AdjustedPrice,
		CASE WHEN ppt.Name = 'Variable' THEN
			ISNULL((SELECT VariableProductServiceFee FROM VIP_VariableProductIndexPrices WHERE VIP_VariableProductIndexID = p.CommoidtyVariableProductIndexID AND @AccountDate BETWEEN EffectiveStartDate and EffectiveEndDate), 0)
		ELSE
			ISNULL(ap.ServiceFeeAmount, 0)
		END AS AdjustedServiceFee 
	FROM VIP_AccountProducts ap
		INNER JOIN VIP_Products p ON ap.VIP_ProductID = p.VIP_ProductID
		INNER JOIN VIP_Accounts a ON ap.VIP_AccountID = a.VIP_AccountID
		INNER JOIN VIP_ProductPricingTypes ppt ON p.VIP_ProductPricingTypeID = ppt.VIP_ProductPricingTypeID
	WHERE a.UtilityServiceAccountID = @UtilityServiceAccountID
		AND @AccountDate BETWEEN ap.StartDate and ap.EndDate
)

GO
