
CREATE TRIGGER DNN360Menu_Insert ON  dbo.Tabs 
FOR INSERT 
AS

   DECLARE @PortalID int
   

   SET @PortalID = (SELECT PortalID FROM Inserted)

Delete from dbo.MCISS_MenuUpdate where PortalID= @PortalID
Insert into dbo.MCISS_MenuUpdate (lastupdate,portalID) values (getdate(),@PortalID)


SET QUOTED_IDENTIFIER OFF
GO
