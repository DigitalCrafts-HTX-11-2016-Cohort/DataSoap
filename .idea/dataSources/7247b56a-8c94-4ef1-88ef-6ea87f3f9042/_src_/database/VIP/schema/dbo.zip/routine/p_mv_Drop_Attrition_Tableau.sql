

CREATE PROC dbo.p_mv_Drop_Attrition_Tableau
(
	@userName VARCHAR(100) = ''
)
AS

DECLARE @currentYear INT = DATEPART(YEAR, GETDATE())
DECLARE @currentMonth INT = DATEPART(MONTH, GETDATE())

IF OBJECT_ID('tempdb..#beginningOfMonth') IS NOT NULL
    DROP TABLE #beginningOfMonth
IF OBJECT_ID('tempdb..#BeginningOfMonthPivot') IS NOT NULL
    DROP TABLE #BeginningOfMonthPivot
--IF OBJECT_ID('tempdb..#endOfMonth') IS NOT NULL
--    DROP TABLE #endOfMonth
--IF OBJECT_ID('tempdb..#EndOfMonthPivot') IS NOT NULL
--    DROP TABLE #EndOfMonthPivot
IF OBJECT_ID('tempdb..#Drops') IS NOT NULL
    DROP TABLE #Drops
IF OBJECT_ID('tempdb..#DropsPivot') IS NOT NULL
    DROP TABLE #DropsPivot
	

--Beginning of Month
SELECT  * ,
        DATEPART(MONTH, CalendarDate) AS Month ,
        DATEPART(YEAR, CalendarDate) AS Year
INTO    #beginningOfMonth
FROM    Usage.mv_PipeLine_DailyCalendarization
WHERE   ((DATEPART(YEAR, CalendarDate) IN ( @currentYear, @currentYear - 1 )
        AND DATEPART(DAY, CalendarDate) = 1)
		OR CalendarDate = CONVERT(VARCHAR(4), @currentYear + 1) + '-01-01')
		AND CalendarDate <= CONVERT(VARCHAR(4), @currentYear) + '-' + CONVERT(VARCHAR(2), @currentMonth + 1) + '-01'

SELECT  bom.*, CASE WHEN bonm.VIP_AccountID IS NULL THEN 1 ELSE 0 END AS [Drop]
INTO    #Drops
FROM    #beginningOfMonth bom
        LEFT JOIN #beginningOfMonth bonm ON bom.VIP_AccountID = bonm.VIP_AccountID
                                            AND DATEADD(MONTH, 1,
                                                        bom.CalendarDate) = bonm.CalendarDate

TRUNCATE TABLE dbo.mv_Drop_Attrition_Tableau
INSERT INTO dbo.mv_Drop_Attrition_Tableau
SELECT TOP 1000
        #Drops.VIP_AccountID ,
        #Drops.CalendarDate ,
        #Drops.UtilityCode ,
        #Drops.Marketer ,
		#Drops.VIP_ProductID ,
		acv.ProductBundle ,
		pView.SalesChannelSourceType ,
		pView.SalesChannelSource_Code ,
		#Drops.PricingType ,
		CASE WHEN PricingType LIKE '%Evergreen%' OR PricingType LIKE '%Off Contract%' THEN 1
			ELSE 0
		END AS OffContract ,
		#Drops.[Drop]
FROM    #Drops
		INNER JOIN AccountServicePoint.mv_VIP_AccountCumulativeView_v2 acv ON acv.VIP_AccountID = #Drops.VIP_AccountID
		INNER JOIN ProspectPricing.mv_Prospect_GetForAccount pa ON pa.VIP_AccountID = acv.VIP_AccountID
		INNER JOIN ProspectPricing.v_ProspectCumulativeView pView ON pView.ProspectID = pa.ProspectID
WHERE CalendarDate <= GETDATE()
GROUP BY #Drops.VIP_AccountID ,
        #Drops.CalendarDate ,
        #Drops.UtilityCode ,
        #Drops.Marketer ,
		#Drops.VIP_ProductID ,
		acv.ProductBundle ,
		pView.SalesChannelSourceType ,
		pView.SalesChannelSource_Code ,
		#Drops.PricingType ,
		#Drops.[Drop]


GO
