
-- =============================================
-- Author:		Bryan Panjavan
-- Create date: 2013-01-31
-- Description:	[B2B].[SourceGas_ExternalEnrollment] Insert new record
-- =============================================
CREATE PROCEDURE [dbo].[MetaKey_GetValue]
(
	-- Add the parameters for the stored procedure here
	@metaKey VARCHAR(800)
	,@metaKeyChain VARCHAR(100) = NULL
)
AS
BEGIN
	SET TRANSACTION ISOLATION LEVEL SNAPSHOT

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	SELECT TOP 1 [Value]
	  FROM [dbo].[MetaConfig_KeyValue]
	WHERE [Key]= @metaKey
		AND
		(
			@metaKeyChain IS NULL
			OR
			(
				@metaKeyChain IS NOT NULL
				AND [dbo].[MetaConfig_KeyValue].MetaKeyChainNodeID = (SELECT MetaKeyChainNodeID FROM dbo.MetaKeyChainNode WHERE KeyName = @metaKeyChain)
			)
		)



END


GO
