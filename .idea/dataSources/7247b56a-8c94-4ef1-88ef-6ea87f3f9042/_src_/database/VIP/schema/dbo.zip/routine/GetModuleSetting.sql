
CREATE PROCEDURE dbo.[GetModuleSetting]

@ModuleId      int,
@SettingName   nvarchar(50)

AS
SELECT 
	CASE WHEN LEFT(LOWER(dbo.ModuleSettings.SettingValue), 6) = 'fileid' 
		THEN
			(SELECT Folder + FileName  
				FROM dbo.Files 
				WHERE 'fileid=' + convert(varchar,dbo.Files.FileID) = dbo.ModuleSettings.SettingValue
			) 
		ELSE 
			dbo.ModuleSettings.SettingValue  
		END 
	AS SettingValue
FROM dbo.ModuleSettings 
WHERE  ModuleId = @ModuleId AND SettingName = @SettingName


GO
