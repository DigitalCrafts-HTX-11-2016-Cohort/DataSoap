
/*
 - 2017-06-12 - LMiranda - Changing the dynamic sql into a stored proc, reviewing with Bryan
 - 2017-07-20 - BRudd - Got rid of all of the nesting.
*/
CREATE PROC dbo.p_VIP_usp_GetAccountInvoices
--parameters go here
    ( @vipAccountID INT )
AS
    BEGIN

        SET TRAN ISOLATION LEVEL SNAPSHOT

--DECLARE @vipAccountID INT = 45110

----#2
--SELECT *,
--       CONVERT(VARCHAR(5),
--               DATEDIFF(   d,
--                           InvoiceDate,
--               (
--                   SELECT TOP 1
--                       PaymentDate
--                   FROM VIP_PaymentsView
--                   WHERE VIP_BillingPointID = a.VIP_BillingPointID
--                         AND (
--                                 PaymentDate >= a.InvoiceDate
--                                 AND PaymentDate < a.NextInvoiceDate
--                             )
--                         AND Status IN ( 'Processed', 'Exported', 'Imported' )
--                   ORDER BY PaymentDate
--               )
--                       )
--              ) + ' Day(s)' DaysFromInvoiceToPayment,
--       (
--           SELECT TOP 1
--               CONVERT(VARCHAR(10), PaymentDate, 101)
--           FROM VIP_PaymentsView
--           WHERE VIP_BillingPointID = a.VIP_BillingPointID
--                 AND (
--                         PaymentDate >= a.InvoiceDate
--                         AND PaymentDate < a.NextInvoiceDate
--                     )
--                 AND Status IN ( 'Processed', 'Exported', 'Imported' )
--           ORDER BY PaymentDate
--       ) NextPaymentDate,
--       (
--           SELECT SUM(PaymentAmount)
--           FROM VIP_PaymentsView
--           WHERE VIP_BillingPointID = a.VIP_BillingPointID
--                 AND (
--                         PaymentDate >= a.InvoiceDate
--                         AND PaymentDate < a.NextInvoiceDate
--                     )
--                 AND Status IN ( 'Processed', 'Exported', 'Imported' )
--       ) PaymentAmount,
--       CASE
--           WHEN
--           (
--               SELECT COUNT(*)
--               FROM VIP_PaymentsView
--               WHERE VIP_BillingPointID = a.VIP_BillingPointID
--                     AND (
--                             PaymentDate > a.InvoiceDate
--                             AND PaymentDate < a.NextInvoiceDate
--                         )
--                     AND Status IN ( 'Processed', 'Exported', 'Imported' )
--           ) > 1 THEN
--               '*'
--           ELSE
--               ''
--       END MultiplePayments,
--       CASE
--           WHEN a.VIP_InvoiceID = a.LastInvoiceID THEN
--               'True'
--           ELSE
--               'False'
--       END ShowPayInfo,
--       (
--           SELECT SUM(InvoiceAmount)
--           FROM VIP_InvoicesView
--           WHERE VIP_BillingPointID = a.VIP_BillingPointID
--                 AND Status IN ( 'Processed', 'Exported', 'Imported' )
--                 AND InvoiceDate <= a.InvoiceDate
--       ) -
--       (
--           SELECT SUM(PaymentAmount)
--           FROM VIP_PaymentsView
--           WHERE VIP_BillingPointID = a.VIP_BillingPointID
--                 AND (PaymentDate <= a.InvoiceDate)
--                 AND Status IN ( 'Processed', 'Exported', 'Imported' )
--       ) BalanceOwed
--FROM
--(
--    SELECT *,
--           (
--               SELECT SUM(UUT_Amt)
--               FROM VIP_VIPMARKET_PGE_BillingView
--               WHERE Parent_SAID IN
--                     (
--                         SELECT UtilityServiceAccountID
--                         FROM VIP_Accounts
--                         WHERE VIP_AccountID = VIP_AccountInvoiceView.VIP_AccountID
--                     )
--                     AND Bill_Dt = VIP_AccountInvoiceView.InvoiceDate
--                     AND Status = 'Calculated'
--                     AND Energy_Amt = VIP_AccountInvoiceView.InvoiceAmount
--           ) UUT,
--           (
--               SELECT DisplayName
--               FROM Users
--               WHERE UserID = VIP_AccountInvoiceView.ReleasedBy
--           ) Userid,
--           CASE
--               WHEN YEAR(ReleaseDate) = 1900 THEN
--                   ''
--               ELSE
--                   CONVERT(VARCHAR(10), ReleaseDate, 101)
--           END ReleaseDt,
--           CASE
--               WHEN ISNULL(ReleasedBy, 0) IN ( 0 )
--                    AND Status IN ( 'Processed', 'Exported' )
--                    AND Archived_Data = '' THEN
--                   'true'
--               ELSE
--                   'false'
--           END showlink,
--           CASE
--               WHEN ISNULL(ReleasedBy, 0) NOT IN ( 0 )
--                    AND Status IN ( 'Processed', 'Exported' ) THEN
--                   'true'
--               ELSE
--                   'false'
--           END showlabel,
--           ISNULL(VIP_InvoiceNotes.Notes, '') InvoiceNotes,
--           CASE
--               WHEN VIP_InvoiceNotes.Notes IS NULL THEN
--                   'false'
--               ELSE
--                   'true'
--           END ShowNotes,
--           ISNULL(
--           (
--               SELECT TOP 1
--                   InvoiceDate
--               FROM VIP_InvoicesView
--               WHERE VIP_BillingPointID = VIP_AccountInvoiceView.VIP_BillingPointID
--                     AND InvoiceDate > VIP_AccountInvoiceView.InvoiceDate
--                     AND Status IN ( 'Exported', 'Processed' )
--               ORDER BY InvoiceDate ASC
--           ),
--           DATEADD(y, 1, GETDATE())
--                 ) NextInvoiceDate,
--           (
--               SELECT TOP 1
--                   VIP_InvoiceID
--               FROM VIP_InvoicesView
--               WHERE VIP_BillingPointID = VIP_AccountInvoiceView.VIP_BillingPointID
--                     AND InvoiceDate = VIP_AccountInvoiceView.InvoiceDate
--                     AND Status IN ( 'Exported', 'Processed' )
--               ORDER BY InvoiceDate ASC
--           ) LastInvoiceID
--    FROM VIP_AccountInvoiceView
--        LEFT OUTER JOIN VIP_InvoiceNotes
--            ON VIP_AccountInvoiceView.VIP_InvoiceID = VIP_InvoiceNotes.VIP_Invoice_ID
--    WHERE VIP_AccountID = @vipAccountID
--          AND Status NOT IN ( 'Shadow Calculated', 'Shadow Calculating', 'Voided' )
--) a
--ORDER BY InvoiceDate DESC;

;
        WITH    initialInvoices
                  AS ( SELECT   invoice.VIP_InvoiceID ,
                                bpa.VIP_AccountID ,
                                invoice.VIP_BillingPointID ,
                                bp.BillingPointName ,
                                invoice.InvoiceDate ,
                                invoice.DateDue ,
                                invoice.InvoiceAmount ,
                                invoice.Status ,
                                invoice.ReleaseDate ,
                                invoice.ReleasedBy ,
                                MAX(ii.PeriodStartDate) AS StartDate ,
                                MAX(ii.PeriodEndDate) AS EndDate ,
                                '' AS Archived_Data ,
                                NULL AS VIP_InvoiceNote_ID ,
                                NULL AS VIP_Invoice_ID ,
                                NULL AS Notes ,
                                NULL AS UUT ,
                                NULL AS UserID ,
                                '' AS ReleaseDt ,
                                CASE WHEN invoice.Status IN ( 'Exported',
                                                              'Processed' )
                                          AND ISNULL(invoice.ReleasedBy, 0) = 0
                                     THEN 'true'
                                     ELSE 'false'
                                END AS showlink ,
                                CASE WHEN invoice.Status IN ( 'Exported',
                                                              'Processed' )
                                          AND ISNULL(invoice.ReleasedBy, 0) <> 0
                                     THEN 'true'
                                     ELSE 'false'
                                END AS showlabel ,
                                '' AS InvoiceNotes ,
                                'false' AS ShowNotes ,
                                DATEADD(MONTH, 1, invoice.InvoiceDate) AS NextInvoiceDate ,
                                invoice.VIP_InvoiceID AS LastInvoiceID ,
                                DATEDIFF(DAY, invoice.InvoiceDate,
                                         MIN(payment.PaymentDate)) AS DaysFromInvoiceToPayment ,
                                MIN(payment.PaymentDate) AS NextPaymentDate ,
                                payment.PaymentAmount , --This is a quick fix until I can find something better to accurately represent payments. This will be correct as long as they have only a single payment.
                                '' AS MultiplePayments ,
                                CASE WHEN invoice.Status IN ( 'Processed',
                                                              'Exported',
                                                              'Imported' )
                                     THEN 'True'
                                     ELSE 'False'
                                END AS ShowPayInfo ,
                                NULL AS BalanceOwed
                       FROM     dbo.VIP_Invoices invoice
                                INNER JOIN dbo.VIP_BillingPointAccounts bpa ON bpa.VIP_BillingPointID = invoice.VIP_BillingPointID
                                INNER JOIN dbo.VIP_BillingPoints bp ON bp.VIP_BillingPointID = bpa.VIP_BillingPointID
                                LEFT JOIN dbo.VIP_InvoiceItems ii ON ii.VIP_InvoiceID = invoice.VIP_InvoiceID
                                             --AND ii.VIP_InvoiceItemTypeID IN (
                                             --2, 5907 )
                                LEFT JOIN dbo.VIP_Payments payment ON payment.VIP_BillingPointID = invoice.VIP_BillingPointID
                                                              AND invoice.Status IN (
                                                              'Processed',
                                                              'Exported',
                                                              'Imported' )
                                                              AND payment.PaymentDate BETWEEN invoice.InvoiceDate
                                                              AND
                                                              DATEADD(MONTH, 1,
                                                              invoice.InvoiceDate)
                       WHERE    bpa.VIP_AccountID = @vipAccountID
                                AND invoice.Status NOT IN (
                                'Shadow Calculated', 'Voided' )
                       GROUP BY DATEADD(MONTH, 1, invoice.InvoiceDate) ,
                                CASE WHEN invoice.Status IN ( 'Exported',
                                                              'Processed' )
                                          AND ISNULL(invoice.ReleasedBy, 0) = 0
                                     THEN 'true'
                                     ELSE 'false'
                                END ,
                                CASE WHEN invoice.Status IN ( 'Processed',
                                                              'Exported',
                                                              'Imported' )
                                     THEN 'True'
                                     ELSE 'False'
                                END ,
                                bpa.VIP_AccountID ,
                                invoice.ReleasedBy ,
                                invoice.ReleaseDate ,
                                invoice.InvoiceTypeCode ,
                                invoice.PrecorrectionStatus ,
                                invoice.Status ,
                                invoice.InvoiceAmount ,
                                payment.PaymentAmount ,
                                invoice.DateDue ,
                                invoice.InvoiceDate ,
                                invoice.BillingBatchGUID ,
                                invoice.VIP_BillingPointID ,
                                invoice.VIP_InvoiceID ,
                                bp.BillingPointName
                     )
            SELECT  initialInvoices.VIP_InvoiceID ,
                    initialInvoices.VIP_AccountID ,
                    initialInvoices.VIP_BillingPointID ,
                    initialInvoices.BillingPointName ,
                    initialInvoices.InvoiceDate ,
                    initialInvoices.DateDue ,
                    initialInvoices.InvoiceAmount ,
                    initialInvoices.Status ,
                    initialInvoices.ReleaseDate ,
                    initialInvoices.ReleasedBy ,
                    initialInvoices.StartDate ,
                    initialInvoices.EndDate ,
                    initialInvoices.Archived_Data ,
                    initialInvoices.VIP_InvoiceNote_ID ,
                    initialInvoices.VIP_Invoice_ID ,
                    initialInvoices.Notes ,
                    initialInvoices.UUT ,
                    initialInvoices.UserID ,
                    initialInvoices.ReleaseDt ,
                    initialInvoices.showlink ,
                    initialInvoices.showlabel ,
                    initialInvoices.InvoiceNotes ,
                    initialInvoices.ShowNotes ,
                    initialInvoices.NextInvoiceDate ,
                    initialInvoices.LastInvoiceID ,
                    initialInvoices.InvoiceDate ,
                    MIN(initialInvoices.DaysFromInvoiceToPayment) AS DaysFromInvoiceToPayment,
                    MIN(initialInvoices.NextPaymentDate) AS NextPaymentDate ,
                    SUM(initialInvoices.PaymentAmount) AS PaymentAmount,
                    CASE WHEN COUNT(*) > 1 THEN '*' ELSE '' END AS MultiplePayments ,
                    initialInvoices.ShowPayInfo ,
                    initialInvoices.BalanceOwed
            FROM    initialInvoices
            GROUP BY initialInvoices.VIP_InvoiceID ,
                    initialInvoices.VIP_AccountID ,
                    initialInvoices.VIP_BillingPointID ,
                    initialInvoices.BillingPointName ,
                    initialInvoices.InvoiceDate ,
                    initialInvoices.DateDue ,
                    initialInvoices.InvoiceAmount ,
                    initialInvoices.Status ,
                    initialInvoices.ReleaseDate ,
                    initialInvoices.ReleasedBy ,
                    initialInvoices.StartDate ,
                    initialInvoices.EndDate ,
                    initialInvoices.Archived_Data ,
                    initialInvoices.VIP_InvoiceNote_ID ,
                    initialInvoices.VIP_Invoice_ID ,
                    initialInvoices.Notes ,
                    initialInvoices.UUT ,
                    initialInvoices.UserID ,
                    initialInvoices.ReleaseDt ,
                    initialInvoices.showlink ,
                    initialInvoices.showlabel ,
                    initialInvoices.InvoiceNotes ,
                    initialInvoices.ShowNotes ,
                    initialInvoices.NextInvoiceDate ,
                    initialInvoices.LastInvoiceID ,
                    initialInvoices.InvoiceDate ,
                    initialInvoices.MultiplePayments ,
                    initialInvoices.ShowPayInfo ,
                    initialInvoices.BalanceOwed
            ORDER BY initialInvoices.InvoiceDate DESC 

    END


GO
