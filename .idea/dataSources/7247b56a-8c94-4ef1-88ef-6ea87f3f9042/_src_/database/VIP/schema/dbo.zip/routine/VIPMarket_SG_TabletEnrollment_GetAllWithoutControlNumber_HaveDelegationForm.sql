

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[VIPMarket_SG_TabletEnrollment_GetAllWithoutControlNumber_HaveDelegationForm]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT TOP 50 -- have to keep this throttled down due to SG's 20MB Email limit
		te.VIPMarket_SG_TabletEnrollmentID
		,te.DateReceived
		,te.EnrollmentSubmissionID
		,te.AccountNumber
		,te.FullName
		,te.BirthMonth
		,pr.[Service_State]
	FROM
		dbo.VIPMarket_SG_TabletEnrollment te
		INNER JOIN dbo.VIPMARKET_SG_ELG_PREMISE pr WITH (NOLOCK)
			ON te.VIPMARKET_SG_ELG_PREMISE_ID = pr.VIPMARKET_SG_ELG_PREMISE_ID
	WHERE (1 = 1)
		AND te.[Status] = 'New'
		AND te.HaveISubmittedMyDelegationForm = 1
		AND ISNULL(te.ControlNumber,'') = ''
		AND te.RepID NOT LIKE '%9999%'
		and enrollmentcreatedon >= '2013-04-05'

		AND te.AccountNumber NOT IN ('211013251864','211013416887','211013332821','221010628097','221013094993','221010802305','221011575046','211013946673','221013018586','221012442707','211014117963','211014100872','221012147285') -- Special block requested by Paul

  		-- Hold anything that comes in from WY after 12:45 PM on last day
		AND NOT
		(
			pr.Service_State = 'WY'
			AND te.EnrollmentCreatedon >= '2013-04-25 12:45:00'
		)        
      
END


GO
