
CREATE PROCEDURE dbo.GetSearchCommonWordByID
	@CommonWordID int
	
AS

SELECT
	[CommonWordID],
	[CommonWord],
	[Locale]
FROM
	dbo.SearchCommonWords
WHERE
	[CommonWordID] = @CommonWordID


GO
