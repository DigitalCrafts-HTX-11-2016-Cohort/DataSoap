
-- =============================================
-- Author:		Brandon Rudd
-- Create date: 2017-02-09
-- Description:	Add an evergreen product to an account. It will start the dat after the current final product.
-- =============================================

CREATE PROC dbo.VariableProduct_Insert
    (
      @currentFinalProductID INT --pick a product and put the product id here
      ,
      @newProductID INT ,
      @custCharge NUMERIC(18, 5)
    )
AS
    BEGIN
        IF OBJECT_ID('tempdb..#temp') IS NOT NULL
            DROP TABLE #temp

	--DECLARE @currentProductID INT = 618--pick a product and put the product id here
	--DECLARE @newProductID INT = 716
	--DECLARE @custCharge NUMERIC(18,5) = 0.00000

        SELECT  prd.VIP_ProductID ,
                uti.Code ,
                prd.ProductName ,
                acc.* ,
                cap.LastAccountProduct_EndDate
        INTO    #temp
        FROM    Products.mv_VIP_CumulativeAccountProductsView cap
                LEFT JOIN dbo.VIP_Accounts acc ON acc.VIP_AccountID = cap.VIP_AccountID
                LEFT JOIN dbo.VIP_Utilities uti ON uti.VIP_UtilityID = acc.VIP_UtilityID
                LEFT JOIN dbo.VIP_AccountClasses ac ON ac.VIP_AccountClassID = acc.VIP_AccountClassID
                LEFT JOIN dbo.VIP_AccountProducts accp ON accp.VIP_AccountProductID = cap.LastAccountProduct_VIP_AccountProductID
                LEFT JOIN dbo.VIP_Products prd ON prd.VIP_ProductID = accp.VIP_ProductID
        WHERE   ( cap.LastAccountProduct_ProductPricingType <> 'Variable'
                  OR ( cap.LastAccountProduct_ProductPricingType = 'Variable'
                       AND cap.LastAccountProduct_ProductName = '%Under%'
                     )
                )
                AND acc.AccountStatus = 'Enrolled'
                AND uti.Code NOT IN ( 'SG', 'CTRPT', 'QST', 'SDGE' )
                AND prd.VIP_ProductID = @currentFinalProductID
        ORDER BY acc.VIP_AccountID

        BEGIN TRAN

        INSERT  INTO dbo.VIP_AccountProducts
                ( VIP_AccountID ,
                  VIP_ProductID ,
                  UtilityCode ,
                  RetailerCode ,
                  FixedPrice ,
                  VariableAdder ,
                  ServiceFeeAmount ,
                  BandwidthMaxPercentage ,
                  BandwidthAdder ,
                  BandwidthUsageAmount ,
                  UsageAllocationAmount ,
                  UsageAllocationPriority ,
                  StartDate ,
                  EndDate ,
                  BrokerCommisionRate ,
                  BandwidthMinPercentage ,
                  BandwidthHighAdder ,
                  BandwidthLowAdder ,
                  BrokerCommisionRate_Intolerance ,
                  Fuel ,
                  BTUPrecision ,
                  FixedBill_Amount ,
                  UtilityApprovalStatus ,
                  Eligibility_Requirement ,
                  Eligibility_Status_DefaultIsEligible ,
                  EndDate_Explicit
                )
                SELECT  VIP_AccountID ,
                        @newProductID ,
                        Code ,
                        'VEM' ,
                        0.00000 ,
                        0.00000 ,
                        @custCharge ,
                        0.00000 ,
                        0.00000 ,
                        0.00000 ,
                        0.00000 ,
                        0 ,
                        DATEADD(DAY, 1, LastAccountProduct_EndDate) ,
                        '2024-12-31' ,
                        0.00000 ,
                        0.00000 ,
                        0.00000 ,
                        0.00000 ,
                        0.00000 ,
                        0 ,
                        NULL ,
                        0.00 ,
                        NULL ,
                        NULL ,
                        NULL ,
                        NULL
                FROM    #temp

        INSERT  INTO dbo.VIP_AccountInteractions
                ( VIP_AccountInteractionTypeID ,
                  VIP_AccountID ,
                  VIP_AccountInteractionGUID ,
                  InitiatedByUserID ,
                  Status ,
                  StartDateTime ,
                  EndDateTime ,
                  EffectiveDate_Override
                )
                SELECT  17 ,
                        VIP_AccountID ,
                        NEWID() ,
                        235 ,
                        'Complete' ,
                        GETDATE() ,
                        GETDATE() ,
                        '1900-01-01 00:00:00.000'
                FROM    #temp

        INSERT  INTO dbo.VIP_AccountNotes
                ( VIP_AccountID ,
                  CreatedByUserID ,
                  CreationDateTime ,
                  Note
                )
                SELECT  VIP_AccountID ,
                        235 ,
                        GETDATE() ,
                        'Account did not have a final product of type evergreen. Only added a new product to start the day after the current final product ended.'
                FROM    #temp

        SELECT TOP 20
                *
        FROM    dbo.VIP_AccountProducts accp
                INNER JOIN #temp ON #temp.VIP_AccountID = accp.VIP_AccountID
        ORDER BY accp.VIP_AccountID DESC ,
                accp.VIP_AccountProductID DESC 

        COMMIT
 
    END
GO
