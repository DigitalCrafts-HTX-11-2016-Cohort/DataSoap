
create procedure dbo.GetSiteLog2

@PortalID int,
@PortalAlias nvarchar(50),
@StartDate datetime,
@EndDate datetime

as

select dbo.SiteLog.DateTime,
 'Name' = 
 case
when dbo.SiteLog.UserId is null then null
else dbo.Users.FirstName + ' ' + Users.LastName
end,
 'Referrer' = 
 case 
 when dbo.SiteLog.Referrer like '%' + @PortalAlias + '%' then null 
 else dbo.SiteLog.Referrer
 end,
 'UserAgent' = 
 case 
 when dbo.SiteLog.UserAgent like '%MSIE 1%' then 'Internet Explorer 1'
 when dbo.SiteLog.UserAgent like '%MSIE 2%' then 'Internet Explorer 2'
 when dbo.SiteLog.UserAgent like '%MSIE 3%' then 'Internet Explorer 3'
 when dbo.SiteLog.UserAgent like '%MSIE 4%' then 'Internet Explorer 4'
 when dbo.SiteLog.UserAgent like '%MSIE 5%' then 'Internet Explorer 5'
 when dbo.SiteLog.UserAgent like '%MSIE 6%' then 'Internet Explorer 6'
 when dbo.SiteLog.UserAgent like '%MSIE%' then 'Internet Explorer'
 when dbo.SiteLog.UserAgent like '%Mozilla/1%' then 'Netscape Navigator 1'
 when dbo.SiteLog.UserAgent like '%Mozilla/2%' then 'Netscape Navigator 2'
 when dbo.SiteLog.UserAgent like '%Mozilla/3%' then 'Netscape Navigator 3'
 when dbo.SiteLog.UserAgent like '%Mozilla/4%' then 'Netscape Navigator 4'
 when dbo.SiteLog.UserAgent like '%Mozilla/5%' then 'Netscape Navigator 6+'
 else dbo.SiteLog.UserAgent
 end,
 dbo.SiteLog.UserHostAddress,
 dbo.Tabs.TabName
from dbo.SiteLog
left outer join dbo.Users on dbo.SiteLog.UserId = dbo.Users.UserId 
left outer join dbo.Tabs on dbo.SiteLog.TabId = dbo.Tabs.TabId 
where dbo.SiteLog.PortalId = @PortalID
and dbo.SiteLog.DateTime between @StartDate and @EndDate
order by dbo.SiteLog.DateTime desc


GO
