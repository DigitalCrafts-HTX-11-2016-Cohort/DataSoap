
-- Stored Procedure

CREATE PROCEDURE [dbo].[VIPMarket_PGE_Invoicing_MarketUsageReference]
(
	@recentOnly AS Bit = 0
	,@LocationNumber AS varchar(100) = NULL
)
AS
BEGIN
	SET TRANSACTION ISOLATION LEVEL SNAPSHOT

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	;
	WITH tblDASR_SPRate AS
	(
		SELECT
			dasr.VIPMARKET_PGE_DASRID,
			dasr.SenderCustomerID,
			dasr.SPRateName
		FROM
			 dbo.VIPMARKET_PGE_DASR dasr 
		WHERE (1 = 1)
			AND SenderID = '006912877' -- Inbound
			AND ISNULL(SPRateName,'') <> ''
	)
	,tbltblDASR_SPRate_MaxRecord AS
	(
		SELECT
			tblDASR_SPRate.*
		FROM
			tblDASR_SPRate
			INNER JOIN
			(
				SELECT
					SenderCustomerID
					,VIPMARKET_PGE_DASRID_Max = MAX(VIPMARKET_PGE_DASRID)
				FROM
					tblDASR_SPRate
				WHERE (1 = 1)      
				GROUP BY
					SenderCustomerID      
			) mx
			ON tblDASR_SPRate.SenderCustomerID = mx.SenderCustomerID
				AND tblDASR_SPRate.VIPMARKET_PGE_DASRID = mx.VIPMARKET_PGE_DASRID_Max
		WHERE (1 = 1)
	)
	SELECT  
		VIPMARKET_PGE_UsageID ,
		CustomerID,
		TransactionDate ,
		LocationNumber ,
		MeterNo ,
		StartDate ,
		EndDate ,
		Constant ,
		StartRead ,
		EndRead,
		tbltblDASR_SPRate_MaxRecord.SPRateName
	FROM    
		VIPMarket_PGE_Usage
		LEFT JOIN tbltblDASR_SPRate_MaxRecord ON VIPMarket_PGE_Usage.CustomerID = tbltblDASR_SPRate_MaxRecord.SenderCustomerID
	WHERE   
		( 1 = 1 )
		AND Purpose NOT IN ( 'HISTORY', 'OK IDR DAILY' )
		AND ISNUMERIC([Data]) = 1
		AND STATUS NOT IN('Duplicate','Loading')
		AND 
		(
			(
				@recentOnly = 1
				AND TransactionDate >= CONVERT(VARCHAR(50), DATEADD(DAY, -60,GETDATE()), 112) -- 60 days
			)
			OR
			(
				@recentOnly = 0
			)          
		)
		AND 
		(
			(
				@LocationNumber IS NOT NULL
				AND VIPMarket_PGE_Usage.LocationNumber = @LocationNumber
			)
			OR
			(
				@LocationNumber IS NULL
			)          
		)

END

GO
