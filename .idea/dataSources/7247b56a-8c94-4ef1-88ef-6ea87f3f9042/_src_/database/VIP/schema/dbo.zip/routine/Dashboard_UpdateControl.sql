
CREATE PROCEDURE dbo.Dashboard_UpdateControl  

	@DashboardControlID 				int,
	@DashboardControlKey 				nvarchar(50),
	@IsEnabled							bit,
	@DashboardControlSrc				nvarchar(250),
	@DashboardControlLocalResources 	nvarchar(250),
	@ControllerClass					nvarchar(250),
	@ViewOrder							int

AS
	UPDATE dbo.Dashboard_Controls 
		SET DashboardControlKey = @DashboardControlKey,
			IsEnabled = @IsEnabled,
			DashboardControlSrc = @DashboardControlSrc,
			DashboardControlLocalResources = @DashboardControlLocalResources,
			ControllerClass = @ControllerClass,
			ViewOrder = @ViewOrder
	WHERE DashboardControlID = @DashboardControlID

GO
