

/*
	2015-09-24 - BPanjavan - Created because the Fixed Bill Type B process kept locking.  I need to update the total and status at the same time
*/
CREATE PROCEDURE [dbo].[usp_VIP_Billing_UpdateInvoiceTotal_AndStatus]
	@VIP_InvoiceID INT
    ,@InvoiceStatus VARCHAR(50)
AS

	UPDATE VIP_Invoices
	SET 
		InvoiceAmount = (SELECT SUM(Total) FROM VIP_InvoiceItems WHERE VIP_InvoiceID = @VIP_InvoiceID)
		,Status = @InvoiceStatus
	WHERE VIP_InvoiceID = @VIP_InvoiceID
GO
