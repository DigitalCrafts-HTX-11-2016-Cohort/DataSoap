

create procedure dbo.DeleteTab

@TabId int

as

delete
from dbo.Tabs
where  TabId = @TabId


GO
