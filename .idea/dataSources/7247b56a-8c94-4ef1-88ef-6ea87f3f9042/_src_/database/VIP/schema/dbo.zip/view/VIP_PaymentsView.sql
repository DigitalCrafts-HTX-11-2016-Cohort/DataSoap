CREATE VIEW dbo.VIP_PaymentsView
AS
SELECT     *, '' Archived
FROM         dbo.VIP_Payments
UNION
SELECT     *, 'Archived' Archived, 'NULL' AS NetAmount
FROM         VIP_Archive..VIP_Payments


GO
