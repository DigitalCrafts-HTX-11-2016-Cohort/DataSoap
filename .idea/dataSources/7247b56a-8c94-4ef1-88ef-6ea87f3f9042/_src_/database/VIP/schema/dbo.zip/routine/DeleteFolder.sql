
create procedure dbo.DeleteFolder
	@PortalID int,
	@FolderPath varchar(300)
AS
	DELETE FROM dbo.Folders
	WHERE ((PortalID = @PortalID) or (PortalID is null and @PortalID is null))
	AND FolderPath = @FolderPath


GO
