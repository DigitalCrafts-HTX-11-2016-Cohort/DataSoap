

create procedure dbo.DeleteBanner

@BannerId int

as

delete
from dbo.Banners
where  BannerId = @BannerId


GO
