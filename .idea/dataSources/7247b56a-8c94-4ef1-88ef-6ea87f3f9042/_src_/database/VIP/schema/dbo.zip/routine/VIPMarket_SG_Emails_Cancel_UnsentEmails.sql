-- Cancel non-sent
CREATE PROCEDURE VIPMarket_SG_Emails_Cancel_UnsentEmails AS
BEGIN
	DECLARE @toReturn INT
	SET @toReturn = (SELECT COUNT(1) FROM dbo.[VIPMarket_SG_Email]  WHERE EmailSent_DateTime IS NULL AND [Status] <> 'CANCELLED')

	UPDATE  dbo.[VIPMarket_SG_Email] 
	SET [Status] = 'CANCELLED'
	WHERE EmailSent_DateTime IS NULL AND [Status] <> 'CANCELLED'

	SELECT NumberOfRecords = @toReturn
END

GO
