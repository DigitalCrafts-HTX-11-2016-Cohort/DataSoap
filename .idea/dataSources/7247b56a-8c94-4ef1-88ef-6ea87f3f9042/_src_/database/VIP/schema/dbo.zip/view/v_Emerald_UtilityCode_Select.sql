
CREATE VIEW dbo.v_Emerald_UtilityCode_Select
AS
SELECT 
	[Text] = '--NONE--'
	,[Value] = ''
WHERE (1 = 1)
UNION ALL 
SELECT 
	[Text] = util.Code + ' - ' + util.Name
	,[Value] = util.Code
FROM 
	dbo.VIP_Utilities util
WHERE (1 = 1)
GO
