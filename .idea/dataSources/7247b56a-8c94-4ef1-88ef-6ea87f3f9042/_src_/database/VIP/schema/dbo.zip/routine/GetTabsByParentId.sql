
CREATE PROCEDURE dbo.[GetTabsByParentId]

@ParentId int

AS
SELECT *
FROM   dbo.vw_Tabs
WHERE  ParentId = @ParentId
ORDER BY TabOrder

GO
