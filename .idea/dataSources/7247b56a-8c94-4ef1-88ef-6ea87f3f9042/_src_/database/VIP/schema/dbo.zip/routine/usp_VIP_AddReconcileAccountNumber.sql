-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_VIP_AddReconcileAccountNumber]	
	@VIP_Accountid int
AS

insert into VIP_Accounts_Reconciliation
(
VIP_Accountid, 
UtilityServiceAccountid, 
UtilityAccountNumber, 
CompanyName, 
ServiceFirstName, 
ServiceLastName, 
ServiceAddress1, 
ServiceAddress2, 
ServiceCity, 
ServiceState, 
ServiceCounty, 
ServiceZipCode, 
ServicePhone, 
ServiceEmail, 
BillingFirstName, 
BillingLastName, 
BillingAddress1, 
BillingAddress2, 
BillingCity, 
BillingState, 
BillingZipCode, 
BillingCounty, 
BillingPhone, 
BillingEmail, 
RetailerAccountNumber,
SSN,
DOB,
ReconcileDate
)
Select 
VIP_Accountid, 
UtilityServiceAccountid, 
UtilityAccountNumber, 
CompanyName, 
ServiceFirstName, 
ServiceLastName, 
ServiceAddress1, 
ServiceAddress2, 
ServiceCity, 
ServiceState, 
ServiceCounty, 
ServiceZipCode, 
ServicePhone, 
ServiceEmail, 
BillingFirstName, 
BillingLastName, 
BillingAddress1, 
BillingAddress2, 
BillingCity, 
BillingState, 
BillingZipCode, 
BillingCounty, 
BillingPhone, 
BillingEmail, 
RetailerAccountNumber,
SSN,
DOB,
GETDATE()
 from dbo.VIP_Accounts
 where vip_accountid = @VIP_Accountid

GO
