

CREATE VIEW [dbo].[VIPMARKET_CGK_DAT_FILE_UserInterfaceView]

AS

SELECT  
	[Export Date] = df.ExportDate
	,[File Name] = df.FileName
	,df.NumberOfRecords
	,[Created By] = CreatedByUserName
	,[Modified By] = ModifiedByUserName
	,VIPMARKET_CGK_DAT_FILEID
FROM
	[dbo].[VIPMARKET_CGK_DAT_FILE_View] df

GO
