
CREATE procedure dbo.UpdateModuleDefinition

	@ModuleDefId int,    
	@FriendlyName    nvarchar(128),
	@DefaultCacheTime int

as

update dbo.ModuleDefinitions 
	SET FriendlyName = @FriendlyName,
		DefaultCacheTime = @DefaultCacheTime
	WHERE ModuleDefId = @ModuleDefId


GO
