
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

--	2014-02-05 - BPanjavan - UNION -> UNION ALL, commented out first query

-- =============================================
CREATE PROCEDURE [dbo].[usp_VIP_ShowUnprocessedUsage]
AS

Select * from
(
	---- Usages with no invoice .. Not sure why we're returning these, they could overlap with the process - 2014-02-05 -- BPanjavan
 --   SELECT  bpa.VIP_BillingPointID ,
 --           vip_usageid ,
 --           UtilityAccountnumber ,
 --           UtilityserviceAccountID ,
 --           CONVERT(VARCHAR(10), u.StartDate, 101) StartDate ,
 --           CONVERT(VARCHAR(10), u.endDate, 101) EndDate ,
 --           ( SELECT    meternumber
 --             FROM      vip_meters
 --             WHERE     vip_meterid = u.vip_meterid
 --           ) MeterNumber ,
 --           u.Notes ,
 --           CASE WHEN u.status = 'Review' THEN 'Reset'
 --                ELSE ''
 --           END linkmessage ,
 --           util.code Utility
 --   FROM    VIP_Usage u
 --           INNER JOIN VIP_UsageTypes ut ON u.VIP_UsageTypeID = ut.VIP_UsageTypeID
 --           INNER JOIN VIP_BillingPointAccounts bpa ON u.VIP_AccountID = bpa.VIP_AccountID
 --           INNER JOIN VIP_AccountProducts ap ON bpa.VIP_AccountID = ap.VIP_AccountID
 --           INNER JOIN VIP_Products p ON ap.VIP_ProductID = p.VIP_ProductID
 --           INNER JOIN VIP_ProductBillingTypes	pbt ON p.VIP_ProductBillingTypeID = pbt.VIP_ProductBillingTypeID
 --           INNER JOIN VIP_Accounts ac ON ac.VIP_AccountID = bpa.VIP_AccountID
 --           INNER JOIN vip_utilities util ON util.vip_utilityid = ac.vip_utilityid
 --   WHERE   ut.Code IN ( 'ACTUAL', 'ESTIMATED', 'CANCELLED' )
 --           AND u.VIP_UsageID NOT IN ( SELECT   VIP_UsageID
 --                                      FROM     VIP_InvoiceItemsView
 --                                      WHERE    VIP_UsageID IS NOT NULL )
 --           AND pbt.Code IN ( 'DUAL','BILL_READY')
 --           AND ( u.Status NOT IN ( 'Review' )
 --                 OR status IS NULL
 --               )

	--UNION ALL
	
	-- Usage that have an invoice on them
    SELECT  bpa.VIP_BillingPointID ,
            vip_usageid ,
            UtilityAccountnumber ,
            UtilityserviceAccountID ,
            CONVERT(VARCHAR(10), u.StartDate, 101) StartDate ,
            CONVERT(VARCHAR(10), u.endDate, 101) EndDate ,
            m.meternumber ,
            u.Notes ,
            CASE WHEN u.status = 'Review' THEN 'Reset'
                 ELSE ''
            END linkmessage ,
            util.code Utility
    FROM    VIP_Invoices i
            INNER JOIN VIP_BillingPointAccounts bpa ON i.VIP_BillingPointID = bpa.VIP_BillingPointID
            INNER JOIN VIP_AccountProducts ap ON bpa.VIP_AccountID = ap.VIP_AccountID
            INNER JOIN VIP_Products p ON ap.VIP_ProductID = p.VIP_ProductID
            INNER JOIN VIP_ProductBillingTypes pbt ON p.VIP_ProductBillingTypeID = pbt.VIP_ProductBillingTypeID
            INNER JOIN VIP_Accounts ac ON ac.VIP_AccountID = bpa.VIP_AccountID
            INNER JOIN vip_utilities util ON util.vip_utilityid = ac.vip_utilityid
            INNER JOIN VIP_Usage u ON u.VIP_AccountID = ac.VIP_AccountID
            INNER JOIN VIP_UsageTypes ut ON u.VIP_UsageTypeID = ut.VIP_UsageTypeID
            INNER JOIN VIP_Meters m ON m.VIP_AccountID = ac.VIP_AccountID
    WHERE   u.Status = 'Review'
            AND pbt.Code IN ( 'DUAL','BILL_READY')
    GROUP BY bpa.VIP_BillingPointID ,
            vip_usageid ,
            UtilityAccountnumber ,
            UtilityserviceAccountID ,
            u.StartDate ,
            u.endDate ,
            m.meternumber ,
            u.Notes ,
            u.status ,
            util.code

	--union
	--Select bpa.VIP_BillingPointID, vip_usageid, UtilityAccountnumber, UtilityserviceAccountID,  
	--convert(varchar(10),u.StartDate,101) StartDate, convert(varchar(10),u.endDate, 101) EndDate,
	--(Select meternumber from vip_meters where vip_meterid = u.vip_meterid) MeterNumber,
	--u.Notes, case when u.status = 'Review' then 'Reset' else '' end linkmessage
	--,util.code Utility
	--FROM VIP_Usage u
	--	INNER JOIN VIP_UsageTypes ut ON u.VIP_UsageTypeID = ut.VIP_UsageTypeID
	--	INNER JOIN VIP_BillingPointAccounts bpa ON u.VIP_AccountID = bpa.VIP_AccountID
	--	INNER JOIN VIP_AccountProducts ap ON bpa.VIP_AccountID = ap.VIP_AccountID
	--	INNER JOIN VIP_Products p ON ap.VIP_ProductID = p.VIP_ProductID
	--	INNER JOIN VIP_ProductBillingTypes pbt ON p.VIP_ProductBillingTypeID = pbt.VIP_ProductBillingTypeID
	--	INNER JOIN VIP_Accounts ac ON ac.VIP_AccountID = bpa.VIP_AccountID
	--	INNER JOIN vip_utilities util on util.vip_utilityid = ac.vip_utilityid
	--WHERE ut.Code IN ('ACTUAL', 'ESTIMATED', 'CANCELLED')
	--	AND u.VIP_UsageID NOT IN (SELECT VIP_UsageID FROM VIP_InvoiceItems WHERE VIP_UsageID IS NOT NULL)
	--	AND pbt.Code = 'RATE_READY'
	--	AND (u.Status not in('Review') or status is null)
	--	and ac.CoreCustomer = 0
) a
order by a.linkmessage desc
GO
