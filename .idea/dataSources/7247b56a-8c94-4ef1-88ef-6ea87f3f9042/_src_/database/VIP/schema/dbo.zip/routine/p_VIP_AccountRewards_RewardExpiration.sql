

CREATE PROC dbo.p_VIP_AccountRewards_RewardExpiration
    (
      @userName VARCHAR(100) = ''
    )
AS
    BEGIN

        DECLARE @ExpirationDays DECIMAL = 45
        BEGIN TRAN;
			UPDATE	rewards
			SET		rewards.RejectedOn = GETDATE()
					, rewards.Notes = 'This reward was not claimed before expiration.'
            FROM    dbo.VIP_AccountRewards rewards
            WHERE   DATEDIFF(DAY, rewards.Reward_Date, GETDATE()) > @ExpirationDays
                    AND RejectedOn IS NULL
                    AND DeletedOn IS NULL
                    AND ExportedOn IS NULL

        COMMIT

    END
GO
