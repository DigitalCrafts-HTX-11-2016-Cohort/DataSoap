CREATE PROCEDURE GetFilteredData()
  BEGIN
  DECLARE bDone INT;DECLARE lowerVar bigint;DECLARE upperVar bigint;DECLARE curs CURSOR FOR  SELECT lowerBound, upperBound FROM cte_bounds;DECLARE CONTINUE HANDLER FOR NOT FOUND SET bDone = 1;OPEN curs;SET bDone = 0;REPEAT
    FETCH curs INTO lowerVar, upperVar;CALL insertBetween(lowerVar, upperVar);UNTIL bDone END REPEAT;CLOSE curs;END;
