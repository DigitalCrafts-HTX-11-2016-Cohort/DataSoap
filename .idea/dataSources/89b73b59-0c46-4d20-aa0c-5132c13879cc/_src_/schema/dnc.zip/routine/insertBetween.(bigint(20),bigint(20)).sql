CREATE PROCEDURE insertBetween(IN var1 BIGINT, IN var2 BIGINT)
  BEGIN
    DECLARE v1 bigint;
    SET v1 = var1;
    WHILE v1 <= var2 DO
    	insert into notReallyWireless (PhoneNumber) values (v1);
    	set v1 = v1 + 1;
    END WHILE;
END;
