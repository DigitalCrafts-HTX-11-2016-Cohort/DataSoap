CREATE PROCEDURE deleteOneByOne(IN earliestChangeDate DATE)
  BEGIN
    -- DECLARE recordsToDeleteCount INT;
    DECLARE phoneToDelete BIGINT;
    REPEAT
#       select count(dnc_delta.PhoneNumber) into @recordsToDeleteCount from dnc_delta
#       inner join master_noindex on dnc_delta.PhoneNumber = master_noindex.PhoneNumber
#       where changeType = 'D' and changeDate >= earliestChangeDate and dnc = 1;
      set @phoneToDelete =
      (select dnc_delta.PhoneNumber from dnc_delta
      inner join master_noindex mni on dnc_delta.PhoneNumber = mni.PhoneNumber
      where changeType = 'D' and changeDate >= earliestChangeDate and mni.dnc = 1 limit 1);
      select @phoneToDelete As '';

      DELETE master_noindex.* from master_noindex WHERE dnc = 1 and master_noindex.PhoneNumber = @phoneToDelete;
#     UNTIL 1=1 END REPEAT;
      UNTIL @phoneToDelete IS NULL END REPEAT;
  END;
